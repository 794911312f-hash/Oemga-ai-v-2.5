# Omega AI — Architecture

## Layers

```
UI (React + Vite)  src/App.tsx · index.html
        │
Express server.ts
  middleware · security · urlGuard · sandbox · health
  workspaceRoutes · modular routes
        │
Cognitive Workspace (Phase 11)
  plan → memory/graph → tools → core → synthesize
  → agents → reflect → confidence → revise → persist
        │
Omega Core · InferenceEngine · Kernel · Ψ (psi.ts)
  fusion · spectralConsensus · evidencePsi · selfVerify
        │
Bridges: OpenHands · Browser · SymPy/Lean · Open-Sora
  Video/OVO · Avatar · Voice · DSPy · Open models
```

## Confidence Ψ

Source of truth: `src/lib/omega/psi.ts`

| Function | Use |
|----------|-----|
| `computeOmegaV2Psi` | Video / OVO path |
| `computePsiAffine` | Consensus / fusion / core |

## Security

- SSRF: `src/server/urlGuard.ts`
- Sandbox: `src/server/sandbox.ts`
- Auth: `src/server/security.ts`
- Rate limits: `src/server/middleware.ts`

## Honesty

API payloads use `sourceClass`: `real` | `mixed` | `simulated` | `failed`.

## Entrypoints

| Path | Role |
|------|------|
| `POST /api/omega/workspace/run` | Full cognitive cycle |
| `POST /api/omega/deduce` | Multi-model deduce |
| `POST /api/omega/code/execute` | Sandboxed JS |
| `GET /api/health` | Readiness |

Media bridges may return `simulated` until external runtimes are wired.
Core, Ψ, workspace, SSRF, and sandbox run in-process.
