import { getDb } from "./firebase";

export interface PersistentModelPerformanceRecord {
  modelId: string;
  domain: string;
  totalCalls: number;
  successfulCalls: number;
  avgPsi: number;
  avgLatencyMs: number;
  eloRating: number;
  lastUpdated: number;
}

const fallbackLedger = new Map<string, PersistentModelPerformanceRecord>();
let permissionNoticeShown = false;

function hasExplicitFirebaseCredentials(): boolean {
  return Boolean(process.env.FIREBASE_SERVICE_ACCOUNT || process.env.GOOGLE_APPLICATION_CREDENTIALS);
}

function keyOf(domain: string, modelId: string): string {
  return `${domain}::${modelId}`;
}

export async function loadModelPerformanceRecords(): Promise<PersistentModelPerformanceRecord[]> {
  if (!hasExplicitFirebaseCredentials()) return [...fallbackLedger.values()];
  const database = getDb();
  if (!database) return [...fallbackLedger.values()];
  try {
    const snapshot = await database.collection("omega_model_performance").limit(500).get();
    const records = snapshot.docs.map((doc: any) => doc.data() as PersistentModelPerformanceRecord);
    records.forEach(record => fallbackLedger.set(keyOf(record.domain, record.modelId), record));
    return records;
  } catch (error: any) {
    if (!permissionNoticeShown) {
      permissionNoticeShown = true;
      console.warn("[Omega Model Ledger] Falling back to local performance records:", error?.message || error);
    }
    return [...fallbackLedger.values()];
  }
}

export async function saveModelPerformanceRecord(
  record: PersistentModelPerformanceRecord,
): Promise<void> {
  fallbackLedger.set(keyOf(record.domain, record.modelId), { ...record });
  if (!hasExplicitFirebaseCredentials()) return;
  const database = getDb();
  if (!database) return;
  try {
    await database
      .collection("omega_model_performance")
      .doc(keyOf(record.domain, record.modelId).replace(/[^a-zA-Z0-9_-]/g, "_"))
      .set(record, { merge: true });
  } catch (error: any) {
    if (!permissionNoticeShown) {
      permissionNoticeShown = true;
      console.warn("[Omega Model Ledger] Persistence unavailable; local record retained:", error?.message || error);
    }
  }
}
