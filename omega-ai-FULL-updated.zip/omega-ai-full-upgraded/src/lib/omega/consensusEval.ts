/**
 * src/lib/omega/consensusEval.ts
 * =============================================================================
 * Measurement package for multi-answer consensus methods.
 *
 * Reference methods (baselines):
 *   - majority vote (string / embedding-cluster)
 *   - self-consistency (cluster then majority)
 *   - logprob-weighted (when logprobs available; falls back to uniform)
 *   - best-of-n (highest weight / logprob)
 *   - LLM-as-judge (pluggable; offline uses heuristic)
 *
 * Competing uncertainty / agreement metrics:
 *   - Spectral cohesion / gap (from spectralConsensus.ts)
 *   - Semantic entropy (cluster-based)
 *   - Jensen–Shannon divergence from the centroid distribution
 *
 * Goal: measure which signals actually predict answer correctness
 * (AUROC / correlation vs gold), not just internal agreement.
 */

import { hashEmbed } from "./embeddings";
import { computeSpectralConsensus, type SpectralConsensusResult } from "./spectralConsensus";
import { cosine, normalize } from "./math";
import {
  candidateEnergies,
  boltzmannSelect,
  computeFreeEnergy,
  normalisedMutualInformation,
  correctnessLabels,
  type FreeEnergyBreakdown,
} from "./infoPhysics";

// ───────────────────────── Types ─────────────────────────

export interface GoldExpect {
  type: string;
  values: string[];
}

export interface CandidateAnswer {
  modelId: string;
  text: string;
  /** Optional token log-probabilities (sum or mean). Higher = more confident. */
  logprob?: number;
  /** Optional precomputed embedding. If missing, hashEmbed is used. */
  embedding?: number[];
}

export interface EvalItem {
  id: string;
  category: string;
  question: string;
  expect: GoldExpect;
  /** Multiple candidate answers (from different models or samples). */
  candidates: CandidateAnswer[];
}

export type AggregatorName =
  | "majority"
  | "self_consistency"
  | "logprob_weighted"
  | "best_of_n"
  | "spectral_weighted"
  | "centroid_nearest"
  | "boltzmann";

export interface AggregatorResult {
  name: AggregatorName;
  chosenIndex: number;
  chosenText: string;
  correct: boolean;
  /** Soft confidence in [0,1] when available. */
  confidence: number;
}

export interface AgreementMetrics {
  spectral: {
    cohesion: number;
    spectralGap: number;
    k: number;
    components: number;
    perronRoot: number;
    outlierCount: number;
  };
  semanticEntropy: number;
  jsdToCentroid: number;
  meanPairwiseCosine: number;
  /** Normalised MI between spectral clusters and correctness (0 if no variance). */
  nmiClusterCorrect: number;
  /** Free-energy breakdown at default T=1. */
  freeEnergy: FreeEnergyBreakdown;
  n: number;
}

export interface ItemEvalResult {
  id: string;
  category: string;
  agreement: AgreementMetrics;
  aggregators: AggregatorResult[];
  /** Gold correctness of each candidate (for AUROC later). */
  candidateCorrect: boolean[];
}

// ───────────────────────── Scoring ─────────────────────────

export function scoreContainsAny(text: string, values: string[]): boolean {
  const lower = text.toLowerCase();
  return values.some((v) => lower.includes(String(v).toLowerCase()));
}

export function isCorrect(text: string, expect: GoldExpect): boolean {
  if (expect.type === "contains_any" || expect.type === "contains") {
    return scoreContainsAny(text, expect.values);
  }
  // Fallback: any value appears
  return scoreContainsAny(text, expect.values);
}

// ───────────────────────── Embeddings helper ─────────────────────────

function ensureEmbeddings(candidates: CandidateAnswer[], dim = 64): number[][] {
  return candidates.map((c) => {
    if (c.embedding && c.embedding.length > 0) return normalize(c.embedding.slice());
    return hashEmbed(c.text, dim);
  });
}

// ───────────────────────── Reference aggregators ─────────────────────────

/** Exact-string majority; ties broken by first occurrence. */
export function majorityVote(candidates: CandidateAnswer[]): { index: number; confidence: number } {
  const counts = new Map<string, { count: number; first: number }>();
  candidates.forEach((c, i) => {
    const key = c.text.trim().toLowerCase();
    const prev = counts.get(key);
    if (prev) prev.count += 1;
    else counts.set(key, { count: 1, first: i });
  });
  let bestKey = "";
  let bestCount = -1;
  let bestFirst = 0;
  for (const [k, v] of counts) {
    if (v.count > bestCount || (v.count === bestCount && v.first < bestFirst)) {
      bestKey = k;
      bestCount = v.count;
      bestFirst = v.first;
    }
  }
  return {
    index: bestFirst,
    confidence: candidates.length ? bestCount / candidates.length : 0,
  };
}

/**
 * Self-consistency: cluster by cosine similarity (threshold), then majority of clusters.
 * Deterministic farthest-first + threshold clustering (no external deps).
 */
export function selfConsistency(
  candidates: CandidateAnswer[],
  simThreshold = 0.75
): { index: number; confidence: number } {
  const vecs = ensureEmbeddings(candidates);
  const n = vecs.length;
  if (n === 0) return { index: 0, confidence: 0 };
  if (n === 1) return { index: 0, confidence: 1 };

  // Greedy clustering: assign to first center with sim >= threshold, else new cluster
  const centers: number[] = [0];
  const labels = new Array(n).fill(-1);
  labels[0] = 0;
  for (let i = 1; i < n; i++) {
    let assigned = -1;
    for (let c = 0; c < centers.length; c++) {
      if (cosine(vecs[i], vecs[centers[c]]) >= simThreshold) {
        assigned = c;
        break;
      }
    }
    if (assigned < 0) {
      assigned = centers.length;
      centers.push(i);
    }
    labels[i] = assigned;
  }

  // Majority cluster
  const clusterSize = new Array(centers.length).fill(0);
  labels.forEach((l) => (clusterSize[l] += 1));
  let maj = 0;
  for (let c = 1; c < clusterSize.length; c++) if (clusterSize[c] > clusterSize[maj]) maj = c;

  // Representative = member of majority cluster closest to its centroid
  const members = labels.map((l, i) => (l === maj ? i : -1)).filter((i) => i >= 0);
  const dim = vecs[0].length;
  const cent = new Array(dim).fill(0);
  for (const i of members) for (let d = 0; d < dim; d++) cent[d] += vecs[i][d] / members.length;
  let best = members[0];
  let bestSim = -Infinity;
  for (const i of members) {
    const s = cosine(vecs[i], cent);
    if (s > bestSim) {
      bestSim = s;
      best = i;
    }
  }
  return {
    index: best,
    confidence: members.length / n,
  };
}

/** Weight by exp(logprob); uniform if no logprobs. */
export function logprobWeighted(candidates: CandidateAnswer[]): { index: number; confidence: number } {
  const has = candidates.some((c) => typeof c.logprob === "number" && Number.isFinite(c.logprob!));
  if (!has) {
    // uniform → first
    return { index: 0, confidence: 1 / Math.max(1, candidates.length) };
  }
  const maxLp = Math.max(...candidates.map((c) => c.logprob ?? -Infinity));
  const weights = candidates.map((c) => Math.exp((c.logprob ?? -Infinity) - maxLp));
  const sum = weights.reduce((a, b) => a + b, 0) || 1;
  const norm = weights.map((w) => w / sum);
  let best = 0;
  for (let i = 1; i < norm.length; i++) if (norm[i] > norm[best]) best = i;
  return { index: best, confidence: norm[best] };
}

/** Best-of-n: highest logprob, else highest spectral Perron weight. */
export function bestOfN(
  candidates: CandidateAnswer[],
  spectral?: SpectralConsensusResult
): { index: number; confidence: number } {
  const hasLp = candidates.some((c) => typeof c.logprob === "number" && Number.isFinite(c.logprob!));
  if (hasLp) {
    let best = 0;
    for (let i = 1; i < candidates.length; i++) {
      if ((candidates[i].logprob ?? -Infinity) > (candidates[best].logprob ?? -Infinity)) best = i;
    }
    return { index: best, confidence: 1 };
  }
  if (spectral && spectral.weights.length === candidates.length) {
    let best = 0;
    for (let i = 1; i < spectral.weights.length; i++) {
      if (spectral.weights[i] > spectral.weights[best]) best = i;
    }
    return { index: best, confidence: spectral.weights[best] };
  }
  return { index: 0, confidence: 1 / Math.max(1, candidates.length) };
}

/** Pick answer with highest spectral Perron weight. */
export function spectralWeighted(
  candidates: CandidateAnswer[],
  spectral: SpectralConsensusResult
): { index: number; confidence: number } {
  let best = spectral.consensusIndex >= 0 ? spectral.consensusIndex : 0;
  return { index: best, confidence: spectral.weights[best] ?? 0 };
}

/** Nearest to embedding centroid. */
export function centroidNearest(candidates: CandidateAnswer[]): { index: number; confidence: number } {
  const vecs = ensureEmbeddings(candidates);
  const n = vecs.length;
  if (n === 0) return { index: 0, confidence: 0 };
  const dim = vecs[0].length;
  const c = new Array(dim).fill(0);
  for (const v of vecs) for (let d = 0; d < dim; d++) c[d] += v[d] / n;
  let best = 0;
  let bestSim = -Infinity;
  const sims: number[] = [];
  for (let i = 0; i < n; i++) {
    const s = cosine(vecs[i], c);
    sims.push(s);
    if (s > bestSim) {
      bestSim = s;
      best = i;
    }
  }
  // soft confidence: margin over second best
  const sorted = sims.slice().sort((a, b) => b - a);
  const margin = sorted.length > 1 ? Math.max(0, sorted[0] - sorted[1]) : 1;
  return { index: best, confidence: Math.min(1, 0.5 + margin) };
}

// ───────────────────────── Competing metrics ─────────────────────────

/**
 * Cluster-based semantic entropy (nats).
 * Soft assignment via temperature-scaled cosine similarities to cluster centers
 * obtained from spectral labels when available, else single cluster → entropy 0.
 */
export function semanticEntropy(
  vectors: number[][],
  labels?: number[],
  temperature = 0.2
): number {
  const n = vectors.length;
  if (n <= 1) return 0;
  const k = labels ? new Set(labels).size : 1;
  if (k <= 1) return 0;

  // Cluster centroids
  const dim = vectors[0].length;
  const centers: number[][] = Array.from({ length: k }, () => new Array(dim).fill(0));
  const counts = new Array(k).fill(0);
  for (let i = 0; i < n; i++) {
    const l = labels![i];
    counts[l] += 1;
    for (let d = 0; d < dim; d++) centers[l][d] += vectors[i][d];
  }
  for (let c = 0; c < k; c++) {
    if (counts[c] === 0) continue;
    for (let d = 0; d < dim; d++) centers[c][d] /= counts[c];
  }

  // Soft assignment entropy averaged
  let totalH = 0;
  for (let i = 0; i < n; i++) {
    const logits = centers.map((c) => cosine(vectors[i], c) / temperature);
    const maxL = Math.max(...logits);
    const exps = logits.map((l) => Math.exp(l - maxL));
    const Z = exps.reduce((a, b) => a + b, 0) || 1;
    const probs = exps.map((e) => e / Z);
    let h = 0;
    for (const p of probs) if (p > 1e-12) h -= p * Math.log(p);
    totalH += h;
  }
  return totalH / n;
}

/** Symmetric KL (Jensen–Shannon) between each answer's softmax-of-dims and the centroid's. Mean JSD. */
export function meanJensenShannon(vectors: number[][]): number {
  const n = vectors.length;
  if (n <= 1) return 0;
  const dim = vectors[0].length;

  const toProb = (v: number[]): number[] => {
    // shift to positive then L1-normalise
    const m = Math.min(...v);
    const shifted = v.map((x) => x - m + 1e-8);
    const s = shifted.reduce((a, b) => a + b, 0) || 1;
    return shifted.map((x) => x / s);
  };

  const probs = vectors.map(toProb);
  const centroidP = new Array(dim).fill(0);
  for (const p of probs) for (let d = 0; d < dim; d++) centroidP[d] += p[d] / n;

  const kl = (p: number[], q: number[]) => {
    let s = 0;
    for (let i = 0; i < p.length; i++) {
      if (p[i] > 1e-12) s += p[i] * Math.log(p[i] / Math.max(q[i], 1e-12));
    }
    return s;
  };

  let total = 0;
  for (const p of probs) {
    const m = p.map((x, i) => 0.5 * (x + centroidP[i]));
    total += 0.5 * kl(p, m) + 0.5 * kl(centroidP, m);
  }
  return total / n;
}

export function meanPairwiseCosine(vectors: number[][]): number {
  const n = vectors.length;
  if (n <= 1) return 1;
  let s = 0;
  let c = 0;
  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      s += cosine(vectors[i], vectors[j]);
      c += 1;
    }
  }
  return c ? s / c : 1;
}

// ───────────────────────── Full item evaluation ─────────────────────────

export function evaluateItem(
  item: EvalItem,
  spectralOpts?: Parameters<typeof computeSpectralConsensus>[1],
  boltzmannTemperature = 1
): ItemEvalResult {
  const { candidates, expect } = item;
  const vecs = ensureEmbeddings(candidates);
  const spectral = computeSpectralConsensus(vecs, spectralOpts);
  const candidateCorrect = candidates.map((c) => isCorrect(c.text, expect));
  const semH = semanticEntropy(vecs, spectral.labels);

  const energies = candidateEnergies(
    candidates.map((c) => c.logprob),
    spectral.weights
  );
  const fe = computeFreeEnergy(energies, semH, boltzmannTemperature, spectral.cohesion);

  const agreement: AgreementMetrics = {
    spectral: {
      cohesion: spectral.cohesion,
      spectralGap: spectral.spectralGap,
      k: spectral.k,
      components: spectral.components,
      perronRoot: spectral.perronRoot,
      outlierCount: spectral.outliers.length,
    },
    semanticEntropy: semH,
    jsdToCentroid: meanJensenShannon(vecs),
    meanPairwiseCosine: meanPairwiseCosine(vecs),
    nmiClusterCorrect: normalisedMutualInformation(
      spectral.labels,
      correctnessLabels(candidateCorrect)
    ),
    freeEnergy: fe,
    n: candidates.length,
  };

  const run = (
    name: AggregatorName,
    fn: () => { index: number; confidence: number }
  ): AggregatorResult => {
    const { index, confidence } = fn();
    const text = candidates[index]?.text ?? "";
    return {
      name,
      chosenIndex: index,
      chosenText: text,
      correct: isCorrect(text, expect),
      confidence,
    };
  };

  const aggregators: AggregatorResult[] = [
    run("majority", () => majorityVote(candidates)),
    run("self_consistency", () => selfConsistency(candidates)),
    run("logprob_weighted", () => logprobWeighted(candidates)),
    run("best_of_n", () => bestOfN(candidates, spectral)),
    run("spectral_weighted", () => spectralWeighted(candidates, spectral)),
    run("centroid_nearest", () => centroidNearest(candidates)),
    run("boltzmann", () => {
      const { index, confidence } = boltzmannSelect(energies, boltzmannTemperature);
      return { index, confidence };
    }),
  ];

  return {
    id: item.id,
    category: item.category,
    agreement,
    aggregators,
    candidateCorrect,
  };
}

// ───────────────────────── Aggregate statistics ─────────────────────────

export interface MethodSummary {
  name: AggregatorName;
  accuracy: number;
  /** Number of items evaluated. */
  n: number;
  /** Number of items answered correctly. */
  nCorrect: number;
  meanConfidence: number;
  /** Binomial standard error √(p(1−p)/n). */
  se: number;
  /** Wilson score 95% CI for accuracy. */
  ci95: { low: number; high: number };
}

export interface MetricPredictivePower {
  metric: string;
  /** Pearson correlation between metric and "any candidate correct" or chosen correctness. */
  pearsonAnyCorrect: number;
  pearsonChosenCorrect: number;
  /** AUROC treating metric as score for "item has at least one correct candidate". */
  aurocAnyCorrect: number;
}

/** Paired comparison of two aggregators on the same items (McNemar). */
export interface PairedComparison {
  methodA: AggregatorName;
  methodB: AggregatorName;
  /** A correct, B wrong. */
  n10: number;
  /** A wrong, B correct. */
  n01: number;
  /** Both correct or both wrong (ties). */
  nTie: number;
  /** Continuity-corrected McNemar χ² (df=1). */
  chi2: number;
  /** Two-sided p-value from χ²(1) approximation; null when discordant pairs < 5. */
  pValue: number | null;
  /** Sign of accuracy(A) − accuracy(B). */
  accuracyDelta: number;
}

export interface EvalReport {
  nItems: number;
  methods: MethodSummary[];
  predictive: MetricPredictivePower[];
  /** Pairwise McNemar tests vs majority (and vs logprob_weighted when present). */
  pairedTests: PairedComparison[];
  byCategory: Record<string, { n: number; methods: MethodSummary[] }>;
  spectralParamSensitivity?: Array<{
    sigma: number | "median";
    minGap: number;
    meanCohesion: number;
    spectralAccuracy: number;
  }>;
}

/** Binomial SE of a proportion. */
export function binomialSE(p: number, n: number): number {
  if (n <= 0) return 0;
  const pp = Math.max(0, Math.min(1, p));
  return Math.sqrt((pp * (1 - pp)) / n);
}

/** Wilson score interval (95%, z=1.96) for a binomial proportion. */
export function wilsonCI(k: number, n: number, z = 1.96): { low: number; high: number } {
  if (n <= 0) return { low: 0, high: 1 };
  const p = k / n;
  const z2 = z * z;
  const den = 1 + z2 / n;
  const centre = p + z2 / (2 * n);
  const margin = z * Math.sqrt((p * (1 - p)) / n + z2 / (4 * n * n));
  return {
    low: Math.max(0, (centre - margin) / den),
    high: Math.min(1, (centre + margin) / den),
  };
}

/**
 * McNemar test with continuity correction on paired binary outcomes.
 * Returns χ² and approximate two-sided p-value; pValue is null if n10+n01 < 5.
 */
export function mcnemar(correctA: boolean[], correctB: boolean[]): PairedComparison & { methodA: AggregatorName; methodB: AggregatorName } {
  let n10 = 0;
  let n01 = 0;
  let nTie = 0;
  const n = Math.min(correctA.length, correctB.length);
  for (let i = 0; i < n; i++) {
    if (correctA[i] && !correctB[i]) n10 += 1;
    else if (!correctA[i] && correctB[i]) n01 += 1;
    else nTie += 1;
  }
  const disc = n10 + n01;
  let chi2 = 0;
  let pValue: number | null = null;
  if (disc >= 5) {
    chi2 = (Math.abs(n10 - n01) - 1) ** 2 / disc;
    // χ²(1) survival: erfc(√(χ²/2)) ≈ 2 * (1-Φ(√χ²))
    const x = Math.sqrt(chi2);
    // Abramowitz-style approximation for erfc via normal tail
    pValue = approxChi2p1(chi2);
  }
  const accA = correctA.filter(Boolean).length / (n || 1);
  const accB = correctB.filter(Boolean).length / (n || 1);
  return {
    methodA: "majority",
    methodB: "majority",
    n10,
    n01,
    nTie,
    chi2,
    pValue,
    accuracyDelta: accA - accB,
  };
}

/** Approximate P(χ²(1) > x) using erfc. */
function approxChi2p1(x: number): number {
  if (x <= 0) return 1;
  // P(χ²_1 > x) = erfc(√(x/2))
  const t = Math.sqrt(x / 2);
  return erfcApprox(t);
}

function erfcApprox(x: number): number {
  // Numerical Recipes approximation
  const z = Math.abs(x);
  const t = 1 / (1 + 0.5 * z);
  const tau =
    t *
    Math.exp(
      -z * z -
        1.26551223 +
        t *
          (1.00002368 +
            t *
              (0.37409196 +
                t *
                  (0.09678418 +
                    t *
                      (-0.18628806 +
                        t *
                          (0.27886807 +
                            t *
                              (-1.13520398 +
                                t * (1.48851587 + t * (-0.82215223 + t * 0.17087277))))))))
    );
  return x >= 0 ? tau : 2 - tau;
}

function pearson(xs: number[], ys: number[]): number {
  const n = xs.length;
  if (n < 2) return 0;
  const mx = xs.reduce((a, b) => a + b, 0) / n;
  const my = ys.reduce((a, b) => a + b, 0) / n;
  let num = 0;
  let dx = 0;
  let dy = 0;
  for (let i = 0; i < n; i++) {
    const a = xs[i] - mx;
    const b = ys[i] - my;
    num += a * b;
    dx += a * a;
    dy += b * b;
  }
  const den = Math.sqrt(dx * dy);
  return den < 1e-12 ? 0 : num / den;
}

/**
 * Mann–Whitney AUROC with mid-ranks for ties.
 * Equal scores between a positive and a negative contribute 0.5, not 0 or 1
 * depending on unstable sort order.
 */
export function auroc(scores: number[], labels: number[]): number {
  const n = scores.length;
  if (n === 0) return 0.5;
  const order = scores
    .map((s, i) => ({ s, y: labels[i] }))
    .sort((a, b) => (a.s < b.s ? -1 : a.s > b.s ? 1 : 0));

  // Mid-ranks within tied score groups (1-based ranks)
  const ranks = new Array(n).fill(0);
  let i = 0;
  while (i < n) {
    let j = i + 1;
    while (j < n && order[j].s === order[i].s) j++;
    const mid = (i + 1 + j) / 2;
    for (let k = i; k < j; k++) ranks[k] = mid;
    i = j;
  }

  let rankSumPos = 0;
  let nPos = 0;
  let nNeg = 0;
  for (let k = 0; k < n; k++) {
    if (order[k].y === 1) {
      rankSumPos += ranks[k];
      nPos += 1;
    } else nNeg += 1;
  }
  if (nPos === 0 || nNeg === 0) return 0.5;
  return (rankSumPos - (nPos * (nPos + 1)) / 2) / (nPos * nNeg);
}

export function summarize(results: ItemEvalResult[]): EvalReport {
  const methodNames: AggregatorName[] = [
    "majority",
    "self_consistency",
    "logprob_weighted",
    "best_of_n",
    "spectral_weighted",
    "centroid_nearest",
    "boltzmann",
  ];

  const methods: MethodSummary[] = methodNames.map((name) => {
    const rows = results.map((r) => r.aggregators.find((a) => a.name === name)!);
    const n = rows.length || 1;
    const nCorrect = rows.filter((r) => r.correct).length;
    const accuracy = nCorrect / n;
    return {
      name,
      accuracy,
      n: rows.length,
      nCorrect,
      meanConfidence: rows.reduce((s, r) => s + r.confidence, 0) / n,
      se: binomialSE(accuracy, n),
      ci95: wilsonCI(nCorrect, n),
    };
  });

  // Paired McNemar: each method vs majority, and boltzmann/spectral vs logprob
  const correctBy = (name: AggregatorName) =>
    results.map((r) => !!r.aggregators.find((a) => a.name === name)?.correct);
  const majorityCorrect = correctBy("majority");
  const pairedTests: PairedComparison[] = [];
  for (const name of methodNames) {
    if (name === "majority") continue;
    const cmp = mcnemar(correctBy(name), majorityCorrect);
    cmp.methodA = name;
    cmp.methodB = "majority";
    pairedTests.push(cmp);
  }
  if (methodNames.includes("boltzmann") && methodNames.includes("logprob_weighted")) {
    const cmp = mcnemar(correctBy("boltzmann"), correctBy("logprob_weighted"));
    cmp.methodA = "boltzmann";
    cmp.methodB = "logprob_weighted";
    pairedTests.push(cmp);
  }
  if (methodNames.includes("spectral_weighted") && methodNames.includes("logprob_weighted")) {
    const cmp = mcnemar(correctBy("spectral_weighted"), correctBy("logprob_weighted"));
    cmp.methodA = "spectral_weighted";
    cmp.methodB = "logprob_weighted";
    pairedTests.push(cmp);
  }

  // Predictive power of continuous metrics
  const anyCorrect = results.map((r) => (r.candidateCorrect.some(Boolean) ? 1 : 0));
  // For chosen correctness we use spectral_weighted as the "spectral choice"
  const spectralChosen = results.map(
    (r) => (r.aggregators.find((a) => a.name === "spectral_weighted")?.correct ? 1 : 0)
  );

  const metricExtractors: Array<{ name: string; fn: (r: ItemEvalResult) => number }> = [
    { name: "spectral.cohesion", fn: (r) => r.agreement.spectral.cohesion },
    { name: "spectral.gap", fn: (r) => r.agreement.spectral.spectralGap },
    { name: "semanticEntropy", fn: (r) => r.agreement.semanticEntropy },
    { name: "jsdToCentroid", fn: (r) => r.agreement.jsdToCentroid },
    { name: "meanPairwiseCosine", fn: (r) => r.agreement.meanPairwiseCosine },
    { name: "outlierCount", fn: (r) => r.agreement.spectral.outlierCount },
    { name: "nmiClusterCorrect", fn: (r) => r.agreement.nmiClusterCorrect },
    { name: "freeEnergy", fn: (r) => r.agreement.freeEnergy.freeEnergy },
    { name: "freeEnergyDisagreement", fn: (r) => r.agreement.freeEnergy.freeEnergyDisagreement },
    { name: "disagreementEnergy", fn: (r) => r.agreement.freeEnergy.disagreementEnergy },
  ];

  const predictive: MetricPredictivePower[] = metricExtractors.map(({ name, fn }) => {
    const xs = results.map(fn);
    // Higher disagreement / energy / entropy → less likely correct → invert
    const inverted =
      name === "semanticEntropy" ||
      name === "jsdToCentroid" ||
      name === "outlierCount" ||
      name === "freeEnergy" ||
      name === "freeEnergyDisagreement" ||
      name === "disagreementEnergy";
    const scores = inverted ? xs.map((x) => -x) : xs;
    return {
      metric: name,
      pearsonAnyCorrect: pearson(scores, anyCorrect),
      pearsonChosenCorrect: pearson(scores, spectralChosen),
      aurocAnyCorrect: auroc(scores, anyCorrect),
    };
  });

  // By category
  const cats = new Map<string, ItemEvalResult[]>();
  for (const r of results) {
    if (!cats.has(r.category)) cats.set(r.category, []);
    cats.get(r.category)!.push(r);
  }
  const byCategory: EvalReport["byCategory"] = {};
  for (const [cat, rows] of cats) {
    byCategory[cat] = {
      n: rows.length,
      methods: methodNames.map((name) => {
        const ms = rows.map((r) => r.aggregators.find((a) => a.name === name)!);
        const n = ms.length || 1;
        const nCorrect = ms.filter((m) => m.correct).length;
        const accuracy = nCorrect / n;
        return {
          name,
          accuracy,
          n: ms.length,
          nCorrect,
          meanConfidence: ms.reduce((s, m) => s + m.confidence, 0) / n,
          se: binomialSE(accuracy, n),
          ci95: wilsonCI(nCorrect, n),
        };
      }),
    };
  }

  return { nItems: results.length, methods, predictive, pairedTests, byCategory };
}

// ───────────────────────── Parameter sensitivity ─────────────────────────

export function spectralSensitivity(
  items: EvalItem[],
  sigmas: Array<number | "median"> = [0.3, 0.5, 0.7, 1.0, "median"],
  minGaps: number[] = [0.05, 0.1, 0.2]
): EvalReport["spectralParamSensitivity"] {
  const out: NonNullable<EvalReport["spectralParamSensitivity"]> = [];
  for (const sigma of sigmas) {
    for (const minGap of minGaps) {
      const results = items.map((it) => evaluateItem(it, { sigma, minGap }));
      const meanCohesion =
        results.reduce((s, r) => s + r.agreement.spectral.cohesion, 0) / (results.length || 1);
      const spectralAccuracy =
        results.filter((r) => r.aggregators.find((a) => a.name === "spectral_weighted")?.correct)
          .length / (results.length || 1);
      out.push({ sigma, minGap, meanCohesion, spectralAccuracy });
    }
  }
  return out;
}

// ───────────────────────── Offline synthetic candidates ─────────────────────────

/**
 * Build synthetic multi-candidate sets from a gold expect.
 * Harder protocol:
 *  - ~30% of items have ZERO correct candidates (tests false-consensus rejection)
 *  - correct answers appear in varied surface forms
 *  - distractors are lexically close (share tokens) so hashEmbed is challenged
 *  - logprobs correlate only weakly with correctness (realistic noise)
 */
export function synthesizeCandidates(
  item: { id: string; category: string; question: string; expect: GoldExpect },
  n = 5,
  seed = 42
): EvalItem {
  let a = (seed + hashStr(item.id) * 17) >>> 0;
  const rnd = () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };

  const golds = item.expect.values.length ? item.expect.values : ["unknown"];
  const primary = golds[0];

  // Distractors must NOT contain any gold substring (scoreContainsAny is substring-based)
  const closeDistractors = [
    "قيمة غير معروفة",
    "نتيجة تقريبية فقط",
    "يحتاج إعادة حساب",
    "احتمال وارد لكنه ضعيف",
    `بديل رقمي ${Math.floor(rnd() * 50) + 100}`,
  ];
  const farDistractors = [
    "لا أعرف الإجابة",
    "المعطيان غير كافيين",
    `الناتج يساوي ${Math.floor(rnd() * 200) + 200}`,
    "تحتاج إلى سياق إضافي",
  ];

  const correctForms = golds.flatMap((g) => [
    g,
    `الجواب: ${g}`,
    `النتيجة ${g}`,
    `= ${g}`,
    `يساوي ${g}`,
  ]);

  const includeCorrect = rnd() > 0.30; // 70% of items have ≥1 correct
  const candidates: CandidateAnswer[] = [];

  for (let i = 0; i < n; i++) {
    let text: string;
    let isGood = false;
    if (includeCorrect && (i === 0 || rnd() < 0.35)) {
      text = correctForms[Math.floor(rnd() * correctForms.length)];
      isGood = true;
    } else if (rnd() < 0.55) {
      text = closeDistractors[Math.floor(rnd() * closeDistractors.length)];
    } else {
      text = farDistractors[Math.floor(rnd() * farDistractors.length)];
    }
    const base = isGood ? -1.2 : -2.0;
    const logprob = base + (rnd() - 0.5) * 2.5;
    candidates.push({
      modelId: `model-${i}`,
      text,
      logprob,
    });
  }

  for (let i = candidates.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [candidates[i], candidates[j]] = [candidates[j], candidates[i]];
  }

  return {
    id: item.id,
    category: item.category,
    question: item.question,
    expect: item.expect,
    candidates,
  };
}

function hashStr(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
