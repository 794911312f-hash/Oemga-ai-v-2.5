/**
 * evidencePsi.ts — Consensus Ψ + Evidence blend (Algorithm upgrade)
 * =============================================================================
 * Addresses review gaps:
 *  1. Pure agreement Ψ cannot detect correlated errors → blend external evidence
 *  2. Two-candidate symmetry → diversity / pairwise separation + uncertain flag
 *  3. Outliers / minority-correct → trimmed centroid (drop farthest point)
 *  4. Real structural quality proxies (not hardcoded novelty/F)
 *
 * Spec: docs/specs/psi-spec.md (Ψ_agreement) + this module (Ψ_hybrid)
 */

import { clipExpPsi, cosine, normalize, softmax } from "./math";
import { hashEmbed as lexicalHashEmbed } from "./embeddings";

export interface EvidenceSignals {
  /** 1 if external verifier said true, 0 false, omit if null/unknown */
  verified?: boolean | null;
  verificationScore?: number | null;
  /** Tool/CAS hit that supports this candidate text */
  toolSupport?: number; // 0..1
  /** Candidate marked simulated */
  simulated?: boolean;
  /** Numeric facts extracted from question that appear in answer */
  numericCoverage?: number; // 0..1
}

export interface ConsensusPsiResult {
  psiAgreement: number[];
  /** Final ranking scores after evidence blend */
  psiHybrid: number[];
  weights: number[];
  spread: number;
  sigma: number;
  /** True when top-2 are too close to declare a winner */
  uncertain: boolean;
  /** How many candidates used for centroid after trim */
  centroidSize: number;
  method: "trimmed_consensus_v1";
  notes: string[];
}

const DIM_DEFAULT = 64;

/**
 * Local lexical fallback. It is stronger than the former character-only hash,
 * but it is still not a pretrained semantic embedding.
 */
export function hashEmbed(text: string, dim = DIM_DEFAULT): number[] {
  return lexicalHashEmbed(text, dim);
}

/** Mean of vectors excluding the `drop` farthest from provisional mean (if k>=3). */
export function trimmedCentroid(vectors: number[][], drop = 1): number[] {
  const k = vectors.length;
  const dim = vectors[0]?.length ?? 0;
  if (k === 0 || dim === 0) return [];
  if (k < 3 || drop <= 0) {
    const c = new Array(dim).fill(0);
    for (const v of vectors) for (let i = 0; i < dim; i++) c[i] += v[i] / k;
    return c;
  }
  // provisional centroid
  const prov = new Array(dim).fill(0);
  for (const v of vectors) for (let i = 0; i < dim; i++) prov[i] += v[i] / k;
  const dist = vectors.map((v) => 1 - cosine(v, prov));
  const order = dist
    .map((d, i) => [d, i] as const)
    .sort((a, b) => b[0] - a[0]);
  const dropSet = new Set(order.slice(0, Math.min(drop, k - 2)).map(([, i]) => i));
  const kept = vectors.filter((_, i) => !dropSet.has(i));
  const c = new Array(dim).fill(0);
  for (const v of kept) for (let i = 0; i < dim; i++) c[i] += v[i] / kept.length;
  return c;
}

/** Extract numbers from text (Arabic-Indic digits normalized). */
export function extractNumbers(text: string): number[] {
  const normalized = text
    .replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)))
    .replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)));
  const out: number[] = [];
  const re = /-?\d+(?:\.\d+)?/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(normalized))) {
    const n = Number(m[0]);
    if (Number.isFinite(n)) out.push(n);
  }
  return out;
}

/**
 * Only runs when the entire question (after stripping leading verbs like احسب/compute)
 * is a pure arithmetic expression: digits, ops, parentheses, decimals, ×÷.
 * Returns 1 / 0 / 0.5 (match / mismatch / not applicable).
 * Uses a built-in precedence-aware evaluator (* / before + -). No dynamic mathjs require.
 */
export function arithmeticCheck(question: string, answer: string): number {
  const expr = extractPureArithmeticExpression(question);
  if (!expr) return 0.5;
  let expected: number;
  try {
    expected = evaluateArithmeticExpression(expr);
  } catch {
    return 0.5;
  }
  if (!Number.isFinite(expected)) return 0.5;
  return answerContainsExpectedNumber(answer, expected) ? 1 : 0;
}

/** @deprecated Prefer arithmeticCheck — kept for confidence.ts import compatibility */
export function numericCoverage(question: string, answer: string): number {
  return arithmeticCheck(question, answer);
}


/**
 * Score 1 only when the *stated answer* matches expected — not decoy mentions.
 *
 * 1) Explicit answer markers (including فالمجموع / therefore / thus…): last marked only.
 * 2) Numbers preceded by negation (ليس / not / …) never count as a match.
 * 3) Leading expected number (optional explanation) → 1.
 * 4) Last bare "=" after dropping intermediate steps → that only.
 * 5) Else single distinct number, or first of ≤2 distinct.
 */
export function answerContainsExpectedNumber(
  answer: string,
  expected: number
): boolean {
  const tol = 1e-6 * Math.max(1, Math.abs(expected));
  const near = (n: number) => Math.abs(n - expected) < tol;

  const isNegatedAt = (idx: number): boolean => {
    const before = answer.slice(Math.max(0, idx - 24), idx);
    return /(?:^|[\s,،])(?:ليس|ليست|لا\s*يساوي|لا\s*يساوى|وليس|وليست|not|isn't|isnt|≠)\s*$/i.test(
      before
    ) || /(?:ليس|لا)\s+$/i.test(before);
  };

  // 1) Verbal / conclusion markers
  const verbal: { n: number; idx: number }[] = [];
  const verbalRe =
    /(?:الجواب|الناتج|النتيجة|فالمجموع|المجموع|إذن|ايذا|answer|result|therefore|thus|hence|\bso\b)\s*[=:]?\s*([-+]?\d+(?:\.\d+)?)/gi;
  let m: RegExpExecArray | null;
  while ((m = verbalRe.exec(answer))) {
    const n = Number(m[1]);
    const idx = m.index + m[0].length - m[1].length;
    if (!isNegatedAt(idx)) verbal.push({ n, idx });
  }
  if (verbal.length > 0) {
    return near(verbal[verbal.length - 1].n);
  }

  // 2) Leading claim (skip if negated)
  const leadMatch = answer.trim().match(/^([-+]?\d+(?:\.\d+)?)/);
  if (leadMatch) {
    const leadIdx = answer.indexOf(leadMatch[1]);
    // "لا، ليس 391 بل 401" — leading is not the first number after negation phrases
    // Detect overall negation-of-expected near start
    const head = answer.slice(0, Math.min(answer.length, 40));
    const negatesExpected =
      /(?:لا[،,]?\s*)?(?:ليس|ليست|not)\s/.test(head) &&
      near(Number(leadMatch[1]));
    // Also: "لا، ليس 391 بل 401" has leading not a number; first number is after ليس
    if (!negatesExpected && near(Number(leadMatch[1]))) {
      // Ensure we didn't start with negation then the number
      if (!isNegatedAt(leadIdx)) return true;
    }
  }

  // Explicit: if text matches "ليس/not <expected>" as a denial of expected, do not accept
  // via other loose paths without a positive marker for expected
  const deniesExpected = new RegExp(
    `(?:ليس|ليست|وليس|not)\\s+${String(expected).replace(".", "\\.")}\\b`,
    "i"
  ).test(answer);

  const stepRe =
    /\d+(?:\.\d+)?\s*[+\-*/×÷]\s*\d+(?:\.\d+)?\s*=\s*\d+(?:\.\d+)?/g;
  const steps = [...answer.matchAll(stepRe)];
  let stripped = answer;
  if (steps.length > 1) {
    for (const s of steps.slice(0, -1)) {
      stripped = stripped.replace(s[0], " ");
    }
  }

  const eqNums: { n: number; idx: number }[] = [];
  const eqRe = /=\s*([-+]?\d+(?:\.\d+)?)/g;
  while ((m = eqRe.exec(stripped))) {
    const n = Number(m[1]);
    const idx = m.index + m[0].length - m[1].length;
    if (!isNegatedAt(idx)) eqNums.push({ n, idx });
  }
  if (eqNums.length > 0) {
    return near(eqNums[eqNums.length - 1].n);
  }

  if (deniesExpected) return false;

  const nums = extractNumbers(stripped);
  if (nums.length === 0) return false;
  const distinct = [...new Set(nums.map((n) => Math.round(n * 1e9) / 1e9))];
  if (distinct.length === 1) return near(distinct[0]);
  if (distinct.length === 2 && near(nums[0])) return true;
  return false;
}


const LEAD_VERBS =
  /^(?:احسب|احسبوا|أوجد|اوجد|compute|calculate|what\s+is|find)\s*[:：]?\s*/i;

function extractPureArithmeticExpression(question: string): string | null {
  let q = question.trim();
  q = q.replace(LEAD_VERBS, "").trim();
  q = q.replace(/[؟?!.]+$/g, "").trim();
  let expr = q
    .replace(/×/g, "*")
    .replace(/÷/g, "/")
    .replace(/x/gi, "*")
    .replace(/\s+/g, "");
  // Pure arithmetic only — rejects algebra like x^2-4=0
  if (!/^[0-9.+\-*/()]+$/.test(expr)) return null;
  if (!/[0-9]/.test(expr) || !/[+\-*/]/.test(expr)) return null;
  return expr;
}

/** Precedence-aware built-in evaluator only (no dynamic mathjs require in ESM). */
function evaluateArithmeticExpression(expr: string): number {
  return evalWithPrecedence(expr);
}

function evalWithPrecedence(expr: string): number {
  const tokens = tokenizeArith(expr);
  const rpn = toRpn(tokens);
  return evalRpn(rpn);
}

function tokenizeArith(expr: string): string[] {
  const out: string[] = [];
  let i = 0;
  while (i < expr.length) {
    const c = expr[i];
    if ("+-*/()".includes(c)) {
      if (
        c === "-" &&
        (out.length === 0 ||
          ["+", "-", "*", "/", "("].includes(out[out.length - 1]))
      ) {
        let j = i + 1;
        while (j < expr.length && /[0-9.]/.test(expr[j])) j++;
        out.push(expr.slice(i, j));
        i = j;
        continue;
      }
      out.push(c);
      i++;
    } else if (/[0-9.]/.test(c)) {
      let j = i + 1;
      while (j < expr.length && /[0-9.]/.test(expr[j])) j++;
      out.push(expr.slice(i, j));
      i = j;
    } else {
      throw new Error("bad char");
    }
  }
  return out;
}

function toRpn(tokens: string[]): string[] {
  const prec: Record<string, number> = { "+": 1, "-": 1, "*": 2, "/": 2 };
  const out: string[] = [];
  const stack: string[] = [];
  for (const t of tokens) {
    if (/^-?[0-9]+(\.[0-9]+)?$/.test(t)) {
      out.push(t);
    } else if (t in prec) {
      while (
        stack.length &&
        stack[stack.length - 1] in prec &&
        prec[stack[stack.length - 1]] >= prec[t]
      ) {
        out.push(stack.pop()!);
      }
      stack.push(t);
    } else if (t === "(") {
      stack.push(t);
    } else if (t === ")") {
      while (stack.length && stack[stack.length - 1] !== "(") {
        out.push(stack.pop()!);
      }
      if (!stack.length) throw new Error("paren");
      stack.pop();
    } else {
      throw new Error("token");
    }
  }
  while (stack.length) {
    const op = stack.pop()!;
    if (op === "(" || op === ")") throw new Error("paren");
    out.push(op);
  }
  return out;
}

function evalRpn(rpn: string[]): number {
  const st: number[] = [];
  for (const t of rpn) {
    if (/^-?[0-9]+(\.[0-9]+)?$/.test(t)) {
      st.push(Number(t));
    } else {
      const b = st.pop();
      const a = st.pop();
      if (a === undefined || b === undefined) throw new Error("stack");
      switch (t) {
        case "+": st.push(a + b); break;
        case "-": st.push(a - b); break;
        case "*": st.push(a * b); break;
        case "/": st.push(a / b); break;
        default: throw new Error("op");
      }
    }
  }
  if (st.length !== 1) throw new Error("rpn");
  return st[0];
}

/**
 * Style/sanity only: penalty for empty or very short answers.
 * No reward for length or step markers (style must stay ≤20% of hybrid score).
 */
export function structuralQuality(text: string): number {
  const len = (text || "").trim().length;
  if (len === 0) return 0.05;
  if (len < 8) return 0.25;
  if (len < 15) return 0.45;
  return 0.55; // neutral — not a quality award for verbosity
}

/**
 * Lightweight self-falsification proxy:
 * - internal numeric contradictions (same symbol different values) — weak
 * - empty / tiny answers score low resistance
 * Returns [0,1], neutral 0.5 when inconclusive.
 */
/** Text sanity only — NOT a falsification / scientific refutation test. */
/** Text sanity only — NOT a falsification / scientific refutation test. */
export function textSanityProxy(text: string): number {
  const len = (text || "").trim().length;
  if (len === 0) return 0.15;
  if (len < 2) return 0.2;
  // Short correct answers (e.g. "Paris", "391") are fine
  return 0.5;
}

function evidenceBoost(sig?: EvidenceSignals): number {
  if (!sig) return 0;
  let b = 0;
  if (sig.verified === true) b += 0.2 * (sig.verificationScore ?? 0.85);
  if (sig.verified === false) b -= 0.25;
  if (typeof sig.toolSupport === "number") b += 0.15 * Math.max(0, Math.min(1, sig.toolSupport));
  if (sig.simulated) b -= 0.12;
  if (typeof sig.numericCoverage === "number") {
    b += 0.12 * (sig.numericCoverage - 0.5); // centered
  }
  return b;
}

/**
 * Main API: agreement Ψ + hybrid Ψ with evidence.
 */
export function scoreEvidencePsi(
  texts: string[],
  options?: {
    embeddings?: number[][];
    evidence?: EvidenceSignals[];
    question?: string;
    uncertainSpread?: number;
    trimOutliers?: boolean;
  }
): ConsensusPsiResult {
  const notes: string[] = [];
  const k = texts.length;
  if (k === 0) {
    return {
      psiAgreement: [],
      psiHybrid: [],
      weights: [],
      spread: 0,
      sigma: 0,
      uncertain: true,
      centroidSize: 0,
      method: "trimmed_consensus_v1",
      notes: ["no candidates"],
    };
  }

  const vectors =
    options?.embeddings && options.embeddings.length === k
      ? options.embeddings
      : texts.map((t) => hashEmbed(t));

  if (k === 1) {
    notes.push("single candidate — agreement Ψ undefined; hybrid uses quality only");
    const style = structuralQuality(texts[0]);
    const sanity = textSanityProxy(texts[0]);
    const arith = options?.question
      ? arithmeticCheck(options.question, texts[0])
      : 0.5;
    let h = 0.35 * arith + 0.2 * style + 0.15 * sanity + 0.3;
    h += evidenceBoost(options?.evidence?.[0]);
    h = Math.max(0.01, Math.min(1, h));
    return {
      psiAgreement: [1],
      psiHybrid: [h],
      weights: [1],
      spread: 0,
      sigma: 0,
      uncertain: true,
      centroidSize: 1,
      method: "trimmed_consensus_v1",
      notes,
    };
  }

  if (k === 2) {
    notes.push("two candidates — pairwise cosine only; prefer evidence to break ties");
  }

  const useTrim = options?.trimOutliers !== false && k >= 3;
  const centroid = useTrim ? trimmedCentroid(vectors, 1) : trimmedCentroid(vectors, 0);
  if (useTrim) notes.push("trimmed centroid (dropped 1 farthest)");

  const delta = vectors.map((v) => 1 - cosine(v, centroid));
  const meanDelta = delta.reduce((a, b) => a + b, 0) / k;
  const variance = delta.reduce((a, d) => a + (d - meanDelta) ** 2, 0) / k;
  const sigma = Math.sqrt(variance);
  const psiAgreement = delta.map((d) => clipExpPsi(d, sigma));

  // Precompute arithmetic for decisive override
  const arithScores = options?.question
    ? texts.map((tx) => arithmeticCheck(options.question!, tx))
    : texts.map(() => 0.5);
  const hasDecisiveArith = arithScores.some((a) => a === 0 || a === 1);
  const hasExternalVerify = (options?.evidence || []).some(
    (e) =>
      e &&
      (e.verified === true ||
        (typeof e.toolSupport === "number" && e.toolSupport > 0.2))
  );

  const psiHybrid = psiAgreement.map((p, i) => {
    const style = structuralQuality(texts[i]); // ≤20% total style channel
    const sanity = textSanityProxy(texts[i]);
    const arith = arithScores[i];
    const ev = options?.evidence?.[i];
    const external =
      (ev?.verified === true ? 0.35 : ev?.verified === false ? -0.3 : 0) +
      (typeof ev?.toolSupport === "number" ? 0.25 * Math.max(0, Math.min(1, ev.toolSupport)) : 0) +
      (ev?.simulated ? -0.1 : 0);
    let h =
      0.40 * p +
      0.25 * arith +
      0.15 * Math.max(0, Math.min(1, 0.5 + external)) +
      0.12 * style +
      0.08 * sanity;
    h += Math.max(-0.15, Math.min(0.25, external * 0.5));

    // Decisive arithmetic (0 or 1) acts as hard evidence when no external verifier:
    // correct must beat incorrect by a clear margin, not lose to majority agreement.
    if (hasDecisiveArith && !hasExternalVerify) {
      if (arith === 1) {
        h = Math.max(h, 0.72) + 0.35;
        notes.push(`arith decisive boost on candidate ${i}`);
      } else if (arith === 0) {
        h = Math.min(h, 0.55) - 0.12;
      }
    }
    return Math.max(0.01, Math.min(1, h));
  });

  const sorted = [...psiHybrid].sort((a, b) => b - a);
  const spread = (sorted[0] ?? 0) - (sorted[sorted.length - 1] ?? 0);
  const topGap = (sorted[0] ?? 0) - (sorted[1] ?? sorted[0] ?? 0);
  const uncertainSpread = options?.uncertainSpread ?? 0.06;
  let uncertain = k < 3 || topGap < uncertainSpread;

  // Agreement majority vs arithmetic minority without external verify → uncertain
  if (options?.question && k >= 3) {
    const arithScores = texts.map((tx) => arithmeticCheck(options.question!, tx));
    const agrRank = psiAgreement
      .map((p, i) => [p, i] as const)
      .sort((a, b) => b[0] - a[0])
      .map(([, i]) => i);
    const arithBest = arithScores.indexOf(Math.max(...arithScores));
    const hasExternal = (options.evidence || []).some(
      (e) => e && (e.verified === true || (typeof e.toolSupport === "number" && e.toolSupport > 0.2))
    );
    if (
      !hasExternal &&
      arithBest >= 0 &&
      arithScores[arithBest] === 1 &&
      arithScores.some((score) => score === 0) &&
      agrRank[0] !== arithBest
    ) {
      uncertain = true;
      notes.push("uncertain: agreement majority conflicts with arithmetic check");
    }
    // Even when lexical agreement happens to rank the arithmetic answer first,
    // a mix of verified-looking and wrong arithmetic candidates is not proof.
    // Keep the result uncertain until an external verifier supports it.
    if (!hasExternal && arithScores.includes(1) && arithScores.includes(0)) {
      uncertain = true;
      notes.push("uncertain: decisive arithmetic lacks external verification");
    }
  }

  if (uncertain) notes.push(`uncertain top-gap=${topGap.toFixed(3)}`);

  const weights = softmax(psiHybrid.map((x) => x * 3)); // sharper than raw

  return {
    psiAgreement,
    psiHybrid,
    weights,
    spread,
    sigma,
    uncertain,
    centroidSize: useTrim ? Math.max(2, k - 1) : k,
    method: "trimmed_consensus_v1",
    notes,
  };
}

/**
 * Rank indices by hybrid Ψ descending.
 */
export function rankByHybridPsi(result: ConsensusPsiResult): number[] {
  return result.psiHybrid
    .map((p, i) => [p, i] as const)
    .sort((a, b) => b[0] - a[0])
    .map(([, i]) => i);
}


/** @deprecated Use textSanityProxy — not a falsification test */
export const selfFalsificationProxy = textSanityProxy;
