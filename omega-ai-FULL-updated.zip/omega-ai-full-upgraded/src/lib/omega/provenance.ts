/**
 * Unified provenance schema for Omega AI outputs.
 * Use these types on API responses and UI so `verified` is never a silent default.
 */

/** Where the payload primarily came from */
export type SourceClass =
  | "provider_live" // real upstream model/provider response
  | "local_compute" // local math / CAS / kernel without external LLM
  | "simulated" // single-model or heuristic stand-in
  | "mixed" // combination of live + simulated
  | "blueprint" // plan/storyboard only — no measured media
  | "demo_seed"; // hard-coded demo / lineage seed data

/** How verification was performed (or that it was not) */
export type VerificationMethod =
  | "external_llm_judge"
  | "cas_proof"
  | "self_consistency"
  | "human"
  | "none"
  | "unknown";

export type Provenance = {
  sourceClass: SourceClass;
  /** true only after an actual verification pass succeeded */
  verified: boolean | null;
  verificationMethod: VerificationMethod;
  /** true when values come from instrumentation/measurement, not placeholders */
  measured: boolean;
  /** optional free-form note for UI / logs */
  note?: string;
};

export const UNVERIFIED_PROVENANCE: Provenance = {
  sourceClass: "simulated",
  verified: null,
  verificationMethod: "none",
  measured: false,
  note: "No verification performed",
};

/** Demo / seed records must never claim verified:true */
export function demoSeedProvenance(note?: string): Provenance {
  return {
    sourceClass: "demo_seed",
    verified: null,
    verificationMethod: "none",
    measured: false,
    note: note ?? "Seed/demo data — not independently verified",
  };
}

export function simulatedProvenance(note?: string): Provenance {
  return {
    sourceClass: "simulated",
    verified: null,
    verificationMethod: "none",
    measured: false,
    note: note ?? "Simulated or fallback path",
  };
}

export function fromVerificationResult(
  verification: { verified: boolean; score?: number } | null | undefined,
  sourceClass: SourceClass,
  method: VerificationMethod = "external_llm_judge",
): Provenance {
  if (!verification) {
    return {
      sourceClass,
      verified: null,
      verificationMethod: "none",
      measured: false,
      note: "Verification skipped or unavailable",
    };
  }
  return {
    sourceClass,
    verified: verification.verified === true,
    verificationMethod: method,
    measured: true,
  };
}
