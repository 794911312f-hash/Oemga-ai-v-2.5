/**
 * OMEGA Local Cortex Controller (OLCC)
 *
 * The open-weight model is the language-generation cortex; Omega remains the
 * budget controller and independent-verification authority. This module never
 * interprets model confidence as proof.
 */

export type OmegaVerificationMode = "symbolic" | "evidence" | "consistency";

export interface LocalInferencePlan {
  complexity: number;
  temperature: number;
  maxTokens: number;
  verificationMode: OmegaVerificationMode;
  independentAuditRecommended: boolean;
}

const clamp = (value: number, low: number, high: number) => Math.max(low, Math.min(high, value));

/** Normalizes an operator-configured OpenAI-compatible base URL, never request input. */
export function normalizeOpenAICompatibleBaseUrl(raw: string): string | null {
  try {
    const parsed = new URL(raw.trim());
    if (
      !["http:", "https:"].includes(parsed.protocol) || parsed.username || parsed.password ||
      parsed.search || parsed.hash
    ) return null;
    let baseUrl = raw.trim().replace(/\/+$/, "");
    if (!parsed.pathname.replace(/\/+$/, "").endsWith("/v1")) baseUrl += "/v1";
    return baseUrl;
  } catch {
    return null;
  }
}

/**
 * A bounded complexity estimate used only to allocate inference budget:
 * C = .30L + .40D + .20M + .10S, where L=length, D=domain prior,
 * M=multi-step cues, and S=symbolic/code density. It is not an accuracy score.
 */
export function planLocalInference(
  question: string,
  domain = "general",
  requestedMaxTokens = 1024
): LocalInferencePlan {
  const text = typeof question === "string" ? question : String(question ?? "");
  const length = clamp(Math.log1p(text.length) / Math.log1p(4000), 0, 1);
  const domainPrior: Record<string, number> = {
    math_logic: 0.95,
    code: 0.88,
    science_factual: 0.84,
    deep_research: 0.9,
    open_problem: 0.82,
    news_realtime: 0.75,
    general: 0.35,
    creative: 0.2,
  };
  const domainScore = domainPrior[domain] ?? 0.5;
  const stepCues = (text.match(/\b(?:step|first|then|finally|prove|derive|compare|analyze)\b|(?:ثم|أولاً|بعد ذلك|أثبت|استنتج|قارن|حلل)/giu) || []).length;
  const multiStep = clamp(stepCues / 4, 0, 1);
  const symbolCount = (text.match(/[=<>±×÷√∑∫^{}()[\]{};]|\b(?:function|class|algorithm|equation|معادلة|دالة|خوارزمية)\b/giu) || []).length;
  const symbolicDensity = clamp(symbolCount / Math.max(6, text.length / 18), 0, 1);
  const complexity = Number(clamp(
    0.3 * length + 0.4 * domainScore + 0.2 * multiStep + 0.1 * symbolicDensity,
    0,
    1
  ).toFixed(4));

  let verificationMode: OmegaVerificationMode = "consistency";
  if (domain === "math_logic" || /[=<>±×÷√∑∫]|\b(?:solve|prove|equation|معادلة|برهان|أثبت)\b/iu.test(text)) {
    verificationMode = "symbolic";
  } else if (
    domain === "science_factual" || domain === "news_realtime" || domain === "deep_research" ||
    /\b(?:source|citation|current|latest|fact|evidence)\b|(?:مصدر|مرجع|حديث|حالي|حقيقة|دليل)/iu.test(text)
  ) {
    verificationMode = "evidence";
  }

  const desiredTokens = Math.round(384 + 1664 * complexity);
  const maxTokens = Math.max(128, Math.min(4096, Number.isFinite(requestedMaxTokens) ? requestedMaxTokens : 1024, desiredTokens));

  return {
    complexity,
    temperature: Number(clamp(0.45 - 0.3 * complexity, 0.15, 0.45).toFixed(2)),
    maxTokens,
    verificationMode,
    independentAuditRecommended: verificationMode !== "consistency" || complexity >= 0.65,
  };
}

export function buildLocalModelSystemInstruction(base: string, plan: LocalInferencePlan): string {
  const modeInstruction = plan.verificationMode === "symbolic"
    ? "For math or logic, provide concise, checkable steps. Do not claim Omega's CAS verified the answer unless a verifier result is explicitly present in the conversation."
    : plan.verificationMode === "evidence"
      ? "Separate supplied evidence from assumptions. Never invent citations or claim live fact-checking unless evidence is explicitly supplied."
      : "Answer clearly, state material assumptions, and flag uncertainty rather than bluffing.";

  return [
    base,
    "You are Omega's open-weight language-generation cortex, not its verifier. Your output is a candidate answer.",
    "Do not reveal private chain-of-thought. Give a concise rationale or checkable result instead.",
    modeInstruction,
  ].filter(Boolean).join("\n\n");
}
