/**
 * src/lib/omega/hybridSelfEvolution.ts
 * =====================================================================
 * Omega AI — Phase 8: Hybrid Self-Evolution Core
 * + Population-Based Evolutionary Archive (Darwin-style)
 * ---------------------------------------------------------------------
 * Features:
 *  • Harness rewriting (prompts / tools / control flow)
 *  • Self-generated preference data from trajectories
 *  • Partial weight updates via external ORPO / DPO training
 *  • Population of competing individuals + Pareto Front
 *  • Lineage tracking + manual parent selection
 *  • Integration with AutoBenchmark + InferenceEngine + Firebase
 * =====================================================================
 */

import { AutoBenchmarkEngine, type BenchmarkRunReport } from "./autoBenchmark";
import { isEvolutionGatePass as checkEvolutionGatePass } from "./evolutionGateStatus";

// ====================== Core Types ======================

export type PreferenceMethod = "orpo" | "dpo";
export type EvolutionTarget = "harness" | "weights_partial" | "hybrid" | "memory";

export interface Trajectory {
  id: string;
  task: string;
  fullTrace: string;
  finalAnswer: string;
  score: number; // 0–1
  latencyMs: number;
  modelId: string;
  harnessVersion: string;
  timestamp: number;
}

export interface PreferencePair {
  prompt: string;
  chosen: string;
  rejected: string;
  scoreDiff: number;
  verified?: boolean;
  chosenEvidence?: PreferenceEvidence;
  rejectedEvidence?: PreferenceEvidence;
}

export interface PreferenceEvidence {
  source: "cas" | "lean" | "tool" | "human";
  proofId: string;
  outcome: boolean;
  confidence: number;
  details?: string;
}

export interface AdapterState {
  id: string;
  method: PreferenceMethod;
  rank: number;
  targetModules: string[];
  performanceDelta: number;
  trainedOnPairs: number;
  createdAt: number;
  adapterUrl?: string;
  adapterPath?: string;
  finalLoss?: number;
}

export interface EvolutionGeneration {
  generation: number;
  target: EvolutionTarget;
  method: PreferenceMethod;
  harnessDiff?: string;
  adapter?: AdapterState;
  benchmarkReport: BenchmarkRunReport;
  accepted: boolean;
  reason: string;
  timestamp: number;
}

export interface HybridEvolutionConfig {
  maxGenerations: number;
  minScoreDiffForPreference: number;
  loRARank: number;
  safetyRollbackThreshold: number;
  preferenceMethod: PreferenceMethod;
  maxPairsPerTraining: number;
  externalTrainingEndpoint?: string;
  trainingTimeoutMs?: number;
}

export interface HybridStatus {
  generation: number;
  method: PreferenceMethod;
  activeAdapters: number;
  stagedAdapters: number;
  preferencePairs: number;
  trajectories: number;
  currentHarness: string;
  archive: EvolutionGeneration[];
  isRunning: boolean;
  lastResult: any;
}

// ====================== Population Types ======================

export interface IndividualMetrics {
  accuracy: number;
  latencyMs: number;
  costEstimate: number;
  stability: number;
}

export interface Individual {
  id: string;
  generationBorn: number;
  parentIds: string[];
  harnessVersion: string;
  harnessDiff?: string;
  adapter?: AdapterState | null;
  metrics: IndividualMetrics;
  compositeScore: number;
  wins: number;
  age: number;
  createdAt: number;
  status: "active" | "archived" | "eliminated";
}

export interface LineageNode {
  id: string;
  parentIds: string[];
  generation: number;
  score: number;
  method: PreferenceMethod;
  summary: string;
}

// ====================== Engine ======================

export class HybridSelfEvolutionEngine {
  private trajectories: Trajectory[] = [];
  private preferenceBuffer: PreferencePair[] = [];
  private archive: EvolutionGeneration[] = [];
  private currentHarnessVersion = "v0-base";
  private currentAdapters: AdapterState[] = [];
  private generation = 0;
  private isRunning = false;
  private lastResult: any = null;

  private benchmark = new AutoBenchmarkEngine();
  private config: HybridEvolutionConfig;

  // Population state
  private population: Individual[] = [];
  private paretoArchive: Individual[] = [];
  private lineage: LineageNode[] = [];
  private readonly maxPopulationSize = 12;
  private readonly maxArchiveSize = 25;
  private readonly tournamentSize = 3;

  constructor(config?: Partial<HybridEvolutionConfig>) {
    this.config = {
      maxGenerations: 50,
      minScoreDiffForPreference: 0.12,
      loRARank: 16,
      safetyRollbackThreshold: -0.04,
      preferenceMethod: "orpo",
      maxPairsPerTraining: 400,
      trainingTimeoutMs: 30 * 60 * 1000,
      ...config,
    };
  }

  // ---------- Public API ----------

  public getStatus(): HybridStatus {
    return {
      generation: this.generation,
      method: this.config.preferenceMethod,
      // Adapter files are staged artifacts; this runtime has no adapter loader.
      activeAdapters: 0,
      stagedAdapters: this.currentAdapters.length,
      preferencePairs: this.preferenceBuffer.filter((pair) => pair.verified === true).length,
      trajectories: this.trajectories.length,
      currentHarness: this.currentHarnessVersion,
      archive: this.archive.slice(-40),
      isRunning: this.isRunning,
      lastResult: this.lastResult,
    };
  }

  public setPreferenceMethod(method: PreferenceMethod) {
    if (method === "orpo" || method === "dpo") {
      this.config.preferenceMethod = method;
    }
  }

  public getPreferenceMethod(): PreferenceMethod {
    return this.config.preferenceMethod;
  }

  public recordTrajectory(traj: Trajectory) {
    this.trajectories.push(traj);
    if (this.trajectories.length > 500) {
      this.trajectories = this.trajectories.slice(-500);
    }
    if (this.trajectories.length % 6 === 0) {
      this.generatePreferenceData();
    }
  }

  /** Adds a pair only when both candidate outcomes carry independent proofs. */
  public recordVerifiedPreferencePair(pair: PreferencePair): boolean {
    const isValidEvidence = (evidence: PreferenceEvidence | undefined, outcome: boolean) =>
      Boolean(
        evidence && typeof evidence === "object" &&
        ["cas", "lean", "tool", "human"].includes(evidence.source) &&
        typeof evidence.proofId === "string" && evidence.proofId.trim() &&
        evidence.outcome === outcome &&
        Number.isFinite(evidence.confidence) && evidence.confidence >= 0.9 && evidence.confidence <= 1
      );

    if (
      !pair || typeof pair !== "object" || pair.verified !== true ||
      typeof pair.prompt !== "string" || !pair.prompt.trim() ||
      typeof pair.chosen !== "string" || !pair.chosen.trim() ||
      typeof pair.rejected !== "string" || !pair.rejected.trim() || pair.chosen === pair.rejected ||
      !Number.isFinite(pair.scoreDiff) || pair.scoreDiff <= 0 || pair.scoreDiff > 1 ||
      !isValidEvidence(pair.chosenEvidence, true) ||
      !isValidEvidence(pair.rejectedEvidence, false)
    ) return false;

    const duplicate = this.preferenceBuffer.some(
      (existing) => existing.verified === true && existing.prompt === pair.prompt &&
        existing.chosen === pair.chosen && existing.rejected === pair.rejected
    );
    if (duplicate) return false;

    this.preferenceBuffer.push({ ...pair });
    if (this.preferenceBuffer.length > 900) {
      this.preferenceBuffer = this.preferenceBuffer
        .sort((a, b) => Number(b.verified === true) - Number(a.verified === true) || b.scoreDiff - a.scoreDiff)
        .slice(0, 700);
    }
    return true;
  }

  public getPopulation() {
    return [...this.population];
  }

  public getParetoArchive() {
    const front = this.getParetoFront();
    return front.length > 0 ? front : [...this.paretoArchive];
  }

  public getLineage() {
    return [...this.lineage];
  }

  public getBestIndividual(): Individual | null {
    return this.population.length > 0 ? this.population[0] : null;
  }

  public getParetoFront(): Individual[] {
    const active = this.population.filter((i) => i.status === "active");
    const front: Individual[] = [];

    for (const candidate of active) {
      let isDominated = false;
      for (const other of active) {
        if (other.id === candidate.id) continue;
        if (this.dominates(other, candidate)) {
          isDominated = true;
          break;
        }
      }
      if (!isDominated) front.push(candidate);
    }

    return front.sort((a, b) => b.compositeScore - a.compositeScore);
  }

  public selectParentById(individualId: string): Individual | null {
    const found = this.population.find(
      (i) => i.id === individualId && i.status === "active"
    );
    if (found) {
      found.wins += 1;
      return found;
    }
    return null;
  }

  public eliminateIndividual(individualId: string, soft = true): boolean {
    const idx = this.population.findIndex((i) => i.id === individualId);
    if (idx === -1) return false;

    if (soft) {
      this.population[idx].status = "archived";
    } else {
      this.population[idx].status = "eliminated";
      this.population.splice(idx, 1);
    }
    return true;
  }

  public promoteIndividual(individualId: string): boolean {
    // Hard gate: refuse promote unless evolution-gate last decision was PASS.
    // Write PASS via: npm run evolution-gate (creates docs/reports/.evolution-gate-status.json)
    if (!this.isEvolutionGatePass()) {
      console.warn(
        "[HybridEvolution] promote blocked — evolution gate is not PASS. Run: npm run evolution-gate"
      );
      return false;
    }

    const idx = this.population.findIndex((i) => i.id === individualId);
    if (idx === -1) return false;
    if (this.population[idx].adapter) {
      console.warn("[HybridEvolution] promotion blocked — adapter has not been loaded and benchmarked in inference");
      return false;
    }

    const [individual] = this.population.splice(idx, 1);
    individual.wins += 2;
    this.population.unshift(individual);
    return true;
  }

  /** Reads status file written by scripts/evolution-gate.ts */
  private isEvolutionGatePass(): boolean {
    return checkEvolutionGatePass();
  }

  public async loadPersistedAdapters(userId = "user_main") {
    try {
      const { getDb } = await import("./firebase");
      const db = getDb();
      if (!db) return;

      const snap = await db
        .collection("omega_hybrid_adapters")
        .where("userId", "==", userId)
        .orderBy("createdAt", "desc")
        .limit(20)
        .get();

      const loaded = snap.docs.map((d: any) => d.data() as AdapterState);
      if (loaded.length > 0) {
        this.currentAdapters = loaded;
        console.log(`[HybridEvolution] Loaded ${loaded.length} adapters from Firebase`);
      }
    } catch (err) {
      console.warn("[HybridEvolution] Failed to load adapters:", err);
    }
  }

  // ---------- Core Evolution Cycle ----------

  public async runEvolutionCycle(
    evaluateFn?: () => Promise<BenchmarkRunReport>
  ): Promise<EvolutionGeneration> {
    if (this.isRunning) {
      throw new Error("دورة تطور هجينة قيد التشغيل بالفعل");
    }

    this.isRunning = true;
    this.generation += 1;

    try {
      const target = this.decideTarget();
      let harnessDiff: string | undefined;
      let adapter: AdapterState | undefined;

      // 1. Harness evolution
      if (target === "harness" || target === "hybrid") {
        const result = await this.evolveHarness();
        harnessDiff = result.diff;
        this.currentHarnessVersion = result.newVersion;
      }

      // 2. Partial weight update (ORPO / DPO)
      if (target === "weights_partial" || target === "hybrid") {
        adapter = (await this.evolveWeightsPartial()) || undefined;
      }

      // 3. Evaluation
      let report: BenchmarkRunReport;

      if (evaluateFn) {
        report = await evaluateFn();
      } else {
        try {
          const { getInferenceEngine } = await import("./inferenceEngine");

          const evaluatorFn = async (prompt: string): Promise<string> => {
            try {
              const engine = getInferenceEngine("hybrid-benchmark");
              const result = await engine.runCycle({
                userId: "hybrid-benchmark",
                question: prompt,
                domain: "general",
              });
              return result.answer || "";
            } catch (err) {
              console.warn("[HybridEvolution] evaluator failed:", (err as Error).message);
              return "";
            }
          };

          report = await this.benchmark.runBenchmark(evaluatorFn, this.generation);
        } catch (benchErr) {
          console.warn("[HybridEvolution] Benchmark failed → fallback", benchErr);
          report = this.createFallbackReport();
        }
      }

      // The benchmark currently evaluates the ordinary inference engine, not
      // the newly trained adapter. Do not attribute its delta to that adapter.
      const accepted = !adapter && report.deltaScore >= this.config.safetyRollbackThreshold;
      if (adapter) adapter.performanceDelta = 0;

      // Population logic
      const parent = this.selectParent();
      const parentIds = parent ? [parent.id] : [];

      const newIndividual = this.createIndividual(
        this.currentHarnessVersion,
        harnessDiff,
        adapter,
        report,
        parentIds
      );

      this.updatePopulationAndArchive(newIndividual);

      const gen: EvolutionGeneration = {
        generation: this.generation,
        target,
        method: this.config.preferenceMethod,
        harnessDiff,
        adapter,
        benchmarkReport: report,
        accepted,
        reason: adapter
          ? "Adapter trained and staged, but not activated or benchmarked in inference; promotion blocked"
          : accepted
            ? `Accepted & added to population (score: ${newIndividual.compositeScore.toFixed(3)})`
            : `Added to population but marked for potential elimination (delta: ${report.deltaScore.toFixed(2)})`,
        timestamp: Date.now(),
      };

      this.archive.push(gen);
      this.lastResult = {
        ...gen,
        individualId: newIndividual.id,
        populationSize: this.population.length,
        archiveSize: this.paretoArchive.length,
      };

      return gen;
    } finally {
      this.isRunning = false;
    }
  }

  // ---------- Internal Helpers ----------

  private decideTarget(): EvolutionTarget {
    const recent = this.archive.slice(-4);
    const harnessStagnant =
      recent.filter((g) => g.target === "harness" && !g.accepted).length >= 2;
    const hasGoodData = this.preferenceBuffer.filter((pair) => pair.verified === true).length >= 60;

    if (harnessStagnant && hasGoodData) return "weights_partial";
    if (hasGoodData && this.generation % 3 === 0) return "hybrid";
    return "harness";
  }

  private async evolveHarness(): Promise<{ newVersion: string; diff: string }> {
    const newVersion = `v${this.generation}-dspy`;

    try {
      const improvedInstruction = await this.optimizeSystemPromptWithDSPy();

      const diff = `[DSPy] Generation ${this.generation}
- Optimized system instruction via DSPy teleprompter
- Added self-critique + verification step
- Improved retrieval weighting
${improvedInstruction ? `- New instruction preview: ${improvedInstruction.slice(0, 120)}...` : ""}`;

      return { newVersion, diff };
    } catch (err) {
      console.warn("[HybridEvolution] DSPy harness evolution failed, using fallback:", err);
      const diff = `[Fallback] Generation ${this.generation}
- Strengthened self-critique loop
- Added explicit verification milestone
- Improved memory retrieval weights`;
      return { newVersion: `v${this.generation}-fallback`, diff };
    }
  }

  private async optimizeSystemPromptWithDSPy(): Promise<string | null> {
    try {
      const res = await fetch("/api/omega/dspy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          signature: "task, current_prompt -> improved_prompt, rationale",
          inputs: {
            task: "تحسين تعليمات وكيل برمجي ذاتي التطور لزيادة الدقة والاستقرار",
            current_prompt:
              "You are Omega Autonomous Agent. Solve complex tasks step by step.",
          },
          optimize: true,
        }),
      });

      if (!res.ok) return null;
      const data = await res.json();
      return data.outputs?.improved_prompt || data.improved_prompt || data.result || null;
    } catch {
      return null;
    }
  }

  private generatePreferenceData() {
    const byTask = new Map<string, Trajectory[]>();
    for (const t of this.trajectories.slice(-250)) {
      if (!byTask.has(t.task)) byTask.set(t.task, []);
      byTask.get(t.task)!.push(t);
    }

    for (const [, list] of byTask) {
      const sorted = [...list].sort((a, b) => b.score - a.score);
      if (sorted.length < 2) continue;

      const best = sorted[0];
      for (let i = 1; i < Math.min(sorted.length, 5); i++) {
        const worse = sorted[i];
        if (best.score - worse.score >= this.config.minScoreDiffForPreference) {
          this.preferenceBuffer.push({
            prompt: best.task,
            chosen: best.fullTrace || best.finalAnswer,
            rejected: worse.fullTrace || worse.finalAnswer,
            scoreDiff: best.score - worse.score,
            verified: false,
          });
        }
      }
    }

    if (this.preferenceBuffer.length > 900) {
      this.preferenceBuffer = this.preferenceBuffer
        .sort((a, b) => Number(b.verified === true) - Number(a.verified === true) || b.scoreDiff - a.scoreDiff)
        .slice(0, 700);
    }
  }

  private async evolveWeightsPartial(): Promise<AdapterState | null> {
    const verifiedPairs = this.preferenceBuffer.filter((pair) => pair.verified === true);
    if (verifiedPairs.length < 50) {
      console.log("[HybridEvolution] Not enough preference pairs");
      return null;
    }

    const method = this.config.preferenceMethod;
    const rank = this.config.loRARank;

    const trainingResult = await this.callExternalTraining(
      verifiedPairs,
      method,
      rank
    );

    if (!trainingResult.success) {
      console.error("[HybridEvolution] Training failed:", trainingResult.error);
      return null;
    }

    const trainedBatch = verifiedPairs.slice(0, this.config.maxPairsPerTraining);
    const trainedSet = new Set(trainedBatch);
    this.preferenceBuffer = this.preferenceBuffer.filter((pair) => !trainedSet.has(pair));

    const adapter: AdapterState = {
      id: trainingResult.adapterId,
      method,
      rank,
      targetModules: [
        "q_proj", "k_proj", "v_proj", "o_proj",
        "gate_proj", "up_proj", "down_proj",
      ],
      performanceDelta: 0,
      trainedOnPairs: trainingResult.trainedPairs,
      createdAt: Date.now(),
      adapterUrl: trainingResult.adapterUrl,
      adapterPath: trainingResult.adapterPath,
      finalLoss: trainingResult.finalLoss,
    };

    this.currentAdapters.push(adapter);

    // Persist to Firebase
    try {
      const { getDb } = await import("./firebase");
      const db = getDb();
      if (db) {
        const docId = `user_main_${adapter.id}`.replace(/[^a-zA-Z0-9_-]/g, "_");
        await db.collection("omega_hybrid_adapters").doc(docId).set(
          { ...adapter, userId: "user_main", savedAt: Date.now() },
          { merge: true }
        );
      }
    } catch (err) {
      console.warn("[HybridEvolution] Failed to save adapter:", err);
    }

    return adapter;
  }

  private async callExternalTraining(
    pairs: PreferencePair[],
    method: PreferenceMethod,
    rank: number
  ): Promise<{
    success: boolean;
    adapterId: string;
    trainedPairs: number;
    adapterUrl?: string;
    adapterPath?: string;
    finalLoss?: number;
    error?: string;
  }> {
    const endpoint =
      this.config.externalTrainingEndpoint ||
      process.env.OMEGA_LORA_TRAINING_ENDPOINT ||
      "http://localhost:8000/train";

    const payload = {
      baseModel: process.env.OMEGA_BASE_MODEL || "Qwen/Qwen2.5-7B-Instruct",
      preferencePairs: pairs
        .filter((pair) => pair.verified === true)
        .slice(0, this.config.maxPairsPerTraining),
      method,
      rank,
      alpha: rank * 2,
      learningRate: method === "orpo" ? 8e-6 : 5e-5,
      numEpochs: 1,
      beta: 0.1,
      maxPairs: this.config.maxPairsPerTraining,
      outputName: `omega-${method}-gen${this.generation}-${Date.now().toString(36)}`,
    };

    let timeout: ReturnType<typeof setTimeout> | undefined;
    try {
      const controller = new AbortController();
      timeout = setTimeout(
        () => controller.abort(),
        this.config.trainingTimeoutMs || 30 * 60 * 1000
      );

      const response = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${process.env.OMEGA_TRAINING_SECRET || ""}`,
        },
        body: JSON.stringify(payload),
        signal: controller.signal,
      });

      if (!response.ok) {
        const errText = await response.text();
        return {
          success: false,
          adapterId: "",
          trainedPairs: 0,
          error: `Training service ${response.status}: ${errText}`,
        };
      }

      const result = await response.json();
      return {
        success: Boolean(result.success),
        adapterId: result.adapterId || payload.outputName,
        trainedPairs: result.trainedPairs || pairs.length,
        adapterUrl: result.adapterUrl,
        adapterPath: result.adapterPath,
        finalLoss: result.finalLoss,
        error: result.error,
      };
    } catch (err: any) {
      return {
        success: false,
        adapterId: "",
        trainedPairs: 0,
        error:
          err.name === "AbortError"
            ? "Training timeout"
            : err.message || "Failed to reach training endpoint",
      };
    } finally {
      if (timeout) clearTimeout(timeout);
    }
  }

  private createFallbackReport(): BenchmarkRunReport {
    // SIMULATED ONLY — deterministic-ish placeholder, not a real benchmark.
    // Must never authorize promote (see evolution-gate + sourceClass honesty).
    const baseScore = 50; // neutral fixed score, not Math.random theatre
    const delta = 0;

    return {
      id: `hybrid-fallback-SIMULATED-${this.generation}`,
      timestamp: Date.now(),
      generation: this.generation,
      overallScore: baseScore,
      deltaScore: delta,
      status: "regressed" as const, // refuse to claim improvement from fallback
      categories: {},
      totalTests: 0,
      passedTests: 0,
      avgLatencyMs: 0,
      recommendations: [
        "SIMULATED fallback – not real AutoBenchmarkEngine data",
        "Do not promote based on this report",
        "Run npm run benchmark with providers + npm run evolution-gate",
      ],
    } as BenchmarkRunReport;
  }

  // ---- Population helpers ----

  private calculateCompositeScore(metrics: IndividualMetrics): number {
    const accuracyNorm = metrics.accuracy / 100;
    const latencyPenalty = Math.min(metrics.latencyMs / 5000, 1) * 0.15;
    const costPenalty = Math.min(metrics.costEstimate / 0.05, 1) * 0.1;
    const stabilityBonus = metrics.stability * 0.12;

    return Number(
      (accuracyNorm - latencyPenalty - costPenalty + stabilityBonus).toFixed(4)
    );
  }

  private createIndividual(
    harnessVersion: string,
    harnessDiff: string | undefined,
    adapter: AdapterState | null | undefined,
    report: BenchmarkRunReport,
    parentIds: string[] = []
  ): Individual {
    const metrics: IndividualMetrics = {
      accuracy: report.overallScore,
      latencyMs: report.avgLatencyMs || 1200,
      costEstimate: 0.012,
      stability:
        report.status === "improved"
          ? 0.85
          : report.status === "stable"
          ? 0.7
          : 0.45,
    };

    return {
      id: `ind-${this.generation}-${Date.now().toString(36)}`,
      generationBorn: this.generation,
      parentIds,
      harnessVersion,
      harnessDiff,
      adapter: adapter || null,
      metrics,
      compositeScore: this.calculateCompositeScore(metrics),
      wins: 0,
      age: 0,
      createdAt: Date.now(),
      status: "active",
    };
  }

  private selectParent(): Individual | null {
    const candidates = this.population.filter((i) => i.status === "active");
    if (candidates.length === 0) return null;
    if (candidates.length === 1) return candidates[0];

    const tournament: Individual[] = [];
    for (let i = 0; i < this.tournamentSize; i++) {
      const idx = Math.floor(Math.random() * candidates.length);
      tournament.push(candidates[idx]);
    }

    tournament.sort((a, b) => b.compositeScore - a.compositeScore);
    tournament[0].wins += 1;
    return tournament[0];
  }

  private updatePopulationAndArchive(newIndividual: Individual) {
    this.population.push(newIndividual);
    this.population.forEach((ind) => (ind.age += 1));
    this.population.sort((a, b) => b.compositeScore - a.compositeScore);

    if (this.population.length > this.maxPopulationSize) {
      const eliminated = this.population.splice(this.maxPopulationSize);
      eliminated.forEach((ind) => (ind.status = "eliminated"));
    }

    this.paretoArchive = [...this.population]
      .sort((a, b) => b.compositeScore - a.compositeScore)
      .slice(0, this.maxArchiveSize);

    this.lineage.push({
      id: newIndividual.id,
      parentIds: newIndividual.parentIds,
      generation: newIndividual.generationBorn,
      score: newIndividual.compositeScore,
      method: this.config.preferenceMethod,
      summary: `${newIndividual.harnessVersion} | acc=${newIndividual.metrics.accuracy.toFixed(1)}`,
    });
  }

  private dominates(a: Individual, b: Individual): boolean {
    const aBetterOrEqual =
      a.metrics.accuracy >= b.metrics.accuracy &&
      a.metrics.latencyMs <= b.metrics.latencyMs &&
      a.metrics.costEstimate <= b.metrics.costEstimate &&
      a.metrics.stability >= b.metrics.stability;

    const aStrictlyBetter =
      a.metrics.accuracy > b.metrics.accuracy ||
      a.metrics.latencyMs < b.metrics.latencyMs ||
      a.metrics.costEstimate < b.metrics.costEstimate ||
      a.metrics.stability > b.metrics.stability;

    return aBetterOrEqual && aStrictlyBetter;
  }
}

// ====================== Singleton ======================

let globalHybridEngine: HybridSelfEvolutionEngine | null = null;

export function getHybridEvolutionEngine(
  config?: Partial<HybridEvolutionConfig>
): HybridSelfEvolutionEngine {
  if (!globalHybridEngine) {
    globalHybridEngine = new HybridSelfEvolutionEngine(config);
    globalHybridEngine.loadPersistedAdapters().catch(console.warn);
  }
  return globalHybridEngine;
}

export function resetHybridEvolutionEngine() {
  globalHybridEngine = null;
}
