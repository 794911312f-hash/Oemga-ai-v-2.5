/**
 * src/lib/omega/psi.ts
 * =============================================================================
 * Ψ (Psi) — درجة اتفاق / قرب (agreement score)، وليست احتمال صحة معايرة.
 * =============================================================================
 *
 * سياسة العرض (P1):
 *   - العربية: «درجة اتفاق» أو «معامل توافق»
 *   - الإنجليزية: «agreement score» — NOT “confidence”, “probability of correctness”,
 *     or calibrated P(correct) until a holdout calibration report says otherwise.
 *   - Ψ يقيس قرب المرشحين أو إشارة زمنية/بكسلية؛ اتفاق نماذج مترابطة قد يرفع Ψ
 *     دون أن تكون الإجابة صحيحة.
 *
 * خلفية الإصلاح: كانت في المستودع ثلاث صور للدالة، وإحداها تحمل الاسم نفسه
 * لصيغة مختلفة:
 *
 *   1) math.ts           :: clipExpPsi         -> exp(-d / (1.5*sigma + 0.05))   clamp [0.01, 1.0]
 *   2) ovoEngine.ts      :: computeOmegaV2Psi  -> exp(-1.2 * (d/sigma)^1.5)      clamp [0.05, 0.99]
 *   3) mediaOrchestrator :: clipExpPsi         -> الصيغة (2) باسم (1): تعارض تسمية
 *
 * الأثر المقيس: قيمة Ψ تختلف بحسب الوحدة المستدعاة بفارق يبلغ ~31 نقطة مئوية
 * (عند sigma=1.15 و d/sigma=1 -> 30.1% في القياسي مقابل 52.3% في التوافقي).
 * راجع psiDivergence().
 *
 * القاعدة الآن: تعريف واحد لكل صيغة، واسم واحد لكل تعريف.
 *   - computeOmegaV2Psi : القياسي — مسار الفيديو (OmegaV2 / OVO) كإشارة اتفاق/استقرار.
 *   - computePsiAffine  : المسار التوافقي/الدلالي (fusion, evidencePsi, omegaCore).
 * لا تُستبدل إحداهما بالأخرى: المقام ونطاق القصّ مختلفان.
 */

export const PSI_SOURCE_OF_TRUTH = "src/lib/omega/psi.ts";

/** Human-facing labels — keep UI/docs aligned with these strings. */
export const PSI_UI_LABEL_AR = "درجة اتفاق";
export const PSI_UI_LABEL_EN = "agreement score";
export const PSI_NOT_PROBABILITY_NOTE_AR =
  "Ψ درجة اتفاق بين المرشحين وليست احتمال صحة معايرة";
export const PSI_NOT_PROBABILITY_NOTE_EN =
  "Ψ is an agreement score among candidates, not a calibrated P(correct)";

/** القياسي: psi = clip(exp(-c * (delta/(sigma+eps))^p), psiMin, psiMax) — OmegaV2 agreement-style score. */
export function computeOmegaV2Psi(
  delta: number,
  sigma = 1.15,
  c = 1.2,
  p = 1.5,
  psiMin = 0.05,
  psiMax = 0.99,
  eps = 1e-8
): number {
  const normDelta = delta / (sigma + eps);
  const raw = Math.exp(-c * Math.pow(normDelta, p));
  return Math.max(psiMin, Math.min(psiMax, raw));
}

/** التوافقي (consensus): psi = clip(exp(-delta/(alpha*sigma+beta)), 0.01, 1.0) — سلوك math.ts قبل الإصلاح حرفيًا. */
export function computePsiAffine(
  delta: number,
  sigma: number,
  alpha = 1.5,
  beta = 0.05,
  eps = 1e-6
): number {
  const effectiveSigma = Math.max(sigma, eps);
  const raw = Math.exp(-delta / (effectiveSigma * alpha + beta));
  return Math.max(0.01, Math.min(1.0, raw));
}

export interface PsiDivergence {
  canonical: number;
  legacy: number;
  gapPoints: number;
}

/**
 * فرق الصيغتين بالنقاط المئوية (canonical - legacy) — للتشخيص والتقارير.
 * ملاحظة نطاق: الفرق يكبر كلما صغر sigma، لأن مقام الصيغة التوافقية محدود
 * بـ beta=0.05 بينما المقام القياسي بلا سقف.
 */
export function psiDivergence(delta: number, sigma: number): PsiDivergence {
  const canonical = computeOmegaV2Psi(delta, sigma);
  const legacy = computePsiAffine(delta, sigma);
  return { canonical, legacy, gapPoints: Number(((canonical - legacy) * 100).toFixed(2)) };
}
