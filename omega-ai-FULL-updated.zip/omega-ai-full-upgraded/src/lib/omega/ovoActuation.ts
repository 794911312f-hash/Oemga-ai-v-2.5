/**
 * ovoActuation — passes OVO controller outputs to the video generator.
 *
 * WHAT IS ACTUATED (clip level, two-pass):
 *   pass 0: generate with the user's parameters → measure the clip (ffmpeg) → OVO
 *   pass 1: if OVO intervened, regenerate with aggregated overrides:
 *             cfgScale, numSamplingSteps, extra prompt tokens, damped motionScore
 *   keep whichever pass measures better (roll back otherwise).
 *
 * WHAT IS NOT ACTUATED (and is reported in `notApplied`):
 *   latentBeliefBlendOmega (ω_t), aggressionFactor, IP-Adapter identity lock.
 *   These are PER-STEP quantities that need hooks on the sampler's latents; a black-box
 *   HTTP / CLI generator exposes none. A per-step integration (e.g. a diffusers
 *   `callback_on_step_end`) is required for them and is outside this module.
 *
 * The "better/worse" decision uses the same pixel-distribution proxies as OVO itself. It is
 * a consistency check, not an independent judgement of perceptual video quality.
 */
import { globalOmegaVideoOptimizer, type OVOTelemetryReport } from "./ovoEngine";
import type { OpenSoraRequest, OpenSoraGenerationResult } from "./openSoraBridge";
import type { VideoProbeResult } from "./videoProbe";

export interface AggregatedControls {
  cfgScale: number;
  numSamplingSteps: number;
  motionScore: number;
  promptTokens: string[];
  interventionFraction: number;
  jitterFraction: number;
}

export interface ClosedLoopDeps {
  generate: (req: OpenSoraRequest) => Promise<OpenSoraGenerationResult>;
  fetchVideo: (url: string) => Promise<Buffer>;
  analyze: (buf: Buffer) => Promise<VideoProbeResult>;
}

export interface PassSummary {
  pass: number;
  videoUrl?: string;
  meanPsiConfidence: number;
  interventionsTriggered: number;
  totalSteps: number;
}

export interface ClosedLoopResult {
  ok: boolean;
  actuated: boolean;
  chosenPass: number | null;
  reasonAr: string;
  applied?: { cfgScale: number; numSamplingSteps: number; motionScore: number; promptTokens: string[] };
  notApplied: string[];
  passes: PassSummary[];
  final?: OpenSoraGenerationResult;
}

const NOT_APPLIED = [
  "latentBeliefBlendOmega (ω_t): يحتاج خطّافًا على كمون كل خطوة",
  "aggressionFactor: متغيّر حلقة مغلقة لكل خطوة",
  "ipAdapterLockStrength: يحتاج صورة مرجعية ومحوّل IP-Adapter",
];

const median = (xs: number[]): number => {
  const s = [...xs].sort((a, b) => a - b);
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
};
const clamp = (x: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, x));

/** Reduce a per-step trace to one set of clip-level generator parameters. */
export function aggregateControls(
  report: OVOTelemetryReport,
  base: { cfgScale: number; numSamplingSteps: number; motionScore: number },
): AggregatedControls {
  const trace = report.stepsTrace;
  const n = Math.max(1, trace.length);

  // Defect-detector path (measured to be far more specific than the S/J path; see
  // docs/reports/ovo-detector-validation-*). Used whenever defect features were supplied.
  if (trace.some((s) => s.defect)) {
    const alarmed = trace.filter((s) => s.defect?.alarm);
    const has = (ch: string) => alarmed.some((s) => s.defect!.channels.includes(ch as any));
    let cfgScale = base.cfgScale, numSamplingSteps = base.numSamplingSteps, motionScore = base.motionScore;
    const tokens: string[] = [];
    // HEURISTIC mapping (design choice; its effect on a real generator is NOT validated):
    if (has("detailDrop")) { cfgScale += 1.0; numSamplingSteps += 10; tokens.push("sharp coherent textures", "fine detail"); }
    if (has("local")) { cfgScale += 0.5; tokens.push("clean artifact-free surfaces"); }
    if (has("change") || has("jitter")) { numSamplingSteps += 5; motionScore = Math.max(1, base.motionScore * 0.8); tokens.push("smooth optical flow", "temporal consistency"); }
    if (has("luma")) { tokens.push("stable consistent exposure and lighting"); }
    return {
      cfgScale: Number(clamp(cfgScale, 4.5, 11.5).toFixed(2)),
      numSamplingSteps: Math.min(50, numSamplingSteps),
      motionScore: Number(motionScore.toFixed(2)),
      promptTokens: [...new Set(tokens)].slice(0, 4),
      interventionFraction: alarmed.length / n,
      jitterFraction: trace.filter((s) => s.motion.jitterDetected).length / n,
    };
  }

  // Median over the steps where the controller actually changed something: robust to one spike.
  const touched = trace.filter(
    (s) =>
      s.promptControl.cfgScale !== base.cfgScale ||
      s.promptControl.denoisingSteps !== base.numSamplingSteps,
  );
  const cfgScale = touched.length
    ? clamp(median(touched.map((s) => s.promptControl.cfgScale)), 4.5, 11.5)
    : base.cfgScale;
  const numSamplingSteps = touched.length
    ? Math.min(50, Math.round(median(touched.map((s) => s.promptControl.denoisingSteps))))
    : base.numSamplingSteps;

  // Tokens that recur in >= 25% of steps (a one-off token is noise).
  const freq = new Map<string, number>();
  for (const s of trace) for (const t of new Set(s.promptControl.injectedTokens)) freq.set(t, (freq.get(t) ?? 0) + 1);
  const promptTokens = [...freq.entries()]
    .filter(([, c]) => c / n >= 0.25)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 4)
    .map(([t]) => t);

  const jitterFraction = trace.filter((s) => s.motion.jitterDetected).length / n;
  const motionScore =
    jitterFraction >= 0.25
      ? Number(clamp(base.motionScore * (1 - 0.4 * jitterFraction), 1.0, 10.0).toFixed(2))
      : base.motionScore;

  return {
    cfgScale: Number(cfgScale.toFixed(2)),
    numSamplingSteps,
    motionScore,
    promptTokens,
    interventionFraction: touched.length / n,
    jitterFraction,
  };
}

async function measure(
  deps: ClosedLoopDeps,
  result: OpenSoraGenerationResult,
  prompt: string,
  base: { cfgScale: number; numSamplingSteps: number },
): Promise<{ report: OVOTelemetryReport } | { error: string }> {
  if (!result.videoUrl) return { error: "المولّد لم يُرجع ملف فيديو (لا يوجد OPEN_SORA_ENDPOINT فعّال أو فشل الطلب)." };
  try {
    const buf = await deps.fetchVideo(result.videoUrl);
    const probe = await deps.analyze(buf);
    if (!probe.frameObservations.length) return { error: "لا إطارات قابلة للفك في الفيديو الناتج." };
    return {
      report: globalOmegaVideoOptimizer.runInferenceOptimizationLoop({
        prompt,
        baseCfg: base.cfgScale,
        baseDenoisingSteps: base.numSamplingSteps,
        frameObservations: probe.frameObservations,
      }),
    };
  } catch (e: any) {
    return { error: `تعذّر قياس الفيديو: ${e?.message ?? e}` };
  }
}

const summarize = (pass: number, r: OpenSoraGenerationResult, t: OVOTelemetryReport): PassSummary => ({
  pass,
  videoUrl: r.videoUrl,
  meanPsiConfidence: t.summaryMetrics.meanPsiConfidence,
  interventionsTriggered: t.summaryMetrics.interventionsTriggered,
  totalSteps: t.summaryMetrics.totalSteps,
});

export async function runClosedLoop(deps: ClosedLoopDeps, req: OpenSoraRequest): Promise<ClosedLoopResult> {
  const base = {
    cfgScale: req.cfgScale ?? 7.0,
    numSamplingSteps: req.numSamplingSteps ?? 30,
    motionScore: req.motionScore ?? 4.5,
  };

  const first = await deps.generate({ ...req, ...base });
  const m0 = await measure(deps, first, req.prompt, base);
  if ("error" in m0) {
    return { ok: true, actuated: false, chosenPass: 0, reasonAr: m0.error, notApplied: NOT_APPLIED, passes: [], final: first };
  }
  const s0 = summarize(0, first, m0.report);

  const hasDefect = m0.report.stepsTrace.some((st) => st.defect);
  // With defect features, only the defect detector triggers a regeneration (S/J alarms were
  // measured to fire on clean clips at a similar rate as on defective ones).
  const triggered = hasDefect ? m0.report.summaryMetrics.defectAlarmSteps > 0 : m0.report.summaryMetrics.interventionsTriggered > 0;
  if (!triggered) {
    return {
      ok: true, actuated: false, chosenPass: 0, notApplied: NOT_APPLIED, passes: [s0], final: first,
      reasonAr: "لم يرصد OVO عيبًا؛ أُبقيت المعاملات الأصلية ولم تُعَد المعالجة.",
    };
  }

  const agg = aggregateControls(m0.report, base);
  const changed =
    agg.cfgScale !== base.cfgScale ||
    agg.numSamplingSteps !== base.numSamplingSteps ||
    agg.motionScore !== base.motionScore ||
    agg.promptTokens.length > 0;
  if (!changed) {
    return {
      ok: true, actuated: false, chosenPass: 0, notApplied: NOT_APPLIED, passes: [s0], final: first,
      reasonAr: "رصد OVO تدخلًا لكنه لا يترجم إلى أي معامل قابل للتمرير؛ لا إعادة توليد.",
    };
  }

  const prompt1 = agg.promptTokens.length ? `${req.prompt}, ${agg.promptTokens.join(", ")}` : req.prompt;
  const second = await deps.generate({
    ...req,
    prompt: prompt1,
    cfgScale: agg.cfgScale,
    numSamplingSteps: agg.numSamplingSteps,
    motionScore: agg.motionScore,
    seed: first.config.seed, // same seed: isolates the effect of the new parameters
  });
  const applied = {
    cfgScale: agg.cfgScale,
    numSamplingSteps: agg.numSamplingSteps,
    motionScore: agg.motionScore,
    promptTokens: agg.promptTokens,
  };

  const m1 = await measure(deps, second, req.prompt, base);
  if ("error" in m1) {
    return {
      ok: true, actuated: true, chosenPass: 0, applied, notApplied: NOT_APPLIED, passes: [s0], final: first,
      reasonAr: `أُعيد التوليد بمعاملات معدّلة لكن لم يُمكن قياس النتيجة (${m1.error}) فأُبقي المقطع الأول.`,
    };
  }
  const s1 = summarize(1, second, m1.report);
  const better =
    s1.meanPsiConfidence >= s0.meanPsiConfidence - 0.005 &&
    s1.interventionsTriggered <= s0.interventionsTriggered;

  return {
    ok: true,
    actuated: true,
    chosenPass: better ? 1 : 0,
    applied,
    notApplied: NOT_APPLIED,
    passes: [s0, s1],
    final: better ? second : first,
    reasonAr: better
      ? "التمرير الثاني بمعاملات OVO أفضل أو مساوٍ حسب نفس المقاييس البكسلية فاعتُمد."
      : "التمرير الثاني لم يتحسّن حسب المقاييس البكسلية فأُرجع المقطع الأول (تراجع).",
  };
}
