/**
 * ovoDefects — frame-level defect detector for OVO.
 *
 * WHY THIS EXISTS: measured on ffmpeg clips with injected faults
 * (docs/reports/ovo-detector-validation-*), the geometric-shift score S (KL of the
 * 8 regional-mean-luminance distribution) reacted only to global brightness changes.
 * This detector instead uses features that move when the faults do:
 *
 *   change      mean |frame_t − frame_{t−1}|            → hard cuts, noise, shake, flicker
 *   local       max over 4×4-px cells of the deviation  → localized artifacts
 *               from the per-cell running median
 *   detailDrop  fall of mean gradient magnitude         → blur / loss of texture
 *   luma        |shift| of mean brightness              → exposure / flicker
 *
 * Each statistic is a ROBUST z-score against the clip's own recent history (median / MAD with a
 * floor), so no absolute scale is assumed. Thresholds were calibrated on CLEAN clips only
 * (scripts/calibrate-ovo-defects.ts) using seeds disjoint from the validation seeds.
 *
 * Limits: 64×36 gray probe at 2 fps. Defects smaller than a few probe pixels, or changes slower
 * than the history window, are invisible. Calibrated on synthetic ffmpeg content only.
 */

export const DEFECT_W = 64;
export const DEFECT_H = 36;
const CELL = 4;
const CELLS_X = DEFECT_W / CELL; // 16
const CELLS_Y = DEFECT_H / CELL; // 9

export interface DefectFrameFeatures {
  luma: number;
  detail: number;
  change: number;
  cells: number[]; // 144 cell means, 0..1
}

export function extractDefectFeatures(
  frame: Uint8Array,
  prev: Uint8Array | null,
): DefectFrameFeatures {
  const W = DEFECT_W, H = DEFECT_H, n = W * H;
  let sum = 0, grad = 0, diff = 0;
  const cells = new Array(CELLS_X * CELLS_Y).fill(0);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const i = y * W + x, v = frame[i];
      sum += v;
      if (x + 1 < W) grad += Math.abs(frame[i + 1] - v);
      if (y + 1 < H) grad += Math.abs(frame[i + W] - v);
      if (prev) diff += Math.abs(v - prev[i]);
      cells[Math.floor(y / CELL) * CELLS_X + Math.floor(x / CELL)] += v;
    }
  }
  return {
    luma: sum / n / 255,
    detail: grad / (2 * n) / 255,
    change: prev ? diff / n / 255 : 0,
    cells: cells.map((c) => c / (CELL * CELL) / 255),
  };
}

/**
 * Calibrated on 120 clean synthetic clips (60 smooth + 60 textured, seeds 90000+) by
 * scripts/calibrate-ovo-defects.ts: tau = max(3, 1.15 × p97 of per-clip max z).
 */
export const DEFECT_THRESHOLDS = {
  change: 4.3,
  local: 7.54,
  detailDrop: 3.0,
  luma: 9.45,
};
/**
 * Strict jitter channel (merged from the legacy motion controller). The legacy rule
 * (psi < 0.55 OR |D| > 0.35) fired on 17–23% of clean clips; these stricter limits are
 * calibrated on clean synthetic clips by scripts/calibrate-ovo-defects.ts.
 *
 * DISABLED BY DEFAULT: on a real handheld phone video (docs: FIXES.md) this channel fired on 6 of 20
 * steps vs 1 for all other channels together — ψ swings 0.05–0.99 on natural footage, so thresholds
 * calibrated on smooth synthetic clips do not transfer. Enable only after calibrating on your footage.
 */
export const DEFECT_JITTER = { enabled: false, psi: 0.218, d: 0.35 };

/** Floors on the robust scale (1.4826·MAD) so a perfectly static history cannot divide by ~0. */
export const DEFECT_FLOORS = { change: 0.003, local: 0.01, detail: 0.003, luma: 0.003 };
export const DEFECT_WARMUP = 6;
const HISTORY = 10;

export interface DefectMetrics {
  warm: boolean;
  zChange: number;
  zLocal: number;
  zDetailDrop: number;
  zLuma: number;
  channels: Array<"change" | "local" | "detailDrop" | "luma" | "jitter">;
  alarm: boolean;
}

const median = (xs: number[]) => {
  const s = [...xs].sort((a, b) => a - b);
  const m = s.length >> 1;
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
};
function robustZ(x: number, hist: number[], floor: number): number {
  const m = median(hist);
  const mad = median(hist.map((h) => Math.abs(h - m)));
  return (x - m) / Math.max(1.4826 * mad, floor);
}

export class OmegaDefectDetector {
  private feats: DefectFrameFeatures[] = [];
  private localHist: number[] = [];
  private thresholds: typeof DEFECT_THRESHOLDS;

  constructor(thresholds: typeof DEFECT_THRESHOLDS = DEFECT_THRESHOLDS) {
    this.thresholds = thresholds;
  }

  evaluate(f: DefectFrameFeatures): DefectMetrics {
    const past = this.feats.slice(-HISTORY);
    // Local deviation: per-cell deviation from the running median of the past frames.
    let local = 0;
    if (past.length >= 3) {
      for (let c = 0; c < f.cells.length; c++) {
        const base = median(past.map((p) => p.cells[c]));
        local = Math.max(local, Math.abs(f.cells[c] - base));
      }
    }
    const warm = past.length >= DEFECT_WARMUP && this.localHist.length >= 3;
    let zChange = 0, zLocal = 0, zDetailDrop = 0, zLuma = 0;
    if (warm) {
      zChange = robustZ(f.change, past.slice(1).map((p) => p.change), DEFECT_FLOORS.change);
      zLocal = robustZ(local, this.localHist.slice(-HISTORY), DEFECT_FLOORS.local);
      zDetailDrop = -robustZ(f.detail, past.map((p) => p.detail), DEFECT_FLOORS.detail);
      zLuma = Math.abs(robustZ(f.luma, past.map((p) => p.luma), DEFECT_FLOORS.luma));
    }
    const channels: DefectMetrics["channels"] = [];
    if (zChange > this.thresholds.change) channels.push("change");
    if (zLocal > this.thresholds.local) channels.push("local");
    if (zDetailDrop > this.thresholds.detailDrop) channels.push("detailDrop");
    if (zLuma > this.thresholds.luma) channels.push("luma");

    this.feats.push(f);
    if (past.length >= 3) this.localHist.push(local);
    return {
      warm,
      zChange: Number(zChange.toFixed(3)),
      zLocal: Number(zLocal.toFixed(3)),
      zDetailDrop: Number(zDetailDrop.toFixed(3)),
      zLuma: Number(zLuma.toFixed(3)),
      channels,
      alarm: channels.length > 0,
    };
  }
}
