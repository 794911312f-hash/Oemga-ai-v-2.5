/**
 * Reads evolution-gate status written by scripts/evolution-gate.ts
 * Rejects PASS if missing sha256, latest, expiresAt, expired, or hash mismatch.
 */
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

export type GateDecision = "PASS" | "REJECT" | "INSUFFICIENT" | "UNKNOWN";

export interface GateStatusPayload {
  decision?: string;
  reason?: string;
  latest?: string | null;
  sha256?: string | null;
  expiresAt?: string | null;
  at?: string;
}

export function readEvolutionGateStatus(
  cwd: string = process.cwd()
): { decision: GateDecision; reason?: string } {
  try {
    const statusPath = path.resolve(cwd, "docs/reports/.evolution-gate-status.json");
    if (!fs.existsSync(statusPath)) {
      return { decision: "UNKNOWN", reason: "status file missing — run npm run evolution-gate" };
    }
    const status = JSON.parse(fs.readFileSync(statusPath, "utf-8")) as GateStatusPayload;
    const d = status?.decision;

    if (d === "PASS") {
      if (!status.sha256 || !status.latest || !status.expiresAt) {
        return {
          decision: "REJECT",
          reason: "PASS requires sha256, latest, and expiresAt",
        };
      }
      const exp = Date.parse(status.expiresAt);
      if (!Number.isFinite(exp) || Date.now() > exp) {
        return { decision: "REJECT", reason: "evolution gate status expired" };
      }
      const reportPath = path.resolve(cwd, "docs/reports", status.latest);
      if (!fs.existsSync(reportPath)) {
        return { decision: "REJECT", reason: "bound report missing" };
      }
      const body = fs.readFileSync(reportPath, "utf-8");
      const hash = crypto.createHash("sha256").update(body).digest("hex");
      if (hash !== status.sha256) {
        return { decision: "REJECT", reason: "report sha256 mismatch" };
      }
      return { decision: "PASS", reason: status?.reason };
    }

    if (d === "REJECT" || d === "INSUFFICIENT") {
      return { decision: d, reason: status?.reason };
    }
    return { decision: "UNKNOWN", reason: "invalid status payload" };
  } catch (e: any) {
    return { decision: "UNKNOWN", reason: e?.message ?? String(e) };
  }
}

export function isEvolutionGatePass(cwd?: string): boolean {
  return readEvolutionGateStatus(cwd).decision === "PASS";
}
