/**
 * src/lib/omega/intelligentRouter.ts
 * =============================================================================
 * Intelligent Model Router — hybrid UCB-inspired heuristic + performance ledger
 * =============================================================================
 *
 * Honest labels:
 *  - seedDefaultPerformance() writes **seeded_prior** rows (not measured history)
 *  - Real stats only after updatePerformance() / ledger hydration from storage
 *  - Score is UCB-inspired hybrid, not textbook UCB1 or Thompson Sampling
 */

import { hashEmbed } from "./embeddings";
import { cosine, softmax } from "./math";
import { loadModelPerformanceRecords, saveModelPerformanceRecord } from "./modelLedger";

export interface ModelPerformanceRecord {
  modelId: string;
  domain: string;
  totalCalls: number;
  successfulCalls: number;
  avgPsi: number;
  avgLatencyMs: number;
  eloRating: number;
  lastUpdated: number;
  /** true = hand-tuned prior, not measured traffic */
  seededPrior?: boolean;
}

export interface RouteDecision {
  selectedModel: string;
  candidatePool: string[];
  domain: string;
  confidenceScore: number;
  reasoning: string;
  expectedLatencyMs: number;
  modelProbabilities: Record<string, number>;
}

export class IntelligentModelRouter {
  // Model performance ledger: domain::modelId -> Record
  private ledger = new Map<string, ModelPerformanceRecord>();
  private hydrated = false;
  private hydrationPromise: Promise<void> | null = null;
  private defaultModels = [
    "gemini-3.8-flash",
    "qwen-2-5-compat",
    "deepseek-r1-compat",
    "gpt-4o-compat",
    "llama-3-3-compat",
    "omega-open-local",
    "claude-3-5-sonnet-compat",
    "grok-compat",
  ];

  constructor() {
    this.seedDefaultPerformance();
  }

  private keyOf(domain: string, modelId: string): string {
    return `${domain}::${modelId}`;
  }

  private seedDefaultPerformance(): void {
    const domains = [
      "math_logic",
      "code",
      "science_factual",
      "creative",
      "news_realtime",
      "general",
      "open_problem",
    ];

    for (const domain of domains) {
      for (const model of this.defaultModels) {
        const rec: ModelPerformanceRecord = {
          modelId: model,
          domain,
          totalCalls: 0,
          successfulCalls: 0,
          // Neutral priors: no model/domain is declared superior before the
          // router observes verified provider-backed outcomes.
          avgPsi: 0.5,
          avgLatencyMs: 500,
          eloRating: 1500,
          lastUpdated: Date.now(),
          seededPrior: true,
        };

        this.ledger.set(this.keyOf(domain, model), rec);
      }
    }
  }

  /** Load durable records once before the first routing decision. */
  async hydrate(): Promise<void> {
    if (this.hydrated) return;
    if (!this.hydrationPromise) {
      this.hydrationPromise = loadModelPerformanceRecords()
        .then((records) => {
          for (const record of records) this.ledger.set(this.keyOf(record.domain, record.modelId), record);
          this.hydrated = true;
        })
        .catch((error) => {
          console.warn("[Omega Router] Ledger hydration failed; seeded records retained:", error);
          this.hydrated = true;
        });
    }
    await this.hydrationPromise;
  }

  /**
   * Intelligently selects the best model ensemble based on empirical history
   */
  route(question: string, domain = "general", poolSize = 3): RouteDecision {
    const records = this.defaultModels.map((m) => {
      const rec = this.ledger.get(this.keyOf(domain, m));
      if (rec) return rec;
      return {
        modelId: m,
        domain,
        totalCalls: 1,
        successfulCalls: 1,
        avgPsi: 0.8,
        avgLatencyMs: 500,
        eloRating: 1500,
        lastUpdated: Date.now(),
      };
    });

    // Compute Empirical UCB1 Score for each model:
    // Score = (SuccessRate * 0.4) + (AvgPsi * 0.4) + (NormalizedElo * 0.2) + UCB_Exploration
    const totalDomainCalls = records.reduce((sum, r) => sum + r.totalCalls, 0) || 1;

    const scored = records.map((r) => {
      const successRate = r.totalCalls > 0 ? r.successfulCalls / r.totalCalls : 0.5;
      const eloFactor = (r.eloRating - 1200) / 800; // Normalizes 1200..2000 to ~0..1
      const exploration = Math.sqrt((2 * Math.log(totalDomainCalls)) / Math.max(1, r.totalCalls));
      const compositeScore =
        0.35 * successRate + 0.35 * r.avgPsi + 0.2 * eloFactor + 0.1 * exploration;

      return {
        record: r,
        score: compositeScore,
      };
    });

    // Softmax probabilities
    const scores = scored.map((s) => s.score);
    const probs = softmax(scores, 0.4);
    const probMap: Record<string, number> = {};
    scored.forEach((s, idx) => {
      probMap[s.record.modelId] = Number(probs[idx].toFixed(4));
    });

    // Sort descending by score
    scored.sort((a, b) => b.score - a.score);

    const winner = scored[0];
    const candidatePool = scored.slice(0, poolSize).map((s) => s.record.modelId);

    const reasoning = `تم التوجيه إلى [${winner.record.modelId}] بناءً على سجل الأداء التجريبي في مجال ${domain}: معدل نجاح ${(
      (winner.record.successfulCalls / Math.max(1, winner.record.totalCalls)) *
      100
    ).toFixed(1)}%، تصنيف ELO ${winner.record.eloRating}، ومتوسط توافق ψ=${winner.record.avgPsi}.`;

    return {
      selectedModel: winner.record.modelId,
      candidatePool,
      domain,
      confidenceScore: Number(winner.score.toFixed(4)),
      reasoning,
      expectedLatencyMs: winner.record.avgLatencyMs,
      modelProbabilities: probMap,
    };
  }

  /**
   * Updates performance records after an actual inference round
   */
  recordOutcome(
    modelId: string,
    domain: string,
    success: boolean,
    psi: number,
    latencyMs = 450
  ): ModelPerformanceRecord {
    const key = this.keyOf(domain, modelId);
    let rec = this.ledger.get(key);

    if (!rec) {
      rec = {
        modelId,
        domain,
        totalCalls: 0,
        successfulCalls: 0,
        avgPsi: 0.8,
        avgLatencyMs: latencyMs,
        eloRating: 1500,
        lastUpdated: Date.now(),
      };
      this.ledger.set(key, rec);
    }

    const n = rec.totalCalls;
    rec.totalCalls += 1;
    if (success) rec.successfulCalls += 1;
    rec.seededPrior = false; // measured traffic replaces prior

    // Moving averages
    rec.avgPsi = Number(((rec.avgPsi * n + psi) / (n + 1)).toFixed(4));
    rec.avgLatencyMs = Math.round((rec.avgLatencyMs * n + latencyMs) / (n + 1));

    // Dynamic ELO update (K-factor = 24)
    const k = 24;
    const expectedWin = 1 / (1 + Math.pow(10, (1500 - rec.eloRating) / 400));
    const actualWin = success ? 1 : 0;
    rec.eloRating = Math.round(rec.eloRating + k * (actualWin - expectedWin));
    rec.lastUpdated = Date.now();
    void saveModelPerformanceRecord(rec);

    return rec;
  }

  getLedger(domain?: string): ModelPerformanceRecord[] {
    const all = [...this.ledger.values()];
    if (!domain) return all;
    return all.filter((r) => r.domain === domain);
  }
}
