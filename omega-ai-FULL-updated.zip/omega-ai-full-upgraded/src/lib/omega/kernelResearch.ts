/**
 * Research-backed extensions for Omega Kernel.
 *
 * These functions are deliberately model-agnostic. They consume observable
 * outputs and traces only; they do not claim access to hidden states or KV-cache.
 *
 * Linked to spectralConsensus.ts for true spectral (algebraic connectivity,
 * Cheeger bounds, Perron weights) when answer vectors are available.
 */

import { computeSpectralConsensus, type SpectralConsensusResult } from "./spectralConsensus";

export interface ReliabilityRecord {
  score: number;
  uncertainty: number;
  samples: number;
}

export interface ResourceBudget {
  remainingTokens: number;
  estimatedRoundCost: number;
  disagreement: number;
  disagreementThreshold?: number;
  consensusTolerance?: number;
  highDisagreementContraction?: number;
  lowDisagreementContraction?: number;
}

export interface ResourceAwarePlan {
  source: "computed";
  stopReason: "consensus_reached" | "budget_exhausted" | "budget_insufficient" | "round_limit";
  initialDisagreement: number;
  targetDisagreement: number;
  estimatedRounds: number;
  estimatedTokenCost: number;
  remainingTokens: number;
  disagreementThreshold: number;
}

export interface SpectralTraceCertificate {
  source: "observed" | "insufficient_trace";
  samples: number;
  disagreement: number[];
  estimatedRadius: number | null;
  spectralGap: number | null;
  estimatedRounds: number | null;
  certified: boolean;
  limitation: string;
}

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

/** Confidence-weight table: high score and low uncertainty produce higher trust. */
export function reliabilityTrust(record?: ReliabilityRecord): number {
  if (!record || record.samples <= 0) return 1;
  const score = clamp(record.score, 0, 1);
  const uncertainty = clamp(record.uncertainty, 0, 1);
  const sampleFactor = 1 - Math.exp(-record.samples / 8);
  return clamp(0.5 + 0.5 * (score * (1 - uncertainty) * sampleFactor), 0.5, 1);
}

/** Online update suitable for a per-model, per-domain reliability ledger. */
export function updateReliabilityRecord(
  previous: ReliabilityRecord | undefined,
  observedScore: number,
  observedUncertainty = 0.25
): ReliabilityRecord {
  const nextScore = clamp(observedScore, 0, 1);
  const nextUncertainty = clamp(observedUncertainty, 0, 1);
  if (!previous || previous.samples <= 0) {
    return { score: nextScore, uncertainty: nextUncertainty, samples: 1 };
  }
  const n = previous.samples;
  return {
    score: (previous.score * n + nextScore) / (n + 1),
    uncertainty: (previous.uncertainty * n + nextUncertainty) / (n + 1),
    samples: n + 1,
  };
}

/**
 * Resource-aware stopping plan inspired by switched consensus control.
 * It is a planning estimate, not a guarantee about an LLM debate.
 */
export function computeResourceAwarePlan(input: ResourceBudget): ResourceAwarePlan {
  const initial = clamp(input.disagreement, 0, 1);
  const target = clamp(input.consensusTolerance ?? 0.05, 1e-4, 1);
  const threshold = clamp(input.disagreementThreshold ?? 0.2, target, 1);
  const cost = Math.max(1, input.estimatedRoundCost);
  const budget = Math.max(0, input.remainingTokens);
  if (initial <= target) {
    return { source: "computed", stopReason: "consensus_reached", initialDisagreement: initial, targetDisagreement: target, estimatedRounds: 0, estimatedTokenCost: 0, remainingTokens: budget, disagreementThreshold: threshold };
  }

  const high = clamp(input.highDisagreementContraction ?? 0.82, 0.01, 0.99);
  const low = clamp(input.lowDisagreementContraction ?? 0.92, 0.01, 0.99);
  const highRounds = initial > threshold ? Math.max(0, Math.ceil(Math.log(threshold / initial) / Math.log(high))) : 0;
  const lowStart = Math.min(initial, threshold);
  const lowRounds = Math.max(0, Math.ceil(Math.log(target / Math.max(lowStart, target)) / Math.log(low)));
  const rounds = highRounds + lowRounds;
  const estimatedCost = rounds * cost;
  const maxAffordable = Math.floor(budget / cost);
  const stopReason = rounds === 0
    ? "consensus_reached"
    : maxAffordable < rounds
      ? (maxAffordable === 0 ? "budget_insufficient" : "budget_exhausted")
      : "consensus_reached";
  return {
    source: "computed",
    stopReason,
    initialDisagreement: initial,
    targetDisagreement: target,
    estimatedRounds: Math.min(rounds, maxAffordable),
    estimatedTokenCost: Math.min(estimatedCost, budget),
    remainingTokens: Math.max(0, budget - Math.min(estimatedCost, budget)),
    disagreementThreshold: threshold,
  };
}

function disagreement(vectors: number[][]): number {
  if (vectors.length < 2) return 0;
  const dim = Math.max(...vectors.map(v => v.length));
  const centroid = new Array(dim).fill(0);
  for (const vector of vectors) for (let i = 0; i < dim; i++) centroid[i] += (vector[i] ?? 0) / vectors.length;
  return vectors.reduce((sum, vector) => {
    const distance = Math.sqrt(vector.reduce((s, x, i) => s + (x - (centroid[i] ?? 0)) ** 2, 0));
    return sum + distance;
  }, 0) / vectors.length;
}

/**
 * Estimates the contraction of disagreement from actual recorded traces.
 * This is intentionally scalar and conservative; a full Koopman/EDMD model
 * requires many aligned time-series observations and is not inferred here.
 */
export function estimateSpectralTraceCertificate(trace: number[][][]): SpectralTraceCertificate {
  const values = trace.map(disagreement);
  if (values.length < 3 || values.some(v => !Number.isFinite(v))) {
    return { source: "insufficient_trace", samples: values.length, disagreement: values, estimatedRadius: null, spectralGap: null, estimatedRounds: null, certified: false, limitation: "At least three aligned disagreement observations are required; a single candidate snapshot is not a spectral certificate." };
  }
  const ratios: number[] = [];
  for (let i = 1; i < values.length; i++) {
    if (values[i - 1] > 1e-8 && values[i] >= 0) ratios.push(clamp(values[i] / values[i - 1], 0, 2));
  }
  const radius = ratios.length ? Math.min(0.999, Math.max(...ratios)) : null;
  const initial = values[0];
  const target = Math.max(values[values.length - 1], 1e-4);
  const rounds = radius !== null && radius > 1e-8 && radius < 1 ? Math.ceil(Math.log(target / Math.max(initial, target)) / Math.log(radius)) : null;
  return { source: "observed", samples: values.length, disagreement: values, estimatedRadius: radius, spectralGap: radius === null ? null : 1 - radius, estimatedRounds: rounds === null ? null : Math.max(0, rounds), certified: radius !== null && radius < 1, limitation: "Empirical scalar contraction from supplied traces; not a proof for unseen prompts or a full EDMD Koopman certificate." };
}

/**
 * True spectral certificate from answer embedding vectors.
 * Uses the algebraic connectivity / Cheeger / Perron machinery of spectralConsensus.ts
 * instead of a scalar contraction ratio.
 */
export interface VectorSpectralCertificate {
  source: "spectral";
  n: number;
  cohesion: number;
  spectralGap: number;
  algebraicConnectivity: number;
  cheeger: { lower: number; upper: number };
  k: number;
  components: number;
  perronRoot: number;
  consensusIndex: number;
  outliers: number[];
  lowSupport: number[];
  weights: number[];
  certified: boolean;
  limitation: string;
}

export function computeVectorSpectralCertificate(
  vectors: number[][],
  opts?: Parameters<typeof computeSpectralConsensus>[1]
): VectorSpectralCertificate {
  if (!vectors.length) {
    return {
      source: "spectral",
      n: 0,
      cohesion: 0,
      spectralGap: 0,
      algebraicConnectivity: 0,
      cheeger: { lower: 0, upper: 0 },
      k: 0,
      components: 0,
      perronRoot: 0,
      consensusIndex: -1,
      outliers: [],
      lowSupport: [],
      weights: [],
      certified: false,
      limitation: "No vectors supplied.",
    };
  }
  const sc: SpectralConsensusResult = computeSpectralConsensus(vectors, opts);
  // Certified when the graph is connected (or nearly) and cohesion is non-trivial.
  const certified = sc.components === 1 && sc.cohesion > 0.15;
  return {
    source: "spectral",
    n: sc.n,
    cohesion: sc.cohesion,
    spectralGap: sc.spectralGap,
    algebraicConnectivity: sc.algebraicConnectivity,
    cheeger: sc.cheeger,
    k: sc.k,
    components: sc.components,
    perronRoot: sc.perronRoot,
    consensusIndex: sc.consensusIndex,
    outliers: sc.outliers,
    lowSupport: sc.lowSupport,
    weights: sc.weights,
    certified,
    limitation:
      "Certificate from the normalised Laplacian spectrum of the affinity graph on the supplied vectors. " +
      "Meaning is only as good as the embedding; with hashEmbed this is lexical/structural similarity, not deep semantics.",
  };
}
