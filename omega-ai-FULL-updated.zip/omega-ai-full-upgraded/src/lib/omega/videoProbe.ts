import { execFile, spawn } from "node:child_process";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { promisify } from "node:util";
import type { OVOFrameObservation } from "./ovoEngine";
import { DEFECT_W, DEFECT_H, extractDefectFeatures } from "./ovoDefects";

const execFileAsync = promisify(execFile);
const FRAME_WIDTH = 16;
const FRAME_HEIGHT = 8;
const BYTES_PER_FRAME = FRAME_WIDTH * FRAME_HEIGHT;

export interface VideoProbeResult {
  metadata: {
    durationSec: number | null;
    width: number | null;
    height: number | null;
    fps: number | null;
    codec: string | null;
    sizeBytes: number;
  };
  frameObservations: OVOFrameObservation[];
  limitations: string[];
}

function parseRate(value: unknown): number | null {
  if (typeof value !== "string" || !value.includes("/")) return null;
  const [a, b] = value.split("/").map(Number);
  return Number.isFinite(a) && Number.isFinite(b) && b !== 0 ? Number((a / b).toFixed(3)) : null;
}

function patchEnergies(frame: Buffer): number[] {
  const patches = Array.from({ length: 8 }, () => 0);
  const counts = Array.from({ length: 8 }, () => 0);
  for (let i = 0; i < BYTES_PER_FRAME; i++) {
    const x = i % FRAME_WIDTH;
    const y = Math.floor(i / FRAME_WIDTH);
    const patch = Math.min(1, Math.floor((y * 2) / FRAME_HEIGHT)) * 4 + Math.min(3, Math.floor((x * 4) / FRAME_WIDTH));
    patches[patch] += frame[i] / 255;
    counts[patch] += 1;
  }
  return patches.map((sum, i) => sum / Math.max(1, counts[i]));
}

function velocity(previous: Buffer | null, current: Buffer): number {
  if (!previous) return 0;
  let total = 0;
  for (let i = 0; i < Math.min(previous.length, current.length); i++) total += Math.abs(previous[i] - current[i]) / 255;
  return Math.min(1, total / Math.max(1, current.length) * 2);
}

/** Largest upload accepted for analysis. The probe downscales inside ffmpeg (64×36 / 16×8), so a
 *  phone-sized 1080p clip is fine; the cap, the 60 s ffmpeg timeout and the 13 s read window bound the cost. */
export const MAX_VIDEO_BYTES = 64 * 1024 * 1024;
const FFMPEG_TIMEOUT_MS = 60_000;

async function extractFrames(inputPath: string, maxFrames: number, width = FRAME_WIDTH, height = FRAME_HEIGHT): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const child = spawn("ffmpeg", [
      "-v", "error", "-nostdin", "-i", inputPath, "-t", "13",
      "-vf", `fps=2,scale=${width}:${height},format=gray`,
      "-frames:v", String(maxFrames), "-f", "rawvideo", "pipe:1",
    ]);
    const chunks: Buffer[] = [];
    let stderr = "";
    child.stdout.on("data", (chunk: Buffer) => chunks.push(Buffer.from(chunk)));
    child.stderr.on("data", (chunk: Buffer) => { stderr += chunk.toString(); });
    const timer = setTimeout(() => { child.kill("SIGKILL"); reject(new Error("ffmpeg timed out while decoding the video")); }, FFMPEG_TIMEOUT_MS);
    child.on("error", (e) => { clearTimeout(timer); reject(e); });
    child.on("close", (code) => { clearTimeout(timer); code === 0 ? resolve(Buffer.concat(chunks)) : reject(new Error(stderr || `ffmpeg exited with ${code}`)); });
  });
}

export async function analyzeVideoBuffer(buffer: Buffer, maxFrames = 24): Promise<VideoProbeResult> {
  if (!Buffer.isBuffer(buffer) || buffer.length === 0) throw new Error("Video buffer is empty");
  if (buffer.length > MAX_VIDEO_BYTES) throw new Error(`Video exceeds the ${MAX_VIDEO_BYTES / 1024 / 1024} MB analysis limit`);
  const safeFrameCount = Math.max(1, Math.min(24, Math.floor(maxFrames) || 24));
  const dir = await mkdtemp(join(tmpdir(), "omega-video-"));
  const inputPath = join(dir, "input.bin");
  try {
    await writeFile(inputPath, buffer);
    const { stdout } = await execFileAsync("ffprobe", [
      "-v", "error", "-show_entries", "format=duration:stream=width,height,avg_frame_rate,codec_name,codec_type",
      "-of", "json", inputPath,
    ], { maxBuffer: 256 * 1024, timeout: 20_000 });
    const probe = JSON.parse(stdout);
    const stream = (probe.streams || []).find((s: any) => s.codec_type === "video") || probe.streams?.[0] || {};
    const raw = await extractFrames(inputPath, safeFrameCount);
    // Second, higher-resolution pass for the defect detector (blur / local artifacts need > 16×8).
    const rawDefect = await extractFrames(inputPath, safeFrameCount, DEFECT_W, DEFECT_H);
    const defectBytes = DEFECT_W * DEFECT_H;
    const observations: OVOFrameObservation[] = [];
    let previous: Buffer | null = null;
    let previousDefect: Buffer | null = null;
    for (let offset = 0, index = 1; offset + BYTES_PER_FRAME <= raw.length; offset += BYTES_PER_FRAME, index++) {
      const frame = raw.subarray(offset, offset + BYTES_PER_FRAME);
      const patches = patchEnergies(frame);
      const rawVelocity = velocity(previous, frame);
      const dOff = (index - 1) * defectBytes;
      const dFrame = dOff + defectBytes <= rawDefect.length ? rawDefect.subarray(dOff, dOff + defectBytes) : null;
      const defect = dFrame ? extractDefectFeatures(dFrame, previousDefect) : undefined;
      if (dFrame) previousDefect = dFrame;
      observations.push({ frameIndex: index, patchEnergies: patches, rawVelocity, colorDrift: rawVelocity, defect });
      previous = frame;
    }
    return {
      metadata: {
        durationSec: Number.isFinite(Number(probe.format?.duration)) ? Number(Number(probe.format.duration).toFixed(3)) : null,
        width: Number.isFinite(Number(stream.width)) ? Number(stream.width) : null,
        height: Number.isFinite(Number(stream.height)) ? Number(stream.height) : null,
        fps: parseRate(stream.avg_frame_rate),
        codec: typeof stream.codec_name === "string" ? stream.codec_name : null,
        sizeBytes: buffer.length,
      },
      frameObservations: observations,
      limitations: [
        "تم القياس من إطارات رمادية منخفضة الدقة 16×8؛ لا يوجد تحليل وجه أو هوية شخصية.",
        "الحركة مشتقة من فرق الإضاءة بين الإطارات وليست Optical Flow كاملًا.",
      ],
    };
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
}

export function decodeVideoBase64(value: unknown): Buffer {
  if (typeof value !== "string") throw new Error("videoBase64 must be a string");
  const clean = value.replace(/^data:video\/[^;]+;base64,/, "");
  if (!/^[A-Za-z0-9+/=\r\n]+$/.test(clean)) throw new Error("Invalid base64 video payload");
  return Buffer.from(clean, "base64");
}
