/**
 * src/lib/omega/cognitiveWorkspace/coreBridge.ts
 * =============================================================================
 * OmegaCore ↔ Cognitive Workspace contract bridge (Phase 12.0)
 * =============================================================================
 *
 * Problem (Phase 11): workspace tried dynamic import of runOmegaCore without
 * OmegaCoreDeps, so production often fell back to placeholders.
 *
 * Solution: a process-wide registry. server.ts (or tests) registers a bound
 * runner once; workspace always calls through this bridge.
 *
 * Contract:
 *   registerCoreRunner(fn)  — call at server boot
 *   runBoundCore(req)      — used by CognitiveWorkspace
 *   getCoreBridgeStatus()   — health / honesty about wiring
 */

import type { OmegaCoreRequest, OmegaCandidate } from "../omegaCore";
import type { SourceClass } from "./types";

export interface BoundCoreResult {
  answer: string;
  candidates: OmegaCandidate[];
  sourceClass: SourceClass;
  psi: number;
  verified: boolean | null;
  domain?: string;
  ensembleMode?: string;
  raw?: unknown;
}

export type BoundCoreRunner = (
  request: OmegaCoreRequest
) => Promise<BoundCoreResult>;

let _runner: BoundCoreRunner | null = null;
let _registeredAt: number | null = null;
let _label = "unregistered";

/**
 * Register the production OmegaCore runner (typically from server.ts).
 * Safe to call multiple times — last registration wins.
 */
export function registerCoreRunner(
  runner: BoundCoreRunner,
  label = "server"
): void {
  _runner = runner;
  _registeredAt = Date.now();
  _label = label;
}

/** Clear registration (tests). */
export function clearCoreRunner(): void {
  _runner = null;
  _registeredAt = null;
  _label = "unregistered";
}

export function getCoreBridgeStatus(): {
  wired: boolean;
  label: string;
  registeredAt: number | null;
} {
  return {
    wired: _runner != null,
    label: _label,
    registeredAt: _registeredAt,
  };
}

/**
 * Execute through the registered runner, or return null if not wired.
 * Never throws for "not registered" — caller handles fallback.
 */
export async function runBoundCore(
  request: OmegaCoreRequest
): Promise<BoundCoreResult | null> {
  if (!_runner) return null;
  return _runner(request);
}

/**
 * Map loose OmegaCore response shapes into BoundCoreResult.
 * Shared by server registration helpers and tests.
 */
export function normalizeCoreResponse(result: any): BoundCoreResult {
  const candidates: OmegaCandidate[] = Array.isArray(result?.candidates)
    ? result.candidates
    : [];

  const ensembleMode = result?.ensembleMode as string | undefined;
  let sourceClass: SourceClass = "simulated";
  if (result?.sourceClass) {
    sourceClass = result.sourceClass as SourceClass;
  } else if (ensembleMode === "real_multi_provider") {
    sourceClass = "real";
  } else if (ensembleMode === "mixed") {
    sourceClass = "mixed";
  } else if (ensembleMode === "simulated_single_model") {
    sourceClass = "simulated";
  } else if (candidates.length === 0) {
    sourceClass = "failed";
  } else if (candidates.every((c) => !c.simulated)) {
    sourceClass = "real";
  } else if (candidates.some((c) => !c.simulated)) {
    sourceClass = "mixed";
  }

  const answer =
    (typeof result?.answer === "string" && result.answer) ||
    (typeof result?.text === "string" && result.text) ||
    (typeof result?.finalAnswer === "string" && result.finalAnswer) ||
    candidates[0]?.text ||
    "";

  const psi =
    typeof result?.psi === "number"
      ? result.psi
      : typeof result?.hybridPsi === "number"
        ? result.hybridPsi
        : typeof candidates[0]?.psi === "number"
          ? candidates[0].psi!
          : 0.55;

  const verified =
    result?.verified === true || result?.verified === false
      ? (result.verified as boolean)
      : null;

  return {
    answer,
    candidates,
    sourceClass,
    psi,
    verified,
    domain: result?.domain,
    ensembleMode,
    raw: result,
  };
}
