/**
 * src/lib/omega/cognitiveWorkspace/synthesizer.ts
 * =============================================================================
 * Synthesizer — merge memory, graph, tools, and model candidates (Phase 11.4)
 * =============================================================================
 *
 * Produces a final answer string from all workspace artifacts collected so far.
 * Does NOT call external LLMs by itself — it ranks / stitches material that
 * already exists. Optional enrichment of the OmegaCore answer with tool outputs.
 */

import type { OmegaCandidate } from "../omegaCore";
import type {
  CognitivePlan,
  MemoryContext,
  SourceClass,
} from "./types";
import type { OrchestratorRunResult } from "./toolOrchestrator";
import type { GraphBridgeResult } from "./graphBridge";

export interface SynthesisInput {
  plan: CognitivePlan;
  memory: MemoryContext;
  /** Optional raw graph result (paths etc.) */
  graph?: Pick<GraphBridgeResult, "paths" | "formattedBlock"> | null;
  tools?: OrchestratorRunResult | null;
  candidates: OmegaCandidate[];
  /** Answer already produced by OmegaCore / reason step (may be empty) */
  coreAnswer: string;
  coreSourceClass: SourceClass;
  corePsi: number;
}

export interface SynthesisResult {
  answer: string;
  /** How the answer was assembled */
  method:
    | "core_only"
    | "core_plus_tools"
    | "tools_primary"
    | "memory_fallback"
    | "plan_placeholder";
  sourceClass: SourceClass;
  /** Short notes for the trace / confidence layer */
  notes: string[];
  /** Material that was injected into the answer */
  injectedSections: string[];
}

// ---------------------------------------------------------------------------
// Ranking helpers
// ---------------------------------------------------------------------------

function bestCandidate(candidates: OmegaCandidate[]): OmegaCandidate | null {
  if (!candidates.length) return null;
  const scored = [...candidates].sort((a, b) => {
    const pa = a.psi ?? (a.simulated ? 0.4 : 0.7);
    const pb = b.psi ?? (b.simulated ? 0.4 : 0.7);
    return pb - pa;
  });
  return scored[0];
}

function successfulToolOutputs(
  tools: OrchestratorRunResult | null | undefined
): Array<{ toolId: string; output: string; sourceClass: SourceClass }> {
  if (!tools) return [];
  return tools.results
    .filter(
      (r) =>
        r.success &&
        r.output &&
        r.toolId !== "direct_synthesis" &&
        r.toolId !== "knowledge_graph"
    )
    .map((r) => ({
      toolId: r.toolId,
      output: r.output.trim(),
      sourceClass: r.sourceClass,
    }));
}

function graphInsights(
  graph: SynthesisInput["graph"],
  memory: MemoryContext
): string[] {
  const lines: string[] = [];
  if (graph?.paths?.length) {
    for (const p of graph.paths.slice(0, 3)) {
      lines.push(`• ${p.explanation} (ثقة=${p.confidence})`);
    }
  } else if (memory.graphNodes.length > 0) {
    lines.push(
      "• عقد ذات صلة: " +
        memory.graphNodes
          .slice(0, 5)
          .map((n) => n.label)
          .join("، ")
    );
  }
  return lines;
}

function memoryHighlights(memory: MemoryContext): string[] {
  const lines: string[] = [];
  for (const ax of memory.semantic.filter((s) => s.tags?.includes("axiom")).slice(0, 2)) {
    lines.push(`• ${ax.topic}: ${ax.content.slice(0, 140)}`);
  }
  for (const p of memory.procedural.slice(0, 2)) {
    lines.push(`• ${p}`);
  }
  return lines;
}

function mergeSourceClass(
  core: SourceClass,
  tools: Array<{ sourceClass: SourceClass }>
): SourceClass {
  if (core === "failed" && tools.every((t) => t.sourceClass === "failed")) {
    return "failed";
  }
  const classes = new Set<SourceClass>([core, ...tools.map((t) => t.sourceClass)]);
  if (classes.has("failed") && (classes.has("real") || classes.has("mixed"))) {
    return "mixed";
  }
  if (classes.has("simulated") && classes.has("real")) return "mixed";
  if (classes.has("real") && classes.size === 1) return "real";
  if (classes.has("mixed")) return "mixed";
  if (classes.has("simulated")) return "simulated";
  return core;
}

// ---------------------------------------------------------------------------
// Main synthesizer
// ---------------------------------------------------------------------------

export function synthesizeAnswer(input: SynthesisInput): SynthesisResult {
  const notes: string[] = [];
  const injected: string[] = [];
  const toolOuts = successfulToolOutputs(input.tools);
  const top = bestCandidate(input.candidates);

  let baseAnswer =
    input.coreAnswer?.trim() ||
    top?.text?.trim() ||
    "";

  // Strip the Phase-11.1 placeholder if OmegaCore was not available
  const isPlaceholder =
    baseAnswer.startsWith("[Cognitive Workspace") ||
    baseAnswer.includes("محرك الاستدلال الكامل (OmegaCore) غير مربوط");

  // ----- Path A: strong tool results for CAS / code / calculator -----
  const primaryTool = input.tools?.plan.primaryTool;
  const hardTool = toolOuts.find((t) =>
    ["symbolic_cas", "calculator", "code_sandbox"].includes(t.toolId)
  );

  if (hardTool && (isPlaceholder || !baseAnswer || primaryTool === hardTool.toolId)) {
    const sections: string[] = [];
    sections.push(hardTool.output);
    injected.push(hardTool.toolId);

    // Attach other successful tools briefly
    for (const t of toolOuts) {
      if (t.toolId === hardTool.toolId) continue;
      sections.push(`\n---\n**[${t.toolId}]**\n${t.output.slice(0, 600)}`);
      injected.push(t.toolId);
    }

    // Light narrative wrapper when we have a non-placeholder core answer
    if (baseAnswer && !isPlaceholder) {
      sections.push(`\n---\n**توضيح إضافي:**\n${baseAnswer.slice(0, 1200)}`);
      notes.push("دمجت مخرجات الأداة مع إجابة النواة");
    } else {
      notes.push(`الإجابة مبنية أساسًا على أداة ${hardTool.toolId}`);
    }

    const graphLines = graphInsights(input.graph, input.memory);
    if (graphLines.length) {
      sections.push(`\n**من الرسم المعرفي:**\n${graphLines.join("\n")}`);
      injected.push("knowledge_graph");
    }

    return {
      answer: sections.join("\n").trim(),
      method: isPlaceholder || !baseAnswer ? "tools_primary" : "core_plus_tools",
      sourceClass: mergeSourceClass(
        isPlaceholder ? "simulated" : input.coreSourceClass,
        toolOuts
      ),
      notes,
      injectedSections: injected,
    };
  }

  // ----- Path B: core answer + optional tool appendices -----
  if (baseAnswer && !isPlaceholder) {
    const sections: string[] = [baseAnswer];
    notes.push("اعتمدت إجابة OmegaCore / المرشّح الأعلى");

    if (toolOuts.length > 0) {
      sections.push("\n---\n### نتائج الأدوات المساعدة");
      for (const t of toolOuts) {
        sections.push(`**[${t.toolId}]**\n${t.output.slice(0, 800)}`);
        injected.push(t.toolId);
      }
      notes.push(`أُلحقت ${toolOuts.length} نتيجة أداة`);
    }

    const graphLines = graphInsights(input.graph, input.memory);
    if (graphLines.length && input.plan.goal.complexity !== "low") {
      sections.push(`\n### روابط من الرسم المعرفي\n${graphLines.join("\n")}`);
      injected.push("knowledge_graph");
    }

    return {
      answer: sections.join("\n").trim(),
      method: toolOuts.length > 0 ? "core_plus_tools" : "core_only",
      sourceClass: mergeSourceClass(input.coreSourceClass, toolOuts),
      notes,
      injectedSections: injected,
    };
  }

  // ----- Path C: tools only (no core) -----
  if (toolOuts.length > 0) {
    const sections = toolOuts.map(
      (t) => `**[${t.toolId}]**\n${t.output}`
    );
    notes.push("لا إجابة من النواة — استخدام مخرجات الأدوات فقط");
    return {
      answer: sections.join("\n\n").trim(),
      method: "tools_primary",
      sourceClass: mergeSourceClass("simulated", toolOuts),
      notes,
      injectedSections: toolOuts.map((t) => t.toolId),
    };
  }

  // ----- Path D: memory / axiom fallback -----
  const memLines = memoryHighlights(input.memory);
  if (memLines.length > 0) {
    notes.push("لا مرشّحين ولا أدوات — استرجاع من الذاكرة/البدهيات");
    return {
      answer:
        `استنادًا إلى الذاكرة المعرفية لأوميغا:\n\n${memLines.join("\n")}\n\n` +
        `_ملاحظة: لم يتوفر استدلال نموذجي كامل لهذه الدورة._`,
      method: "memory_fallback",
      sourceClass: "mixed",
      notes,
      injectedSections: ["memory"],
    };
  }

  // ----- Path E: plan-aware placeholder -----
  notes.push("لا مواد كافية — إرجاع مخطط الدورة");
  const taskLines = input.plan.tasks
    .map((t, i) => `  ${i + 1}. [${t.type}] ${t.title} → ${t.status}`)
    .join("\n");
  return {
    answer: [
      `لم أتمكن من توليد إجابة كاملة لهذا السؤال في هذه الدورة.`,
      ``,
      `الهدف: ${input.plan.goal.refinedGoal}`,
      `النطاق: ${input.plan.goal.domain} | التعقيد: ${input.plan.estimatedComplexity}`,
      ``,
      `حالة المهام:`,
      taskLines,
    ].join("\n"),
    method: "plan_placeholder",
    sourceClass: "failed",
    notes,
    injectedSections: [],
  };
}
