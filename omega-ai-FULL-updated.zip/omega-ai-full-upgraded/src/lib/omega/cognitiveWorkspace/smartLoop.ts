/**
 * smartLoop.ts — Behavioral intelligence layer for Cognitive Workspace
 * =============================================================================
 * Makes Omega *act* smarter (not just score smarter):
 *  1. Problem classification → policy (tool-first, decompose, debate)
 *  2. Multi-step decomposition into ordered sub-goals
 *  3. Revision trigger after weak reflection / low confidence
 *  4. Answer merge when tools contradict free-form text
 */

export type SmartProblemClass =
  | "math_symbolic"
  | "math_numeric"
  | "code"
  | "factual"
  | "multi_step"
  | "open_ended"
  | "logical";

export interface SmartPolicy {
  problemClass: SmartProblemClass;
  /** Run CAS/calculator before calling LLM core */
  toolFirst: boolean;
  /** Prefer symbolic path in Hyper-Grid style decisions */
  preferSymbolic: boolean;
  /** Split question into sub-questions */
  decompose: boolean;
  subQuestions: string[];
  /** Allow one revision pass after reflection */
  allowRevision: boolean;
  /** Minimum confidence before accepting without revision */
  revisionBelowPsi: number;
  reason: string;
}

const MATH_SYM =
  /(?:حل|بسط|اشتق|تكامل|عامل|محدد|معادلة|solve|simplify|differentiate|integrate|factor|det\b|matrix)/i;
const MATH_NUM =
  /(?:احسب|ناتج|كم|عدد|٪|%|\d+\s*[\+\-\*\/×÷]\s*\d+|حاسب)/i;
const CODE =
  /(?:كود|دالة|function|python|javascript|sql|برمج|اكتب دالة|algorithm)/i;
const MULTI =
  /(?:ثم|بعد ذلك|أول[اًا].*ثاني|الخطوة|and then|first.+then|احسب.*(ثم|وبعد))/i;
const LOGIC =
  /(?:هل يلزم|إذا كان|إذن|منطق|تناقض|true xor|AND|OR|contrapositive)/i;

/**
 * Classify the question and return an execution policy.
 */
export function classifyAndPolicy(question: string): SmartPolicy {
  const q = question.trim();
  const subQuestions: string[] = [];

  let problemClass: SmartProblemClass = "open_ended";
  let toolFirst = false;
  let preferSymbolic = false;
  let decompose = false;
  let reason = "default open-ended";

  if (MATH_SYM.test(q)) {
    problemClass = "math_symbolic";
    toolFirst = true;
    preferSymbolic = true;
    reason = "symbolic math cues → CAS before generation";
  } else if (MATH_NUM.test(q) && /\d/.test(q)) {
    problemClass = "math_numeric";
    toolFirst = true;
    preferSymbolic = true;
    reason = "numeric calculation cues → calculator/CAS first";
  } else if (CODE.test(q)) {
    problemClass = "code";
    toolFirst = true;
    reason = "code task → sandbox/tools preferred";
  } else if (LOGIC.test(q)) {
    problemClass = "logical";
    reason = "logical form → careful verification";
  } else if (MULTI.test(q) || (q.match(/\?/g) || []).length > 1) {
    problemClass = "multi_step";
    decompose = true;
    reason = "multi-step markers → decompose";
  } else if (
    /(?:ما|من|أين|متى|عاصمة|what|who|where|when)\s/i.test(q) &&
    q.length < 120
  ) {
    problemClass = "factual";
    reason = "short factual question";
  }

  if (decompose || MULTI.test(q)) {
    // Lightweight split on ثم / then / .
    const parts = q
      .split(/\s*(?:ثم|وبعد ذلك|and then|after that)\s+/i)
      .map((s) => s.trim())
      .filter((s) => s.length > 3);
    if (parts.length >= 2) {
      subQuestions.push(...parts.slice(0, 4));
      decompose = true;
    } else {
      // Sentence split fallback
      const sents = q.split(/[.؟!]\s+/).map((s) => s.trim()).filter((s) => s.length > 8);
      if (sents.length >= 2) {
        subQuestions.push(...sents.slice(0, 3));
        decompose = true;
      }
    }
  }

  return {
    problemClass,
    toolFirst,
    preferSymbolic,
    decompose,
    subQuestions,
    allowRevision: problemClass !== "factual",
    revisionBelowPsi: problemClass === "open_ended" ? 0.55 : 0.62,
    reason,
  };
}

/**
 * If tools produced a real CAS/calc result, prefer integrating it over pure prose.
 */
export function mergeToolGroundedAnswer(
  freeAnswer: string,
  toolBlock: string | null | undefined,
  problemClass: SmartProblemClass
): { answer: string; grounded: boolean } {
  if (!toolBlock || toolBlock.trim().length < 3) {
    return { answer: freeAnswer, grounded: false };
  }
  const isHard =
    problemClass === "math_symbolic" ||
    problemClass === "math_numeric" ||
    /CAS|حاسبة|calculator|نتيجة:/i.test(toolBlock);

  if (!isHard) {
    return { answer: freeAnswer, grounded: false };
  }

  // Extract "نتيجة: ..." lines if present
  const resultLine = toolBlock
    .split("\n")
    .map((l) => l.trim())
    .find((l) => /^(?:نتيجة|result)\s*[:=]/i.test(l));

  if (resultLine) {
    const core = resultLine.replace(/^(?:نتيجة|result)\s*[:=]\s*/i, "").trim();
    const answer =
      `${freeAnswer.trim()}\n\n---\n` +
      `**تحقق رمزي/حسابي:** ${core}\n` +
      `(مُستمد من أداة خارجية — يُفضَّل على التخمين إن تعارض)`;
    return { answer, grounded: true };
  }

  // Generic append
  const answer =
    `${freeAnswer.trim()}\n\n---\n` +
    `**مخرجات الأدوات:**\n${toolBlock.trim().slice(0, 800)}`;
  return { answer, grounded: true };
}

export interface RevisionDecision {
  shouldRevise: boolean;
  reason: string;
}

/**
 * Decide whether to run a second-pass revision.
 */
export function shouldRevise(opts: {
  psi: number;
  verified: boolean | null;
  policy: SmartPolicy;
  answerLength: number;
  reflectionNotesCount: number;
}): RevisionDecision {
  if (!opts.policy.allowRevision) {
    return { shouldRevise: false, reason: "policy disallows revision" };
  }
  if (opts.verified === false) {
    return { shouldRevise: true, reason: "verification failed" };
  }
  if (opts.psi < opts.policy.revisionBelowPsi) {
    return {
      shouldRevise: true,
      reason: `psi ${opts.psi.toFixed(2)} < threshold ${opts.policy.revisionBelowPsi}`,
    };
  }
  if (opts.answerLength < 12) {
    return { shouldRevise: true, reason: "answer too short" };
  }
  if (opts.reflectionNotesCount >= 3 && opts.psi < 0.75) {
    return { shouldRevise: true, reason: "many reflection notes + moderate psi" };
  }
  return { shouldRevise: false, reason: "accepted" };
}

/**
 * Build a revision prompt hint (for core re-call or synthesizer).
 */
export function buildRevisionHint(
  question: string,
  previousAnswer: string,
  notes: string[],
  toolBlock?: string
): string {
  const lines = [
    "راجع الإجابة السابقة وحسّنها.",
    `السؤال: ${question}`,
    `الإجابة السابقة:\n${previousAnswer.slice(0, 1500)}`,
  ];
  if (notes.length) {
    lines.push("ملاحظات يجب مراعاتها:");
    notes.slice(0, 5).forEach((n, i) => lines.push(`${i + 1}. ${n}`));
  }
  if (toolBlock) {
    lines.push(`مخرجات أدوات موثوقة:\n${toolBlock.slice(0, 600)}`);
  }
  lines.push(
    "أعد إجابة أوضح وأكثر التزامًا بالأدلة. لا تختلق تحققًا خارجيًا غير موجود."
  );
  return lines.join("\n");
}


export interface SubAnswer {
  question: string;
  answer: string;
  psi: number;
  sourceClass?: string;
}

/**
 * Merge ordered sub-answers into one coherent response.
 */
export function mergeSubAnswers(
  originalQuestion: string,
  parts: SubAnswer[]
): string {
  if (parts.length === 0) return "";
  if (parts.length === 1) return parts[0].answer;
  const lines = [
    `**السؤال الأصلي:** ${originalQuestion}`,
    ``,
    `تم تفكيك المسألة إلى ${parts.length} خطوات:`,
    ``,
  ];
  parts.forEach((p, i) => {
    lines.push(`### الخطوة ${i + 1}`);
    lines.push(`*${p.question}*`);
    lines.push(p.answer.trim());
    lines.push(``);
  });
  lines.push(`### الخلاصة`);
  const last = parts[parts.length - 1].answer.trim();
  lines.push(
    last.length > 400
      ? last.slice(0, 400) + "…"
      : `بناءً على الخطوات السابقة: ${last.slice(0, 280)}`
  );
  return lines.join("\n");
}
