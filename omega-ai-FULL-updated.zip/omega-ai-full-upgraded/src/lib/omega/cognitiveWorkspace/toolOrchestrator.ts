/**
 * src/lib/omega/cognitiveWorkspace/toolOrchestrator.ts
 * =============================================================================
 * Tool Orchestrator — unified tool selection + execution (Phase 11.3)
 * =============================================================================
 *
 * Wraps existing engines behind a single interface:
 *   - symbolic_cas     → SymPyLeanBridge / symbolicEngine / mathjs+nerdamer
 *   - code_sandbox     → SafeCodeSandbox (JS/TS)
 *   - web_search       → BrowserUseEngine (DuckDuckGo + Wikipedia)
 *   - arxiv            → searchArxiv
 *   - knowledge_graph  → already handled by graphBridge (optional re-query)
 *   - calculator       → mathjs evaluate (fast numeric)
 *   - direct_synthesis → no-op marker (reasoning handled by OmegaCore)
 *
 * Every call produces a ToolCallRecord for the Cognitive Trace.
 */

import { ToolPlanner, type ToolType, type ToolExecutionPlan } from "../toolPlanner";
import { globalSafeSandbox } from "../codeSandbox";
import { globalSymPyLeanBridge } from "../sympyLeanBridge";
import { executeSymbolicOperation, type SymbolicOperation } from "../symbolicEngine";
import { globalBrowserUseEngine } from "../browserUseEngine";
import { searchArxiv } from "../arxivClient";
import type { ToolCallRecord, SourceClass } from "./types";

// ---------------------------------------------------------------------------
// Tool IDs exposed to the workspace
// ---------------------------------------------------------------------------

export type WorkspaceToolId =
  | "symbolic_cas"
  | "code_sandbox"
  | "web_search"
  | "arxiv"
  | "calculator"
  | "knowledge_graph"
  | "direct_synthesis";

export interface ToolInvocation {
  toolId: WorkspaceToolId;
  /** Free-form input — expression, code, search query, etc. */
  input: string;
  /** Optional structured params */
  params?: Record<string, unknown>;
}

export interface ToolResult {
  toolId: WorkspaceToolId;
  success: boolean;
  output: string;
  data?: unknown;
  sourceClass: SourceClass;
  latencyMs: number;
  error?: string;
}

export interface OrchestratorOptions {
  /** Hard cap on tool calls this cycle */
  maxToolCalls: number;
  /**
   * Optional cost budget (sum of TOOL_COST[toolId]).
   * When set, invocations are selected greedily in order until the budget is exhausted.
   */
  maxToolCost?: number;
  /** Skip tools that need network if true */
  offlineOnly?: boolean;
  /** Timeout per tool (ms) */
  perToolTimeoutMs?: number;
}

/** Relative cost units for resource-bounded tool use (docs/MATH-SECURITY-ROADMAP.md). */
export const TOOL_COST: Record<WorkspaceToolId, number> = {
  calculator: 1,
  symbolic_cas: 2,
  knowledge_graph: 1,
  direct_synthesis: 0,
  web_search: 2,
  arxiv: 2,
  code_sandbox: 3,
};

export function toolCost(id: WorkspaceToolId): number {
  return TOOL_COST[id] ?? 1;
}

/** Greedy select under maxCount and optional maxCost; preserves order. */
export function selectWithinBudget(
  invs: ToolInvocation[],
  maxCount: number,
  maxCost?: number
): { selected: ToolInvocation[]; totalCost: number; skipped: ToolInvocation[] } {
  const selected: ToolInvocation[] = [];
  const skipped: ToolInvocation[] = [];
  let totalCost = 0;
  const limit = Math.max(0, maxCount);
  for (const inv of invs) {
    if (selected.length >= limit) {
      skipped.push(inv);
      continue;
    }
    const c = toolCost(inv.toolId);
    if (maxCost !== undefined && maxCost !== null && totalCost + c > maxCost) {
      skipped.push(inv);
      continue;
    }
    selected.push(inv);
    totalCost += c;
  }
  return { selected, totalCost, skipped };
}

export interface OrchestratorRunResult {
  plan: ToolExecutionPlan;
  results: ToolResult[];
  records: ToolCallRecord[];
  /** Concatenated human-readable summary for prompt injection */
  formattedBlock: string;
  toolsUsed: WorkspaceToolId[];
  /** Actual cost sum of executed tools (optional for older call sites). */
  totalCost?: number;
  /** Invocations dropped due to maxToolCalls / maxToolCost */
  skippedByBudget?: WorkspaceToolId[];
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function mapPlannerTool(t: ToolType): WorkspaceToolId {
  switch (t) {
    case "symbolic_cas":
      return "symbolic_cas";
    case "code_sandbox":
      return "code_sandbox";
    case "web_search":
      return "web_search";
    case "knowledge_graph":
      return "knowledge_graph";
    case "image_generation":
      // Not wired in 11.3 — treat as direct
      return "direct_synthesis";
    case "mcts_reasoning":
      return "direct_synthesis";
    case "direct_synthesis":
    default:
      return "direct_synthesis";
  }
}

/** Detect if the question itself looks like pure code to execute */
function extractCodeBlock(question: string): string | null {
  const fence = question.match(/```(?:javascript|js|typescript|ts)?\s*([\s\S]*?)```/i);
  if (fence?.[1]?.trim()) return fence[1].trim();
  return null;
}

/** Heuristic: pick CAS operation from question text */
function detectCasOperation(question: string): SymbolicOperation {
  const q = question.toLowerCase();
  if (/تكامل|integrate|integral/.test(q)) return "integrate";
  if (/مشتق|derivative|diff\b|تفاضل/.test(q)) return "diff";
  if (/حل|solve|جذور|roots/.test(q)) return "solve";
  if (/فك|factor/.test(q)) return "factor";
  if (/وسّع|expand/.test(q)) return "expand";
  if (/محدد|determinant|matrix/.test(q)) return "matrix_det";
  if (/كولاتز|collatz|3n\+1/.test(q)) return "collatz_orbit";
  return "simplify";
}

/** Extract a math expression-ish substring */
function extractExpression(question: string): string {
  // Prefer content inside $...$ or \(...\)
  const latex = question.match(/\$([^$]+)\$/) || question.match(/\\\(([^)]+)\\\)/);
  if (latex?.[1]) return latex[1].trim();

  // Code-like: solve(...), diff(...), etc.
  const fn = question.match(
    /\b(solve|diff|integrate|simplify|factor|expand)\s*\(\s*([^)]+)\s*\)/i
  );
  if (fn?.[2]) return fn[2].trim();

  // Fallback: strip Arabic/English instruction words and keep operators/numbers
  const cleaned = question
    .replace(
      /(احسب|حل|بسّط|simplify|solve|calculate|compute|find|ما هو|ما هي|قيمة)/gi,
      " "
    )
    .replace(/[؟?]/g, " ")
    .trim();
  // If still long, take the densest math-looking token sequence
  const mathy = cleaned.match(/[\d\w\s\+\-\*\/\^\(\)\=\.\,]+/);
  return (mathy?.[0] || cleaned).trim().slice(0, 200);
}

function withTimeout<T>(p: Promise<T>, ms: number, label: string): Promise<T> {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error(`timeout after ${ms}ms (${label})`)), ms);
    p.then(
      (v) => {
        clearTimeout(t);
        resolve(v);
      },
      (e) => {
        clearTimeout(t);
        reject(e);
      }
    );
  });
}

// ---------------------------------------------------------------------------
// Individual tool executors
// ---------------------------------------------------------------------------

async function runCalculator(input: string): Promise<ToolResult> {
  const t0 = Date.now();
  try {
    // Prefer nerdamer via SymPyLeanBridge for symbolic-ish, mathjs for pure numeric
    const bridge = globalSymPyLeanBridge;
    const expr = extractExpression(input) || input;

    // Try nerdamer simplify / evaluate
    const sympy = bridge.generateSymPyRepresentation(expr);
    const latencyMs = Date.now() - t0;

    if (sympy.simplified && sympy.simplified !== expr) {
      return {
        toolId: "calculator",
        success: true,
        output: `النتيجة: ${sympy.simplified}\nLaTeX: ${sympy.latex}`,
        data: sympy,
        sourceClass: "real",
        latencyMs,
      };
    }

    // Numeric fallback via Function (restricted) — only pure math chars
    const safe = expr.replace(/[^0-9+\-*/().eE\s]/g, "");
    if (safe.length > 0 && safe.length < 100) {
      // eslint-disable-next-line no-new-func
      const val = Function(`"use strict"; return (${safe});`)();
      return {
        toolId: "calculator",
        success: true,
        output: `النتيجة العددية: ${val}`,
        data: { value: val, expression: safe },
        sourceClass: "real",
        latencyMs: Date.now() - t0,
      };
    }

    return {
      toolId: "calculator",
      success: false,
      output: "",
      sourceClass: "failed",
      latencyMs: Date.now() - t0,
      error: "تعذّر تقييم التعبير",
    };
  } catch (err: any) {
    return {
      toolId: "calculator",
      success: false,
      output: "",
      sourceClass: "failed",
      latencyMs: Date.now() - t0,
      error: String(err?.message ?? err),
    };
  }
}

async function runSymbolicCas(input: string): Promise<ToolResult> {
  const t0 = Date.now();
  try {
    const operation = detectCasOperation(input);
    const expression =
      operation === "collatz_orbit"
        ? (input.match(/\d+/)?.[0] ?? "27")
        : extractExpression(input) || input;

    // 1) Local nerdamer path (real, no network)
    const local = globalSymPyLeanBridge.generateSymPyRepresentation(expression);
    if (local.simplified) {
      return {
        toolId: "symbolic_cas",
        success: true,
        output: [
          `العملية: ${operation}`,
          `التعبير: ${expression}`,
          `النتيجة: ${local.simplified}`,
          `LaTeX: $${local.latex}$`,
        ].join("\n"),
        data: { operation, ...local },
        sourceClass: "real",
        latencyMs: Date.now() - t0,
      };
    }

    // 2) Fallback to symbolicEngine (may hit HTTP endpoint)
    const remote = await executeSymbolicOperation({
      operation,
      expression,
      variable: "x",
    });

    return {
      toolId: "symbolic_cas",
      success: remote.ok,
      output: remote.ok
        ? `العملية: ${remote.operation}\nالنتيجة: ${remote.result}\nLaTeX: $${remote.latex}$`
        : remote.error || "فشل CAS",
      data: remote,
      sourceClass: remote.error ? "mixed" : "real",
      latencyMs: Date.now() - t0,
      error: remote.ok ? undefined : remote.error,
    };
  } catch (err: any) {
    return {
      toolId: "symbolic_cas",
      success: false,
      output: "",
      sourceClass: "failed",
      latencyMs: Date.now() - t0,
      error: String(err?.message ?? err),
    };
  }
}

async function runCodeSandbox(input: string): Promise<ToolResult> {
  const t0 = Date.now();
  try {
    const code = extractCodeBlock(input) || input;
    // Safety: reject obviously huge payloads
    if (code.length > 12_000) {
      return {
        toolId: "code_sandbox",
        success: false,
        output: "",
        sourceClass: "failed",
        latencyMs: Date.now() - t0,
        error: "الكود أطول من الحد المسموح (12KB)",
      };
    }

    const result = await globalSafeSandbox.executeWithSelfCorrection(code, undefined, 2);
    return {
      toolId: "code_sandbox",
      success: result.ok,
      output: result.ok
        ? result.output
        : `فشل التنفيذ: ${result.error ?? "unknown"}\n${result.output || ""}`,
      data: {
        returnValue: result.returnValue,
        attempts: result.attempts,
        executionTimeMs: result.executionTimeMs,
      },
      sourceClass: result.ok ? "real" : "failed",
      latencyMs: Date.now() - t0,
      error: result.ok ? undefined : result.error ?? undefined,
    };
  } catch (err: any) {
    return {
      toolId: "code_sandbox",
      success: false,
      output: "",
      sourceClass: "failed",
      latencyMs: Date.now() - t0,
      error: String(err?.message ?? err),
    };
  }
}

async function runWebSearch(input: string): Promise<ToolResult> {
  const t0 = Date.now();
  try {
    const engine = globalBrowserUseEngine;
    const [ddg, wiki] = await Promise.all([
      engine.searchDuckDuckGo(input).catch(() => []),
      engine.searchWikipedia(input, "ar").catch(() => []),
    ]);

    const results = [...wiki, ...ddg].slice(0, 6);
    if (results.length === 0) {
      return {
        toolId: "web_search",
        success: false,
        output: "لم يُعثر على نتائج بحث.",
        sourceClass: "failed",
        latencyMs: Date.now() - t0,
        error: "empty search results",
      };
    }

    const output = results
      .map(
        (r, i) =>
          `${i + 1}. **${r.title}**\n   ${r.snippet?.slice(0, 200) || ""}\n   ${r.url}`
      )
      .join("\n\n");

    return {
      toolId: "web_search",
      success: true,
      output,
      data: { results },
      sourceClass: "real",
      latencyMs: Date.now() - t0,
    };
  } catch (err: any) {
    return {
      toolId: "web_search",
      success: false,
      output: "",
      sourceClass: "failed",
      latencyMs: Date.now() - t0,
      error: String(err?.message ?? err),
    };
  }
}

async function runArxiv(input: string): Promise<ToolResult> {
  const t0 = Date.now();
  try {
    const papers = await searchArxiv(input, 4);
    if (!papers.length) {
      return {
        toolId: "arxiv",
        success: false,
        output: "لا أوراق مطابقة على arXiv (أو القائمة المرجعية).",
        sourceClass: "mixed",
        latencyMs: Date.now() - t0,
      };
    }
    const output = papers
      .map(
        (p, i) =>
          `${i + 1}. **${p.title}** (${p.id || "?"})\n   ${
             (p.summary || "").slice(0, 220)
          }…`
      )
      .join("\n\n");
    return {
      toolId: "arxiv",
      success: true,
      output,
      data: { papers },
      sourceClass: "real",
      latencyMs: Date.now() - t0,
    };
  } catch (err: any) {
    return {
      toolId: "arxiv",
      success: false,
      output: "",
      sourceClass: "failed",
      latencyMs: Date.now() - t0,
      error: String(err?.message ?? err),
    };
  }
}

// ---------------------------------------------------------------------------
// Dispatch
// ---------------------------------------------------------------------------

async function executeOne(
  inv: ToolInvocation,
  opts: OrchestratorOptions
): Promise<ToolResult> {
  const timeout = opts.perToolTimeoutMs ?? 12_000;

  if (opts.offlineOnly && (inv.toolId === "web_search" || inv.toolId === "arxiv")) {
    return {
      toolId: inv.toolId,
      success: false,
      output: "",
      sourceClass: "failed",
      latencyMs: 0,
      error: "network tools disabled (offlineOnly)",
    };
  }

  if (inv.toolId === "direct_synthesis" || inv.toolId === "knowledge_graph") {
    // knowledge_graph is handled by graphBridge; direct_synthesis by OmegaCore
    return {
      toolId: inv.toolId,
      success: true,
      output: `(${inv.toolId} — يُعالج في طبقة أخرى من مساحة العمل)`,
      sourceClass: "simulated",
      latencyMs: 0,
    };
  }

  const runner = async (): Promise<ToolResult> => {
    switch (inv.toolId) {
      case "calculator":
        return runCalculator(inv.input);
      case "symbolic_cas":
        return runSymbolicCas(inv.input);
      case "code_sandbox":
        return runCodeSandbox(inv.input);
      case "web_search":
        return runWebSearch(inv.input);
      case "arxiv":
        return runArxiv(inv.input);
      default:
        return {
          toolId: inv.toolId,
          success: false,
          output: "",
          sourceClass: "failed",
          latencyMs: 0,
          error: `أداة غير معروفة: ${inv.toolId}`,
        };
    }
  };

  try {
    return await withTimeout(runner(), timeout, inv.toolId);
  } catch (err: any) {
    return {
      toolId: inv.toolId,
      success: false,
      output: "",
      sourceClass: "failed",
      latencyMs: timeout,
      error: String(err?.message ?? err),
    };
  }
}

function toRecord(r: ToolResult, input: string): ToolCallRecord {
  return {
    toolId: r.toolId,
    input,
    output: r.success ? r.output : r.error ?? r.output,
    success: r.success,
    latencyMs: r.latencyMs,
    sourceClass: r.sourceClass,
    error: r.error,
  };
}

// ---------------------------------------------------------------------------
// Public Orchestrator
// ---------------------------------------------------------------------------

export class ToolOrchestrator {
  private planner = new ToolPlanner();

  /**
   * Plan which tools to use for a question (does not execute).
   */
  plan(question: string, attachments: unknown[] = []): ToolExecutionPlan {
    return this.planner.plan(question, attachments as any[]);
  }

  /**
   * Build invocation list from a planner plan + the raw question.
   */
  buildInvocations(
    question: string,
    plan: ToolExecutionPlan,
    maxToolCalls: number
  ): ToolInvocation[] {
    const invs: ToolInvocation[] = [];
    const seen = new Set<WorkspaceToolId>();

    // Extra: arxiv if research-y
    const q = question.toLowerCase();
    if (
      /arxiv|ورقة|بحث علمي|paper|preprint|كولاتز|riemann|ريمان/.test(q)
    ) {
      invs.push({ toolId: "arxiv", input: question });
      seen.add("arxiv");
    }

    for (const step of plan.steps) {
      const id = mapPlannerTool(step.tool);
      if (id === "direct_synthesis" || id === "knowledge_graph") continue;
      if (seen.has(id)) continue;
      seen.add(id);
      invs.push({ toolId: id, input: question });
      if (invs.length >= maxToolCalls) break;
    }

    // If primary is CAS but we also want a quick calculator for pure arithmetic
    if (
      plan.primaryTool === "symbolic_cas" &&
      !seen.has("calculator") &&
      invs.length < maxToolCalls &&
      /[\d\+\-\*\/]/.test(question)
    ) {
      // calculator runs only for short numeric-looking queries
      if (question.length < 80) {
        invs.unshift({ toolId: "calculator", input: question });
      }
    }

    return invs.slice(0, maxToolCalls);
  }

  /**
   * Plan + execute tools for a question. Fail-soft: individual failures
   * do not abort the rest.
   */
  async run(
    question: string,
    options: OrchestratorOptions,
    attachments: unknown[] = []
  ): Promise<OrchestratorRunResult> {
    const plan = this.plan(question, attachments);
    // Build with a high count ceiling, then apply count+cost budget
    const planned = this.buildInvocations(question, plan, Math.max(options.maxToolCalls, 16));
    const { selected, totalCost, skipped } = selectWithinBudget(
      planned,
      Math.max(0, options.maxToolCalls),
      options.maxToolCost
    );

    const results: ToolResult[] = [];
    const records: ToolCallRecord[] = [];

    for (const inv of selected) {
      if (options.offlineOnly && (inv.toolId === "web_search" || inv.toolId === "arxiv")) {
        results.push({
          toolId: inv.toolId,
          success: false,
          output: "",
          sourceClass: "failed",
          latencyMs: 0,
          error: "offlineOnly: network tools disabled",
        });
        records.push(toRecord(results[results.length - 1], inv.input));
        continue;
      }
      const result = await executeOne(inv, options);
      results.push(result);
      records.push(toRecord(result, inv.input));
    }

    const successful = results.filter((r) => r.success && r.toolId !== "direct_synthesis");
    const parts: string[] = [];
    if (successful.length > 0) {
      parts.push("### 🛠️ نتائج الأدوات:");
      for (const r of successful) {
        parts.push(
          `**[${r.toolId}]** (${r.latencyMs}ms, ${r.sourceClass}, cost=${toolCost(r.toolId)})\n${r.output}`
        );
      }
    }
    if (skipped.length > 0) {
      parts.push(
        `### ⚠️ أدوات تُركت بسبب الميزانية: ${skipped.map((s) => s.toolId).join(", ")} (cost used=${totalCost})`
      );
    }

    return {
      plan,
      results,
      records,
      formattedBlock: parts.join("\n\n"),
      toolsUsed: [...new Set(results.map((r) => r.toolId))],
      totalCost,
      skippedByBudget: skipped.map((s) => s.toolId),
    };
  }

  /** Execute a single explicit tool call (for advanced callers). */
  async invoke(
    inv: ToolInvocation,
    options: Partial<OrchestratorOptions> = {}
  ): Promise<ToolResult> {
    return executeOne(inv, {
      maxToolCalls: 1,
      perToolTimeoutMs: options.perToolTimeoutMs ?? 12_000,
      offlineOnly: options.offlineOnly,
    });
  }
}

// Singleton
let _orch: ToolOrchestrator | null = null;

export function getToolOrchestrator(): ToolOrchestrator {
  if (!_orch) _orch = new ToolOrchestrator();
  return _orch;
}

export async function runToolsForQuestion(
  question: string,
  options: OrchestratorOptions
): Promise<OrchestratorRunResult> {
  return getToolOrchestrator().run(question, options);
}
