/**
 * src/lib/omega/cognitiveWorkspace/index.ts
 * =============================================================================
 * Public exports for Omega Cognitive Workspace (Phase 11)
 * =============================================================================
 */

export type {
  ReasoningDepth,
  WorkspaceConfig,
  CognitiveGoal,
  TaskType,
  TaskStatus,
  TaskNode,
  CognitivePlan,
  MemoryContext,
  GraphNodeRef,
  GraphEdgeRef,
  SourceClass,
  ToolCallRecord,
  AgentRole,
  AgentOpinion,
  ConfidenceReport,
  ReflectionNote,
  TraceStep,
  CognitiveTrace,
  WorkspaceRequest,
  WorkspaceResult,
} from "./types";

export {
  DEFAULT_WORKSPACE_CONFIG,
  configForDepth,
} from "./types";

export { CognitiveTraceRecorder } from "./trace";

export {
  createCognitivePlan,
  getReadyTasks,
  updateTaskStatus,
  type PlannerInput,
  type PlannerResult,
} from "./planner";

export {
  CognitiveWorkspace,
  getCognitiveWorkspace,
  runCognitiveWorkspace,
} from "./workspace";

export {
  retrieveMemoryContext,
  persistWorkspaceOutcome,
  getMemoryManager,
  type MemoryBridgeOptions,
  type MemoryBridgeResult,
} from "./memoryBridge";

export {
  retrieveGraphContext,
  mergeGraphIntoMemory,
  persistGraph,
  enrichGraph,
  getKnowledgeGraph,
  type GraphBridgeOptions,
  type GraphBridgeResult,
} from "./graphBridge";

export {
  ToolOrchestrator,
  getToolOrchestrator,
  runToolsForQuestion,
  type WorkspaceToolId,
  type ToolInvocation,
  type ToolResult,
  type OrchestratorOptions,
  type OrchestratorRunResult,
} from "./toolOrchestrator";

export {
  synthesizeAnswer,
  type SynthesisInput,
  type SynthesisResult,
} from "./synthesizer";

export {
  estimateConfidence,
  type ConfidenceInput,
} from "./confidence";

export {
  reflectOnAnswer,
  runVerificationPass,
  type ReflectorInput,
  type ReflectorResult,
} from "./reflector";

export {
  AgentCoordinator,
  getAgentCoordinator,
  runAgentPanel,
  type AgentCoordinatorConfig,
  type AgentCoordinatorInput,
  type AgentCoordinatorResult,
  type ModelCaller,
} from "./agentCoordinator";

export {
  registerCoreRunner,
  clearCoreRunner,
  runBoundCore,
  getCoreBridgeStatus,
  normalizeCoreResponse,
  type BoundCoreResult,
  type BoundCoreRunner,
} from "./coreBridge";

export {
  classifyAndPolicy,
  mergeToolGroundedAnswer,
  shouldRevise,
  mergeSubAnswers,
} from "./smartLoop";
