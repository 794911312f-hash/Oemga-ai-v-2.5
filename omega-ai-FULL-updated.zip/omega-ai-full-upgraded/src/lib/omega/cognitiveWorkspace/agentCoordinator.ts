/**
 * src/lib/omega/cognitiveWorkspace/agentCoordinator.ts
 * =============================================================================
 * Agent Coordinator — multi-agent opinions + adversarial critique (Phase 11.6)
 * =============================================================================
 *
 * Roles (subset activated by domain / depth):
 *   scientist | critic | programmer | planner | security | mathematician | general
 *
 * Modes:
 *   1. Lightweight panel — parallel role heuristics + optional model calls
 *   2. Adversarial debate — Proponent / Sceptic / Arbiter via AdversarialDebateEngine
 *
 * Fail-soft: missing model backend falls back to structured local opinions
 * so the workspace cycle never hard-depends on live providers.
 */

import {
  AdversarialDebateEngine,
  type DebateResult,
} from "../adversarialDebate";
import type { Domain } from "../domainRouting";
import type {
  AgentOpinion,
  AgentRole,
  CognitivePlan,
  ReasoningDepth,
  SourceClass,
} from "./types";
import type { SynthesisResult } from "./synthesizer";
import type { OrchestratorRunResult } from "./toolOrchestrator";

export type ModelCaller = (
  modelId: string,
  prompt: string
) => Promise<string>;

export interface AgentCoordinatorConfig {
  maxAgents: number;
  depth: ReasoningDepth;
  /** Injected LLM caller — optional */
  callModel?: ModelCaller;
  /** Force debate mode even on balanced */
  forceDebate?: boolean;
}

export interface AgentCoordinatorInput {
  question: string;
  plan: CognitivePlan;
  draftAnswer: string;
  synthesis: SynthesisResult;
  tools?: OrchestratorRunResult | null;
  config: AgentCoordinatorConfig;
}

export interface AgentCoordinatorResult {
  opinions: AgentOpinion[];
  debate: DebateResult | null;
  /** Optional refined answer when critic/arbiter improve the draft */
  refinedAnswer: string | null;
  /** Aggregate panel confidence 0–1 */
  panelConfidence: number;
  sourceClass: SourceClass;
  notes: string[];
}

// ---------------------------------------------------------------------------
// Role selection
// ---------------------------------------------------------------------------

function rolesForDomain(domain: Domain, maxAgents: number): AgentRole[] {
  const base: AgentRole[] = ["critic"];
  switch (domain) {
    case "code":
      base.push("programmer", "security", "planner");
      break;
    case "math_logic":
      base.push("mathematician", "scientist", "critic");
      break;
    case "science_factual":
      base.push("scientist", "critic", "planner");
      break;
    case "philosophy_theology":
      base.push("critic", "scientist", "general");
      break;
    default:
      base.push("general", "planner", "scientist");
  }
  // unique preserve order
  const seen = new Set<AgentRole>();
  const out: AgentRole[] = [];
  for (const r of base) {
    if (!seen.has(r)) {
      seen.add(r);
      out.push(r);
    }
    if (out.length >= maxAgents) break;
  }
  return out;
}

// ---------------------------------------------------------------------------
// Local (offline) role opinions — honest structured critique, not fake LLM
// ---------------------------------------------------------------------------

function localOpinion(
  role: AgentRole,
  question: string,
  draft: string,
  plan: CognitivePlan,
  tools: OrchestratorRunResult | null | undefined
): AgentOpinion {
  const critiques: string[] = [];
  let confidence = 0.62;
  let answer = "";

  const toolOk =
    tools?.results.filter((r) => r.success).map((r) => r.toolId) ?? [];
  const toolFail =
    tools?.results.filter((r) => !r.success).map((r) => r.toolId) ?? [];

  switch (role) {
    case "critic":
      if (draft.length < 80) {
        critiques.push("الإجابة قصيرة وقد لا تغطي السؤال بالكامل");
        confidence -= 0.1;
      }
      if (plan.goal.complexity === "high" && draft.length < 200) {
        critiques.push("تعقيد عالٍ مع إجابة غير مفصّلة بما يكفي");
        confidence -= 0.08;
      }
      if (toolFail.length) {
        critiques.push(`أدوات فشلت قبل الاعتماد على النص: ${toolFail.join(", ")}`);
        confidence -= 0.05;
      }
      if (!critiques.length) {
        critiques.push("لم يُرصد ضعف هيكلي واضح في المسودة");
        confidence += 0.08;
      }
      answer = critiques.join("؛ ");
      break;

    case "scientist":
      answer =
        "أتحقق من الاتساق العلمي: هل تُذكر وحدات/شروط صلاحية؟ هل الادعاءات قابلة للفحص؟";
      if (toolOk.includes("symbolic_cas") || toolOk.includes("calculator")) {
        critiques.push("وجود نتيجة CAS/حاسبة يدعم الجانب الكمي");
        confidence += 0.1;
      }
      if (plan.goal.domain === "science_factual" || plan.goal.domain === "math_logic") {
        confidence += 0.05;
      }
      break;

    case "mathematician":
      answer =
        "أراجع الصيغ والخطوات: هل النتيجة محددة؟ هل ذُكرت الافتراضات؟";
      if (toolOk.includes("symbolic_cas")) {
        critiques.push("CAS نفّذ عملية رمزية — أولوية للنتيجة الحسابية");
        confidence += 0.12;
      } else if (/[=∫∑√]|\\frac|مشتق|تكامل|معادلة/.test(question + draft)) {
        critiques.push("سؤال رياضي بدون تأكيد CAS — خطر خطأ رمزي");
        confidence -= 0.08;
      }
      break;

    case "programmer":
      answer =
        "أراجع صحة المنطق البرمجي وإمكانية التنفيذ والحدود (timeout، أخطاء).";
      if (toolOk.includes("code_sandbox")) {
        critiques.push("sandbox نفّذ الكود بنجاح");
        confidence += 0.12;
      } else if (plan.goal.domain === "code") {
        critiques.push("لا دليل تنفيذ من sandbox");
        confidence -= 0.06;
      }
      break;

    case "security":
      answer =
        "أفحص مخاطر التنفيذ: كود غير موثوق، تسريب أسرار، SSRF، صلاحيات زائدة.";
      if (toolOk.includes("code_sandbox")) {
        critiques.push("تم التنفيذ داخل sandbox — جيد، مع بقاء حدود الشبكة/الذاكرة");
        confidence += 0.05;
      }
      break;

    case "planner":
      answer = `الخطة الحالية: ${plan.tasks.map((t) => t.type).join(" → ")}. التعقيد=${plan.estimatedComplexity}.`;
      const failedTasks = plan.tasks.filter((t) => t.status === "failed");
      if (failedTasks.length) {
        critiques.push(`مهام فاشلة: ${failedTasks.map((t) => t.id).join(", ")}`);
        confidence -= 0.1;
      } else {
        critiques.push("تسلسل المهام مكتمل دون فشل صريح");
        confidence += 0.05;
      }
      break;

    case "general":
    default:
      answer =
        draft.slice(0, 280) ||
        "لا مسودة كافية — أوصي بإعادة الاستدلال مع أدوات أو سياق إضافي.";
      confidence = draft.length > 100 ? 0.65 : 0.45;
      break;
  }

  return {
    agentId: `agent_${role}`,
    role,
    answer,
    confidence: Math.max(0.15, Math.min(0.95, confidence)),
    critiques,
    sourceClass: "simulated",
  };
}

async function modelOpinion(
  role: AgentRole,
  question: string,
  draft: string,
  callModel: ModelCaller
): Promise<AgentOpinion | null> {
  const rolePrompt: Record<AgentRole, string> = {
    critic:
      "أنت ناقد صارم. اذكر نقاط ضعف المسودة فقط بشكل موجز (3 نقاط كحد أقصى).",
    scientist:
      "أنت عالم. قيّم الدقة العلمية للمسودة واذكر أي فجوات تجريبية أو مفاهيمية.",
    mathematician:
      "أنت رياضياتي. تحقق من الصيغ والخطوات؛ أشر إلى أي خطأ محتمل.",
    programmer:
      "أنت مهندس برمجيات. قيّم صحة الحل البرمجي ومخاطره.",
    security:
      "أنت خبير أمن. حدد مخاطر أمنية في الحل أو في طريقة الوصول إليه.",
    planner:
      "أنت مخطط. هل خطوات الحل كافية ومنظمة؟ ماذا ينقص؟",
    general: "قدّم رأياً موجزاً ومتوازناً حول جودة الإجابة.",
  };

  try {
    const text = await callModel(
      "gemini-3.8-flash",
      `${rolePrompt[role]}\n\nالسؤال: ${question}\n\nالمسودة:\n${draft.slice(0, 2000)}\n\nأجب بالعربية باختصار.`
    );
    if (!text?.trim()) return null;
    return {
      agentId: `agent_${role}_llm`,
      role,
      answer: text.trim().slice(0, 1200),
      confidence: 0.72,
      critiques: [],
      sourceClass: "real",
      modelId: "gemini-3.8-flash" as any,
    };
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// Coordinator
// ---------------------------------------------------------------------------

export class AgentCoordinator {
  private debateEngine = new AdversarialDebateEngine();

  async run(input: AgentCoordinatorInput): Promise<AgentCoordinatorResult> {
    const { question, plan, draftAnswer, synthesis, tools, config } = input;
    const notes: string[] = [];
    const opinions: AgentOpinion[] = [];
    let debate: DebateResult | null = null;
    let sourceClass: SourceClass = "simulated";

    const roles = rolesForDomain(plan.goal.domain, config.maxAgents);
    notes.push(`أدوار مفعّلة: ${roles.join(", ")}`);

    // Parallel local opinions
    for (const role of roles) {
      let op = localOpinion(role, question, draftAnswer, plan, tools);
      if (config.callModel) {
        const llm = await modelOpinion(role, question, draftAnswer, config.callModel);
        if (llm) {
          // Merge critiques from local into LLM opinion
          llm.critiques = [...op.critiques, ...llm.critiques];
          op = llm;
          sourceClass = "mixed";
        }
      }
      opinions.push(op);
    }

    // Adversarial debate on deep (or forced)
    const useDebate =
      config.forceDebate ||
      config.depth === "deep" ||
      plan.goal.complexity === "high";

    if (useDebate) {
      try {
        debate = await this.debateEngine.conductDebate(
          question,
          draftAnswer.slice(0, 1500),
          config.callModel
        );
        notes.push(
          `نقاش خصومي: resilience=${debate.resilienceScore.toFixed(2)} falsificationPassed=${debate.falsificationPassed}`
        );
        // Represent debate sides as opinions
        opinions.push({
          agentId: "debate_proponent",
          role: "general",
          answer: debate.thesis.arguments.join(" "),
          confidence: debate.thesis.confidenceScore,
          critiques: [],
          sourceClass: config.callModel ? "mixed" : "simulated",
        });
        opinions.push({
          agentId: "debate_sceptic",
          role: "critic",
          answer: (debate.antithesis.challengedPoints || debate.antithesis.arguments).join(" "),
          confidence: debate.antithesis.confidenceScore,
          critiques: debate.unresolvedVulnerabilities || [],
          sourceClass: config.callModel ? "mixed" : "simulated",
        });
        opinions.push({
          agentId: "debate_arbiter",
          role: "planner",
          answer: debate.synthesis.arguments.join(" "),
          confidence: debate.synthesis.confidenceScore,
          critiques: [],
          sourceClass: config.callModel ? "mixed" : "simulated",
        });
      } catch (err: any) {
        notes.push(`فشل النقاش الخصومي: ${err?.message ?? err}`);
      }
    }

    // Panel confidence = average of agent confidences (critic weighted a bit more)
    let weightSum = 0;
    let scoreSum = 0;
    for (const op of opinions) {
      const w = op.role === "critic" ? 1.3 : 1;
      weightSum += w;
      scoreSum += op.confidence * w;
    }
    const panelConfidence =
      weightSum > 0 ? Number((scoreSum / weightSum).toFixed(4)) : 0.5;

    // Refined answer: append arbiter / strong critic notes when debate ran
    let refinedAnswer: string | null = null;
    if (debate && draftAnswer.trim()) {
      const vulns = debate.unresolvedVulnerabilities?.filter(Boolean) ?? [];
      if (vulns.length > 0 || !debate.falsificationPassed) {
        refinedAnswer =
          draftAnswer.trimEnd() +
          "\n\n---\n_ملخص لجنة الوكلاء:_\n" +
          `- صمود أمام التفنيد: ${debate.falsificationPassed ? "نعم" : "جزئي/لا"}\n` +
          `- درجة الصمود: ${debate.resilienceScore.toFixed(2)}\n` +
          (vulns.length
            ? `- ثغرات مفتوحة: ${vulns.slice(0, 3).join("؛ ")}\n`
            : "");
        notes.push("أُضيف ملخص اللجنة إلى الإجابة");
      }
    } else {
      // If critic confidence is low, surface top critiques
      const critic = opinions.find((o) => o.role === "critic");
      if (critic && critic.confidence < 0.55 && critic.critiques.length > 0) {
        refinedAnswer =
          draftAnswer.trimEnd() +
          "\n\n---\n_ملاحظات الناقد:_\n" +
          critic.critiques.map((c) => `- ${c}`).join("\n");
        notes.push("أُلحقت ملاحظات الناقد بسبب ثقة منخفضة");
      }
    }

    // If any real LLM opinions, bump source class
    if (opinions.some((o) => o.sourceClass === "real")) {
      sourceClass = opinions.every((o) => o.sourceClass === "real")
        ? "real"
        : "mixed";
    }

    return {
      opinions,
      debate,
      refinedAnswer,
      panelConfidence,
      sourceClass,
      notes,
    };
  }
}

let _coord: AgentCoordinator | null = null;

export function getAgentCoordinator(): AgentCoordinator {
  if (!_coord) _coord = new AgentCoordinator();
  return _coord;
}

export async function runAgentPanel(
  input: AgentCoordinatorInput
): Promise<AgentCoordinatorResult> {
  return getAgentCoordinator().run(input);
}
