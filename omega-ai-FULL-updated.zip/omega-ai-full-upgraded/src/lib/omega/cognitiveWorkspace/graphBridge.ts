/**
 * src/lib/omega/cognitiveWorkspace/graphBridge.ts
 * =============================================================================
 * Knowledge Graph Bridge — connects RealKnowledgeGraph (Phase 11.2)
 * =============================================================================
 *
 * Responsibilities:
 *   - Obtain (or create) a per-user RealKnowledgeGraph instance
 *   - Load persisted snapshot when available (firebase)
 *   - Query relevant nodes/edges for the current question
 *   - Run multi-hop deduction when the inquiry matches the graph
 *   - Optionally enrich MemoryContext with graph refs
 *   - Persist graph after enrichment
 */

import { RealKnowledgeGraph, type GraphNode, type GraphEdge, type DeductionPath } from "../realKnowledgeGraph";
import {
  loadKnowledgeGraphSnapshot,
  saveKnowledgeGraphSnapshot,
} from "../firebase";
import type { MemoryContext, GraphNodeRef, GraphEdgeRef } from "./types";

// ---------------------------------------------------------------------------
// Per-user graph cache
// ---------------------------------------------------------------------------

const graphs = new Map<string, RealKnowledgeGraph>();
const loadedFlags = new Map<string, boolean>();

async function getGraph(userId: string): Promise<RealKnowledgeGraph> {
  let g = graphs.get(userId);
  if (!g) {
    g = new RealKnowledgeGraph();
    graphs.set(userId, g);
  }

  // Load snapshot once per process lifetime (best-effort)
  if (!loadedFlags.get(userId)) {
    loadedFlags.set(userId, true);
    try {
      const snap = await loadKnowledgeGraphSnapshot(userId);
      if (snap && (snap.nodes?.length || snap.edges?.length)) {
        g.load(snap);
      }
    } catch {
      // local seed remains
    }
  }

  return g;
}

// ---------------------------------------------------------------------------
// Mapping helpers
// ---------------------------------------------------------------------------

function toNodeRef(n: GraphNode): GraphNodeRef {
  return {
    id: n.id,
    label: n.label,
    type: n.type,
    properties: n.attributes as Record<string, unknown>,
  };
}

function toEdgeRef(e: GraphEdge): GraphEdgeRef {
  return {
    id: e.id,
    from: e.source,
    to: e.target,
    relation: e.relation,
    weight: e.weight,
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export interface GraphBridgeOptions {
  userId: string;
  query: string;
  /** Maximum nodes to return */
  maxNodes?: number;
  /** Maximum edges to return */
  maxEdges?: number;
  /** Run multi-hop inference */
  enableDeduction?: boolean;
}

export interface GraphBridgeResult {
  nodes: GraphNodeRef[];
  edges: GraphEdgeRef[];
  /** Multi-hop deduction paths (if any) */
  paths: DeductionPath[];
  /** Human-readable summary for prompts */
  formattedBlock: string;
  stats: {
    nodeCount: number;
    edgeCount: number;
    pathCount: number;
    totalGraphNodes: number;
    totalGraphEdges: number;
  };
}

/**
 * Retrieve graph context relevant to the query.
 */
export async function retrieveGraphContext(
  options: GraphBridgeOptions
): Promise<GraphBridgeResult> {
  const {
    userId,
    query,
    maxNodes = 8,
    maxEdges = 12,
    enableDeduction = true,
  } = options;

  const graph = await getGraph(userId);
  const snapshot = graph.getSnapshot();

  // Multi-hop deduction first — returns only genuinely related paths
  let paths: DeductionPath[] = [];
  if (enableDeduction) {
    try {
      paths = graph.inferMultiHop(query);
    } catch {
      paths = [];
    }
  }

  // Collect nodes/edges from paths
  const nodeMap = new Map<string, GraphNodeRef>();
  const edgeMap = new Map<string, GraphEdgeRef>();

  for (const path of paths) {
    for (const n of path.nodes) {
      nodeMap.set(n.id, toNodeRef(n));
    }
    for (const e of path.edges) {
      edgeMap.set(e.id, toEdgeRef(e));
    }
  }

  // If deduction found nothing, fall back to keyword / label matching
  if (nodeMap.size === 0) {
    const qLower = query.toLowerCase();
    const scored = snapshot.nodes
      .map((n) => {
        const label = n.label.toLowerCase();
        const words = label
          .replace(/[^\p{L}\p{N}\s]/gu, " ")
          .split(/\s+/)
          .filter((w) => w.length > 2);
        const hits = words.filter((w) => qLower.includes(w)).length;
        // also check type / attributes
        const typeHit = n.type && qLower.includes(n.type.toLowerCase()) ? 1 : 0;
        return { node: n, score: hits + typeHit };
      })
      .filter((s) => s.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, maxNodes);

    for (const { node } of scored) {
      nodeMap.set(node.id, toNodeRef(node));
    }

    // Include edges that connect any selected nodes
    for (const e of snapshot.edges) {
      if (nodeMap.has(e.source) || nodeMap.has(e.target)) {
        edgeMap.set(e.id, toEdgeRef(e));
        // pull the other endpoint if missing
        if (!nodeMap.has(e.source)) {
          const src = snapshot.nodes.find((n) => n.id === e.source);
          if (src) nodeMap.set(src.id, toNodeRef(src));
        }
        if (!nodeMap.has(e.target)) {
          const tgt = snapshot.nodes.find((n) => n.id === e.target);
          if (tgt) nodeMap.set(tgt.id, toNodeRef(tgt));
        }
      }
    }
  }

  const nodes = [...nodeMap.values()].slice(0, maxNodes);
  const edges = [...edgeMap.values()].slice(0, maxEdges);

  // Formatted block
  const parts: string[] = [];
  if (paths.length > 0) {
    parts.push(
      "### 🕸️ سلاسل استدلال من الرسم المعرفي:\n" +
        paths
          .map(
            (p, i) =>
              `${i + 1}. ${p.explanation}  (ثقة=${p.confidence}, قفزات=${p.hops})`
          )
          .join("\n")
    );
  }
  if (nodes.length > 0 && paths.length === 0) {
    parts.push(
      "### 🕸️ عقد ذات صلة من الرسم المعرفي:\n" +
        nodes
          .map((n) => `• **${n.label}** (${n.type ?? "concept"})`)
          .join("\n")
    );
  }
  if (edges.length > 0 && paths.length === 0) {
    parts.push(
      "العلاقات:\n" +
        edges
          .slice(0, 6)
          .map((e) => `  ${e.from} ──[${e.relation}]──> ${e.to}`)
          .join("\n")
    );
  }

  return {
    nodes,
    edges,
    paths,
    formattedBlock: parts.join("\n\n"),
    stats: {
      nodeCount: nodes.length,
      edgeCount: edges.length,
      pathCount: paths.length,
      totalGraphNodes: snapshot.nodeCount,
      totalGraphEdges: snapshot.edgeCount,
    },
  };
}

/**
 * Merge graph results into an existing MemoryContext (mutates it).
 */
export function mergeGraphIntoMemory(
  memory: MemoryContext,
  graph: GraphBridgeResult
): MemoryContext {
  memory.graphNodes = graph.nodes;
  memory.graphEdges = graph.edges;
  return memory;
}

/**
 * Persist the current graph snapshot for the user (best-effort).
 */
export async function persistGraph(userId: string): Promise<boolean> {
  const g = graphs.get(userId);
  if (!g) return false;
  try {
    const snap = g.serialize();
    await saveKnowledgeGraphSnapshot(userId, snap as any);
    return true;
  } catch {
    return false;
  }
}

/**
 * Add a new concept discovered during a workspace cycle.
 */
export async function enrichGraph(
  userId: string,
  node: { id: string; label: string; type?: string; attributes?: Record<string, string | number> },
  edges?: Array<{ targetId: string; relation?: string; weight?: number }>
): Promise<void> {
  const g = await getGraph(userId);
  g.addNode(node.id, node.label, node.type ?? "concept", node.attributes ?? {});
  if (edges) {
    for (const e of edges) {
      g.addEdge(
        node.id,
        e.targetId,
        (e.relation as any) ?? "depends_on",
        e.weight ?? 0.75
      );
    }
  }
}

/** For tests / advanced use */
export async function getKnowledgeGraph(userId: string): Promise<RealKnowledgeGraph> {
  return getGraph(userId);
}
