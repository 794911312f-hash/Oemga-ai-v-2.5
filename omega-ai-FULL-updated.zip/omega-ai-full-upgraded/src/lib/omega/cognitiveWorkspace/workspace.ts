/**
 * src/lib/omega/cognitiveWorkspace/workspace.ts
 * =============================================================================
 * CognitiveWorkspace — main orchestrator (Phase 11.0 → 11.2)
 * =============================================================================
 *
 * Implements:
 *   - Config resolution
 *   - Intent analysis + Planner (11.1)
 *   - Memory Bridge + Graph Bridge (11.2)
 *   - Tool Orchestrator (11.3)
 *   - Synthesizer + rich Confidence Estimator (11.4)
 *   - Reflector + selfVerify (11.5)
 *   - AgentCoordinator multi-agent panel + debate (11.6)
 *   - Core bridge (12.0) — registerCoreRunner from server
 *   - Trace recording
 */

import type { OmegaCoreRequest, OmegaCandidate } from "../omegaCore";
import {
  type WorkspaceConfig,
  type WorkspaceRequest,
  type WorkspaceResult,
  type CognitivePlan,
  type MemoryContext,
  type ConfidenceReport,
  type SourceClass,
  type ReasoningDepth,
  configForDepth,
  DEFAULT_WORKSPACE_CONFIG,
} from "./types";
import { CognitiveTraceRecorder } from "./trace";
import {
  createCognitivePlan,
  getReadyTasks,
  updateTaskStatus,
} from "./planner";
import {
  retrieveMemoryContext,
  persistWorkspaceOutcome,
} from "./memoryBridge";
import {
  retrieveGraphContext,
  mergeGraphIntoMemory,
} from "./graphBridge";
import {
  getToolOrchestrator,
  type OrchestratorRunResult,
} from "./toolOrchestrator";
import { synthesizeAnswer } from "./synthesizer";
import { estimateConfidence } from "./confidence";
import { reflectOnAnswer } from "./reflector";
import { getAgentCoordinator } from "./agentCoordinator";
import { runBoundCore, getCoreBridgeStatus } from "./coreBridge";
import {
  classifyAndPolicy,
  mergeToolGroundedAnswer,
  shouldRevise,
  buildRevisionHint,
  mergeSubAnswers,
  type SmartPolicy,
} from "./smartLoop";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function mergeConfig(
  depth: ReasoningDepth,
  overrides?: Partial<WorkspaceConfig>
): WorkspaceConfig {
  const base = configForDepth(depth);
  return { ...base, ...overrides, depth };
}

function emptyMemory(): MemoryContext {
  return {
    episodic: [],
    semantic: [],
    procedural: [],
    graphNodes: [],
    graphEdges: [],
    workingKeys: [],
  };
}

function buildFallbackConfidence(
  sourceClass: SourceClass,
  psi = 0.5
): ConfidenceReport {
  return {
    psi,
    confidence: psi,
    evidence: [],
    risk: sourceClass === "failed" ? ["فشل تنفيذ مساحة العمل المعرفية"] : [],
    unknowns: [],
    sourceClass,
    verified: null,
  };
}

// ---------------------------------------------------------------------------
// CognitiveWorkspace
// ---------------------------------------------------------------------------

export class CognitiveWorkspace {
  private config: WorkspaceConfig;

  constructor(config?: Partial<WorkspaceConfig>) {
    const depth = config?.depth ?? DEFAULT_WORKSPACE_CONFIG.depth;
    this.config = mergeConfig(depth, config);
  }

  /** Update runtime config (e.g. switch depth mid-session) */
  setConfig(partial: Partial<WorkspaceConfig>): void {
    this.config = mergeConfig(
      partial.depth ?? this.config.depth,
      { ...this.config, ...partial }
    );
  }

  getConfig(): Readonly<WorkspaceConfig> {
    return this.config;
  }

  /**
   * Main entry point.
   * Phase 11.1: runs Intent → Plan → (stub) remaining pipeline → returns result.
   */
  async run(request: WorkspaceRequest): Promise<WorkspaceResult> {
    const depth = request.depth ?? this.config.depth;
    const config = mergeConfig(depth, {
      ...this.config,
      ...request.config,
    });

    const tracer = new CognitiveTraceRecorder(request.userId, depth);

    try {
      // -----------------------------------------------------------------
      // 1. Intent & Planning
      // -----------------------------------------------------------------
      tracer.beginStep("intent_and_plan");

      const { plan, domainRoute } = createCognitivePlan({
        question: request.question,
        depth,
        config,
        forcedDomain: request.domain ?? config.forcedDomain,
      });

      tracer.setPlan(plan);
      const smartPolicy: SmartPolicy = classifyAndPolicy(request.question);
      (plan as any)._smartPolicy = smartPolicy;
      tracer.endStep(
        "ok",
        `domain=${plan.goal.domain} complexity=${plan.estimatedComplexity} tasks=${plan.tasks.length} smart=${smartPolicy.problemClass} toolFirst=${smartPolicy.toolFirst}`
      );

      // -----------------------------------------------------------------
      // 2. Memory + Graph  (Phase 11.2)
      // -----------------------------------------------------------------
      tracer.beginStep("memory_and_graph");
      updateTaskStatus(plan, "t_retrieve", "running");

      let memory = emptyMemory();
      let memoryFormatted = "";
      let graphFormatted = "";

      try {
        const [memResult, graphResult] = await Promise.all([
          retrieveMemoryContext({
            userId: request.userId,
            query: request.question,
            episodicLimit: depth === "fast" ? 2 : 4,
            semanticLimit: depth === "fast" ? 3 : 6,
          }),
          retrieveGraphContext({
            userId: request.userId,
            query: request.question,
            maxNodes: depth === "deep" ? 12 : 8,
            enableDeduction: depth !== "fast",
          }),
        ]);

        memory = mergeGraphIntoMemory(memResult.context, graphResult);
        memoryFormatted = memResult.formattedBlock;
        graphFormatted = graphResult.formattedBlock;

        updateTaskStatus(plan, "t_retrieve", "done", {
          episodic: memResult.stats.episodicCount,
          semantic: memResult.stats.semanticCount,
          axioms: memResult.stats.axiomCount,
          procedural: memResult.stats.proceduralCount,
          graphNodes: graphResult.stats.nodeCount,
          graphPaths: graphResult.stats.pathCount,
        });

        tracer.setMemory(memory);
        tracer.endStep(
          "ok",
          `mem(ep=${memResult.stats.episodicCount},sem=${memResult.stats.semanticCount},ax=${memResult.stats.axiomCount}) ` +
            `graph(n=${graphResult.stats.nodeCount},e=${graphResult.stats.edgeCount},paths=${graphResult.stats.pathCount})`
        );
      } catch (err: any) {
        updateTaskStatus(plan, "t_retrieve", "failed", undefined, String(err));
        tracer.setMemory(memory);
        tracer.endStep("error", String(err?.message ?? err));
      }

      // Keep formatted blocks for later injection into reasoning (Phase 11.3+)
      (plan as any)._memoryFormatted = memoryFormatted;
      (plan as any)._graphFormatted = graphFormatted;

      // -----------------------------------------------------------------
      // 3. Tools (Phase 11.3)
      // -----------------------------------------------------------------
      let toolsFormatted = "";
      let toolRun: OrchestratorRunResult | null = null;
      const toolTask = plan.tasks.find((t) => t.id === "t_tools");
      // Run tools only when the plan includes a tool task, or when the
      // standalone ToolPlanner would pick something other than pure synthesis.
      let shouldRunTools = false;
      // Reuse policy from planning (tool-first for math/code)
      if (config.enableTools) {
        if (toolTask || smartPolicy.toolFirst) {
          shouldRunTools = true;
        } else {
          try {
            const preview = getToolOrchestrator().plan(request.question);
            shouldRunTools =
              preview.primaryTool !== "direct_synthesis" &&
              preview.primaryTool !== "mcts_reasoning";
          } catch {
            shouldRunTools = false;
          }
        }
      }

      if (shouldRunTools) {
        tracer.beginStep("tools");
        if (toolTask) updateTaskStatus(plan, "t_tools", "running");

        try {
          const orch = getToolOrchestrator();
          toolRun = await orch.run(request.question, {
            maxToolCalls: config.maxToolCalls,
            perToolTimeoutMs: depth === "fast" ? 6_000 : 12_000,
            offlineOnly: false,
          });

          for (const rec of toolRun.records) {
            tracer.addToolCall(rec);
          }
          toolsFormatted = toolRun.formattedBlock;

          const okCount = toolRun.results.filter((r) => r.success).length;
          if (toolTask) {
            updateTaskStatus(plan, "t_tools", "done", {
              toolsUsed: toolRun.toolsUsed,
              okCount,
              total: toolRun.results.length,
              primary: toolRun.plan.primaryTool,
            });
          }
          tracer.endStep(
            "ok",
            `tools=${toolRun.toolsUsed.join(",") || "none"} ok=${okCount}/${toolRun.results.length}`
          );
        } catch (err: any) {
          if (toolTask) {
            updateTaskStatus(plan, "t_tools", "failed", undefined, String(err));
          }
          tracer.endStep("error", String(err?.message ?? err));
        }
      } else if (toolTask) {
        tracer.beginStep("tools");
        updateTaskStatus(plan, "t_tools", "skipped", { note: "tools disabled by config" });
        tracer.endStep("skipped");
      }

      (plan as any)._toolsFormatted = toolsFormatted;

      // -----------------------------------------------------------------
      // 4. Core Reasoning (calls existing OmegaCore path when available)
      // -----------------------------------------------------------------
      tracer.beginStep("reason");
      updateTaskStatus(plan, "t_reason", "running");

      let candidates: OmegaCandidate[] = [];
      let finalAnswer = "";
      let sourceClass: SourceClass = "simulated";
      let psi = 0.55;

      // Attempt to use the real OmegaCore if it is available in the runtime.
      // This keeps the workspace useful even before the full pipeline is wired.
      try {
        // Multi-step: run each sub-question then merge (cap 3 to bound cost)
        if (
          smartPolicy.decompose &&
          smartPolicy.subQuestions.length >= 2 &&
          getCoreBridgeStatus().wired
        ) {
          const subParts: { question: string; answer: string; psi: number; sourceClass?: string }[] = [];
          for (const sq of smartPolicy.subQuestions.slice(0, 3)) {
            const sub = await runBoundCore({
              userId: request.userId,
              question: sq,
              domain: plan.goal.domain,
              models: request.models ?? domainRoute.models,
              history: request.history,
            });
            if (sub?.answer) {
              subParts.push({
                question: sq,
                answer: sub.answer,
                psi: sub.psi ?? 0.5,
                sourceClass: sub.sourceClass,
              });
              if (sub.candidates?.length) {
                candidates.push(...sub.candidates);
              }
            }
          }
          if (subParts.length >= 2) {
            finalAnswer = mergeSubAnswers(request.question, subParts);
            psi = subParts.reduce((a, p) => a + p.psi, 0) / subParts.length;
            sourceClass = subParts.some((p) => p.sourceClass === "real")
              ? "mixed"
              : (subParts[0].sourceClass as SourceClass) || "simulated";
            updateTaskStatus(plan, "t_reason", "done", {
              mode: "multi_step",
              steps: subParts.length,
              candidateCount: candidates.length,
              sourceClass,
              bridge: getCoreBridgeStatus().label,
            });
            tracer.endStep(
              "ok",
              `multi-step ${subParts.length} parts → psi=${psi.toFixed(2)}`
            );
          }
        }

        if (!finalAnswer) {
        const coreResult = await runBoundCore({
          userId: request.userId,
          question: request.question,
          domain: plan.goal.domain,
          models: request.models ?? domainRoute.models,
          history: request.history,
        });

        if (coreResult && coreResult.answer) {
          candidates = coreResult.candidates ?? [];
          finalAnswer = coreResult.answer;
          sourceClass = coreResult.sourceClass;
          psi = coreResult.psi;
          updateTaskStatus(plan, "t_reason", "done", {
            candidateCount: candidates.length,
            sourceClass,
            verified: coreResult.verified,
            bridge: getCoreBridgeStatus().label,
          });
          tracer.endStep(
            "ok",
            `OmegaCore[${getCoreBridgeStatus().label}] → ${candidates.length} candidates, sourceClass=${sourceClass}`
          );
        } else {
          const status = getCoreBridgeStatus();
          finalAnswer = this.buildPlanAwarePlaceholder(plan, status.wired);
          sourceClass = "simulated";
          updateTaskStatus(plan, "t_reason", "done", {
            note: status.wired
              ? "OmegaCore returned empty — placeholder"
              : "OmegaCore not registered — placeholder",
            bridge: status.label,
          });
          tracer.endStep(
            "warn",
            status.wired
              ? "OmegaCore wired but returned no answer"
              : "OmegaCore bridge not registered (call registerCoreRunner from server)"
          );
        }
        } // end if (!finalAnswer)
      } catch (err: any) {
        finalAnswer = this.buildPlanAwarePlaceholder(plan);
        sourceClass = "failed";
        updateTaskStatus(plan, "t_reason", "failed", undefined, String(err));
        tracer.endStep("error", String(err?.message ?? err));
      }

      tracer.setCandidates(candidates);

      // Agents run after synthesis (see step 6b)
      // -----------------------------------------------------------------
      // 6. Synthesis (Phase 11.4)
      // -----------------------------------------------------------------
      tracer.beginStep("synthesize");
      updateTaskStatus(plan, "t_synthesize", "running");

      const synthesis = synthesizeAnswer({
        plan,
        memory,
        graph: null, // paths already merged into memory; formatted blocks available on plan
        tools: toolRun,
        candidates,
        coreAnswer: finalAnswer,
        coreSourceClass: sourceClass,
        corePsi: psi,
      });

      finalAnswer = synthesis.answer;
      sourceClass = synthesis.sourceClass;

      // Ground free-form answer with CAS/calc when available
      {
        const grounded = mergeToolGroundedAnswer(
          finalAnswer,
          toolsFormatted || toolRun?.formattedBlock,
          smartPolicy.problemClass
        );
        if (grounded.grounded) {
          finalAnswer = grounded.answer;
          synthesis.notes.push("smartLoop: tool-grounded merge applied");
          if (sourceClass === "simulated") sourceClass = "mixed";
          else if (sourceClass === "real") sourceClass = "mixed";
        }
      }

      updateTaskStatus(plan, "t_synthesize", "done", {
        method: synthesis.method,
        injected: synthesis.injectedSections,
        answerLength: finalAnswer.length,
        smartClass: smartPolicy.problemClass,
      });
      tracer.endStep(
        "ok",
        `method=${synthesis.method} injected=${synthesis.injectedSections.join(",") || "none"}`
      );

      // -----------------------------------------------------------------
      // 6b. Multi-Agent panel (Phase 11.6) — critiques the draft answer
      // -----------------------------------------------------------------
      let agentPanelConfidence: number | null = null;
      const agentTask = plan.tasks.find((t) => t.id === "t_agents");
      const shouldRunAgents =
        config.enableMultiAgent &&
        (agentTask != null || depth === "deep" || plan.goal.complexity === "high");

      if (shouldRunAgents) {
        tracer.beginStep("agents");
        if (agentTask) updateTaskStatus(plan, "t_agents", "running");
        try {
          const panel = await getAgentCoordinator().run({
            question: request.question,
            plan,
            draftAnswer: finalAnswer,
            synthesis,
            tools: toolRun,
            config: {
              maxAgents: config.maxAgents,
              depth,
              // callModel left undefined → local structured opinions (honest offline)
            },
          });

          for (const op of panel.opinions) {
            tracer.addAgentOpinion(op);
          }
          if (panel.refinedAnswer) {
            finalAnswer = panel.refinedAnswer;
          }
          agentPanelConfidence = panel.panelConfidence;
          if (panel.sourceClass === "real" || panel.sourceClass === "mixed") {
            // don't override failed synthesis upward carelessly
            if (sourceClass !== "failed") {
              sourceClass =
                sourceClass === "real" && panel.sourceClass === "real"
                  ? "real"
                  : "mixed";
            }
          }

          if (agentTask) {
            updateTaskStatus(plan, "t_agents", "done", {
              opinionCount: panel.opinions.length,
              panelConfidence: panel.panelConfidence,
              debate: Boolean(panel.debate),
              refined: Boolean(panel.refinedAnswer),
            });
          }
          tracer.endStep(
            "ok",
            `opinions=${panel.opinions.length} panel=${panel.panelConfidence} debate=${Boolean(panel.debate)}`
          );
        } catch (err: any) {
          if (agentTask) {
            updateTaskStatus(plan, "t_agents", "failed", undefined, String(err));
          }
          tracer.endStep("error", String(err?.message ?? err));
        }
      } else if (agentTask) {
        tracer.beginStep("agents");
        updateTaskStatus(plan, "t_agents", "skipped", {
          note: "multi-agent disabled by config/depth",
        });
        tracer.endStep("skipped");
      }

      // -----------------------------------------------------------------
      // 7 + 8. Verify + Reflect (Phase 11.5)
      // -----------------------------------------------------------------
      let coreVerified: boolean | null = null;
      let confidenceDelta = 0;

      const shouldReflect =
        config.enableReflection && depth !== "fast";
      const verifyTask = plan.tasks.find((t) => t.id === "t_verify");
      const reflectTask = plan.tasks.find((t) => t.id === "t_reflect");

      if (verifyTask || shouldReflect || reflectTask) {
        tracer.beginStep("verify_and_reflect");
        if (verifyTask) updateTaskStatus(plan, "t_verify", "running");
        if (reflectTask) updateTaskStatus(plan, "t_reflect", "running");

        try {
          const reflection = await reflectOnAnswer({
            question: request.question,
            answer: finalAnswer,
            plan,
            synthesis,
            tools: toolRun,
            depth,
            offlineOnly: false,
          });

          finalAnswer = reflection.answer;
          coreVerified = reflection.verified;
          confidenceDelta = reflection.confidenceDelta;

          for (const note of reflection.notes) {
            tracer.addReflection(note);
          }

          if (verifyTask) {
            updateTaskStatus(plan, "t_verify", "done", {
              verified: reflection.verified,
              score: reflection.verification.score,
              hasContradiction: reflection.verification.hasContradiction,
            });
          }
          if (reflectTask) {
            updateTaskStatus(plan, "t_reflect", "done", {
              notes: reflection.notes.length,
              improved: reflection.improved,
              confidenceDelta: reflection.confidenceDelta,
            });
          }

          tracer.endStep(
            reflection.verification.hasContradiction ? "warn" : "ok",
            `verified=${reflection.verified} score=${reflection.verification.score} notes=${reflection.notes.length}`
          );
        } catch (err: any) {
          if (verifyTask) {
            updateTaskStatus(plan, "t_verify", "failed", undefined, String(err));
          }
          if (reflectTask) {
            updateTaskStatus(plan, "t_reflect", "failed", undefined, String(err));
          }
          tracer.endStep("error", String(err?.message ?? err));
        }
      } else {
        if (verifyTask) {
          tracer.beginStep("verify");
          updateTaskStatus(plan, "t_verify", "skipped", {
            note: "reflection disabled",
          });
          tracer.endStep("skipped");
        }
      }

      // -----------------------------------------------------------------
      // 9. Confidence (Phase 11.4 + delta from 11.5)
      // -----------------------------------------------------------------
      tracer.beginStep("confidence");
      const confidence = estimateConfidence({
        plan,
        memory,
        tools: toolRun,
        toolRecords: toolRun?.records,
        candidates,
        synthesis,
        corePsi: psi,
        coreVerified,
        depth,
        domainKeywords: domainRoute.matchedKeywords,
      });
      // Apply reflector delta + optional agent panel blend
      let totalDelta = confidenceDelta;
      if (agentPanelConfidence != null) {
        // Pull overall confidence slightly toward panel consensus
        totalDelta += (agentPanelConfidence - confidence.confidence) * 0.15;
        confidence.evidence.push(
          `ثقة لجنة الوكلاء: ${agentPanelConfidence.toFixed(2)}`
        );
      }
      if (totalDelta !== 0) {
        confidence.confidence = Math.max(
          0,
          Math.min(1, Number((confidence.confidence + totalDelta).toFixed(4)))
        );
        confidence.psi = Math.max(
          0,
          Math.min(1, Number((confidence.psi + totalDelta * 0.5).toFixed(4)))
        );
      }
      confidence.sourceClass = sourceClass;
      confidence.verified = coreVerified;
      psi = confidence.psi;
      tracer.setConfidence(confidence);
      tracer.endStep(
        "ok",
        `psi=${confidence.psi} conf=${confidence.confidence} verified=${coreVerified}`
      );

      // -----------------------------------------------------------------
      // 9b. Smart revision pass (one shot) when weak confidence / verify
      // -----------------------------------------------------------------
      const revision = shouldRevise({
        psi: confidence.psi,
        verified: coreVerified,
        policy: smartPolicy,
        answerLength: finalAnswer.length,
        reflectionNotesCount: (confidence.risk?.length ?? 0) + (confidence.unknowns?.length ?? 0),
      });
      if (revision.shouldRevise && depth !== "fast") {
        tracer.beginStep("smart_revision");
        try {
          const hint = buildRevisionHint(
            request.question,
            finalAnswer,
            [
              ...confidence.risk.slice(0, 3),
              ...confidence.unknowns.slice(0, 2),
              revision.reason,
            ],
            toolsFormatted || toolRun?.formattedBlock
          );
          const status = getCoreBridgeStatus();
          if (status.wired) {
            const revised = await runBoundCore({
              userId: request.userId,
              question: hint,
              depth: depth === "deep" ? "balanced" : depth,
            });
            if (revised.answer && revised.answer.trim().length > finalAnswer.trim().length * 0.5) {
              const g = mergeToolGroundedAnswer(
                revised.answer,
                toolsFormatted || toolRun?.formattedBlock,
                smartPolicy.problemClass
              );
              finalAnswer = g.answer;
              if (typeof revised.psi === "number" && revised.psi > 0) {
                confidence.psi = Math.max(confidence.psi, Math.min(1, revised.psi));
                confidence.confidence = confidence.psi;
              }
              confidence.evidence.push(`مراجعة ذكية: ${revision.reason}`);
              tracer.endStep("ok", `revised via core (${revision.reason})`);
            } else {
              // Local tightening without new model call
              finalAnswer =
                finalAnswer.trim() +
                "\n\n—\n[مراجعة] يُفضَّل التحقق من النقاط الضعيفة: " +
                revision.reason;
              confidence.evidence.push(`مراجعة محلية: ${revision.reason}`);
              tracer.endStep("ok", "local revision note");
            }
          } else {
            finalAnswer =
              finalAnswer.trim() +
              "\n\n—\n[مراجعة] " +
              revision.reason +
              (toolsFormatted ? "\n[أدوات]\n" + toolsFormatted.slice(0, 400) : "");
            confidence.evidence.push(`مراجعة بدون نواة: ${revision.reason}`);
            tracer.endStep("ok", "offline revision annotate");
          }
        } catch (err: any) {
          tracer.endStep("error", String(err?.message ?? err));
        }
      }

      // Best-effort write-back of successful outcomes into memory
      if (
        sourceClass !== "failed" &&
        confidence.confidence >= 0.5 &&
        finalAnswer.length > 20
      ) {
        try {
          await persistWorkspaceOutcome({
            userId: request.userId,
            question: request.question,
            answer: finalAnswer,
            domain: plan.goal.domain,
            psi: confidence.psi,
            verified: confidence.verified,
            sourceClass,
            isGuest:
              request.userId === "guest-user" ||
              request.userId.startsWith("guest-"),
          });
        } catch {
          // non-fatal
        }
      }

      // -----------------------------------------------------------------
      // 10. Finalize
      // -----------------------------------------------------------------
      const trace = tracer.finalize(finalAnswer);

      return {
        answer: finalAnswer,
        confidence,
        trace,
        sourceClass,
        psi: confidence.psi,
      };
    } catch (err: any) {
      tracer.setError(String(err?.message ?? err));
      const confidence = buildFallbackConfidence("failed", 0);
      const trace = tracer.finalize(
        "حدث خطأ أثناء تنفيذ مساحة العمل المعرفية."
      );
      return {
        answer: trace.finalAnswer,
        confidence,
        trace,
        sourceClass: "failed",
        psi: 0,
      };
    }
  }

  // -----------------------------------------------------------------------
  // Internal: optional bridge to existing OmegaCore
  // -----------------------------------------------------------------------

  /** Honest placeholder when OmegaCore bridge is missing or empty (Phase 12.0) */
  private buildPlanAwarePlaceholder(plan: CognitivePlan, coreWired = false): string {
    const lines = [
      `[Cognitive Workspace]`,
      ``,
      `الهدف: ${plan.goal.refinedGoal}`,
      `النطاق: ${plan.goal.domain}`,
      `التعقيد: ${plan.estimatedComplexity}`,
      ``,
      `الخطة المولَّدة:`,
      ...plan.tasks.map(
        (t, i) =>
          `  ${i + 1}. [${t.type}] ${t.title} (${t.status})`
      ),
      ``,
      coreWired
        ? `ملاحظة: OmegaCore مربوط لكنه لم يُرجع إجابة نصية — استُخدم مخطط الدورة.`
        : `ملاحظة: OmegaCore غير مسجّل. من server.ts استدعِ registerCoreRunner(...).`,
    ];
    return lines.join("\n");
  }
}

// ---------------------------------------------------------------------------
// Singleton helper
// ---------------------------------------------------------------------------

let _instance: CognitiveWorkspace | null = null;

export function getCognitiveWorkspace(
  config?: Partial<WorkspaceConfig>
): CognitiveWorkspace {
  if (!_instance || config) {
    _instance = new CognitiveWorkspace(config);
  }
  return _instance;
}

export async function runCognitiveWorkspace(
  request: WorkspaceRequest
): Promise<WorkspaceResult> {
  const depth = request.depth ?? "balanced";
  const ws = getCognitiveWorkspace({ depth, ...request.config });
  return ws.run(request);
}
