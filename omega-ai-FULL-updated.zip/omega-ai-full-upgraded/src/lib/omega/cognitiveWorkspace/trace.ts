/**
 * src/lib/omega/cognitiveWorkspace/trace.ts
 * =============================================================================
 * Cognitive Trace Recorder — records every step of a workspace cycle
 * =============================================================================
 */

import type {
  CognitiveTrace,
  CognitivePlan,
  MemoryContext,
  ToolCallRecord,
  AgentOpinion,
  ReflectionNote,
  ConfidenceReport,
  TraceStep,
  ReasoningDepth,
  SourceClass,
} from "./types";
import type { OmegaCandidate } from "../omegaCore";

function generateId(): string {
  try {
    // crypto.randomUUID available in Node 19+ and modern runtimes
    const uuid =
      typeof globalThis.crypto?.randomUUID === "function"
        ? globalThis.crypto.randomUUID()
        : null;
    if (uuid) return `ws_${uuid}`;
  } catch {
    // fall through
  }
  // Fallback: high-entropy composite (still better than Math.random alone)
  const a = Date.now().toString(36);
  const b = process.hrtime.bigint().toString(36);
  const c = Math.random().toString(36).slice(2, 10);
  return `ws_${a}_${b}_${c}`;
}

const EMPTY_MEMORY: MemoryContext = {
  episodic: [],
  semantic: [],
  procedural: [],
  graphNodes: [],
  graphEdges: [],
  workingKeys: [],
};

const EMPTY_CONFIDENCE: ConfidenceReport = {
  psi: 0,
  confidence: 0,
  evidence: [],
  risk: [],
  unknowns: [],
  sourceClass: "failed",
  verified: null,
};

export class CognitiveTraceRecorder {
  private trace: CognitiveTrace;
  private currentStepName: string | null = null;
  private currentStepStarted = 0;

  constructor(userId: string, depth: ReasoningDepth) {
    this.trace = {
      workspaceId: generateId(),
      userId,
      startedAt: Date.now(),
      depth,
      plan: {
        goal: {
          originalQuestion: "",
          refinedGoal: "",
          domain: "general",
          successCriteria: [],
          constraints: [],
          keywords: [],
          complexity: "low",
        },
        tasks: [],
        estimatedComplexity: "low",
        createdAt: Date.now(),
      },
      memory: { ...EMPTY_MEMORY },
      toolCalls: [],
      agentOpinions: [],
      candidates: [],
      reflectionNotes: [],
      confidence: { ...EMPTY_CONFIDENCE },
      finalAnswer: "",
      steps: [],
    };
  }

  get id(): string {
    return this.trace.workspaceId;
  }

  /** Start a named step. Automatically closes the previous open step. */
  beginStep(name: string): void {
    if (this.currentStepName) {
      this.endStep("ok");
    }
    this.currentStepName = name;
    this.currentStepStarted = Date.now();
  }

  /** Close the current step with a status. */
  endStep(
    status: TraceStep["status"] = "ok",
    detail?: string
  ): void {
    if (!this.currentStepName) return;
    this.trace.steps.push({
      name: this.currentStepName,
      startedAt: this.currentStepStarted,
      durationMs: Date.now() - this.currentStepStarted,
      status,
      detail,
    });
    this.currentStepName = null;
  }

  setPlan(plan: CognitivePlan): void {
    this.trace.plan = plan;
  }

  setMemory(memory: MemoryContext): void {
    this.trace.memory = memory;
  }

  addToolCall(record: ToolCallRecord): void {
    this.trace.toolCalls.push(record);
  }

  addAgentOpinion(opinion: AgentOpinion): void {
    this.trace.agentOpinions.push(opinion);
  }

  setCandidates(candidates: OmegaCandidate[]): void {
    this.trace.candidates = candidates;
  }

  addReflection(note: ReflectionNote): void {
    this.trace.reflectionNotes.push(note);
  }

  setConfidence(report: ConfidenceReport): void {
    this.trace.confidence = report;
  }

  setError(message: string): void {
    this.trace.error = message;
    if (this.currentStepName) {
      this.endStep("error", message);
    }
  }

  /**
   * Finalize the trace with the chosen answer.
   * Closes any open step and stamps finishedAt.
   */
  finalize(finalAnswer: string): CognitiveTrace {
    if (this.currentStepName) {
      this.endStep("ok");
    }
    this.trace.finalAnswer = finalAnswer;
    this.trace.finishedAt = Date.now();
    return { ...this.trace };
  }

  /** Snapshot of the current (possibly incomplete) trace */
  snapshot(): CognitiveTrace {
    return { ...this.trace };
  }
}
