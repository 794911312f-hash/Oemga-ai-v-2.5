/**
 * src/lib/omega/cognitiveWorkspace/reflector.ts
 * =============================================================================
 * Reflector + Self-Verification (Phase 11.5)
 * =============================================================================
 *
 * Two layers:
 *   1. verifyAnswer (selfVerify.ts) — model or algorithmic consistency check
 *   2. Local reflection heuristics — coverage of success criteria, constraints,
 *      empty answers, tool failures, plan completeness
 *
 * Can optionally append a short honesty footer to the answer when issues found.
 * Does not invent new factual claims.
 */

import { verifyAnswer, type VerificationResult } from "../selfVerify";
import type { ModelId } from "../models";
import type {
  CognitivePlan,
  ReflectionNote,
  SourceClass,
  ReasoningDepth,
} from "./types";
import type { SynthesisResult } from "./synthesizer";
import type { OrchestratorRunResult } from "./toolOrchestrator";

export interface ReflectorInput {
  question: string;
  answer: string;
  plan: CognitivePlan;
  synthesis: SynthesisResult;
  tools?: OrchestratorRunResult | null;
  depth: ReasoningDepth;
  /** Preferred verifier model */
  verifierModel?: ModelId;
  /** Skip network verify (use algorithmic only) */
  offlineOnly?: boolean;
}

export interface ReflectorResult {
  /** Possibly annotated answer */
  answer: string;
  notes: ReflectionNote[];
  verification: VerificationResult;
  /** true | false | null (null = verification inconclusive / skipped) */
  verified: boolean | null;
  /** Suggested confidence adjustment (-0.15 … +0.08) */
  confidenceDelta: number;
  improved: boolean;
}

const DEFAULT_VERIFIER: ModelId = "gemini-3.8-flash" as ModelId;

// ---------------------------------------------------------------------------
// Local heuristics
// ---------------------------------------------------------------------------

function checkSuccessCriteria(
  answer: string,
  plan: CognitivePlan
): ReflectionNote[] {
  const notes: ReflectionNote[] = [];
  const lower = answer.toLowerCase();

  for (const criterion of plan.goal.successCriteria) {
    // Lightweight keyword overlap — not a semantic judge
    const tokens = criterion
      .replace(/[^\p{L}\p{N}\s]/gu, " ")
      .split(/\s+/)
      .filter((t) => t.length > 3)
      .slice(0, 4);
    if (tokens.length === 0) continue;
    const hits = tokens.filter((t) => lower.includes(t.toLowerCase())).length;
    if (hits === 0 && plan.goal.complexity !== "low") {
      notes.push({
        type: "coverage",
        message: `معيار النجاح قد يكون غير مغطى صراحة: «${criterion}»`,
        severity: "info",
      });
    }
  }
  return notes;
}

function checkConstraints(answer: string, plan: CognitivePlan): ReflectionNote[] {
  const notes: ReflectionNote[] = [];
  for (const c of plan.goal.constraints) {
    if (/مختصر|briefly/i.test(c) && answer.length > 1200) {
      notes.push({
        type: "improvement",
        message: "طُلب الاختصار لكن الإجابة طويلة نسبيًا",
        severity: "warn",
      });
    }
    if (/مفصل|in detail|بالتفصيل/i.test(c) && answer.length < 120) {
      notes.push({
        type: "coverage",
        message: "طُلب التفصيل لكن الإجابة قصيرة",
        severity: "warn",
      });
    }
  }
  return notes;
}

function checkSynthesisAndTools(
  synthesis: SynthesisResult,
  tools: OrchestratorRunResult | null | undefined
): ReflectionNote[] {
  const notes: ReflectionNote[] = [];

  if (synthesis.method === "plan_placeholder") {
    notes.push({
      type: "other",
      message: "لم تُنتَج إجابة فعلية — الدورة انتهت بمخطط فقط",
      severity: "error",
    });
  }
  if (synthesis.method === "memory_fallback") {
    notes.push({
      type: "other",
      message: "الإجابة من الذاكرة فقط دون استدلال نموذجي كامل",
      severity: "warn",
    });
  }
  if (synthesis.sourceClass === "simulated") {
    notes.push({
      type: "hallucination",
      message: "المصدر موسوم simulated — احتمال أعلى للهلوسة أو التقريب",
      severity: "warn",
    });
  }

  if (tools) {
    const failed = tools.results.filter((r) => !r.success);
    for (const f of failed) {
      notes.push({
        type: "other",
        message: `فشل الأداة ${f.toolId}: ${f.error || "unknown"}`,
        severity: "warn",
      });
    }
  }

  if (!synthesis.answer.trim() || synthesis.answer.trim().length < 15) {
    notes.push({
      type: "coverage",
      message: "الإجابة فارغة أو أقصر من أن تغطي السؤال",
      severity: "error",
    });
  }

  return notes;
}

function checkInternalTension(answer: string): ReflectionNote[] {
  const notes: ReflectionNote[] = [];
  const lower = answer.toLowerCase();
  if (
    (lower.includes(" is ") && lower.includes(" is not ")) ||
    (lower.includes("صحيح") && lower.includes("غير صحيح")) ||
    (lower.includes("always") && lower.includes("never"))
  ) {
    notes.push({
      type: "contradiction",
      message: "عبارات قطعية متقابلة داخل الإجابة — تحتاج مراجعة سياقية",
      severity: "warn",
    });
  }
  return notes;
}

function buildHonestyFooter(notes: ReflectionNote[], verification: VerificationResult): string {
  const important = notes.filter((n) => n.severity !== "info");
  if (important.length === 0 && verification.verified && verification.warnings.length === 0) {
    return "";
  }

  const lines: string[] = ["", "---", "_ملاحظات التأمل الذاتي:_"];
  if (!verification.verified) {
    lines.push(`- التحقق: لم يُجتَز بالكامل (درجة ${verification.score.toFixed(2)})`);
  } else if (verification.warnings.length > 0) {
    lines.push(`- التحقق: نجح مع تحفظات (درجة ${verification.score.toFixed(2)})`);
  }
  for (const w of verification.warnings.slice(0, 3)) {
    lines.push(`- ${w}`);
  }
  for (const n of important.slice(0, 4)) {
    lines.push(`- [${n.severity}] ${n.message}`);
  }
  return lines.join("\n");
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export async function reflectOnAnswer(
  input: ReflectorInput
): Promise<ReflectorResult> {
  const notes: ReflectionNote[] = [];
  let confidenceDelta = 0;
  let improved = false;
  let answer = input.answer;

  // 1) Structured self-verification
  let verification: VerificationResult;
  try {
    // When offlineOnly, force algorithmic path by passing a throwaway that still
    // works if fetch fails — verifyAnswer already falls back.
    verification = await verifyAnswer(
      input.question,
      input.answer,
      input.verifierModel ?? DEFAULT_VERIFIER
    );
  } catch (err: any) {
    verification = {
      verified: false,
      score: 0.4,
      critique: `تعذّر التحقق: ${err?.message ?? err}`,
      hasContradiction: false,
      claimsChecked: 0,
      warnings: ["verification threw"],
      verifierModel: input.verifierModel ?? DEFAULT_VERIFIER,
    };
  }

  if (verification.hasContradiction) {
    notes.push({
      type: "contradiction",
      message: verification.critique || "تناقض داخلي مُكتشف",
      severity: "error",
    });
    confidenceDelta -= 0.12;
  } else if (verification.verified) {
    notes.push({
      type: "other",
      message: verification.critique || "اجتازت فحص الاتساق",
      severity: "info",
    });
    confidenceDelta += 0.05;
  } else {
    notes.push({
      type: "other",
      message: verification.critique || "التحقق لم يصل لعتبة القبول",
      severity: "warn",
    });
    confidenceDelta -= 0.06;
  }

  for (const w of verification.warnings) {
    notes.push({ type: "other", message: w, severity: "warn" });
  }

  // 2) Local reflection
  notes.push(...checkSuccessCriteria(answer, input.plan));
  notes.push(...checkConstraints(answer, input.plan));
  notes.push(...checkSynthesisAndTools(input.synthesis, input.tools));
  notes.push(...checkInternalTension(answer));

  // Severity-based delta
  const errors = notes.filter((n) => n.severity === "error").length;
  const warns = notes.filter((n) => n.severity === "warn").length;
  confidenceDelta -= Math.min(0.1, errors * 0.05);
  confidenceDelta -= Math.min(0.08, warns * 0.02);

  // 3) Optional honesty footer (balanced/deep only, and only if issues)
  if (input.depth !== "fast") {
    const footer = buildHonestyFooter(notes, verification);
    if (footer) {
      answer = answer.trimEnd() + footer;
      improved = true;
      notes.push({
        type: "improvement",
        message: "أُضيفت حاشية صدق بعد التأمل الذاتي",
        severity: "info",
      });
    }
  }

  const verified: boolean | null = verification.verified;

  return {
    answer,
    notes,
    verification,
    verified,
    confidenceDelta: Number(confidenceDelta.toFixed(3)),
    improved,
  };
}

/**
 * Verification-only helper (no answer mutation) — useful for the verify task.
 */
export async function runVerificationPass(
  question: string,
  answer: string,
  verifierModel?: ModelId
): Promise<VerificationResult> {
  return verifyAnswer(question, answer, verifierModel ?? DEFAULT_VERIFIER);
}
