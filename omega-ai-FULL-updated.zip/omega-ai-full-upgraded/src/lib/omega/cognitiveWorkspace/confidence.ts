/**
 * src/lib/omega/cognitiveWorkspace/confidence.ts
 * =============================================================================
 * Confidence Estimator — rich Ψ + Evidence + Risk + Unknowns (Phase 11.4)
 * =============================================================================
 */

import type { OmegaCandidate } from "../omegaCore";
import { scoreEvidencePsi, numericCoverage } from "../evidencePsi";
import type {
  CognitivePlan,
  MemoryContext,
  ConfidenceReport,
  SourceClass,
  ToolCallRecord,
  ReasoningDepth,
} from "./types";
import type { SynthesisResult } from "./synthesizer";
import type { OrchestratorRunResult } from "./toolOrchestrator";

export interface ConfidenceInput {
  plan: CognitivePlan;
  memory: MemoryContext;
  tools?: OrchestratorRunResult | null;
  toolRecords?: ToolCallRecord[];
  candidates: OmegaCandidate[];
  synthesis: SynthesisResult;
  /** Ψ from OmegaCore / kernel when available */
  corePsi: number;
  coreVerified: boolean | null;
  depth: ReasoningDepth;
  domainKeywords?: string[];
}

// ---------------------------------------------------------------------------
// Scoring
// ---------------------------------------------------------------------------

function clamp01(n: number): number {
  return Math.max(0, Math.min(1, n));
}

function candidateAgreement(candidates: OmegaCandidate[]): number {
  if (candidates.length <= 1) return candidates.length === 1 ? 0.55 : 0.3;
  const real = candidates.filter((c) => !c.simulated);
  if (real.length >= 2) return 0.75;
  if (real.length === 1) return 0.55;
  return 0.4;
}

function toolBoost(tools: OrchestratorRunResult | null | undefined): {
  boost: number;
  realCount: number;
  failCount: number;
  casHit: boolean;
  casSnippet: string | null;
} {
  if (!tools || tools.results.length === 0) {
    return { boost: 0, realCount: 0, failCount: 0, casHit: false, casSnippet: null };
  }
  const real = tools.results.filter(
    (r) => r.success && r.sourceClass === "real"
  );
  const fail = tools.results.filter((r) => !r.success);
  // Hard tools (CAS/code/calc) are stronger evidence
  const hard = real.filter((r) =>
    ["symbolic_cas", "calculator", "code_sandbox"].includes(r.toolId)
  );
  const cas = real.find((r) => r.toolId === "symbolic_cas" || r.toolId === "calculator");
  let boost = 0;
  boost += Math.min(0.12, real.length * 0.04);
  boost += Math.min(0.15, hard.length * 0.08);
  // Explicit CAS/calculator external evidence channel → B_ev
  if (cas) {
    boost += 0.12;
  }
  boost -= Math.min(0.1, fail.length * 0.04);
  const casSnippet =
    cas && typeof (cas as any).output === "string"
      ? String((cas as any).output).slice(0, 120)
      : cas && typeof (cas as any).result === "string"
        ? String((cas as any).result).slice(0, 120)
        : cas
          ? "CAS/calc ok"
          : null;
  return {
    boost,
    realCount: real.length,
    failCount: fail.length,
    casHit: !!cas,
    casSnippet,
  };
}

function memoryBoost(memory: MemoryContext): {
  boost: number;
  axiomHits: number;
  episodicHits: number;
  graphHits: number;
} {
  const axiomHits = memory.semantic.filter((s) =>
    s.tags?.includes("axiom")
  ).length;
  const episodicHits = memory.episodic.length;
  const graphHits = memory.graphNodes.length;
  let boost = 0;
  boost += Math.min(0.08, axiomHits * 0.04);
  boost += Math.min(0.06, episodicHits * 0.02);
  boost += Math.min(0.08, graphHits * 0.02);
  if (memory.procedural.length > 0) boost += 0.02;
  return { boost, axiomHits, episodicHits, graphHits };
}

function methodFactor(method: SynthesisResult["method"]): number {
  switch (method) {
    case "core_plus_tools":
      return 0.08;
    case "core_only":
      return 0.04;
    case "tools_primary":
      return 0.06;
    case "memory_fallback":
      return -0.05;
    case "plan_placeholder":
      return -0.25;
    default:
      return 0;
  }
}

function depthPenalty(depth: ReasoningDepth, plan: CognitivePlan): number {
  // Deep requests that skipped reflection / agents slightly lower confidence
  // until those stages are real (11.5 / 11.6)
  if (depth === "deep") {
    const hasReflect = plan.tasks.some((t) => t.id === "t_reflect");
    const reflectDone = plan.tasks.find((t) => t.id === "t_reflect")?.status === "done";
    if (hasReflect && !reflectDone) return -0.03;
  }
  return 0;
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

export function estimateConfidence(input: ConfidenceInput): ConfidenceReport {
  const evidence: string[] = [];
  const risk: string[] = [];
  const unknowns: string[] = [];

  const agree = candidateAgreement(input.candidates);
  const tools = toolBoost(input.tools);
  const mem = memoryBoost(input.memory);

  // Tool support signal for evidence Ψ (hard tools weigh more)
  const toolSupportLevel = clamp01(
    (tools.realCount > 0 ? 0.35 : 0) + tools.boost * 2
  );

  // Hybrid evidence Ψ over candidates when available
  let hybridTop: number | null = null;
  let hybridUncertain = false;
  if (input.candidates.length > 0) {
    const question = input.plan.goal.originalQuestion || "";
    const scored = scoreEvidencePsi(
      input.candidates.map((c) => c.text),
      {
        question,
        trimOutliers: true,
        evidence: input.candidates.map((c) => {
          let ts = toolSupportLevel;
          // Align candidate with CAS snippet when present (external symbolic evidence)
          if (tools.casHit && tools.casSnippet) {
            const snip = tools.casSnippet.toLowerCase();
            const textL = c.text.toLowerCase();
            if (snip.length > 2 && textL.includes(snip.slice(0, Math.min(40, snip.length)))) {
              ts = clamp01(ts + 0.2);
            } else {
              // CAS succeeded but candidate ignores it — mild penalty
              ts = clamp01(ts * 0.7);
            }
          }
          return {
            simulated: c.simulated,
            verified: input.coreVerified,
            verificationScore:
              input.coreVerified === true
                ? 0.85
                : input.coreVerified === false
                  ? 0.2
                  : null,
            toolSupport: ts,
            numericCoverage: question
              ? numericCoverage(question, c.text)
              : 0.5,
          };
        }),
      }
    );
    hybridTop = Math.max(...scored.psiHybrid);
    hybridUncertain = scored.uncertain;
  }

  // Base: prefer hybrid when present, else core Ψ
  let psi = clamp01(
    hybridTop != null
      ? hybridTop * 0.7 + (input.corePsi > 0 ? input.corePsi : 0.5) * 0.3
      : input.corePsi > 0
        ? input.corePsi
        : 0.5
  );
  psi = clamp01(
    psi * 0.7 +
      agree * 0.12 +
      0.18 * (0.5 + tools.boost + mem.boost + methodFactor(input.synthesis.method))
  );
  psi = clamp01(psi + depthPenalty(input.depth, input.plan));
  if (hybridUncertain) {
    psi = clamp01(psi - 0.04);
  }

  // --- Evidence ---
  evidence.push(`النطاق: ${input.plan.goal.domain}`);
  evidence.push(`التعقيد التقديري: ${input.plan.estimatedComplexity}`);
  evidence.push(`طريقة التركيب: ${input.synthesis.method}`);

  if (input.domainKeywords && input.domainKeywords.length > 0) {
    evidence.push(
      `كلمات مفتاحية: ${input.domainKeywords.slice(0, 6).join(", ")}`
    );
  }

  const realCandidates = input.candidates.filter((c) => !c.simulated);
  if (realCandidates.length > 0) {
    evidence.push(`مرشّحون حقيقيون من مزودين: ${realCandidates.length}`);
  }
  if (input.candidates.length > 1) {
    evidence.push(`عدد المرشّحين الإجمالي: ${input.candidates.length}`);
  }

  if (tools.realCount > 0) {
    const ids = input.tools!.results
      .filter((r) => r.success && r.sourceClass === "real")
      .map((r) => r.toolId);
    evidence.push(`أدوات حقيقية ناجحة: ${ids.join(", ")}`);
  }

  if (mem.axiomHits > 0) {
    evidence.push(`بدهيات مسترجعة: ${mem.axiomHits}`);
  }
  if (mem.episodicHits > 0) {
    evidence.push(`تجارب عرضية: ${mem.episodicHits}`);
  }
  if (mem.graphHits > 0) {
    evidence.push(
      `رسم معرفي: ${mem.graphHits} عقدة / ${input.memory.graphEdges.length} علاقة`
    );
  }
  if (input.memory.procedural.length > 0) {
    evidence.push(`أنماط إجرائية: ${input.memory.procedural.length}`);
  }
  for (const n of input.synthesis.notes.slice(0, 3)) {
    evidence.push(n);
  }
  if (input.synthesis.injectedSections.length > 0) {
    evidence.push(
      `أقسام مُحقونة في الإجابة: ${input.synthesis.injectedSections.join(", ")}`
    );
  }

  // --- Risk ---
  if (input.synthesis.sourceClass === "simulated") {
    risk.push("الإجابة تعتمد كليًا أو جزئيًا على محاكاة / fallback");
  }
  if (input.synthesis.sourceClass === "mixed") {
    risk.push("مزيج من مصادر حقيقية ومحاكاة");
  }
  if (tools.failCount > 0) {
    const failed = input.tools!.results
      .filter((r) => !r.success)
      .map((r) => r.toolId);
    risk.push(`فشل أدوات: ${failed.join(", ")}`);
  }
  if (input.candidates.every((c) => c.simulated) && input.candidates.length > 0) {
    risk.push("كل مرشّحي النماذج موسومون simulated");
  }
  if (input.synthesis.method === "memory_fallback") {
    risk.push("لا استدلال نموذجي — اعتماد على ذاكرة فقط");
  }
  if (input.synthesis.method === "plan_placeholder") {
    risk.push("لم تُنتَج إجابة فعلية");
  }
  if (input.plan.goal.complexity === "high" && input.depth === "fast") {
    risk.push("سؤال عالي التعقيد نُفِّذ بعمق fast");
  }

  // --- Unknowns ---
  if (input.coreVerified === null) {
    unknowns.push("لم يُنفَّذ تحقق ذاتي رسمي بعد (Phase 11.5)");
  } else if (input.coreVerified === false) {
    unknowns.push("التحقق الذاتي لم يمر بنجاح");
    risk.push("verification failed");
  }

  if (mem.episodicHits === 0 && mem.axiomHits === 0 && mem.graphHits === 0) {
    unknowns.push("لا سياق ذاكرة/رسم قوي لهذا السؤال");
  }
  if (tools.realCount === 0 && input.plan.tasks.some((t) => t.id === "t_tools")) {
    unknowns.push("مهمة أدوات في الخطة لكن بلا نتائج حقيقية");
  }
  if (
    input.plan.tasks.some((t) => t.id === "t_agents") &&
    input.plan.tasks.find((t) => t.id === "t_agents")?.status !== "done"
  ) {
    unknowns.push("نقاش الوكلاء المتعددين لم يُنفَّذ بعد (Phase 11.6)");
  }
  if (
    input.plan.tasks.some((t) => t.id === "t_reflect") &&
    input.plan.tasks.find((t) => t.id === "t_reflect")?.status !== "done"
  ) {
    unknowns.push("مرحلة التأمل الذاتي لم تُكتمل بعد (Phase 11.5)");
  }

  // Overall confidence: slightly smoothed Ψ, penalize failed synthesis
  let confidence = psi;
  if (input.synthesis.method === "plan_placeholder") {
    confidence = Math.min(confidence, 0.25);
  }
  if (input.coreVerified === true) {
    confidence = clamp01(confidence + 0.05);
    evidence.push("تحقق ذاتي: نجح");
  }

  const sourceClass: SourceClass = input.synthesis.sourceClass;

  return {
    psi: Number(psi.toFixed(4)),
    confidence: Number(confidence.toFixed(4)),
    evidence,
    risk,
    unknowns,
    sourceClass,
    verified: input.coreVerified,
  };
}
