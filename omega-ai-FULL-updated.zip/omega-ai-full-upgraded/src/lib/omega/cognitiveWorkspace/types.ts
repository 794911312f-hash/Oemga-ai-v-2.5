/**
 * src/lib/omega/cognitiveWorkspace/types.ts
 * =============================================================================
 * Omega Cognitive Workspace — Core Types (Phase 11)
 * =============================================================================
 *
 * Defines the full type system for the Cognitive Workspace orchestration layer.
 * This layer sits above OmegaCore / InferenceEngine and coordinates:
 *   Planner → Memory → Knowledge Graph → Tools → Agents → Verification → Reflection
 */

import type { Domain } from "../domainRouting";
import type { ModelId } from "../models";
import type { OmegaCandidate } from "../omegaCore";
import type { MemoryItem } from "../firebase";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

export type ReasoningDepth = "fast" | "balanced" | "deep";

export interface WorkspaceConfig {
  /** How deep the reasoning pipeline should go */
  depth: ReasoningDepth;
  /** Allow tool calling */
  enableTools: boolean;
  /** Allow multi-agent debate / voting */
  enableMultiAgent: boolean;
  /** Run self-reflection after synthesis */
  enableReflection: boolean;
  /** Maximum number of tool calls in one cycle */
  maxToolCalls: number;
  /** Maximum number of agents in multi-agent mode */
  maxAgents: number;
  /** Hard timeout for the whole workspace cycle (ms) */
  timeoutMs: number;
  /** Optional override of domain detection */
  forcedDomain?: Domain;
}

export const DEFAULT_WORKSPACE_CONFIG: WorkspaceConfig = {
  depth: "balanced",
  enableTools: true,
  enableMultiAgent: false,
  enableReflection: true,
  maxToolCalls: 5,
  maxAgents: 3,
  timeoutMs: 45_000,
};

export function configForDepth(depth: ReasoningDepth): WorkspaceConfig {
  switch (depth) {
    case "fast":
      return {
        depth: "fast",
        enableTools: true,
        enableMultiAgent: false,
        enableReflection: false,
        maxToolCalls: 2,
        maxAgents: 1,
        timeoutMs: 15_000,
      };
    case "deep":
      return {
        depth: "deep",
        enableTools: true,
        enableMultiAgent: true,
        enableReflection: true,
        maxToolCalls: 12,
        maxAgents: 5,
        timeoutMs: 90_000,
      };
    case "balanced":
    default:
      return { ...DEFAULT_WORKSPACE_CONFIG };
  }
}

// ---------------------------------------------------------------------------
// Goal & Planning
// ---------------------------------------------------------------------------

export interface CognitiveGoal {
  originalQuestion: string;
  refinedGoal: string;
  domain: Domain;
  successCriteria: string[];
  constraints: string[];
  keywords: string[];
  complexity: "low" | "medium" | "high";
}

export type TaskType =
  | "retrieve"
  | "reason"
  | "tool"
  | "verify"
  | "synthesize"
  | "reflect"
  | "agent";

export type TaskStatus =
  | "pending"
  | "running"
  | "done"
  | "failed"
  | "skipped";

export interface TaskNode {
  id: string;
  title: string;
  titleAr?: string;
  type: TaskType;
  status: TaskStatus;
  dependsOn: string[];
  /** Optional tool identifier when type === "tool" */
  toolId?: string;
  /** Optional agent role when type === "agent" */
  agentRole?: AgentRole;
  result?: unknown;
  confidence?: number;
  sourceClass?: SourceClass;
  error?: string;
  startedAt?: number;
  finishedAt?: number;
  durationMs?: number;
}

export interface CognitivePlan {
  goal: CognitiveGoal;
  tasks: TaskNode[];
  estimatedComplexity: "low" | "medium" | "high";
  createdAt: number;
}

// ---------------------------------------------------------------------------
// Memory & Graph context
// ---------------------------------------------------------------------------

export interface GraphNodeRef {
  id: string;
  label: string;
  type?: string;
  properties?: Record<string, unknown>;
}

export interface GraphEdgeRef {
  id: string;
  from: string;
  to: string;
  relation: string;
  weight?: number;
}

export interface MemoryContext {
  /** Recent / related session episodes */
  episodic: MemoryItem[];
  /** General semantic knowledge */
  semantic: MemoryItem[];
  /** How similar tasks were solved before */
  procedural: string[];
  /** Relevant knowledge-graph nodes */
  graphNodes: GraphNodeRef[];
  /** Relevant knowledge-graph edges */
  graphEdges: GraphEdgeRef[];
  /** Working-memory keys that were active */
  workingKeys: string[];
}

// ---------------------------------------------------------------------------
// Tools
// ---------------------------------------------------------------------------

export type SourceClass = "real" | "mixed" | "simulated" | "failed";

export interface ToolCallRecord {
  toolId: string;
  input: unknown;
  output: unknown;
  success: boolean;
  latencyMs: number;
  sourceClass: SourceClass;
  error?: string;
}

// ---------------------------------------------------------------------------
// Multi-Agent
// ---------------------------------------------------------------------------

export type AgentRole =
  | "scientist"
  | "critic"
  | "programmer"
  | "planner"
  | "security"
  | "mathematician"
  | "general";

export interface AgentOpinion {
  agentId: string;
  role: AgentRole;
  answer: string;
  confidence: number;
  critiques: string[];
  modelId?: ModelId;
  sourceClass?: SourceClass;
}

// ---------------------------------------------------------------------------
// Confidence & Reflection
// ---------------------------------------------------------------------------

export interface ConfidenceReport {
  /** Hybrid Ψ score from the kernel */
  psi: number;
  /** Overall confidence 0–1 */
  confidence: number;
  /** Supporting evidence statements */
  evidence: string[];
  /** Risks / weaknesses */
  risk: string[];
  /** Things we could not verify */
  unknowns: string[];
  sourceClass: SourceClass;
  /** null = verification was not possible */
  verified: boolean | null;
  verifierNotes?: string;
}

export interface ReflectionNote {
  type: "contradiction" | "improvement" | "hallucination" | "coverage" | "other";
  message: string;
  severity: "info" | "warn" | "error";
}

// ---------------------------------------------------------------------------
// Trace (full audit of one workspace cycle)
// ---------------------------------------------------------------------------

export interface TraceStep {
  name: string;
  startedAt: number;
  durationMs: number;
  status: "ok" | "warn" | "error" | "skipped";
  detail?: string;
}

export interface CognitiveTrace {
  workspaceId: string;
  userId: string;
  startedAt: number;
  finishedAt?: number;
  depth: ReasoningDepth;
  plan: CognitivePlan;
  memory: MemoryContext;
  toolCalls: ToolCallRecord[];
  agentOpinions: AgentOpinion[];
  candidates: OmegaCandidate[];
  reflectionNotes: ReflectionNote[];
  confidence: ConfidenceReport;
  finalAnswer: string;
  steps: TraceStep[];
  error?: string;
}

// ---------------------------------------------------------------------------
// Public result
// ---------------------------------------------------------------------------

export interface WorkspaceRequest {
  userId: string;
  question: string;
  history?: Array<{ role: string; content: string }>;
  domain?: Domain;
  models?: ModelId[];
  depth?: ReasoningDepth;
  config?: Partial<WorkspaceConfig>;
}

export interface WorkspaceResult {
  answer: string;
  confidence: ConfidenceReport;
  trace: CognitiveTrace;
  sourceClass: SourceClass;
  /** Convenience: same as confidence.psi */
  psi: number;
}
