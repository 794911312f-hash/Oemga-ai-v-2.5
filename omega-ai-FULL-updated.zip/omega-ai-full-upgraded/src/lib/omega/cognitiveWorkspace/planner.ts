/**
 * src/lib/omega/cognitiveWorkspace/planner.ts
 * =============================================================================
 * Cognitive Planner — Goal analysis + Task decomposition (Phase 11.1)
 * =============================================================================
 *
 * Turns a raw user question into a structured CognitivePlan:
 *   Intent → Domain → Complexity → Goal → Ordered Task Graph
 *
 * Reuses domainRouting for domain detection and keeps the plan
 * intentionally simple so it can be executed by the Workspace.
 */

import {
  modelsForQuestion,
  type Domain,
  type DomainRouteResult,
} from "../domainRouting";
import type {
  CognitiveGoal,
  CognitivePlan,
  TaskNode,
  TaskType,
  ReasoningDepth,
  WorkspaceConfig,
} from "./types";
import { classifyAndPolicy } from "./smartLoop";

// ---------------------------------------------------------------------------
// Intent / complexity heuristics (lightweight, no LLM required)
// ---------------------------------------------------------------------------

const TOOL_HINTS = [
  "احسب", "calculate", "solve", "compute", "execute", "run code",
  "شغّل", "نفّذ", "كود", "code", "python", "javascript",
  "ابحث", "search", "web", "arxiv", "pdf", "اقرأ", "read file",
  "حلل صورة", "analyze image", "ocr",
];

const MATH_HINTS = [
  "معادلة", "equation", "برهان", "proof", "تكامل", "integral",
  "تفاضل", "derivative", "مصفوفة", "matrix", "احتمال", "probability",
  "نظرية", "theorem", "رمز", "symbolic", "sympy", "latex",
];

const MULTI_STEP_HINTS = [
  "خطة", "plan", "خطوات", "steps", "ثم", "after that", "أولاً", "ثانياً",
  "قارن", "compare", "حلل", "analyze", "اقترح", "suggest", "صمم", "design",
  "كيف", "how to", "why", "لماذا", "اشرح بالتفصيل", "explain in detail",
];

const DEEP_REASONING_HINTS = [
  "ناقش", "debate", "انقد", "critique", "تحقق", "verify", "هل صحيح",
  "تناقض", "contradiction", "بدائل", "alternatives", "سيناريو",
];

function detectComplexity(
  question: string,
  domain: Domain,
  depth: ReasoningDepth
): "low" | "medium" | "high" {
  const q = question.toLowerCase();
  let score = 0;

  if (question.length > 180) score += 1;
  if (question.length > 400) score += 1;
  if (MULTI_STEP_HINTS.some((h) => q.includes(h))) score += 2;
  if (DEEP_REASONING_HINTS.some((h) => q.includes(h))) score += 2;
  if (TOOL_HINTS.some((h) => q.includes(h))) score += 1;
  if (MATH_HINTS.some((h) => q.includes(h))) score += 1;
  if (domain === "math_logic" || domain === "code") score += 1;
  if (depth === "deep") score += 2;
  if (depth === "fast") score = Math.max(0, score - 2);

  if (score >= 5) return "high";
  if (score >= 2) return "medium";
  return "low";
}

function extractKeywords(question: string): string[] {
  const tokens = question
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .split(/\s+/)
    .map((t) => t.trim())
    .filter((t) => t.length > 2);

  // Keep unique, prefer longer tokens, limit to 12
  const seen = new Set<string>();
  const result: string[] = [];
  for (const t of tokens) {
    const lower = t.toLowerCase();
    if (!seen.has(lower)) {
      seen.add(lower);
      result.push(t);
      if (result.length >= 12) break;
    }
  }
  return result;
}

function buildSuccessCriteria(
  question: string,
  domain: Domain,
  complexity: "low" | "medium" | "high"
): string[] {
  const criteria: string[] = [
    "الإجابة تجيب مباشرة على السؤال المطروح",
  ];

  if (domain === "math_logic") {
    criteria.push("الخطوات الرياضية واضحة وقابلة للتحقق");
    criteria.push("النتيجة النهائية محددة بوضوح");
  }
  if (domain === "code") {
    criteria.push("الكود قابل للتشغيل أو يوضح الفكرة بدقة");
    criteria.push("توضيح أي افتراضات أو قيود");
  }
  if (domain === "science_factual") {
    criteria.push("الادعاءات مدعومة أو موضحة بمصدر/منطق");
  }
  if (complexity === "high") {
    criteria.push("تم تغطية الجوانب الرئيسية دون إغفال جوهري");
    criteria.push("تم ذكر نقاط عدم اليقين إن وُجدت");
  }

  return criteria;
}

function buildConstraints(question: string, domain: Domain): string[] {
  const constraints: string[] = [];
  const q = question.toLowerCase();

  if (q.includes("باختصار") || q.includes("briefly") || q.includes("مختصر")) {
    constraints.push("الإجابة يجب أن تكون مختصرة");
  }
  if (q.includes("بالتفصيل") || q.includes("in detail") || q.includes("شرح مفصل")) {
    constraints.push("الإجابة يجب أن تكون مفصلة");
  }
  if (domain === "code") {
    constraints.push("تجنب تنفيذ كود خطير أو غير آمن");
  }
  return constraints;
}

// ---------------------------------------------------------------------------
// Task graph construction
// ---------------------------------------------------------------------------

function makeTask(
  id: string,
  title: string,
  type: TaskType,
  dependsOn: string[] = [],
  extra?: Partial<TaskNode>
): TaskNode {
  return {
    id,
    title,
    type,
    status: "pending",
    dependsOn,
    ...extra,
  };
}

function buildTaskGraph(
  goal: CognitiveGoal,
  depth: ReasoningDepth,
  config: WorkspaceConfig
): TaskNode[] {
  const tasks: TaskNode[] = [];
  const smart = classifyAndPolicy(goal.originalQuestion);
  const needsTools =
    config.enableTools &&
    (smart.toolFirst ||
      TOOL_HINTS.some((h) => goal.originalQuestion.toLowerCase().includes(h)) ||
      goal.domain === "code" ||
      goal.domain === "math_logic");

  const needsDeepReason =
    depth === "deep" ||
    goal.complexity === "high" ||
    DEEP_REASONING_HINTS.some((h) =>
      goal.originalQuestion.toLowerCase().includes(h)
    );

  // Always start with retrieval
  tasks.push(
    makeTask("t_retrieve", "استرجاع الذاكرة والرسم المعرفي", "retrieve")
  );

  // Optional tool stage
  if (needsTools) {
    tasks.push(
      makeTask(
        "t_tools",
        "اختيار وتنفيذ الأدوات اللازمة",
        "tool",
        ["t_retrieve"],
        { toolId: "auto" }
      )
    );
  }

  // Core reasoning
  const reasonDeps = needsTools ? ["t_tools"] : ["t_retrieve"];
  tasks.push(
    makeTask("t_reason", "الاستدلال الأساسي وتوليد المرشحين", "reason", reasonDeps)
  );

  // Multi-agent (only in deep + enabled)
  if (config.enableMultiAgent && needsDeepReason) {
    tasks.push(
      makeTask(
        "t_agents",
        "نقاش متعدد الوكلاء / نقد",
        "agent",
        ["t_reason"],
        { agentRole: "critic" }
      )
    );
  }

  // Synthesis
  const synthDeps =
    config.enableMultiAgent && needsDeepReason
      ? ["t_agents"]
      : ["t_reason"];
  tasks.push(
    makeTask("t_synthesize", "دمج النتائج وصياغة الإجابة", "synthesize", synthDeps)
  );

  // Verification
  tasks.push(
    makeTask(
      "t_verify",
      "التحقق من الاتساق والدقة",
      "verify",
      ["t_synthesize"]
    )
  );

  // Reflection (balanced / deep)
  if (config.enableReflection && depth !== "fast") {
    tasks.push(
      makeTask(
        "t_reflect",
        "التأمل الذاتي وتحسين الإجابة",
        "reflect",
        ["t_verify"]
      )
    );
  }

  return tasks;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export interface PlannerInput {
  question: string;
  depth: ReasoningDepth;
  config: WorkspaceConfig;
  /** Optional pre-detected domain */
  forcedDomain?: Domain;
}

export interface PlannerResult {
  plan: CognitivePlan;
  domainRoute: DomainRouteResult;
}

/**
 * Analyze the question and produce a full CognitivePlan.
 * Pure function — no side effects, no network.
 */
export function createCognitivePlan(input: PlannerInput): PlannerResult {
  const { question, depth, config } = input;

  // 1. Domain detection (reuse existing router)
  const domainRoute = modelsForQuestion(question);
  const domain: Domain =
    input.forcedDomain ?? config.forcedDomain ?? domainRoute.domain;

  // 2. Complexity
  const complexity = detectComplexity(question, domain, depth);

  // 3. Keywords
  const keywords = extractKeywords(question);

  // 4. Goal
  const goal: CognitiveGoal = {
    originalQuestion: question,
    refinedGoal: question.trim(),
    domain,
    successCriteria: buildSuccessCriteria(question, domain, complexity),
    constraints: buildConstraints(question, domain),
    keywords,
    complexity,
  };

  // 5. Task graph
  const tasks = buildTaskGraph(goal, depth, config);

  const plan: CognitivePlan = {
    goal,
    tasks,
    estimatedComplexity: complexity,
    createdAt: Date.now(),
  };

  return { plan, domainRoute };
}

/**
 * Return only the tasks that are ready to run given current statuses.
 */
export function getReadyTasks(plan: CognitivePlan): TaskNode[] {
  const statusMap = new Map(plan.tasks.map((t) => [t.id, t.status]));
  return plan.tasks.filter((t) => {
    if (t.status !== "pending") return false;
    return t.dependsOn.every((dep) => statusMap.get(dep) === "done");
  });
}

/**
 * Mark a task as running / done / failed and update the plan in-place.
 */
export function updateTaskStatus(
  plan: CognitivePlan,
  taskId: string,
  status: TaskNode["status"],
  result?: unknown,
  error?: string
): void {
  const task = plan.tasks.find((t) => t.id === taskId);
  if (!task) return;

  const now = Date.now();
  if (status === "running") {
    task.startedAt = now;
  }
  if (status === "done" || status === "failed" || status === "skipped") {
    task.finishedAt = now;
    if (task.startedAt) {
      task.durationMs = now - task.startedAt;
    }
  }
  task.status = status;
  if (result !== undefined) task.result = result;
  if (error) task.error = error;
}
