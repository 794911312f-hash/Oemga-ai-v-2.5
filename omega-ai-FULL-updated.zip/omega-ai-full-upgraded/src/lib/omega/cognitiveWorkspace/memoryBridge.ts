/**
 * src/lib/omega/cognitiveWorkspace/memoryBridge.ts
 * =============================================================================
 * Memory Bridge — connects Hierarchical + Semantic + Episodic memory (Phase 11.2)
 * =============================================================================
 *
 * Pulls context from:
 *   1. HierarchicalMemoryManager  (Working + Episodic + Axiomatic)
 *   2. firebase.searchMemory      (long-term ranked by sim/recency/confidence)
 *   3. globalOmegaMemory          (local semantic store)
 *
 * Returns a unified MemoryContext ready for the Cognitive Workspace.
 */

import { hashEmbed } from "../embeddings";
import { HierarchicalMemoryManager } from "../hierarchicalMemory";
import { searchMemory, type MemoryItem, type EvolutionExperience } from "../firebase";
import { globalOmegaMemory, type MemoryNode } from "../memory";
import type { MemoryContext } from "./types";

// Per-user manager cache (mirrors how InferenceEngine owns one)
const managers = new Map<string, HierarchicalMemoryManager>();

function getManager(userId: string): HierarchicalMemoryManager {
  let m = managers.get(userId);
  if (!m) {
    m = new HierarchicalMemoryManager(userId);
    managers.set(userId, m);
  }
  return m;
}

export interface MemoryBridgeOptions {
  userId: string;
  query: string;
  /** Max episodic items */
  episodicLimit?: number;
  /** Max semantic / long-term items */
  semanticLimit?: number;
  /** Max procedural snippets */
  proceduralLimit?: number;
}

export interface MemoryBridgeResult {
  context: MemoryContext;
  /** Human-readable block suitable for injection into prompts */
  formattedBlock: string;
  /** Stats for the trace */
  stats: {
    workingCount: number;
    episodicCount: number;
    semanticCount: number;
    axiomCount: number;
    proceduralCount: number;
  };
}

/**
 * Convert an EvolutionExperience into a MemoryItem-like shape for the context.
 */
function experienceToMemoryItem(exp: EvolutionExperience): MemoryItem {
  return {
    id: exp.id,
    userId: exp.userId,
    topic: exp.question.slice(0, 120),
    content: exp.finalAnswer.slice(0, 600),
    domain: exp.domain,
    confidence: exp.topPsi,
    tags: ["episodic", exp.domain],
    embedding: exp.embedding ?? [],
    accessCount: 1,
    timestamp: exp.timestamp,
    _sim: exp._sim,
  };
}

/**
 * Convert a local MemoryNode into MemoryItem.
 */
function nodeToMemoryItem(node: MemoryNode, userId: string, sim?: number): MemoryItem {
  return {
    id: node.id,
    userId,
    topic: node.topic,
    content: node.content,
    domain: node.domain,
    confidence: node.confidence,
    tags: node.tags,
    embedding: node.vector,
    accessCount: node.accessCount,
    timestamp: node.timestamp,
    _sim: sim,
  };
}

/**
 * Build procedural hints from past successful experiences.
 */
function extractProcedural(
  experiences: EvolutionExperience[],
  limit: number
): string[] {
  return experiences
    .filter((e) => e.verificationPassed && e.topPsi >= 0.6)
    .slice(0, limit)
    .map((e) => {
      const model = e.chosenModelId ? ` عبر ${e.chosenModelId}` : "";
      return `سبق حل سؤال مشابه («${e.question.slice(0, 60)}…») بنجاح (Ψ=${e.topPsi.toFixed(2)})${model}`;
    });
}

/**
 * Main entry: retrieve a full hierarchical memory context for the query.
 */
export async function retrieveMemoryContext(
  options: MemoryBridgeOptions
): Promise<MemoryBridgeResult> {
  const {
    userId,
    query,
    episodicLimit = 4,
    semanticLimit = 5,
    proceduralLimit = 3,
  } = options;

  const manager = getManager(userId);

  // 1. Hierarchical context (working + episodic + axioms) — single call
  const hierarchical = await manager.buildHierarchicalContext(query);

  // 2. Long-term semantic memory via firebase (ranked composite score)
  let longTerm: MemoryItem[] = [];
  try {
    const qVec = hashEmbed(query, 64);
    longTerm = await searchMemory(userId, qVec, semanticLimit);
  } catch {
    longTerm = [];
  }

  // 3. Local semantic store
  let localSemantic: MemoryItem[] = [];
  try {
    const hits = globalOmegaMemory.query(query, semanticLimit, 0.12);
    localSemantic = hits.map((h) => nodeToMemoryItem(h.node, userId, h.similarity));
  } catch {
    localSemantic = [];
  }

  // Merge semantic sources, prefer higher confidence / similarity, dedupe by topic
  const semanticMap = new Map<string, MemoryItem>();
  for (const item of [...longTerm, ...localSemantic]) {
    const key = (item.topic || item.content || "").slice(0, 80).toLowerCase();
    const existing = semanticMap.get(key);
    if (!existing || (item._sim ?? item.confidence) > (existing._sim ?? existing.confidence)) {
      semanticMap.set(key, item);
    }
  }
  const semantic = [...semanticMap.values()].slice(0, semanticLimit);

  // Episodic as MemoryItems
  const episodic = hierarchical.episodic
    .slice(0, episodicLimit)
    .map(experienceToMemoryItem);

  // Procedural
  const procedural = extractProcedural(hierarchical.episodic, proceduralLimit);

  // Working keys
  const workingKeys = hierarchical.working.map((w) => w.key);

  // Enrich semantic with axiom summaries (as high-confidence semantic items)
  for (const ax of hierarchical.axioms) {
    const key = ax.name.slice(0, 80).toLowerCase();
    if (!semanticMap.has(key)) {
      semantic.push({
        id: ax.id,
        userId,
        topic: ax.name,
        content: ax.statement + (ax.mathematicalLaw ? ` [${ax.mathematicalLaw}]` : ""),
        domain: ax.domain,
        confidence: 0.97,
        tags: ["axiom", ax.domain],
        embedding: [],
        accessCount: 0,
        timestamp: ax.verifiedAt,
        _sim: 0.9,
      });
    }
  }

  const context: MemoryContext = {
    episodic,
    semantic: semantic.slice(0, semanticLimit + hierarchical.axioms.length),
    procedural,
    graphNodes: [], // filled by graphBridge
    graphEdges: [],
    workingKeys,
  };

  // Build a compact formatted block for prompts
  const parts: string[] = [];
  if (hierarchical.formattedBlock) {
    parts.push(hierarchical.formattedBlock);
  }
  if (semantic.length > 0 && hierarchical.axioms.length === 0) {
    parts.push(
      "### 📚 ذاكرة دلالية مسترجعة:\n" +
        semantic
          .slice(0, 4)
          .map(
            (s) =>
              `• **${s.topic}**: ${s.content.slice(0, 160)}${s.content.length > 160 ? "…" : ""}`
          )
          .join("\n")
    );
  }
  if (procedural.length > 0) {
    parts.push(
      "### 🔧 ذاكرة إجرائية (كيف أُنجزت مهام مشابهة):\n" +
        procedural.map((p) => `• ${p}`).join("\n")
    );
  }

  return {
    context,
    formattedBlock: parts.join("\n\n"),
    stats: {
      workingCount: hierarchical.working.length,
      episodicCount: episodic.length,
      semanticCount: semantic.length,
      axiomCount: hierarchical.axioms.length,
      proceduralCount: procedural.length,
    },
  };
}

/**
 * Store a successful workspace outcome back into memory (optional write-back).
 * Call after a high-confidence cycle.
 */
export async function persistWorkspaceOutcome(opts: {
  userId: string;
  question: string;
  answer: string;
  domain: string;
  psi: number;
  verified: boolean | null;
  /** Must be real (or mixed) — never persist pure simulated/failed into shared stores */
  sourceClass?: string;
  /** Guests must not pollute global semantic memory */
  isGuest?: boolean;
}): Promise<void> {
  const isGuest =
    opts.isGuest === true ||
    opts.userId === "guest-user" ||
    opts.userId.startsWith("guest-");
  const src = opts.sourceClass ?? "simulated";

  // Only user-scoped working memory for authenticated, non-failed outcomes
  if (src === "failed") return;

  const manager = getManager(opts.userId);
  manager.setWorking(
    `last_answer_${Date.now()}`,
    {
      question: opts.question.slice(0, 200),
      answer: opts.answer.slice(0, 400),
      psi: opts.psi,
      sourceClass: src,
    },
    1000 * 60 * 30,
    2
  );

  // Shared global semantic store: authenticated + real/mixed only (Phase 12.2 security)
  if (isGuest) return;
  if (src !== "real" && src !== "mixed") return;
  if (opts.psi < 0.55) return;

  try {
    globalOmegaMemory.add(
      opts.question.slice(0, 120),
      opts.answer.slice(0, 800),
      opts.domain as any,
      Math.max(0.4, Math.min(0.99, opts.psi)),
      [
        "workspace",
        opts.domain,
        opts.verified ? "verified" : "unverified",
        `user:${opts.userId.slice(0, 32)}`,
        src,
      ]
    );
  } catch {
    // non-fatal
  }
}

/** Expose manager for advanced callers / tests */
export function getMemoryManager(userId: string): HierarchicalMemoryManager {
  return getManager(userId);
}
