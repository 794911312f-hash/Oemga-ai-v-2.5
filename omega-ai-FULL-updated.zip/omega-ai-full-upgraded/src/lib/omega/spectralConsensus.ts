/**
 * src/lib/omega/spectralConsensus.ts
 * =============================================================================
 * Spectral Consensus — قائم على جبر خطي فعلي، بلا اعتماديات خارجية.
 *
 * المدخل: n متجهاً (تمثيل n إجابة/نموذج). المخرج: تحليل طيفي لرسم التشابه بينها.
 *
 *  1) مصفوفة التقارب (affinity)   W_ij = exp(-‖x̂_i - x̂_j‖² / 2σ²),  W_ii = 0
 *     (x̂ = المتجه بعد التطبيع L2، فالمسافة في [0,2]. σ مطلق افتراضياً = 0.5، أي أن تشابه
 *      جيب التمام 0.875 يعطي W≈0.61، والتعامد التام يعطي W≈0.018. اخترنا σ مطلقاً لا
 *      وسيطاً عن قصد: وسيط المسافات يبتلع الفصل بين العناقيد حين تكون معظم الأزواج
 *      عابرة للعناقيد، ويجعل "التماسك" نسبياً للبيانات لا مقياساً للاتفاق.
 *      sigma:"median" متاح عند الحاجة.)
 *  2) لابلاسيان الرسم            L = D - W            (غير مُطبَّع)
 *                                 L_sym = I - D^{-1/2} W D^{-1/2}   (مُطبَّع)
 *  3) تحليل ذاتي متماثل           طريقة Jacobi الدورية (مستقرة ودقيقة للمصفوفات الصغيرة)
 *  4) عدد العناقيد k              فجوة القيم الذاتية (eigengap) على L_sym
 *  5) التجميع الطيفي              Ng–Jordan–Weiss: أول k متجهات ذاتية → تطبيع الصفوف → k-means
 *  6) أوزان الإجماع               متجه Perron (أكبر قيمة ذاتية لـ W)، موجب تماماً لأن W > 0
 *  7) شهادة التماسك               λ₂ (الاتصالية الجبرية)، وحدود Cheeger:
 *                                 λ₂/2 ≤ h(G) ≤ √(2 λ₂)   حيث h = conductance
 *
 * حدود صريحة: التمثيل المتجهي الذي تُغذّيه هو الذي يحدد "المعنى". مع hashEmbed المعجمي
 * يقيس هذا التحليل التشابه البنيوي/المعجمي لا الدلالي العميق.
 */

export type Matrix = number[][];

const EPS = 1e-12;

// ───────────────────────── Linear algebra ─────────────────────────

export interface EigenResult {
  /** القيم الذاتية تصاعدياً. */
  values: number[];
  /** vectors[i] هو المتجه الذاتي (طوله n، معياري) المقابل لـ values[i]. */
  vectors: number[][];
  sweeps: number;
}

/**
 * Cyclic Jacobi eigenvalue algorithm for a real symmetric matrix.
 * Throws on non-square / non-finite / clearly non-symmetric input.
 */
export function symmetricEigen(A: Matrix, maxSweeps = 100, tol = 1e-13): EigenResult {
  const n = A.length;
  if (n === 0) return { values: [], vectors: [], sweeps: 0 };
  for (let i = 0; i < n; i++) {
    if (A[i].length !== n) throw new Error("symmetricEigen: matrix must be square");
    for (let j = 0; j < n; j++) {
      if (!Number.isFinite(A[i][j])) throw new Error("symmetricEigen: non-finite entry");
    }
  }
  let scale = 0;
  for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) scale = Math.max(scale, Math.abs(A[i][j]));
  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      if (Math.abs(A[i][j] - A[j][i]) > 1e-9 * Math.max(1, scale)) throw new Error("symmetricEigen: matrix is not symmetric");
    }
  }

  const a: Matrix = A.map((r) => r.slice());
  for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) { const m = (a[i][j] + a[j][i]) / 2; a[i][j] = m; a[j][i] = m; }
  const v: Matrix = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => (i === j ? 1 : 0)));

  let sweeps = 0;
  for (; sweeps < maxSweeps; sweeps++) {
    let off = 0;
    for (let p = 0; p < n; p++) for (let q = p + 1; q < n; q++) off += a[p][q] * a[p][q];
    if (Math.sqrt(off) <= tol * Math.max(1, scale)) break;

    for (let p = 0; p < n - 1; p++) {
      for (let q = p + 1; q < n; q++) {
        const apq = a[p][q];
        if (Math.abs(apq) < 1e-300) continue;
        const theta = (a[q][q] - a[p][p]) / (2 * apq);
        const t = (theta >= 0 ? 1 : -1) / (Math.abs(theta) + Math.sqrt(theta * theta + 1));
        const c = 1 / Math.sqrt(t * t + 1);
        const s = t * c;
        // A ← Jᵀ A J  (columns, then rows); V ← V J
        for (let k = 0; k < n; k++) {
          const akp = a[k][p], akq = a[k][q];
          a[k][p] = c * akp - s * akq;
          a[k][q] = s * akp + c * akq;
        }
        for (let k = 0; k < n; k++) {
          const apk = a[p][k], aqk = a[q][k];
          a[p][k] = c * apk - s * aqk;
          a[q][k] = s * apk + c * aqk;
        }
        for (let k = 0; k < n; k++) {
          const vkp = v[k][p], vkq = v[k][q];
          v[k][p] = c * vkp - s * vkq;
          v[k][q] = s * vkp + c * vkq;
        }
      }
    }
  }

  const order = Array.from({ length: n }, (_, i) => i).sort((i, j) => a[i][i] - a[j][j]);
  const values = order.map((i) => a[i][i]);
  const vectors = order.map((col) => {
    const vec = v.map((row) => row[col]);
    // deterministic sign: largest-magnitude component positive
    let big = 0;
    for (let k = 1; k < n; k++) if (Math.abs(vec[k]) > Math.abs(vec[big])) big = k;
    return vec[big] < 0 ? vec.map((x) => -x) : vec;
  });
  return { values, vectors, sweeps };
}

// ───────────────────────── Graph construction ─────────────────────────

function l2normalize(x: number[]): number[] {
  const nrm = Math.sqrt(x.reduce((s, y) => s + y * y, 0));
  return nrm > EPS ? x.map((y) => y / nrm) : x.slice();
}

function sqDist(a: number[], b: number[]): number {
  const len = Math.max(a.length, b.length);
  let s = 0;
  for (let i = 0; i < len; i++) { const d = (a[i] ?? 0) - (b[i] ?? 0); s += d * d; }
  return s;
}

export interface AffinityOptions {
  /**
   * Gaussian bandwidth σ on L2-normalised vectors (distances in [0,2]).
   * Default 0.5 (absolute scale). "median" = median of non-zero pairwise distances (data-relative).
   */
  sigma?: number | "median";
}

export function buildAffinity(vectors: number[][], opts: AffinityOptions = {}): { W: Matrix; sigma: number } {
  const n = vectors.length;
  for (const v of vectors) for (const x of v) if (!Number.isFinite(x)) throw new Error("buildAffinity: non-finite vector entry");
  const xs = vectors.map(l2normalize);
  const d2: Matrix = Array.from({ length: n }, () => new Array(n).fill(0));
  const nonzero: number[] = [];
  for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) {
    const d = sqDist(xs[i], xs[j]);
    d2[i][j] = d2[j][i] = d;
    if (d > 1e-18) nonzero.push(Math.sqrt(d));
  }
  let sigma: number;
  if (opts.sigma === "median") {
    nonzero.sort((a, b) => a - b);
    sigma = nonzero.length ? nonzero[Math.floor(nonzero.length / 2)] : 1;
  } else if (opts.sigma === undefined) {
    sigma = 0.5;
  } else if (Number.isFinite(opts.sigma) && opts.sigma > 0) {
    sigma = opts.sigma;
  } else {
    throw new Error("buildAffinity: sigma must be a positive number or \"median\"");
  }
  const W: Matrix = Array.from({ length: n }, () => new Array(n).fill(0));
  for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
    if (i !== j) W[i][j] = Math.exp(-d2[i][j] / (2 * sigma * sigma));
  }
  return { W, sigma };
}

export function degrees(W: Matrix): number[] {
  return W.map((row) => row.reduce((s, x) => s + x, 0));
}

/** L = D − W */
export function graphLaplacian(W: Matrix): Matrix {
  const d = degrees(W);
  return W.map((row, i) => row.map((w, j) => (i === j ? d[i] - w : -w)));
}

/** L_sym = I − D^{-1/2} W D^{-1/2}. Isolated vertices (d≈0) get a unit diagonal and no edges. */
export function normalizedLaplacian(W: Matrix): Matrix {
  const d = degrees(W);
  const inv = d.map((x) => (x > EPS ? 1 / Math.sqrt(x) : 0));
  return W.map((row, i) => row.map((w, j) => (i === j ? 1 - inv[i] * w * inv[j] : -inv[i] * w * inv[j])));
}

// ───────────────────────── Spectral clustering ─────────────────────────

function kmeans(points: number[][], k: number, maxIter = 100): number[] {
  const n = points.length;
  if (k <= 1 || n === 0) return new Array(n).fill(0);
  // deterministic farthest-first initialisation
  const centers: number[][] = [points[0].slice()];
  while (centers.length < k) {
    let best = -1, bestD = -1;
    for (let i = 0; i < n; i++) {
      const dmin = Math.min(...centers.map((c) => sqDist(points[i], c)));
      if (dmin > bestD) { bestD = dmin; best = i; }
    }
    centers.push(points[best].slice());
  }
  let labels = new Array(n).fill(0);
  for (let it = 0; it < maxIter; it++) {
    const next = points.map((p) => {
      let bi = 0, bd = Infinity;
      centers.forEach((c, ci) => { const d = sqDist(p, c); if (d < bd) { bd = d; bi = ci; } });
      return bi;
    });
    const changed = next.some((l, i) => l !== labels[i]);
    labels = next;
    for (let ci = 0; ci < k; ci++) {
      const members = points.filter((_, i) => labels[i] === ci);
      if (!members.length) continue;
      const dim = members[0].length;
      centers[ci] = Array.from({ length: dim }, (_, d) => members.reduce((s, m) => s + m[d], 0) / members.length);
    }
    if (!changed && it > 0) break;
  }
  return labels;
}

/** Relabel so cluster ids are 0..k'-1 in order of first appearance (stable output). */
function canonicalLabels(labels: number[]): number[] {
  const map = new Map<number, number>();
  return labels.map((l) => { if (!map.has(l)) map.set(l, map.size); return map.get(l)!; });
}

// ───────────────────────── Main entry ─────────────────────────

export interface SpectralConsensusOptions extends AffinityOptions {
  /** Upper bound on the number of clusters considered by the eigengap heuristic. Default 6. */
  maxClusters?: number;
  /** Minimum eigengap to accept k>1; otherwise a single cluster is reported. Default 0.1. */
  minGap?: number;
  /** Force k instead of using the eigengap heuristic. */
  k?: number;
  /**
   * A member is "low support" when its Perron weight is below this fraction of the median weight. Default 0.25.
   * Heuristic threshold (not a theorem): a lone dissimilar answer has conductance ≈ 1, so normalised spectral
   * clustering cannot isolate it as a cluster, while its Perron weight collapses.
   */
  lowSupportRatio?: number;
}

export interface SpectralConsensusResult {
  n: number;
  sigma: number;
  /** Eigenvalues of L_sym, ascending, all in [0, 2]. */
  normalizedEigenvalues: number[];
  /** Eigenvalues of the unnormalised Laplacian L = D − W, ascending. */
  laplacianEigenvalues: number[];
  /** Number of (numerically) zero eigenvalues of L = number of connected components of W. */
  components: number;
  /** λ₂(L): algebraic connectivity. */
  algebraicConnectivity: number;
  /** λ₂(L_sym) = spectral gap of the random walk P = D⁻¹W. */
  spectralGap: number;
  /**
   * Agreement score in [0, 1].
   * - n ≥ 3: λ₂(L_sym) / (n/(n−1)) (spectral cohesion; 1 = complete-graph maximum).
   * - n = 2: affinity W₀₁ (direct similarity); NOT spectral — L_sym always has λ₂=2 for a
   *   connected 2-node graph without self-loops, which would spuriously yield cohesion=1.
   * - n = 1: 0 (no pair to compare); see spectralSufficient.
   */
  cohesion: number;
  /**
   * False when n < 3: spectral gap / Cheeger / relaxation-time interpretations are not
   * meaningful (n=1 has no spectrum of agreement; n=2 is a bipartite complete graph so
   * the simple random walk oscillates and λ₂(L_sym)=2 always when connected).
   */
  spectralSufficient: boolean;
  /** Cheeger bounds on conductance: lower = λ₂/2, upper = √(2 λ₂). Meaningful only if spectralSufficient. */
  cheeger: { lower: number; upper: number };
  /**
   * 1/λ₂(L_sym): relaxation time of the random walk.
   * Infinity if disconnected, or if n < 3 (walk on K₂ oscillates; single node has no mixing).
   */
  relaxationTime: number;
  /** Largest eigenvalue of W (Perron root). */
  perronRoot: number;
  /** Fiedler vector (eigenvector of λ₂(L)). */
  fiedlerVector: number[];
  /** Eigengap-selected (or forced) number of clusters. */
  k: number;
  eigengaps: number[];
  /** labels[i] ∈ 0..k−1 */
  labels: number[];
  /** Perron eigenvector of W, positive, sums to 1: spectral centrality of each answer. */
  weights: number[];
  /** Cluster with the largest total weight. */
  dominantCluster: number;
  /** Index of the highest-weight member of the dominant cluster. */
  consensusIndex: number;
  /** Members whose Perron weight is below lowSupportRatio × median weight (catches lone dissimilar answers). */
  lowSupport: number[];
  /** Union of (members outside the dominant cluster) and lowSupport, ascending by index. */
  outliers: number[];
}

export function computeSpectralConsensus(vectors: number[][], opts: SpectralConsensusOptions = {}): SpectralConsensusResult {
  const n = vectors.length;
  if (n === 0) throw new Error("computeSpectralConsensus: at least one vector is required");
  if (n === 1) {
    return {
      n, sigma: 1, normalizedEigenvalues: [0], laplacianEigenvalues: [0], components: 1, algebraicConnectivity: 0, spectralGap: 0,
      cohesion: 0, spectralSufficient: false, cheeger: { lower: 0, upper: 0 }, relaxationTime: Infinity, perronRoot: 0, fiedlerVector: [1], k: 1, eigengaps: [],
      labels: [0], weights: [1], dominantCluster: 0, consensusIndex: 0, lowSupport: [], outliers: [],
    };
  }

  const { W, sigma } = buildAffinity(vectors, opts);
  const L = graphLaplacian(W);
  const Ls = normalizedLaplacian(W);

  const eL = symmetricEigen(L);
  const eS = symmetricEigen(Ls);
  const eW = symmetricEigen(W);

  const maxL = Math.max(1, ...eL.values.map(Math.abs));
  const zeroTol = 1e-9 * maxL;
  const components = eL.values.filter((x) => Math.abs(x) < zeroTol).length;
  const lam2L = Math.max(0, eL.values[1] ?? 0);
  const lam2S = Math.max(0, eS.values[1] ?? 0);
  // n=2: L_sym of connected loopless graph always has λ₂=2 → ratio λ₂/(n/(n-1))=1 always.
  // Use affinity as a direct similarity score instead; mark spectral claims insufficient.
  const spectralSufficient = n >= 3;
  const cohesion = spectralSufficient
    ? Math.min(1, lam2S / (n / (n - 1)))
    : Math.min(1, Math.max(0, W[0][1] ?? 0));

  // eigengap heuristic on L_sym
  const kmax = Math.max(1, Math.min(opts.maxClusters ?? 6, n - 1));
  const gaps: number[] = [];
  for (let i = 1; i <= Math.min(kmax, n - 1); i++) gaps.push(eS.values[i] - eS.values[i - 1]);
  let k = 1;
  if (opts.k && opts.k >= 1) k = Math.min(opts.k, n);
  else if (n >= 3) {
    let best = 0;
    gaps.forEach((g, i) => { if (g > gaps[best]) best = i; });
    if (gaps[best] >= (opts.minGap ?? 0.1)) k = best + 1;
  }

  // Ng–Jordan–Weiss embedding: rows of first k eigenvectors, row-normalised
  let labels: number[];
  if (k <= 1) labels = new Array(n).fill(0);
  else {
    const embed = Array.from({ length: n }, (_, i) => l2normalize(Array.from({ length: k }, (_, c) => eS.vectors[c][i])));
    labels = canonicalLabels(kmeans(embed, k));
  }
  k = new Set(labels).size;

  // Perron weights: eigenvector of the largest eigenvalue of W, positive by Perron–Frobenius (W > 0 off-diagonal)
  const top = eW.vectors[n - 1];
  const sign = top.reduce((s, x) => s + x, 0) < 0 ? -1 : 1;
  const raw = top.map((x) => Math.max(0, sign * x));
  const tot = raw.reduce((s, x) => s + x, 0) || 1;
  const weights = raw.map((x) => x / tot);

  const mass = new Array(k).fill(0);
  labels.forEach((l, i) => { mass[l] += weights[i]; });
  const dominantCluster = mass.indexOf(Math.max(...mass));
  let consensusIndex = -1;
  weights.forEach((w, i) => { if (labels[i] === dominantCluster && (consensusIndex < 0 || w > weights[consensusIndex])) consensusIndex = i; });
  const sortedW = weights.slice().sort((a, b) => a - b);
  const medianW = n % 2 ? sortedW[(n - 1) / 2] : (sortedW[n / 2 - 1] + sortedW[n / 2]) / 2;
  const ratio = opts.lowSupportRatio ?? 0.25;
  const lowSupport = weights.map((w, i) => (w < ratio * medianW ? i : -1)).filter((i) => i >= 0);
  const outlierSet = new Set<number>(lowSupport);
  labels.forEach((l, i) => { if (l !== dominantCluster) outlierSet.add(i); });
  const outliers = [...outlierSet].sort((a, b) => a - b);

  return {
    n, sigma,
    normalizedEigenvalues: eS.values,
    laplacianEigenvalues: eL.values,
    components,
    algebraicConnectivity: lam2L,
    spectralGap: lam2S,
    cohesion,
    spectralSufficient,
    cheeger: { lower: lam2S / 2, upper: Math.sqrt(2 * lam2S) },
    // n<3: do not report a finite relaxation time (K₂ walk oscillates; n=1 has no mixing)
    relaxationTime: spectralSufficient && lam2S > EPS ? 1 / lam2S : Infinity,
    perronRoot: eW.values[n - 1],
    fiedlerVector: eL.vectors[1],
    k, eigengaps: gaps, labels, weights, dominantCluster, consensusIndex, lowSupport, outliers,
  };
}
