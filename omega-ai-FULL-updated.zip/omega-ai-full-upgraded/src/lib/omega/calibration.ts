/**
 * calibration.ts — Map a score (e.g. Ψ agreement) toward P̂(correct)
 * =============================================================================
 * Each item: y ∈ {0,1} (task correct?) and p ∈ [0,1] (raw score, often Ψ).
 *
 * Metrics: Brier, ECE, confidence gap.
 * Optional link: temperature scaling on a *train* split → evaluate on *holdout*.
 *
 * Honesty:
 *   - Offline fixtures only validate the harness (metrics math + fit pipeline).
 *   - Public claims require live holdout with fixed models and executive labels y.
 *   - Until holdout ECE is low, UI must still call Ψ «درجة اتفاق» not P(correct).
 */

export interface CalibrationPair {
  /** Ground-truth correctness: 1 = pass, 0 = fail */
  y: 0 | 1;
  /** Predicted confidence / Ψ in [0,1] */
  p: number;
  id?: string;
}

export interface ECEResult {
  ece: number;
  nBins: number;
  bins: Array<{
    lo: number;
    hi: number;
    count: number;
    avgP: number;
    avgY: number;
    gap: number;
  }>;
}

export interface CalibrationReport {
  n: number;
  accuracy: number;
  meanConfidence: number;
  brier: number;
  ece: ECEResult;
  /** mean(p) - accuracy: positive => overconfident */
  confidenceGap: number;
}

function clamp01(x: number): number {
  return Math.max(0, Math.min(1, x));
}

/** Brier score: mean (p - y)^2 — lower is better */
export function brierScore(pairs: CalibrationPair[]): number {
  if (pairs.length === 0) return 0;
  let s = 0;
  for (const { y, p } of pairs) {
    const pp = clamp01(p);
    s += (pp - y) ** 2;
  }
  return s / pairs.length;
}

/**
 * Expected Calibration Error with equal-width bins on [0,1].
 * ECE = Σ (|B_m|/n) * |avg(p) - avg(y)|
 */
export function expectedCalibrationError(
  pairs: CalibrationPair[],
  nBins = 10
): ECEResult {
  const bins = Array.from({ length: nBins }, (_, i) => ({
    lo: i / nBins,
    hi: (i + 1) / nBins,
    count: 0,
    sumP: 0,
    sumY: 0,
  }));

  for (const { y, p } of pairs) {
    const pp = clamp01(p);
    let idx = Math.floor(pp * nBins);
    if (idx >= nBins) idx = nBins - 1;
    if (idx < 0) idx = 0;
    bins[idx].count++;
    bins[idx].sumP += pp;
    bins[idx].sumY += y;
  }

  const n = pairs.length || 1;
  let ece = 0;
  const out = bins.map((b) => {
    if (b.count === 0) {
      return { lo: b.lo, hi: b.hi, count: 0, avgP: 0, avgY: 0, gap: 0 };
    }
    const avgP = b.sumP / b.count;
    const avgY = b.sumY / b.count;
    const gap = Math.abs(avgP - avgY);
    ece += (b.count / n) * gap;
    return { lo: b.lo, hi: b.hi, count: b.count, avgP, avgY, gap };
  });

  return { ece, nBins, bins: out };
}

export function evaluateCalibration(
  pairs: CalibrationPair[],
  nBins = 10
): CalibrationReport {
  const n = pairs.length;
  if (n === 0) {
    return {
      n: 0,
      accuracy: 0,
      meanConfidence: 0,
      brier: 0,
      ece: { ece: 0, nBins, bins: [] },
      confidenceGap: 0,
    };
  }
  const accuracy = pairs.reduce((a, x) => a + x.y, 0) / n;
  const meanConfidence =
    pairs.reduce((a, x) => a + clamp01(x.p), 0) / n;
  return {
    n,
    accuracy,
    meanConfidence,
    brier: brierScore(pairs),
    ece: expectedCalibrationError(pairs, nBins),
    confidenceGap: meanConfidence - accuracy,
  };
}

/** Format a short markdown section for benchmark reports */
export function formatCalibrationMarkdown(report: CalibrationReport): string {
  const lines = [
    `## Calibration`,
    ``,
    `| Metric | Value |`,
    `|--------|-------|`,
    `| n | ${report.n} |`,
    `| Accuracy | ${(report.accuracy * 100).toFixed(1)}% |`,
    `| Mean confidence | ${report.meanConfidence.toFixed(3)} |`,
    `| Brier (↓ better) | ${report.brier.toFixed(4)} |`,
    `| ECE (↓ better) | ${report.ece.ece.toFixed(4)} |`,
    `| Confidence gap (mean p − acc) | ${report.confidenceGap.toFixed(3)} |`,
    ``,
  ];
  if (report.confidenceGap > 0.05) {
    lines.push(`> Overconfident on average (gap > 0.05).`);
    lines.push(``);
  } else if (report.confidenceGap < -0.05) {
    lines.push(`> Underconfident on average (gap < −0.05).`);
    lines.push(``);
  }
  return lines.join("\n");
}

// ---------------------------------------------------------------------------
// Temperature scaling: p_cal = σ( logit(p) / T )
// Fit T on a calibration *train* set; report metrics on an independent holdout.
// ---------------------------------------------------------------------------

const EPS = 1e-6;

export function logit(p: number): number {
  const pp = clamp01(p);
  const x = Math.min(1 - EPS, Math.max(EPS, pp));
  return Math.log(x / (1 - x));
}

export function sigmoid(z: number): number {
  if (z >= 0) {
    const ez = Math.exp(-z);
    return 1 / (1 + ez);
  }
  const ez = Math.exp(z);
  return ez / (1 + ez);
}

/** Apply temperature: T→1 leaves p unchanged; T>1 softens (less confident). */
export function applyTemperature(p: number, T: number): number {
  const t = Math.max(EPS, T);
  return clamp01(sigmoid(logit(p) / t));
}

export function applyTemperatureToPairs(
  pairs: CalibrationPair[],
  T: number
): CalibrationPair[] {
  return pairs.map((x) => ({ ...x, p: applyTemperature(x.p, T) }));
}

/** Binary NLL for numerical stability when fitting T */
export function negativeLogLikelihood(pairs: CalibrationPair[]): number {
  if (pairs.length === 0) return 0;
  let s = 0;
  for (const { y, p } of pairs) {
    const pp = Math.min(1 - EPS, Math.max(EPS, clamp01(p)));
    s += y === 1 ? -Math.log(pp) : -Math.log(1 - pp);
  }
  return s / pairs.length;
}

export interface TemperatureFitResult {
  T: number;
  trainNll: number;
  trainBrier: number;
}

/**
 * Grid-search temperature on train pairs (minimize NLL, break ties with Brier).
 * Search range covers overconfident raw Ψ (T>1) and underconfident (T<1).
 */
export function fitTemperature(
  train: CalibrationPair[],
  options: { tMin?: number; tMax?: number; steps?: number } = {}
): TemperatureFitResult {
  const tMin = options.tMin ?? 0.5;
  const tMax = options.tMax ?? 5;
  const steps = options.steps ?? 46; // ~0.1 resolution
  if (train.length === 0) {
    return { T: 1, trainNll: 0, trainBrier: 0 };
  }
  let bestT = 1;
  let bestNll = Infinity;
  let bestBrier = Infinity;
  for (let i = 0; i < steps; i++) {
    const T = tMin + ((tMax - tMin) * i) / Math.max(1, steps - 1);
    const scaled = applyTemperatureToPairs(train, T);
    const nll = negativeLogLikelihood(scaled);
    const br = brierScore(scaled);
    if (nll < bestNll - 1e-12 || (Math.abs(nll - bestNll) < 1e-12 && br < bestBrier)) {
      bestNll = nll;
      bestBrier = br;
      bestT = T;
    }
  }
  return { T: bestT, trainNll: bestNll, trainBrier: bestBrier };
}

export interface HoldoutCalibrationResult {
  rawHoldout: CalibrationReport;
  calibratedHoldout: CalibrationReport;
  fit: TemperatureFitResult;
  /** true only when caller marks the run as live + independent holdout */
  claimEligible: boolean;
}

/**
 * Fit T on train, evaluate raw vs temperature-scaled p on holdout.
 * claimEligible must be set by the runner (live data + disjoint holdout).
 */
export function calibrateScoreOnHoldout(
  train: CalibrationPair[],
  holdout: CalibrationPair[],
  options?: { nBins?: number; claimEligible?: boolean; fitOptions?: Parameters<typeof fitTemperature>[1] }
): HoldoutCalibrationResult {
  const nBins = options?.nBins ?? 10;
  const fit = fitTemperature(train, options?.fitOptions);
  const calibrated = applyTemperatureToPairs(holdout, fit.T);
  return {
    rawHoldout: evaluateCalibration(holdout, nBins),
    calibratedHoldout: evaluateCalibration(calibrated, nBins),
    fit,
    claimEligible: options?.claimEligible === true,
  };
}

export function formatHoldoutCalibrationMarkdown(
  result: HoldoutCalibrationResult,
  title = "Ψ → P̂(correct) holdout calibration"
): string {
  const { rawHoldout: r, calibratedHoldout: c, fit, claimEligible } = result;
  const lines = [
    `## ${title}`,
    ``,
    claimEligible
      ? `> **claimEligible=true** — live holdout; metrics may support careful calibration claims.`
      : `> **claimEligible=false** — harness / offline only. Do **not** cite as model calibration.`,
    ``,
    `| Stage | n | Accuracy | Mean p | Brier ↓ | ECE ↓ | gap (p−acc) |`,
    `|-------|---|----------|--------|---------|-------|-------------|`,
    `| Raw score (e.g. Ψ) on holdout | ${r.n} | ${(r.accuracy * 100).toFixed(1)}% | ${r.meanConfidence.toFixed(3)} | ${r.brier.toFixed(4)} | ${r.ece.ece.toFixed(4)} | ${r.confidenceGap.toFixed(3)} |`,
    `| After temperature T=${fit.T.toFixed(3)} | ${c.n} | ${(c.accuracy * 100).toFixed(1)}% | ${c.meanConfidence.toFixed(3)} | ${c.brier.toFixed(4)} | ${c.ece.ece.toFixed(4)} | ${c.confidenceGap.toFixed(3)} |`,
    ``,
    `- Train fit: NLL=${fit.trainNll.toFixed(4)}, Brier=${fit.trainBrier.toFixed(4)}`,
    `- Accuracy is unchanged by temperature (labels fixed); only the probabilistic mapping p→P̂ changes.`,
    ``,
  ];
  return lines.join("\n");
}
