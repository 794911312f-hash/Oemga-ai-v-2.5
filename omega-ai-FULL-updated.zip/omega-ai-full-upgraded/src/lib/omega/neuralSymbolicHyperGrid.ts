/**
 * src/lib/omega/neuralSymbolicHyperGrid.ts
 * =====================================================================
 * Omega AI — Neural-Symbolic Hyper-Grid & Distillation Engine
 * ---------------------------------------------------------------------
 * Phase 9 Core Module
 *
 * Combines:
 *  • Neural reasoning paths (LLMs + evolved adapters)
 *  • Symbolic reasoning paths (Knowledge Graph + CAS + Rules)
 *  • Hybrid bidirectional paths
 *  • Dynamic Hyper-Grid routing
 *  • Knowledge Distillation (Neural ↔ Symbolic)
 *
 * Integrates with:
 *  - inferenceEngine.ts
 *  - realKnowledgeGraph.ts
 *  - symbolicEngine.ts / sympyLeanBridge.ts
 *  - hybridSelfEvolution.ts
 *  - kernel.ts / omegaCore.ts
 * =====================================================================
 */

// ====================== Types ======================

export type GridPathType = "neural" | "symbolic" | "hybrid";

export type DistillationDirection =
  | "neural_to_symbolic"
  | "symbolic_to_neural"
  | "cross_grid";

export interface HyperGridRequest {
  question: string;
  userId?: string;
  domain?: string;
  preferredPath?: GridPathType | "auto";
  maxLatencyMs?: number;
  requireVerification?: boolean;
  distillation?: {
    enabled: boolean;
    direction?: DistillationDirection;
  };
}

export interface PathResult {
  path: GridPathType;
  answer: string;
  confidence: number;          // 0-1
  latencyMs: number;
  evidence: string[];          // supporting facts / steps
  symbolicTrace?: string[];    // CAS / logic steps
  neuralTrace?: string[];      // model reasoning snippets
  verified: boolean | null;
  verificationScore?: number | null;
  verificationEvidence?: VerificationEvidence;
}

/** Proof attached to one specific candidate answer, not a confidence heuristic. */
export interface VerificationEvidence {
  source: "cas" | "lean" | "tool" | "human";
  proofId: string;
  outcome: boolean;
  confidence: number;
  details?: string;
}

export interface DistillationResult {
  direction: DistillationDirection;
  success: boolean;
  distilledArtifact?: {
    type: "rule" | "adapter_hint" | "preference_pair" | "symbolic_fact";
    content: any;
  };
  message: string;
}

export interface HyperGridResponse {
  finalAnswer: string;
  chosenPath: GridPathType;
  pathResults: PathResult[];
  confidence: number;
  distillation?: DistillationResult;
  gridDecisionReason: string;
  totalLatencyMs: number;
  metadata: {
    neuralUsed: boolean;
    symbolicUsed: boolean;
    hybridUsed: boolean;
    verificationPassed: boolean;
  };
}

export interface GridRoutingDecision {
  primaryPath: GridPathType;
  fallbackPaths: GridPathType[];
  reason: string;
  estimatedCost: number;
}

// ====================== Hyper-Grid Router ======================

/**
 * Decides which reasoning path(s) to activate based on question characteristics.
 */

/** Normalize Arabic for routing: strip diacritics/tatweel, unify letter forms. */
export function normalizeArabic(text: string): string {
  let s = text.normalize("NFKD");
  // Remove Arabic diacritics (tashkeel) and tatweel
  s = s.replace(/[\u064B-\u065F\u0670\u0640]/g, "");
  // Unify alef forms
  s = s.replace(/[أإآٱ]/g, "ا");
  // teh marbuta → heh
  s = s.replace(/ة/g, "ه");
  // alef maqsura → yeh
  s = s.replace(/ى/g, "ي");
  return s.toLowerCase();
}

const ARABIC_PREFIXES = ["وال", "ال", "و", "ف", "ب", "ل", "ك"];

/** Token set with optional prefix stripping variants for matching. */
export function expandTokenVariants(token: string): string[] {
  const t = normalizeArabic(token);
  const out = new Set<string>([t]);
  for (const p of ARABIC_PREFIXES) {
    if (t.startsWith(p) && t.length > p.length + 1) {
      out.add(t.slice(p.length));
    }
  }
  return [...out];
}

function tokensMatchSignal(tokens: Set<string>, signal: string): boolean {
  const sig = normalizeArabic(signal);
  for (const tok of tokens) {
    const variants = expandTokenVariants(tok);
    if (variants.includes(sig) || variants.some((v) => v === sig)) return true;
    // also: signal matches a variant of token
    if (variants.includes(sig)) return true;
  }
  // direct: any token variant equals signal
  for (const tok of tokens) {
    if (expandTokenVariants(tok).includes(sig)) return true;
  }
  return false;
}

export class HyperGridRouter {
  /**
   * Simple but effective heuristic router.
   * Can later be replaced by a learned policy from Hybrid Evolution.
   */
  public decide(request: HyperGridRequest): GridRoutingDecision {
    const q = normalizeArabic(request.question);
    // Tokenize on whitespace + punctuation so "تحليل" does not match "حل"
    const tokens = new Set(
      q
        .split(/[\s\u060C\u061B,.;:!?()\[\]{}"'«»\^=+\-0-9]+/u)
        .map((t) => t.trim().replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, ""))
        .filter((t) => t.length > 0)
    );

    // Strong symbolic signals (normalized + prefix-stripped match)
    const symbolicSignals = [
      "معادله", "معادلة", "حل", "اشتق", "تكامل", "بسط", "عامل", "مصفوفه", "مصفوفة",
      "محدد", "احسب", "قانون", "نظريه", "نظرية", "برهن", "اثبت", "أثبت", "منطق", "قاعده",
      "equation", "solve", "differentiate", "integrate", "simplify",
      "prove", "theorem", "logic", "collatz", "matrix", "determinant", "det",
    ];

    // Strong neural / open-ended signals
    const neuralSignals = [
      "اشرح", "لخص", "اكتب", "قصه", "قصة", "راي", "رأي", "تحليل", "قارن",
      "explain", "summarize", "write", "story", "opinion", "compare",
      "creative", "brainstorm",
    ];

    let symbolicScore = 0;
    let neuralScore = 0;

    for (const s of symbolicSignals) {
      if (tokensMatchSignal(tokens, s)) symbolicScore += 1;
    }
    for (const s of neuralSignals) {
      if (tokensMatchSignal(tokens, s)) neuralScore += 1;
    }

    // Domain boost
    if (request.domain === "math_logic" || request.domain === "science_factual") {
      symbolicScore += 1.5;
    }
    if (request.domain === "creative" || request.domain === "general") {
      neuralScore += 0.8;
    }

    // Forced path
    if (request.preferredPath && request.preferredPath !== "auto") {
      return {
        primaryPath: request.preferredPath,
        fallbackPaths: request.preferredPath === "hybrid"
          ? ["neural", "symbolic"]
          : ["hybrid"],
        reason: `User forced path: ${request.preferredPath}`,
        estimatedCost: 1.0,
      };
    }

    // Decision logic
    if (symbolicScore >= 2 && symbolicScore > neuralScore) {
      return {
        primaryPath: "symbolic",
        fallbackPaths: ["hybrid", "neural"],
        reason: `High symbolic signal (score=${symbolicScore.toFixed(1)})`,
        estimatedCost: 0.6,
      };
    }

    if (neuralScore >= 2 && neuralScore > symbolicScore) {
      return {
        primaryPath: "neural",
        fallbackPaths: ["hybrid"],
        reason: `High neural/open-ended signal (score=${neuralScore.toFixed(1)})`,
        estimatedCost: 1.0,
      };
    }

    // Default: Hybrid for balanced or ambiguous questions
    return {
      primaryPath: "hybrid",
      fallbackPaths: ["neural", "symbolic"],
      reason: "Ambiguous or balanced question → Hybrid path",
      estimatedCost: 1.4,
    };
  }
}

// ====================== Path Executors ======================


export class SymbolicPathExecutor {
  async execute(question: string, userId = "default"): Promise<PathResult> {
    const start = Date.now();
    const evidence: string[] = [];
    const symbolicTrace: string[] = [];
    let answer = "";
    let confidence = 0.5;
    let verified = false;
    let verificationScore = 0.4;
    let verificationEvidence: VerificationEvidence | undefined;

    try {
      // 1) Knowledge Graph facts
      try {
        const { getInferenceEngine } = await import("./inferenceEngine");
        const engine = getInferenceEngine(userId);
        const prep = await (engine as any).prepare?.({
          userId,
          question,
          domain: "math_logic",
        });
        if (prep?.inferredFacts?.length) {
          evidence.push(...prep.inferredFacts.slice(0, 5));
          symbolicTrace.push(`KG facts: ${prep.inferredFacts.length}`);
          confidence += 0.1;
        }
      } catch {
        symbolicTrace.push("KG prepare unavailable");
      }

      // 2) RealKnowledgeGraph multi-hop
      try {
        const mod = await import("./realKnowledgeGraph");
        const RealKnowledgeGraph = (mod as any).RealKnowledgeGraph;
        if (RealKnowledgeGraph) {
          const graph = new RealKnowledgeGraph();
          if (typeof graph.inferMultiHop === "function") {
            const paths = graph.inferMultiHop(question);
            if (Array.isArray(paths) && paths.length) {
              evidence.push(`Multi-hop: ${paths.slice(0, 2).join(" | ")}`);
              symbolicTrace.push(`RealKG multi-hop hits: ${paths.length}`);
              confidence += 0.08;
            }
          }
        }
      } catch {
        // optional
      }

      // 3) CAS via symbolicEngine
      const mathPatterns: Array<{
        re: RegExp;
        op: "solve" | "simplify" | "diff" | "integrate" | "factor" | "matrix_det";
      }> = [
        { re: /(?:^|\s)(?:حل|solve)\s+(.+)/i, op: "solve" },
        { re: /(?:بسط|simplify)\s+(.+)/i, op: "simplify" },
        { re: /(?:اشتق|differentiate|derivative)\s+(.+)/i, op: "diff" },
        { re: /(?:تكامل|integrate)\s+(.+)/i, op: "integrate" },
        { re: /(?:^|\s)(?:عامل|factor)\s+(.+)/i, op: "factor" },
        { re: /(?:محدد|determinant|det)\s+(.+)/i, op: "matrix_det" },
      ];

      let casAnswer = "";
      for (const { re, op } of mathPatterns) {
        const match = question.match(re);
        if (!match) continue;
        const expr = (match[1] || question).trim();
        try {
          const sym = await import("./symbolicEngine");
          if (typeof sym.executeSymbolicOperation === "function") {
            const casResult = await sym.executeSymbolicOperation({
              operation: op,
              expression: expr,
              variable: "x",
            });
            const resultText = String(casResult?.result ?? "").trim();
            // A placeholder/fallback response is not a CAS proof. The symbolic
            // endpoint must have returned a real result without an error.
            const isRealResult = Boolean(
              casResult?.ok && !casResult.error && resultText &&
              !/^Symbolic\(/i.test(resultText) &&
              !resultText.startsWith("تم استقبال التعبير:")
            );
            if (isRealResult) {
              casAnswer = `نتيجة CAS (${op}): ${resultText}`;
              if (casResult.latex) casAnswer += `\nLaTeX: ${casResult.latex}`;
              symbolicTrace.push(`CAS ${op} -> ${resultText}`);
              evidence.push(`CAS:${op}=${resultText}`);
              confidence += 0.22;
              verified = true;
              verificationScore = Math.max(verificationScore, 0.8);
              verificationEvidence = {
                source: "cas",
                proofId: `cas:${op}:${expr}:${resultText}`,
                outcome: true,
                confidence: 0.995,
                details: `CAS operation ${op} on ${expr} returned ${resultText}`,
              };
            } else if (casResult?.error || !casResult?.ok) {
              symbolicTrace.push(`CAS ${op} unavailable/failed: ${casResult?.error || "no valid result"}`);
            }
          } else {
            symbolicTrace.push("symbolicEngine CAS operation unavailable");
          }
        } catch (e: any) {
          symbolicTrace.push(`CAS import/exec error: ${e.message || e}`);
        }
        break;
      }

      // 4) SymPyLeanBridge presence (heuristic)
      try {
        const leanMod = await import("./sympyLeanBridge");
        const Bridge = (leanMod as any).SymPyLeanBridge || (leanMod as any).default;
        if (Bridge) {
          symbolicTrace.push("SymPyLeanBridge available (heuristic mode)");
          confidence += 0.05;
        }
      } catch {
        symbolicTrace.push("SymPyLeanBridge not loaded");
      }

      const parts: string[] = [];
      if (casAnswer) parts.push(casAnswer);
      if (evidence.length) {
        parts.push("أدلة من الرسم المعرفي:");
        parts.push(...evidence.slice(0, 5).map((e) => `• ${e}`));
      }

      if (parts.length) {
        answer = parts.join("\n");
        confidence = Math.min(0.94, confidence);
        verificationScore = verified ? Math.max(verificationScore, confidence) : confidence * 0.65;
      } else {
        answer = "لم يُعثر على مسار رمزي قوي لهذه الصيغة. يُفضّل المسار الهجين.";
        confidence = 0.34;
        verificationScore = 0.3;
      }
    } catch (err: any) {
      answer = `خطأ في المسار الرمزي: ${err.message}`;
      confidence = 0.2;
      verificationScore = 0.15;
    }

    return {
      path: "symbolic",
      answer,
      confidence,
      latencyMs: Date.now() - start,
      evidence,
      symbolicTrace,
      verified,
      verificationScore,
      verificationEvidence,
    };
  }
}

export class NeuralPathExecutor {
  async execute(question: string, userId = "default"): Promise<PathResult> {
    const start = Date.now();
    const evidence: string[] = [];
    const neuralTrace: string[] = [];
    let answer = "";
    let confidence = 0.6;

    try {
      const { getInferenceEngine } = await import("./inferenceEngine");
      const engine = getInferenceEngine(userId);

      const result = await engine.runCycle({
        userId,
        question,
        domain: "general",
      });

      answer = result.answer || "";
      confidence = Math.max(0.3, Math.min(0.95, result.confidence || result.selfEval?.score || 0.65));
      neuralTrace.push(`Inference generation: ${result.generation}`);
      if (result.inferredFacts?.length) {
        evidence.push(...result.inferredFacts.slice(0, 3));
      }
      if (result.recalledMemories?.length) {
        neuralTrace.push(`Recalled memories: ${result.recalledMemories.length}`);
      }
    } catch (err: any) {
      answer = `خطأ في المسار العصبي: ${err.message}`;
      confidence = 0.25;
    }

    return {
      path: "neural",
      answer,
      confidence,
      latencyMs: Date.now() - start,
      evidence,
      neuralTrace,
      // confidence ≠ verification — only external tools/CAS may set verified
      verified: null,
      verificationScore: null,
    };
  }
}

export class HybridPathExecutor {
  private neural = new NeuralPathExecutor();
  private symbolic = new SymbolicPathExecutor();

  async execute(question: string, userId = "default"): Promise<PathResult> {
    const start = Date.now();

    // Run both in parallel
    const [neuralRes, symbolicRes] = await Promise.all([
      this.neural.execute(question, userId),
      this.symbolic.execute(question, userId),
    ]);

    // Fusion strategy: weighted by confidence + prefer verified symbolic
    let finalAnswer = "";
    let confidence = 0;
    const evidence = [...neuralRes.evidence, ...symbolicRes.evidence];

    if (symbolicRes.verified && symbolicRes.confidence > 0.65) {
      // Symbolic takes priority when strong
      finalAnswer = symbolicRes.answer;
      if (neuralRes.confidence > 0.6) {
        finalAnswer += `\n\n---\nتعزيز عصبي:\n${neuralRes.answer.slice(0, 400)}`;
      }
      confidence = Math.min(0.95, symbolicRes.confidence * 0.7 + neuralRes.confidence * 0.3 + 0.08);
    } else if (neuralRes.confidence >= symbolicRes.confidence) {
      finalAnswer = neuralRes.answer;
      if (symbolicRes.evidence.length > 0) {
        finalAnswer += `\n\n---\nأدلة رمزية داعمة:\n- ${symbolicRes.evidence.slice(0, 3).join("\n- ")}`;
      }
      confidence = neuralRes.confidence * 0.75 + symbolicRes.confidence * 0.25;
    } else {
      finalAnswer = symbolicRes.answer || neuralRes.answer;
      confidence = (neuralRes.confidence + symbolicRes.confidence) / 2;
    }

    return {
      path: "hybrid",
      answer: finalAnswer,
      confidence: Math.min(0.97, confidence),
      latencyMs: Date.now() - start,
      evidence,
      symbolicTrace: symbolicRes.symbolicTrace,
      neuralTrace: neuralRes.neuralTrace,
      // Only symbolic path verification counts — neural confidence is not verification
      verified: symbolicRes.verified === true ? true : symbolicRes.verified === false ? false : null,
      verificationScore:
        typeof symbolicRes.verificationScore === "number"
          ? symbolicRes.verificationScore
          : null,
    };
  }
}

// ====================== Distillation Engine ======================

export class DistillationEngine {
  /**
   * Neural → Symbolic: extract structured facts / rules from neural answers
   */
  async distillNeuralToSymbolic(
    question: string,
    neuralAnswer: string
  ): Promise<DistillationResult> {
    try {
      // Simple extraction heuristic (can be upgraded with LLM call)
      const facts: string[] = [];
      const lines = neuralAnswer.split(/\n+/).filter((l) => l.trim().length > 20);

      for (const line of lines.slice(0, 5)) {
        if (
          line.includes("لأن") ||
          line.includes("بسبب") ||
          line.includes(" accordingly") ||
          line.includes("therefore") ||
          line.includes("=") ||
          line.match(/^\d+\./)
        ) {
          facts.push(line.trim().slice(0, 220));
        }
      }

      if (facts.length === 0) {
        return {
          direction: "neural_to_symbolic",
          success: false,
          message: "No clear structured facts extracted",
        };
      }

      return {
        direction: "neural_to_symbolic",
        success: true,
        distilledArtifact: {
          type: "symbolic_fact",
          content: { question, facts },
        },
        message: `Extracted ${facts.length} candidate symbolic facts`,
      };
    } catch (err: any) {
      return {
        direction: "neural_to_symbolic",
        success: false,
        message: err.message,
      };
    }
  }

  /**
   * Symbolic → Neural: create preference-style data to improve neural path
   * (feeds into Hybrid Self-Evolution preference buffer)
   */
  async distillSymbolicToNeural(
    question: string,
    symbolicAnswer: string,
    neuralAnswer: string,
    opts?: {
      symbolicEvidence?: VerificationEvidence | null;
      neuralEvidence?: VerificationEvidence | null;
    }
  ): Promise<DistillationResult> {
    try {
      const chosenProof = opts?.symbolicEvidence;
      const rejectedProof = opts?.neuralEvidence;
      const allowedSources = new Set(["cas", "lean", "tool", "human"]);
      const isTrustedProof = (proof?: VerificationEvidence | null) => Boolean(
        proof && typeof proof === "object" && allowedSources.has(proof.source) &&
        typeof proof.proofId === "string" && proof.proofId.trim() &&
        Number.isFinite(proof.confidence) && proof.confidence >= 0.9 && proof.confidence <= 1
      );

      // A chosen answer must be independently confirmed and the rejected answer
      // independently falsified. An unverified answer is not automatically wrong.
      if (
        !isTrustedProof(chosenProof) || chosenProof?.outcome !== true ||
        !isTrustedProof(rejectedProof) || rejectedProof?.outcome !== false
      ) {
        return {
          direction: "symbolic_to_neural",
          success: false,
          message: "No preference pair: require independent proof that chosen is correct and rejected is incorrect",
        };
      }

      if (!symbolicAnswer.trim() || !neuralAnswer.trim()) {
        return {
          direction: "symbolic_to_neural",
          success: false,
          message: "No preference pair: both candidate answers must be non-empty",
        };
      }

      // Evidence-strength margin: sum of the two independent verdict log-odds.
      // It is bounded for stable preference optimization and has no text-length term.
      const logit = (p: number) => Math.log(p / (1 - p));
      const scoreDiff = Math.max(0.05, Math.min(1, (
        logit(chosenProof!.confidence) + logit(rejectedProof!.confidence)
      ) / 8));

      return {
        direction: "symbolic_to_neural",
        success: true,
        distilledArtifact: {
          type: "preference_pair",
          content: {
            prompt: question,
            chosen: symbolicAnswer,
            rejected: neuralAnswer || "No neural answer",
            scoreDiff,
            verified: true,
            chosenEvidence: chosenProof,
            rejectedEvidence: rejectedProof,
            source: "neural-symbolic-distillation-verified-only",
          },
        },
        message: "Preference pair created from independent positive and negative verification proofs",
      };
    } catch (err: any) {
      return {
        direction: "symbolic_to_neural",
        success: false,
        message: err.message,
      };
    }
  }
}

// ====================== Main Hyper-Grid Engine ======================

export class NeuralSymbolicHyperGrid {
  private router = new HyperGridRouter();
  private neuralExec = new NeuralPathExecutor();
  private symbolicExec = new SymbolicPathExecutor();
  private hybridExec = new HybridPathExecutor();
  private distiller = new DistillationEngine();

  /**
   * Main entry point
   */
  public async run(request: HyperGridRequest): Promise<HyperGridResponse> {
    const started = Date.now();
    const userId = request.userId || "default";

    // 1. Routing decision
    const decision = this.router.decide(request);

    // 2. Execute primary path
    const pathResults: PathResult[] = [];
    let primaryResult: PathResult;

    switch (decision.primaryPath) {
      case "symbolic":
        primaryResult = await this.symbolicExec.execute(request.question, userId);
        break;
      case "neural":
        primaryResult = await this.neuralExec.execute(request.question, userId);
        break;
      case "hybrid":
      default:
        primaryResult = await this.hybridExec.execute(request.question, userId);
        break;
    }
    pathResults.push(primaryResult);

    // 3. Optional fallback if confidence is low
    if (
      primaryResult.confidence < 0.55 &&
      decision.fallbackPaths.length > 0 &&
      decision.primaryPath !== "hybrid"
    ) {
      const fallback = decision.fallbackPaths[0];
      let fallbackResult: PathResult;
      if (fallback === "hybrid") {
        fallbackResult = await this.hybridExec.execute(request.question, userId);
      } else if (fallback === "symbolic") {
        fallbackResult = await this.symbolicExec.execute(request.question, userId);
      } else {
        fallbackResult = await this.neuralExec.execute(request.question, userId);
      }
      pathResults.push(fallbackResult);

      // Prefer higher confidence
      if (fallbackResult.confidence > primaryResult.confidence) {
        primaryResult = fallbackResult;
      }
    }

    // 4. Distillation (optional)
    let distillation: DistillationResult | undefined;
    if (request.distillation?.enabled) {
      const neuralRes = pathResults.find((p) => p.path === "neural" || p.path === "hybrid");

      if (request.distillation.direction === "symbolic_to_neural") {
        // Never use a fused hybrid response as both sides of a preference pair.
        const standaloneSymbolic = pathResults.find((p) => p.path === "symbolic") ||
          await this.symbolicExec.execute(request.question, userId);
        const standaloneNeural = pathResults.find((p) => p.path === "neural") ||
          await this.neuralExec.execute(request.question, userId);
        if (!pathResults.includes(standaloneSymbolic)) pathResults.push(standaloneSymbolic);
        if (!pathResults.includes(standaloneNeural)) pathResults.push(standaloneNeural);
        distillation = await this.distiller.distillSymbolicToNeural(
          request.question,
          standaloneSymbolic.answer,
          standaloneNeural.answer,
          {
            symbolicEvidence: standaloneSymbolic.verificationEvidence,
            neuralEvidence: standaloneNeural.verificationEvidence,
          }
        );

        // Feed into Hybrid Evolution if possible
        if (distillation.success && distillation.distilledArtifact?.type === "preference_pair") {
          try {
            const { getHybridEvolutionEngine } = await import("./hybridSelfEvolution");
            const hybrid = getHybridEvolutionEngine();
            const pair = distillation.distilledArtifact.content;
            hybrid.recordVerifiedPreferencePair({
              prompt: pair.prompt,
              chosen: pair.chosen,
              rejected: pair.rejected,
              scoreDiff: pair.scoreDiff,
              verified: true,
              chosenEvidence: pair.chosenEvidence,
              rejectedEvidence: pair.rejectedEvidence,
            });
          } catch {
            // optional
          }
        }
      } else if (neuralRes) {
        distillation = await this.distiller.distillNeuralToSymbolic(
          request.question,
          neuralRes.answer
        );
      }
    }

    const totalLatencyMs = Date.now() - started;

    
    // Persist decision for learning / analytics
    await this.logDecisionToLedger(request, {
      finalAnswer: primaryResult.answer,
      chosenPath: primaryResult.path,
      pathResults,
      confidence: primaryResult.confidence,
      distillation,
      gridDecisionReason: decision.reason,
      totalLatencyMs,
      metadata: {
        neuralUsed: pathResults.some((p) => p.path === "neural" || p.path === "hybrid"),
        symbolicUsed: pathResults.some((p) => p.path === "symbolic" || p.path === "hybrid"),
        hybridUsed: pathResults.some((p) => p.path === "hybrid"),
        verificationPassed: primaryResult.verified === true,
      },
    });

return {
      finalAnswer: primaryResult.answer,
      chosenPath: primaryResult.path,
      pathResults,
      confidence: primaryResult.confidence,
      distillation,
      gridDecisionReason: decision.reason,
      totalLatencyMs,
      metadata: {
        neuralUsed: pathResults.some((p) => p.path === "neural" || p.path === "hybrid"),
        symbolicUsed: pathResults.some((p) => p.path === "symbolic" || p.path === "hybrid"),
        hybridUsed: pathResults.some((p) => p.path === "hybrid"),
        verificationPassed: primaryResult.verified === true,
      },
    };
  }

  /** Persist routing + outcome signals for later router learning */
  private async logDecisionToLedger(
    request: HyperGridRequest,
    response: HyperGridResponse
  ): Promise<void> {
    try {
      const { saveModelPerformanceRecord } = await import("./modelLedger");
      const domain = request.domain || "hypergrid";
      const modelId = `hypergrid:${response.chosenPath}`;

      await saveModelPerformanceRecord({
        modelId,
        domain,
        totalCalls: 1,
        successfulCalls: response.metadata.verificationPassed ? 1 : 0,
        avgPsi: response.confidence,
        avgLatencyMs: response.totalLatencyMs,
        eloRating: 1500 + Math.round((response.confidence - 0.5) * 200),
        lastUpdated: Date.now(),
      } as any);

      // Optional richer log collection
      try {
        const { getDb } = await import("./firebase");
        const db = getDb();
        if (db) {
          await db.collection("omega_hypergrid_decisions").add({
            question: request.question.slice(0, 500),
            userId: request.userId || "user_main",
            domain,
            chosenPath: response.chosenPath,
            confidence: response.confidence,
            latencyMs: response.totalLatencyMs,
            reason: response.gridDecisionReason,
            verificationPassed: response.metadata.verificationPassed,
            distillation: response.distillation?.success || false,
            createdAt: Date.now(),
          });
        }
      } catch {
        // firebase optional
      }
    } catch (err) {
      console.warn("[HyperGrid] ledger log failed:", err);
    }
  }


}

// ====================== Singleton ======================

let globalHyperGrid: NeuralSymbolicHyperGrid | null = null;

export function getNeuralSymbolicHyperGrid(): NeuralSymbolicHyperGrid {
  if (!globalHyperGrid) {
    globalHyperGrid = new NeuralSymbolicHyperGrid();
  }
  return globalHyperGrid;
}

export function resetNeuralSymbolicHyperGrid() {
  globalHyperGrid = null;
}
