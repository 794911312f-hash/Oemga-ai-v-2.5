/**
 * Client-side auth helpers for Omega AI.
 * Server expects Firebase ID token (Bearer) or queue token — not localStorage alone.
 */

export type OmegaAuthSession = {
  email: string;
  name: string;
  loginTime: number;
  /** Firebase ID token when available — required for paid/costly API routes */
  idToken?: string;
  uid?: string;
  /** true when session is local-only (no server-verified token) */
  localOnly: boolean;
};

const STORAGE_KEY = "omega_auth_user";

export function loadAuthSession(): OmegaAuthSession | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed?.email) return null;
    return {
      email: String(parsed.email),
      name: String(parsed.name || parsed.email.split("@")[0]),
      loginTime: Number(parsed.loginTime) || Date.now(),
      idToken: typeof parsed.idToken === "string" ? parsed.idToken : undefined,
      uid: typeof parsed.uid === "string" ? parsed.uid : undefined,
      localOnly: !parsed.idToken,
    };
  } catch {
    return null;
  }
}

export function saveAuthSession(session: OmegaAuthSession): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
  } catch {
    // ignore quota / private mode
  }
}

export function clearAuthSession(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    // ignore
  }
}

/**
 * Build fetch headers for Omega API calls.
 * Attaches Bearer token when a real ID token is present.
 */
export function authHeaders(extra?: Record<string, string>): Record<string, string> {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...extra,
  };
  const session = loadAuthSession();
  if (session?.idToken) {
    headers["Authorization"] = `Bearer ${session.idToken}`;
  }
  return headers;
}

/** True when the client can call AUTH_REQUIRED routes successfully */
export function hasServerAuth(): boolean {
  const s = loadAuthSession();
  return Boolean(s?.idToken);
}
