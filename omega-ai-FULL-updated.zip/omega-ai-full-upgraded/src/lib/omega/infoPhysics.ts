/**
 * src/lib/omega/infoPhysics.ts
 * =============================================================================
 * Information-theoretic and statistical-physics primitives for Omega consensus.
 *
 * Design rule: every quantity is computable from observable answer texts /
 * embeddings / logprobs. No hidden activations. Metaphors (particles, free
 * energy) are only kept when they map 1–1 onto these observables.
 *
 * Contents:
 *  1) Boltzmann / softmax selection from energies
 *  2) Measurable free-energy style objective F = E − T S
 *  3) Cluster / label mutual information helpers
 *  4) Bridge from SpectralConsensusResult → energies & objective
 */

import type { SpectralConsensusResult } from "./spectralConsensus";

const EPS = 1e-12;

// ───────────────────────── Boltzmann ─────────────────────────

/**
 * Energy of a candidate. Lower = preferred.
 * Default: E_i = −logprob  (high likelihood → low energy).
 * Fallback when logprob missing: E_i = −log(w_i + ε) from spectral weights,
 * or uniform.
 */
export function candidateEnergies(
  logprobs: Array<number | undefined>,
  spectralWeights?: number[]
): number[] {
  const n = logprobs.length;
  const hasLp = logprobs.some((x) => typeof x === "number" && Number.isFinite(x!));
  if (hasLp) {
    return logprobs.map((lp) => (typeof lp === "number" && Number.isFinite(lp) ? -lp : 20));
  }
  if (spectralWeights && spectralWeights.length === n) {
    return spectralWeights.map((w) => -Math.log(Math.max(w, EPS)));
  }
  return new Array(n).fill(0);
}

/**
 * Boltzmann distribution: P_i = exp(−E_i / T) / Z.
 * T → 0: argmin energy (hard best-of-n).
 * T → ∞: uniform.
 * Returns normalised probabilities (sum = 1).
 */
export function boltzmannWeights(energies: number[], temperature = 1): number[] {
  const T = Math.max(temperature, 1e-8);
  const scaled = energies.map((e) => -e / T);
  const maxS = Math.max(...scaled);
  const exps = scaled.map((s) => Math.exp(s - maxS));
  const Z = exps.reduce((a, b) => a + b, 0) || 1;
  return exps.map((e) => e / Z);
}

/** Pick index of max Boltzmann probability; return soft confidence. */
export function boltzmannSelect(
  energies: number[],
  temperature = 1
): { index: number; probabilities: number[]; confidence: number } {
  const p = boltzmannWeights(energies, temperature);
  let best = 0;
  for (let i = 1; i < p.length; i++) if (p[i] > p[best]) best = i;
  return { index: best, probabilities: p, confidence: p[best] };
}

// ───────────────────────── Free-energy style objective ─────────────────────────

/**
 * Measurable free-energy proxy for a multi-answer round:
 *
 *   F = E − T · S
 *
 * where (all derived from observables):
 *   E = expected energy under Boltzmann weights  (⟨E⟩)
 *       or, if preferred, (1 − cohesion) as disagreement energy
 *   S = semantic / spectral entropy of the answer set (nats)
 *   T = temperature (control knob: higher T tolerates more diversity)
 *
 * Minimising F prefers low-energy (confident / central) answers while
 * the −T S term keeps the system from collapsing to a single spurious mode
 * when T is large — same tradeoff as variational free energy, without
 * claiming a neural generative model.
 */
export interface FreeEnergyBreakdown {
  /** ⟨E⟩ under the Boltzmann distribution used */
  expectedEnergy: number;
  /** Entropy term S (nats) */
  entropy: number;
  /** Temperature */
  temperature: number;
  /** F = expectedEnergy − temperature * entropy */
  freeEnergy: number;
  /** Alternative disagreement energy: 1 − spectral cohesion ∈ [0,1] */
  disagreementEnergy: number;
  /** F using disagreement energy instead of ⟨E⟩ */
  freeEnergyDisagreement: number;
}

export function computeFreeEnergy(
  energies: number[],
  entropyNats: number,
  temperature: number,
  spectralCohesion?: number
): FreeEnergyBreakdown {
  const T = Math.max(temperature, 1e-8);
  const p = boltzmannWeights(energies, T);
  const expectedEnergy = p.reduce((s, pi, i) => s + pi * energies[i], 0);
  const S = Math.max(0, entropyNats);
  const disagreementEnergy =
    spectralCohesion !== undefined ? Math.max(0, 1 - spectralCohesion) : expectedEnergy;
  return {
    expectedEnergy,
    entropy: S,
    temperature: T,
    freeEnergy: expectedEnergy - T * S,
    disagreementEnergy,
    freeEnergyDisagreement: disagreementEnergy - T * S,
  };
}

/**
 * Map a SpectralConsensusResult + optional logprobs into energies, Boltzmann
 * weights, and free-energy breakdown. Single entry point for the bridge /
 * kernel layers.
 */
export function fromSpectral(
  spectral: SpectralConsensusResult,
  logprobs?: Array<number | undefined>,
  temperature = 1,
  entropyNats?: number
): {
  energies: number[];
  boltzmann: number[];
  selectedIndex: number;
  freeEnergy: FreeEnergyBreakdown;
} {
  const n = spectral.n;
  const lp = logprobs && logprobs.length === n ? logprobs : new Array(n).fill(undefined);
  const energies = candidateEnergies(lp, spectral.weights);
  const { index, probabilities } = boltzmannSelect(energies, temperature);
  // Prefer explicit entropy; else use a simple spectral proxy: −∑ w log w on Perron weights
  const S =
    entropyNats !== undefined
      ? entropyNats
      : -spectral.weights.reduce((s, w) => s + (w > EPS ? w * Math.log(w) : 0), 0);
  const freeEnergy = computeFreeEnergy(energies, S, temperature, spectral.cohesion);
  return {
    energies,
    boltzmann: probabilities,
    selectedIndex: index,
    freeEnergy,
  };
}

// ───────────────────────── Mutual information (discrete) ─────────────────────────

/**
 * Normalised mutual information between two hard labelings (e.g. spectral
 * clusters vs correctness labels). Useful as an offline diagnostic:
 * does the clustering align with “correct / incorrect”?
 *
 * Returns NMI in [0,1].
 */
export function normalisedMutualInformation(labelsA: number[], labelsB: number[]): number {
  const n = labelsA.length;
  if (n === 0 || labelsB.length !== n) return 0;

  const count = (labs: number[]) => {
    const m = new Map<number, number>();
    for (const l of labs) m.set(l, (m.get(l) || 0) + 1);
    return m;
  };
  const a = count(labelsA);
  const b = count(labelsB);
  const joint = new Map<string, number>();
  for (let i = 0; i < n; i++) {
    const k = `${labelsA[i]}|${labelsB[i]}`;
    joint.set(k, (joint.get(k) || 0) + 1);
  }

  const H = (m: Map<number, number>) => {
    let h = 0;
    for (const c of m.values()) {
      const p = c / n;
      if (p > EPS) h -= p * Math.log(p);
    }
    return h;
  };
  const HA = H(a);
  const HB = H(b);
  if (HA < EPS || HB < EPS) return 0;

  let MI = 0;
  for (const [k, c] of joint) {
    const [la, lb] = k.split("|").map(Number);
    const pxy = c / n;
    const px = (a.get(la) || 0) / n;
    const py = (b.get(lb) || 0) / n;
    if (pxy > EPS && px > EPS && py > EPS) MI += pxy * Math.log(pxy / (px * py));
  }
  return Math.max(0, Math.min(1, MI / Math.sqrt(HA * HB)));
}

/**
 * Binary correctness labels from a boolean array (true → 1, false → 0).
 * Convenience for NMI(spectral labels, correctness).
 */
export function correctnessLabels(correct: boolean[]): number[] {
  return correct.map((c) => (c ? 1 : 0));
}
