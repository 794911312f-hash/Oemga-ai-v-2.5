/**
 * src/lib/omega/embeddings.ts
 *
 * Provider-backed semantic embeddings with a deterministic local lexical fallback.
 * The fallback is deliberately labelled "hash"; it is not a pretrained semantic
 * model and must not be presented as one in benchmark reports.
 */

import { normalize } from "./math";
import type { ProviderKeys } from "./models";

const ARABIC_STOPWORDS = new Set([
  "من", "في", "على", "الى", "إلى", "عن", "ما", "هو", "هي", "هذا", "هذه",
  "ذلك", "تلك", "و", "أو", "ثم", "أن", "إن", "لا", "لم", "لن", "مع", "كل",
  "the", "a", "an", "is", "are", "of", "to", "in", "on", "and", "or", "what",
]);

/** Normalize common Arabic orthographic variants before token hashing. */
export function normalizeEmbeddingText(text: string): string {
  return text
    .normalize("NFKD")
    .replace(/[\u064B-\u065F\u0670\u0640]/g, "")
    .replace(/[أإآٱ]/g, "ا")
    .replace(/[ى]/g, "ي")
    .replace(/[ة]/g, "ه")
    .toLowerCase()
    .trim();
}

function tokenize(text: string): string[] {
  return normalizeEmbeddingText(text)
    .split(/[^\p{L}\p{N}_]+/u)
    .map((token) => token.trim())
    .filter((token) => token.length > 1 && !ARABIC_STOPWORDS.has(token));
}

function hashFeature(feature: string): { index: number; sign: number } {
  let h = 2166136261;
  for (let i = 0; i < feature.length; i++) {
    h ^= feature.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return { index: Math.abs(h) >>> 0, sign: (h & 1) === 0 ? 1 : -1 };
}

/**
 * Deterministic lexical n-gram embedding, not a semantic embedding.
 *
 * Compared with the old character-only fallback this uses normalized tokens,
 * token bigrams, subword trigrams, numeric/type markers and sign hashing. It
 * improves lexical robustness across Arabic spelling variants while remaining
 * honest: real semantic similarity requires a provider-backed embedding.
 */
export function hashEmbed(text: string, dim = 64): number[] {
  const vec = new Array(dim).fill(0);
  const normalized = normalizeEmbeddingText(text);
  if (!normalized) return vec;
  const tokens = tokenize(normalized);

  const add = (feature: string, weight: number) => {
    const h = hashFeature(feature);
    vec[h.index % dim] += h.sign * weight;
  };

  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];
    add(`w:${token}`, 1.5);
    if (i + 1 < tokens.length) add(`b:${token}_${tokens[i + 1]}`, 1.0);
    if (/^\d+(?:\.\d+)?$/.test(token)) add("type:number", 0.8);
    if (/^[a-z_$][\w$]*$/i.test(token)) add("type:identifier", 0.35);
    for (let j = 0; j < token.length - 2; j++) {
      add(`s:${token.slice(j, j + 3)}`, 0.25);
    }
  }

  if (/[?؟]/.test(normalized)) add("type:question", 0.25);
  if (/[=<>+*/^×÷]/.test(normalized)) add("type:math", 0.45);
  if (/\b(?:code|javascript|typescript|python|كود|برمج|خوارزمي)/i.test(normalized)) {
    add("type:code", 0.45);
  }
  if (/\b(?:اشرح|شرح|explain|summarize|لخص)/i.test(normalized)) {
    add("type:explanation", 0.3);
  }

  return normalize(vec);
}

export interface EmbedBatchResult {
  vectors: number[][];
  source: "semantic" | "hash";
}

/**
 * Use the server's provider-backed embedding endpoint when available; fall
 * back to the deterministic lexical vector when offline or unconfigured.
 */
export async function embedBatch(
  texts: string[],
  keys?: ProviderKeys
): Promise<EmbedBatchResult> {
  if (texts.length === 0) return { vectors: [], source: "hash" };

  try {
    const res = await fetch("/api/omega/embed", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ texts, keys }),
    });
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data.vectors) && data.vectors.length === texts.length) {
        return {
          vectors: data.vectors.map((v: number[]) => normalize(v)),
          source: data.source === "semantic" ? "semantic" : "hash",
        };
      }
    }
  } catch {
    // Expected in local/offline Node execution; use the explicit fallback.
  }

  return { vectors: texts.map((text) => hashEmbed(text, 64)), source: "hash" };
}
