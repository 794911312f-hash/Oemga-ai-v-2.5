/**
 * Self-checking is not external fact verification. This module deliberately
 * fails closed: only a response carrying an explicit external proof may set
 * `verified: true`.
 */

import type { ModelId, ProviderKeys } from "./models";

export interface VerificationResult {
  verified: boolean;
  score: number; // heuristic consistency score, not a probability of truth
  critique: string;
  hasContradiction: boolean;
  claimsChecked: number;
  warnings: string[];
  verifierModel?: ModelId;
  verificationType?: "external_proof" | "model_judgment" | "heuristic_consistency";
}

export async function verifyAnswer(
  question: string,
  answer: string,
  verifierModel: ModelId,
  keys?: ProviderKeys
): Promise<VerificationResult> {
  if (!answer.trim()) {
    return {
      verified: false,
      score: 0,
      critique: "الإجابة فارغة أو غير مكتملة",
      hasContradiction: false,
      claimsChecked: 0,
      warnings: ["Empty answer returned"],
      verifierModel,
      verificationType: "heuristic_consistency",
    };
  }

  try {
    const res = await fetch("/api/omega/verify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question, answer, verifierModel, keys }),
    });

    if (res.ok) {
      const data = await res.json();
      if (typeof data.score === "number") {
        const hasExternalProof = data.verificationType === "external_proof";
        return {
          // A model's confidence or a consistency check is not ground truth.
          verified: hasExternalProof && data.verified === true,
          score: Math.max(0, Math.min(1, data.score)),
          critique: data.critique || "اكتمل فحص الإجابة",
          hasContradiction: Boolean(data.hasContradiction),
          claimsChecked: Number.isFinite(data.claimsChecked) ? data.claimsChecked : 0,
          warnings: [
            ...(Array.isArray(data.warnings) ? data.warnings : []),
            ...(!hasExternalProof ? ["لم يُرفق إثبات خارجي؛ هذه النتيجة لا تثبت صحة الوقائع."] : []),
          ],
          verifierModel,
          verificationType: hasExternalProof ? "external_proof" : "model_judgment",
        };
      }
    }
  } catch {
    // Network/server error: only run a local consistency heuristic below.
  }

  return algorithmicVerification(question, answer, verifierModel);
}

/** Local lexical checks can flag some issues, but cannot certify truth. */
export function algorithmicVerification(
  question: string,
  answer: string,
  verifierModel: ModelId
): VerificationResult {
  const warnings: string[] = [];
  let score = 0.5;
  let hasContradiction = false;
  const sentences = answer
    .split(/[.!?؟\n]+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 5);

  const lower = answer.toLowerCase();
  if (
    (lower.includes("صحيح") && lower.includes("غير صحيح في نفس الوقت")) ||
    (lower.includes("always") && lower.includes("never"))
  ) {
    warnings.push("احتمال تعارض لفظي؛ يلزم تدقيق سياقي.");
    hasContradiction = true;
    score = 0.2;
  }

  if (!question.trim()) warnings.push("لم يُقدَّم سؤال للمقارنة.");
  warnings.push("فحص الاتساق المحلي لا يتحقق من الحقائق أو الحسابات؛ لا يوجد إثبات خارجي.");

  return {
    verified: false,
    score: Number(score.toFixed(2)),
    critique: hasContradiction
      ? "رُصد احتمال تعارض لفظي، ولم تُتحقق صحة الادعاءات خارجياً."
      : "لم يرصد الفحص اللفظي تعارضاً واضحاً؛ صحة الوقائع غير محسومة.",
    hasContradiction,
    claimsChecked: sentences.length,
    warnings,
    verifierModel,
    verificationType: "heuristic_consistency",
  };
}
