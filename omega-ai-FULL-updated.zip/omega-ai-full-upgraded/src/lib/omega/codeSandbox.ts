/**
 * src/lib/omega/codeSandbox.ts
 * =============================================================================
 * Sandboxed code execution for Omega — security-hardened.
 *
 * CRITICAL (Manus / internal audit):
 *   node:vm is NOT a security boundary. Passing host objects (Math, String,
 *   Object, console, …) into createContext lets untrusted code reach Function
 *   constructors and often process.env / filesystem APIs.
 *
 * Server path:
 *   Delegates to src/server/sandbox.ts → child process with:
 *     - empty env (no secrets)
 *     - Node permission model (no fs / child_process / …)
 *     - heap + wall-clock limits
 *     - vm context that receives NO host objects
 *
 * Browser path:
 *   Disabled by default (new Function is not isolation). Set
 *   OMEGA_ALLOW_BROWSER_SANDBOX=1 only for trusted local demos.
 *
 * Kill switch:
 *   OMEGA_DISABLE_CODE_SANDBOX=1 → all execution refused.
 */

import type { SandboxResult } from "../../server/sandbox";

export interface ExecutionResult {
  ok: boolean;
  output: string;
  returnValue?: unknown;
  error?: string | null;
  attempts: number;
  history: Array<{
    attempt: number;
    code: string;
    error: string | null;
    output: string;
  }>;
  executionTimeMs: number;
}

function isDisabled(): boolean {
  return typeof process !== "undefined" && process.env?.OMEGA_DISABLE_CODE_SANDBOX === "1";
}

function allowBrowserSandbox(): boolean {
  return typeof process !== "undefined" && process.env?.OMEGA_ALLOW_BROWSER_SANDBOX === "1";
}

export class SafeCodeSandbox {
  private timeoutMs = 3500;

  /**
   * Browser runner — NOT a security boundary.
   * Only enabled when OMEGA_ALLOW_BROWSER_SANDBOX=1.
   */
  runClientSafe(code: string): {
    ok: boolean;
    output: string;
    returnValue?: unknown;
    error?: string | null;
  } {
    if (isDisabled()) {
      return {
        ok: false,
        output: "",
        error: "Code sandbox disabled (OMEGA_DISABLE_CODE_SANDBOX=1)",
      };
    }
    if (!allowBrowserSandbox()) {
      return {
        ok: false,
        output: "",
        error:
          "Browser code execution disabled. Use the server /api sandbox, or set OMEGA_ALLOW_BROWSER_SANDBOX=1 for trusted local demos only.",
      };
    }

    const logs: string[] = [];
    const customConsole = {
      log: (...args: unknown[]) =>
        logs.push(
          args
            .map((a) => (typeof a === "object" ? JSON.stringify(a, null, 2) : String(a)))
            .join(" ")
        ),
      error: (...args: unknown[]) => logs.push("[خطأ] " + args.join(" ")),
      warn: (...args: unknown[]) => logs.push("[تنبيه] " + args.join(" ")),
      info: (...args: unknown[]) => logs.push(args.join(" ")),
    };

    try {
      const wrapped = `
        "use strict";
        const console = customConsole;
        return (function() {
          ${code}
        })();
      `;
      // eslint-disable-next-line no-new-func
      const fn = new Function("customConsole", wrapped);
      const returnValue = fn(customConsole);
      const output =
        logs.join("\n") +
        (returnValue !== undefined
          ? `\n[النتيجة المُرجعة]: ${JSON.stringify(returnValue, null, 2)}`
          : "");
      return { ok: true, output: output.trim(), returnValue, error: null };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      return { ok: false, output: logs.join("\n"), error: msg };
    }
  }

  /**
   * Server: process-isolated runner (src/server/sandbox.ts).
   * Does NOT pass host Math/String/Object into the guest context.
   */
  async runSingle(code: string): Promise<{
    ok: boolean;
    output: string;
    returnValue?: unknown;
    error?: string | null;
  }> {
    if (isDisabled()) {
      return {
        ok: false,
        output: "",
        error: "Code sandbox disabled (OMEGA_DISABLE_CODE_SANDBOX=1)",
      };
    }

    if (typeof window !== "undefined") {
      return this.runClientSafe(code);
    }

    const { runUntrustedJs } = await import("../../server/sandbox");
    const result: SandboxResult = await runUntrustedJs(code, {
      wallMs: this.timeoutMs,
      heapMb: 64,
    });

    return {
      ok: result.ok,
      output: result.output,
      returnValue: undefined,
      error: result.error,
    };
  }

  /**
   * Self-correcting loop (heuristic repairs only — each attempt still isolated).
   */
  async executeWithSelfCorrection(
    initialCode: string,
    repairFn?: (code: string, error: string) => Promise<string>,
    maxAttempts = 3
  ): Promise<ExecutionResult> {
    const startTime = Date.now();
    let currentCode = initialCode;
    const history: ExecutionResult["history"] = [];

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const run = await this.runSingle(currentCode);
      history.push({
        attempt,
        code: currentCode,
        error: run.error ?? null,
        output: run.output,
      });

      if (run.ok) {
        return {
          ok: true,
          output: run.output || "تم تنفيذ الكود البرمجي بنجاح.",
          returnValue: run.returnValue,
          error: null,
          attempts: attempt,
          history,
          executionTimeMs: Date.now() - startTime,
        };
      }

      if (attempt === maxAttempts) break;

      if (repairFn) {
        currentCode = await repairFn(currentCode, run.error || "unknown error");
      } else {
        currentCode = this.heuristicRepair(currentCode, run.error || "");
      }
    }

    const last = history[history.length - 1];
    return {
      ok: false,
      output: last?.output ?? "",
      error: last?.error ?? "Execution failed",
      attempts: history.length,
      history,
      executionTimeMs: Date.now() - startTime,
    };
  }

  /** Heuristic repair only — never injects host APIs. */
  private heuristicRepair(code: string, error: string): string {
    let repaired = code;

    if (/is not defined/.test(error)) {
      const match = error.match(/(\w+) is not defined/);
      const name = match?.[1];
      if (
        name &&
        !["process", "require", "global", "globalThis", "Function", "eval"].includes(name)
      ) {
        repaired = `let ${name} = 0;\n` + repaired;
      }
    }

    if (/Illegal return statement/.test(error)) {
      repaired = `(() => {\n${repaired}\n})();`;
    }

    if (/zero/i.test(error) || /infinity/i.test(error)) {
      repaired = repaired.replace(/\/ 0/g, "/ 1e-12");
    }

    return repaired;
  }
}

export const globalSafeSandbox = new SafeCodeSandbox();
