import express from "express";
import rateLimit from "express-rate-limit";
import crypto from "crypto";
import { sanitizeUserId, routeGuard } from "./security";

export interface QueueAuthOptions {
  secretEnvVar?: string;
}

function timingSafeStringEqual(a: string, b: string): boolean {
  try {
    const ba = Buffer.from(a);
    const bb = Buffer.from(b);
    if (ba.length !== bb.length) {
      // still perform a compare to reduce timing signal on length-only path
      crypto.timingSafeEqual(ba, ba);
      return false;
    }
    return crypto.timingSafeEqual(ba, bb);
  } catch {
    return false;
  }
}

/** Registers the API safety boundary without coupling it to route handlers. */
export function registerApiMiddleware(
  app: express.Application,
  options: QueueAuthOptions = {},
): void {
  // Parse JSON before auth middleware so body fields are available when needed
  // Slightly higher limit to absorb base64 video payloads ~12MB → ~16MB encoded
  app.use(express.json({ limit: "20mb" }));

  const globalApiLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 120,
    standardHeaders: true,
    legacyHeaders: false,
    // trustProxy left false by default; set TRUST_PROXY=1 in reverse-proxy deploys
    validate: {
      trustProxy: false,
      xForwardedForHeader: false,
    },
    message: { ok: false, error: "Too many requests to Omega API. Please try again in a minute." },
  });

  const aiComputeLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 45,
    standardHeaders: true,
    legacyHeaders: false,
    validate: {
      trustProxy: false,
      xForwardedForHeader: false,
    },
    message: { ok: false, error: "Rate limit exceeded for AI inference queue. Please wait a moment." },
  });

  /**
   * Code-execution surfaces (sandbox / self-correct / tools that may run JS).
   * MATH-SECURITY-ROADMAP A3: tighter than general AI compute.
   * Key prefers authenticated userId, falls back to IP.
   */
  const codeExecLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: Number(process.env.OMEGA_CODE_EXEC_RPM ?? 8),
    standardHeaders: true,
    legacyHeaders: false,
    validate: { trustProxy: false, xForwardedForHeader: false },
    keyGenerator: (req) => {
      // Prefer authenticated identity only — never trust body.userId (bucket rotation).
      const authUser = (req as any).user as { uid?: string; isGuest?: boolean } | undefined;
      if (authUser?.uid && !authUser.isGuest) {
        return `code:user:${String(authUser.uid).slice(0, 128)}`;
      }
      return `code:ip:${req.ip || req.socket?.remoteAddress || "unknown"}`;
    },
    message: {
      ok: false,
      error: "Code execution rate limit exceeded. Try again in a minute.",
      code: "CODE_EXEC_RATE_LIMIT",
    },
  });

  async function queueAuthMiddleware(
    req: express.Request,
    _res: express.Response,
    next: express.NextFunction,
  ): Promise<void> {
    const authHeader = req.headers.authorization;
    const queueToken = req.headers["x-queue-token"] || req.headers["x-omega-token"];
    const secretKey = process.env[options.secretEnvVar ?? "OMEGA_QUEUE_SECRET"];

    if (secretKey && typeof queueToken === "string" && timingSafeStringEqual(queueToken, secretKey)) {
      (req as any).user = { uid: "queue-worker", role: "admin" };
      next();
      return;
    }

    if (authHeader && authHeader.startsWith("Bearer ")) {
      const idToken = authHeader.split("Bearer ")[1];
      try {
        const { getAuth } = await import("firebase-admin/auth");
        const decoded = await getAuth().verifyIdToken(idToken);
        (req as any).user = decoded;
        next();
        return;
      } catch {
        // Fall through to guest context; protected handlers decide access.
      }
    }

    // Guest: never trust body/header userId as identity — fixed guest scope only
    (req as any).user = { uid: "guest-user", isGuest: true };
    next();
  }


  // Optional reverse-proxy trust (Replit, nginx, etc.)
  if (process.env.TRUST_PROXY === "1" || process.env.TRUST_PROXY === "true") {
    app.set("trust proxy", 1);
  }

  app.use("/api/", globalApiLimiter as unknown as express.RequestHandler);
  app.use("/v1/", globalApiLimiter as unknown as express.RequestHandler);

  app.use(
    [
      "/api/omega/complete",
      "/api/omega/ensemble",
      "/api/omega/deduce",
      "/api/omega/self-play",
      "/api/omega/hypergrid/run",
      "/api/omega/video/analyze",
      "/api/omega/video/analyze-upload",
      "/api/omega/open-sora/closed-loop",
      "/api/omega/core",
      "/api/omega/core/process",
      "/api/omega/workspace",
      "/v1/chat/completions",
    ],
    aiComputeLimiter as unknown as express.RequestHandler,
  );

  // All paths that can run untrusted code or claim to
  const codeExecPaths = [
    "/api/omega/code/execute",
    "/api/omega/code/self-correct",
    "/api/omega/tools/execute",
  ];
  for (const p of codeExecPaths) {
    app.use(p, codeExecLimiter as unknown as express.RequestHandler);
  }

  // Auth context for API + OpenAI-compatible surface
  app.use("/api/omega/", queueAuthMiddleware);
  app.use("/v1/", queueAuthMiddleware);
  app.use("/api/omega/", routeGuard);
}
