import type express from "express";

const USER_ID_PATTERN = /^[a-zA-Z0-9._:@-]{1,128}$/;

export function sanitizeUserId(value: unknown, fallback = "guest-user"): string {
  if (typeof value !== "string") return fallback;
  const normalized = value.trim();
  return USER_ID_PATTERN.test(normalized) ? normalized : fallback;
}

export function validateSecretInput(value: unknown, maxLength = 512): string | null {
  if (typeof value !== "string") return null;
  const normalized = value.trim();
  if (!normalized || normalized.length > maxLength || /[\u0000-\u001f\u007f]/.test(normalized)) return null;
  return normalized;
}

export function isPrivilegedRequest(req: express.Request): boolean {
  const user = (req as any).user;
  return user?.role === "admin" || user?.admin === true || user?.claims?.admin === true;
}

/**
 * Resolve the trusted user id for the request.
 * - Prefer authenticated Firebase/queue user (req.user.uid)
 * - Guests must NOT supply arbitrary body/header userId for sensitive operations
 */
export type TrustedUserResult =
  | { ok: true; userId: string; isGuest: boolean }
  | { ok: false; error: string };

export function isTrustedUserFailure(
  value: TrustedUserResult
): value is { ok: false; error: string } {
  return value.ok === false;
}

export function resolveTrustedUserId(
  req: express.Request,
  options: { allowGuest?: boolean; guestFallback?: string } = {},
): TrustedUserResult {
  const user = (req as any).user as
    | { uid?: string; isGuest?: boolean; role?: string }
    | undefined;

  const isGuest = Boolean(user?.isGuest) || !user?.uid;
  const allowGuest = options.allowGuest === true;
  const guestFallback = options.guestFallback ?? "guest-user";

  if (!isGuest && user?.uid) {
    return { ok: true, userId: sanitizeUserId(user.uid), isGuest: false };
  }

  if (!allowGuest) {
    return {
      ok: false,
      error:
        "Authentication required. Do not pass userId in body/headers for sensitive memory or graph operations.",
    };
  }

  // Guest mode: ignore attacker-controlled body/header identity; use fixed guest scope
  return { ok: true, userId: guestFallback, isGuest: true };
}

/** Express helper: reject unauthenticated access to sensitive routes */
export function requireAuthenticatedUser(
  req: express.Request,
  res: express.Response,
): string | null {
  const resolved = resolveTrustedUserId(req, { allowGuest: false });
  if (isTrustedUserFailure(resolved)) {
    res.status(401).json({ ok: false, error: resolved.error });
    return null;
  }
  return resolved.userId;
}

/** Low-risk browser and API response headers; intentionally avoids a CSP that could break Vite/auth flows. */
export function registerSecurityMiddleware(app: express.Application): void {
  app.disable("x-powered-by");
  app.use((req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader("Permissions-Policy", "camera=(), geolocation=(), usb=()");
    if (req.path.startsWith("/api/")) res.setHeader("Cache-Control", "no-store");
    next();
  });
}

/**
 * Routes that spend paid provider keys, run costly compute, or mutate evolution state.
 * Guests (isGuest / missing uid) are rejected by routeGuard.
 *
 * Intentional: `/api/omega/complete`, `/ensemble`, `/core`, `/dspy`, etc. require auth
 * so anonymous localStorage sessions cannot burn provider quota. Public probes stay open
 * (e.g. `/api/health`, `/api/omega/workspace/health`, `/api/omega/video-models`).
 */
export const AUTH_REQUIRED_PREFIXES = [
  "/api/omega/browser-use",
  "/api/omega/generate-image",
  "/api/omega/generate-video",
  "/api/omega/voice/",
  "/api/omega/open-sora",
  "/api/omega/openhands",
  "/api/omega/media/generate",
  "/api/omega/pipeline/",
  "/api/omega/avatar",
  "/api/omega/video/analyze-upload",
  "/api/omega/video/analyze",
  "/api/omega/code/execute",
  "/api/omega/code/self-correct",
  "/api/omega/tools/execute",
  // LLM / fusion surfaces that burn provider quota
  "/api/omega/dspy",
  "/api/omega/complete",
  "/api/omega/ensemble",
  "/api/omega/deduce",
  "/api/omega/core",
  "/api/omega/core/process",
  "/api/omega/workspace",
  "/api/omega/hypergrid/run",
  // Hybrid evolution: training / promote / costly runs
  "/api/omega/hybrid-evolution/run",
  "/api/omega/hybrid-evolution/promote",
  "/api/omega/hybrid-evolution/trajectory",
  "/api/omega/hybrid-evolution/verified-pair",
  "/api/omega/hybrid-evolution/select-parent",
  "/api/omega/hybrid-evolution/individual",
];
/** Paths that remain open to guests even when under a broader protected prefix. */
export const AUTH_PUBLIC_PREFIXES = [
  "/api/health",
  "/api/omega/workspace/health",
  "/api/omega/open-model/health",
  "/api/omega/video-models",
];

export const ADMIN_ONLY_PREFIXES = [
  "/api/omega/self-play/toggle",
  "/api/omega/self-play/cycle",
  "/api/omega/hybrid-evolution/promote",
];

export function routeGuard(req: express.Request, res: express.Response, next: express.NextFunction): void {
  // Behind app.use("/api/omega/") req.path is relative, so match on the full original URL.
  const p = (req.originalUrl || req.url || "").split("?")[0];

  if (AUTH_PUBLIC_PREFIXES.some((x) => p === x || p.startsWith(x + "/"))) {
    next();
    return;
  }

  if (ADMIN_ONLY_PREFIXES.some((x) => p.startsWith(x))) {
    if (!isPrivilegedRequest(req)) {
      res.status(403).json({ ok: false, error: "Admin access required." });
      return;
    }
  } else if (AUTH_REQUIRED_PREFIXES.some((x) => p.startsWith(x))) {
    const u = (req as any).user;
    if (u?.isGuest || !u?.uid) {
      res.status(401).json({ ok: false, error: "Authentication required for this operation." });
      return;
    }
  }
  next();
}



/**
 * Simple in-process token bucket (MATH-SECURITY-ROADMAP A3).
 * Used for tests and optional secondary limits; HTTP layer uses express-rate-limit.
 */
export class TokenBucket {
  private tokens: number;
  private lastRefill: number;

  constructor(
    private readonly capacity: number,
    private readonly refillPerSec: number,
  ) {
    this.tokens = capacity;
    this.lastRefill = Date.now();
  }

  private refill(): void {
    const now = Date.now();
    const elapsed = (now - this.lastRefill) / 1000;
    if (elapsed <= 0) return;
    this.tokens = Math.min(this.capacity, this.tokens + elapsed * this.refillPerSec);
    this.lastRefill = now;
  }

  /** Try to consume n tokens; returns false if insufficient. */
  tryTake(n = 1): boolean {
    this.refill();
    if (this.tokens < n) return false;
    this.tokens -= n;
    return true;
  }

  get remaining(): number {
    this.refill();
    return this.tokens;
  }
}

/** Per-key registry of buckets (e.g. userId → sandbox budget). */
export class TokenBucketRegistry {
  private buckets = new Map<string, TokenBucket>();

  constructor(
    private readonly capacity: number,
    private readonly refillPerSec: number,
  ) {}

  tryTake(key: string, n = 1): boolean {
    let b = this.buckets.get(key);
    if (!b) {
      b = new TokenBucket(this.capacity, this.refillPerSec);
      this.buckets.set(key, b);
    }
    return b.tryTake(n);
  }
}
