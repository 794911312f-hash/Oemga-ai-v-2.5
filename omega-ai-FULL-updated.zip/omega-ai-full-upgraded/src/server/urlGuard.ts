/**
 * SSRF guard: only public http(s) destinations, re-validated on every redirect hop.
 *
 * Policy:
 *  - Expand IPv4-mapped / compatible / NAT64 / 6to4 embeddings before private checks
 *    (closes ::ffff:7f00:1 which URL() produces for [::ffff:127.0.0.1]).
 *  - Reject if *any* resolved address is private (mixed A/AAAA must fail closed).
 *  - Pin TCP via undici Agent custom `lookup` (handles both scalar and `all: true`
 *    forms required by Node 20+), keeping the original hostname for SNI/cert.
 * Network/container egress filters remain recommended defense-in-depth.
 */
import dns from "node:dns/promises";
import net from "node:net";
import { createRequire } from "node:module";

export class UnsafeUrlError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "UnsafeUrlError";
  }
}

function ipv4ToInt(ip: string): number {
  return ip.split(".").reduce((a, o) => (a << 8) + Number(o), 0) >>> 0;
}

const V4_BLOCKS: Array<[string, number]> = [
  ["0.0.0.0", 8],
  ["10.0.0.0", 8],
  ["100.64.0.0", 10],
  ["127.0.0.0", 8],
  ["169.254.0.0", 16],
  ["172.16.0.0", 12],
  ["192.0.0.0", 24],
  ["192.0.2.0", 24],
  ["192.168.0.0", 16],
  ["198.18.0.0", 15],
  ["198.51.100.0", 24],
  ["203.0.113.0", 24],
  ["224.0.0.0", 4],
  ["240.0.0.0", 4],
];

export function extractEmbeddedIpv4(ip: string): string | null {
  const l = ip.toLowerCase().replace(/^\[|\]$/g, "");

  let m = l.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
  if (m) return m[1];

  m = l.match(/^::ffff:([0-9a-f]{1,4}):([0-9a-f]{1,4})$/);
  if (m) {
    const hi = parseInt(m[1], 16);
    const lo = parseInt(m[2], 16);
    if (Number.isFinite(hi) && Number.isFinite(lo)) {
      return `${(hi >> 8) & 255}.${hi & 255}.${(lo >> 8) & 255}.${lo & 255}`;
    }
  }

  m = l.match(/^::(\d+\.\d+\.\d+\.\d+)$/);
  if (m) return m[1];

  m = l.match(/^64:ff9b::([0-9a-f]{1,4}):([0-9a-f]{1,4})$/);
  if (m) {
    const hi = parseInt(m[1], 16);
    const lo = parseInt(m[2], 16);
    return `${(hi >> 8) & 255}.${hi & 255}.${(lo >> 8) & 255}.${lo & 255}`;
  }

  m = l.match(/^2002:([0-9a-f]{1,4}):([0-9a-f]{1,4})(?::|$)/);
  if (m) {
    const hi = parseInt(m[1], 16);
    const lo = parseInt(m[2], 16);
    return `${(hi >> 8) & 255}.${hi & 255}.${(lo >> 8) & 255}.${lo & 255}`;
  }

  return null;
}

export function isPrivateAddress(ip: string): boolean {
  const raw = ip.trim().toLowerCase().replace(/^\[|\]$/g, "");

  const embedded = extractEmbeddedIpv4(raw);
  if (embedded) return isPrivateAddress(embedded);

  if (net.isIPv4(raw)) {
    const n = ipv4ToInt(raw);
    return V4_BLOCKS.some(([base, bits]) => {
      const mask = bits === 0 ? 0 : (~0 << (32 - bits)) >>> 0;
      return (n & mask) === (ipv4ToInt(base) & mask);
    });
  }

  if (net.isIPv6(raw)) {
    const l = raw;
    if (l === "::" || l === "::1") return true;
    if (/^f[cd]/.test(l)) return true;
    if (/^fe[89ab]/.test(l)) return true;
    if (/^fe[cdef]/.test(l)) return true;
    if (l.startsWith("ff")) return true;
    return false;
  }

  return true;
}

export interface PublicUrlCheck {
  url: URL;
  addresses: string[];
}

export async function assertPublicHttpUrlDetailed(raw: string): Promise<PublicUrlCheck> {
  let u: URL;
  try {
    u = new URL(raw);
  } catch {
    throw new UnsafeUrlError("Invalid URL");
  }
  if (u.protocol !== "http:" && u.protocol !== "https:") {
    throw new UnsafeUrlError("Only http/https URLs are allowed");
  }
  if (u.username || u.password) {
    throw new UnsafeUrlError("Credentials in URL are not allowed");
  }
  if (u.port && u.port !== "80" && u.port !== "443") {
    throw new UnsafeUrlError("Port not allowed");
  }

  const host = u.hostname.replace(/^\[|\]$/g, "");
  const hostLower = host.toLowerCase();
  if (
    hostLower === "localhost" ||
    hostLower.endsWith(".localhost") ||
    hostLower.endsWith(".internal") ||
    hostLower === "metadata.google.internal" ||
    hostLower === "metadata"
  ) {
    throw new UnsafeUrlError("Local hostnames are not allowed");
  }

  let addrs: Array<{ address: string; family?: number }>;
  if (net.isIP(host)) {
    addrs = [{ address: host }];
  } else {
    try {
      addrs = await dns.lookup(host, { all: true });
    } catch {
      addrs = [];
    }
  }
  if (!addrs.length) throw new UnsafeUrlError("Host did not resolve");

  // Fail closed: ANY private answer rejects the whole host (mixed A/AAAA).
  if (addrs.some((a) => isPrivateAddress(a.address))) {
    throw new UnsafeUrlError("Destination resolves to a private/internal address");
  }

  return { url: u, addresses: addrs.map((a) => a.address) };
}

export async function assertPublicHttpUrl(raw: string): Promise<URL> {
  const { url } = await assertPublicHttpUrlDetailed(raw);
  return url;
}

/** Minimal surface used by safeFetch (undici Agent or test stub). */
export type PinnedDispatcher = {
  close?: () => void | Promise<void>;
  destroy?: () => void | Promise<void>;
};

export type PinnedDispatcherFactory = (addresses: string[]) => PinnedDispatcher;

/** Optional override for tests (inject stub when undici is not installed). */
let pinnedDispatcherFactory: PinnedDispatcherFactory | null = null;

export function setPinnedDispatcherFactory(factory: PinnedDispatcherFactory | null): void {
  pinnedDispatcherFactory = factory;
}

/**
 * undici Agent with connect.lookup pinned to validated addresses.
 * Supports both Node legacy (address, family) and Node 20+ `all: true` array form.
 */
function createPinnedDispatcher(addresses: string[]): PinnedDispatcher {
  if (pinnedDispatcherFactory) {
    return pinnedDispatcherFactory(addresses);
  }

  const primary = addresses[0];
  const family = net.isIPv6(primary) ? 6 : 4;

  try {
    const require = createRequire(import.meta.url);
    const { Agent } = require("undici") as typeof import("undici");
    return new Agent({
      connect: {
        lookup(
          _hostname: string,
          options: { all?: boolean } | undefined,
          callback: (...args: any[]) => void
        ) {
          // Node 20+ may call with { all: true } and expect an array.
          if (options && options.all) {
            callback(null, [{ address: primary, family }]);
            return;
          }
          callback(null, primary, family);
        },
      },
    });
  } catch (err) {
    throw new UnsafeUrlError(
      `DNS-pin requires the undici package (npm i undici): ${(err as Error).message}`
    );
  }
}

async function closeDispatcher(dispatcher: PinnedDispatcher | null | undefined): Promise<void> {
  if (!dispatcher) return;
  try {
    if (typeof dispatcher.close === "function") await dispatcher.close();
    else if (typeof dispatcher.destroy === "function") await dispatcher.destroy();
  } catch {
    // ignore close errors
  }
}

/**
 * fetch that validates the URL and every redirect hop (max 3), and pins TCP
 * to a validated public address via undici dispatcher (keeps SNI / cert host).
 */
export async function safeFetch(
  raw: string,
  init: RequestInit = {},
  maxRedirects = 3
): Promise<Response> {
  let current = raw;
  for (let hop = 0; hop <= maxRedirects; hop++) {
    const { url, addresses } = await assertPublicHttpUrlDetailed(current);
    const dispatcher = createPinnedDispatcher(addresses);
    try {
      // Original hostname preserved → TLS SNI + certificate ALTNAME stay valid.
      const res = await fetch(url, {
        ...init,
        redirect: "manual",
        dispatcher,
      } as RequestInit);

      if (res.status >= 300 && res.status < 400 && res.headers.get("location")) {
        current = new URL(res.headers.get("location")!, url).toString();
        continue;
      }
      return res;
    } finally {
      // Do not await: closing must not block the caller from reading the body.
      // undici Agent.close() drains in-flight requests asynchronously.
      void closeDispatcher(dispatcher);
    }
  }
  throw new UnsafeUrlError("Too many redirects");
}
