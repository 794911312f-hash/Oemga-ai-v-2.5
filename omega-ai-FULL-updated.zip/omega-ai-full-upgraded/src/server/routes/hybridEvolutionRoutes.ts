/**
 * src/server/routes/hybridEvolutionRoutes.ts
 * Extracted from server.ts — Phase 8 Hybrid Self-Evolution API
 */
import type express from "express";
import {
  isPrivilegedRequest,
  resolveTrustedUserId, isTrustedUserFailure,
} from "../security";

export function registerHybridEvolutionRoutes(app: express.Application): void {

// =============================================================================
// Phase 8 — Hybrid Self-Evolution API (wired)
// =============================================================================

app.get("/api/omega/hybrid-evolution/status", async (_req, res) => {
  try {
    const { getHybridEvolutionEngine } = await import("../../lib/omega/hybridSelfEvolution");
    const engine = getHybridEvolutionEngine();
    res.json({ ok: true, ...engine.getStatus() });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err?.message || "Failed to get hybrid status" });
  }
});

app.post("/api/omega/hybrid-evolution/run", async (req, res) => {
  try {
    const resolved = resolveTrustedUserId(req, { allowGuest: true, guestFallback: "guest-user" });
    if (resolved.ok === false) return res.status(401).json({ ok: false, error: resolved.error });

    const { method = "orpo", rank = 16, maxPairs = 300 } = req.body || {};
    if (method !== "orpo" && method !== "dpo") {
      return res.status(400).json({ success: false, error: "method must be 'orpo' or 'dpo'" });
    }

    const { getHybridEvolutionEngine } = await import("../../lib/omega/hybridSelfEvolution");
    const engine = getHybridEvolutionEngine({
      preferenceMethod: method,
      loRARank: Number(rank) || 16,
      maxPairsPerTraining: Number(maxPairs) || 300,
    });
    engine.setPreferenceMethod(method);

    const result = await engine.runEvolutionCycle();
    res.json({
      success: true,
      accepted: result.accepted,
      generation: result.generation,
      method: result.method,
      target: result.target,
      reason: result.reason,
      benchmarkReport: result.benchmarkReport,
      adapter: result.adapter
        ? {
            id: result.adapter.id,
            method: result.adapter.method,
            rank: result.adapter.rank,
            trainedOnPairs: result.adapter.trainedOnPairs,
            performanceDelta: result.adapter.performanceDelta,
          }
        : null,
      status: engine.getStatus(),
      userId: resolved.userId,
    });
  } catch (err: any) {
    if (String(err?.message || "").includes("قيد التشغيل")) {
      return res.status(409).json({ success: false, error: err.message });
    }
    res.status(500).json({ success: false, error: err?.message || "Hybrid evolution failed" });
  }
});

app.post("/api/omega/hybrid-evolution/config", async (req, res) => {
  try {
    if (!isPrivilegedRequest(req)) {
      return res.status(403).json({ ok: false, error: "Administrative authentication required" });
    }
    const { method } = req.body || {};
    const { getHybridEvolutionEngine } = await import("../../lib/omega/hybridSelfEvolution");
    const engine = getHybridEvolutionEngine();
    if (method === "orpo" || method === "dpo") {
      engine.setPreferenceMethod(method);
    }
    res.json({ ok: true, method: engine.getPreferenceMethod(), status: engine.getStatus() });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err?.message });
  }
});

app.post("/api/omega/hybrid-evolution/reset", async (req, res) => {
  try {
    if (!isPrivilegedRequest(req)) {
      return res.status(403).json({ ok: false, error: "Administrative authentication required" });
    }
    const { resetHybridEvolutionEngine } = await import("../../lib/omega/hybridSelfEvolution");
    resetHybridEvolutionEngine();
    res.json({ ok: true, message: "Hybrid Evolution engine has been reset" });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err?.message });
  }
});

app.post("/api/omega/hybrid-evolution/trajectory", async (req, res) => {
  try {
    const resolved = resolveTrustedUserId(req, { allowGuest: true, guestFallback: "guest-user" });
    if (resolved.ok === false) return res.status(401).json({ ok: false, error: resolved.error });

    const { id, task, fullTrace, finalAnswer, score, latencyMs = 0, modelId = "unknown", harnessVersion } = req.body || {};
    if (!task || score === undefined) {
      return res.status(400).json({ ok: false, error: "task and score are required" });
    }

    const { getHybridEvolutionEngine } = await import("../../lib/omega/hybridSelfEvolution");
    const engine = getHybridEvolutionEngine();
    engine.recordTrajectory({
      id: id || `traj_${Date.now()}`,
      task,
      fullTrace: fullTrace || finalAnswer || "",
      finalAnswer: finalAnswer || "",
      score: Math.max(0, Math.min(1, Number(score))),
      latencyMs: Number(latencyMs) || 0,
      modelId,
      harnessVersion: harnessVersion || engine.getStatus().currentHarness,
      timestamp: Date.now(),
    });

    const status = engine.getStatus();
    res.json({
      ok: true,
      preferencePairs: status.preferencePairs,
      trajectories: status.trajectories,
      userId: resolved.userId,
    });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err?.message });
  }
});

// Only privileged verifier integrations may submit proof-bearing preference pairs.
app.post("/api/omega/hybrid-evolution/verified-pair", async (req, res) => {
  try {
    if (!isPrivilegedRequest(req)) {
      return res.status(403).json({ ok: false, error: "Administrative authentication required" });
    }
    const { getHybridEvolutionEngine } = await import("../../lib/omega/hybridSelfEvolution");
    const accepted = getHybridEvolutionEngine().recordVerifiedPreferencePair(req.body || {});
    if (!accepted) {
      return res.status(400).json({
        ok: false,
        error: "Pair rejected: require independent positive proof for chosen and negative proof for rejected",
      });
    }
    return res.json({ ok: true, accepted: true, preferencePairs: getHybridEvolutionEngine().getStatus().preferencePairs });
  } catch (err: any) {
    return res.status(500).json({ ok: false, error: err?.message || "Failed to record verified pair" });
  }
});

app.get("/api/omega/hybrid-evolution/population", async (_req, res) => {
  try {
    const { getHybridEvolutionEngine } = await import("../../lib/omega/hybridSelfEvolution");
    const engine = getHybridEvolutionEngine();
    res.json({
      ok: true,
      population: engine.getPopulation(),
      paretoArchive: engine.getParetoArchive(),
      best: engine.getBestIndividual(),
      lineage: engine.getLineage().slice(-50),
      stats: {
        populationSize: engine.getPopulation().length,
        archiveSize: engine.getParetoArchive().length,
        generation: engine.getStatus().generation,
      },
    });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err?.message });
  }
});

app.get("/api/omega/hybrid-evolution/lineage", async (req, res) => {
  try {
    const limit = Math.min(Number(req.query.limit) || 40, 100);
    const { getHybridEvolutionEngine } = await import("../../lib/omega/hybridSelfEvolution");
    const engine = getHybridEvolutionEngine();
    const lineage = engine.getLineage().slice(-limit);
    res.json({ ok: true, lineage, total: engine.getLineage().length });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err?.message });
  }
});

app.get("/api/omega/hybrid-evolution/pareto", async (_req, res) => {
  try {
    const { getHybridEvolutionEngine } = await import("../../lib/omega/hybridSelfEvolution");
    const engine = getHybridEvolutionEngine();
    const front = engine.getParetoFront();
    res.json({ ok: true, paretoFront: front, size: front.length });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err?.message });
  }
});

app.post("/api/omega/hybrid-evolution/select-parent", async (req, res) => {
  try {
    const { individualId } = req.body || {};
    if (!individualId) return res.status(400).json({ ok: false, error: "individualId is required" });
    const { getHybridEvolutionEngine } = await import("../../lib/omega/hybridSelfEvolution");
    const engine = getHybridEvolutionEngine();
    const parent = engine.selectParentById(individualId);
    if (!parent) return res.status(404).json({ ok: false, error: "Individual not found or not active" });
    res.json({
      ok: true,
      parent: {
        id: parent.id,
        harnessVersion: parent.harnessVersion,
        compositeScore: parent.compositeScore,
        wins: parent.wins,
      },
    });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err?.message });
  }
});

app.post("/api/omega/hybrid-evolution/promote", async (req, res) => {
  try {
    const { individualId } = req.body || {};
    if (!individualId) return res.status(400).json({ ok: false, error: "individualId is required" });
    const { getHybridEvolutionEngine } = await import("../../lib/omega/hybridSelfEvolution");
    const engine = getHybridEvolutionEngine();
    const success = engine.promoteIndividual(individualId);
    if (!success) return res.status(404).json({ ok: false, error: "Individual not found" });
    res.json({ ok: true, message: "Individual promoted", population: engine.getPopulation().slice(0, 8) });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err?.message });
  }
});

app.delete("/api/omega/hybrid-evolution/individual/:id", async (req, res) => {
  try {
    if (!isPrivilegedRequest(req)) {
      return res.status(403).json({ ok: false, error: "Administrative authentication required" });
    }
    const individualId = req.params.id;
    const soft = req.query.soft !== "false";
    const { getHybridEvolutionEngine } = await import("../../lib/omega/hybridSelfEvolution");
    const engine = getHybridEvolutionEngine();
    const success = engine.eliminateIndividual(individualId, soft);
    if (!success) return res.status(404).json({ ok: false, error: "Individual not found" });
    res.json({
      ok: true,
      message: soft ? "Individual archived" : "Individual eliminated",
      populationSize: engine.getPopulation().length,
    });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err?.message });
  }
});



}
