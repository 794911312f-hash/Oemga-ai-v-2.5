/**
 * src/server/routes/graphRoutes.ts
 * Multi-Hop Knowledge Graph API (extracted from server.ts)
 */
import type express from "express";
import {
  resolveTrustedUserId, isTrustedUserFailure,
  requireAuthenticatedUser,
} from "../security";
import { getInferenceEngine } from "../../lib/omega/inferenceEngine";

export function registerGraphRoutes(app: express.Application): void {
  app.get("/api/omega/graph/snapshot", (req, res) => {
    try {
      const resolved = resolveTrustedUserId(req, {
        allowGuest: true,
        guestFallback: "guest-user",
      });
      if (resolved.ok === false) {
        return res.status(401).json({ ok: false, error: resolved.error });
      }
      const engine = getInferenceEngine(resolved.userId);
      const snapshot = engine.realGraph.getSnapshot();
      res.json({
        ok: true,
        snapshot,
        userId: resolved.userId,
        isGuest: resolved.isGuest,
      });
    } catch (err: any) {
      res.status(500).json({ ok: false, error: err?.message });
    }
  });

  app.post("/api/omega/graph/infer", (req, res) => {
    try {
      const resolved = resolveTrustedUserId(req, {
        allowGuest: true,
        guestFallback: "guest-user",
      });
      if (resolved.ok === false) {
        return res.status(401).json({ ok: false, error: resolved.error });
      }
      const { inquiry, sourceId, targetId } = req.body || {};
      const engine = getInferenceEngine(resolved.userId);

      if (sourceId && targetId) {
        const path = engine.realGraph.findDeductionPath(sourceId, targetId);
        return res.json({ ok: true, path, userId: resolved.userId });
      }

      if (!inquiry) {
        return res
          .status(400)
          .json({ ok: false, error: "Inquiry or sourceId/targetId required." });
      }
      const paths = engine.realGraph.inferMultiHop(inquiry);
      res.json({ ok: true, paths, userId: resolved.userId });
    } catch (err: any) {
      res.status(500).json({ ok: false, error: err?.message });
    }
  });

  app.post("/api/omega/graph/add-node", (req, res) => {
    try {
      const userId = requireAuthenticatedUser(req, res);
      if (!userId) return;
      const { id, label, type = "concept", attributes = {} } = req.body || {};
      if (!id || !label) {
        return res
          .status(400)
          .json({ ok: false, error: "id and label are required." });
      }
      const engine = getInferenceEngine(userId);
      const node = engine.realGraph.addNode(id, label, type, attributes);
      res.json({ ok: true, node });
    } catch (err: any) {
      res.status(500).json({ ok: false, error: err?.message });
    }
  });

  app.post("/api/omega/graph/add-edge", (req, res) => {
    try {
      const userId = requireAuthenticatedUser(req, res);
      if (!userId) return;
      const {
        source,
        target,
        relation = "depends_on",
        weight = 0.9,
        evidence,
      } = req.body || {};
      if (!source || !target) {
        return res
          .status(400)
          .json({ ok: false, error: "source and target are required." });
      }
      const engine = getInferenceEngine(userId);
      const edge = engine.realGraph.addEdge(
        source,
        target,
        relation,
        Number(weight),
        evidence
      );
      res.json({ ok: true, edge });
    } catch (err: any) {
      res.status(500).json({ ok: false, error: err?.message });
    }
  });
}
