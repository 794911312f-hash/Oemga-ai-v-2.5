/**
 * src/server/routes/modelRouterRoutes.ts
 * Performance-Driven Model Router API (extracted from server.ts)
 */
import type express from "express";
import { resolveTrustedUserId, isTrustedUserFailure } from "../security";
import { getInferenceEngine } from "../../lib/omega/inferenceEngine";

export function registerModelRouterRoutes(app: express.Application): void {
  app.post("/api/omega/router/route", (req, res) => {
    try {
      const resolved = resolveTrustedUserId(req, {
        allowGuest: true,
        guestFallback: "guest-user",
      });
      if (resolved.ok === false) {
        return res.status(401).json({ ok: false, error: resolved.error });
      }
      const userId = resolved.userId;
      const { question, domain = "general", poolSize = 3 } = req.body || {};
      if (!question) {
        return res.status(400).json({ ok: false, error: "Question is required." });
      }
      const engine = getInferenceEngine(userId);
      const decision = engine.router.route(question, domain, poolSize);
      res.json({ ok: true, decision });
    } catch (err: any) {
      res.status(500).json({ ok: false, error: err?.message });
    }
  });

  app.get("/api/omega/router/ledger", (req, res) => {
    try {
      const resolved = resolveTrustedUserId(req, {
        allowGuest: true,
        guestFallback: "guest-user",
      });
      if (resolved.ok === false) {
        return res.status(401).json({ ok: false, error: resolved.error });
      }
      const { domain } = req.query;
      const engine = getInferenceEngine(resolved.userId);
      const ledger = engine.router.getLedger(domain as string | undefined);
      res.json({ ok: true, ledger });
    } catch (err: any) {
      res.status(500).json({ ok: false, error: err?.message });
    }
  });

  app.post("/api/omega/router/feedback", (req, res) => {
    try {
      const resolved = resolveTrustedUserId(req, {
        allowGuest: true,
        guestFallback: "guest-user",
      });
      if (resolved.ok === false) {
        return res.status(401).json({ ok: false, error: resolved.error });
      }
      const userId = resolved.userId;
      const {
        modelId,
        domain = "general",
        success = true,
        psi = 0.88,
        latencyMs = 420,
      } = req.body || {};
      if (!modelId) {
        return res.status(400).json({ ok: false, error: "modelId is required." });
      }
      const engine = getInferenceEngine(userId);
      const rec = engine.router.recordOutcome(
        modelId,
        domain,
        !!success,
        Number(psi),
        Number(latencyMs)
      );
      res.json({ ok: true, record: rec });
    } catch (err: any) {
      res.status(500).json({ ok: false, error: err?.message });
    }
  });
}
