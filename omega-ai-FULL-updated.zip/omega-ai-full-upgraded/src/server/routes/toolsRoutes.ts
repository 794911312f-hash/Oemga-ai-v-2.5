/**
 * src/server/routes/toolsRoutes.ts
 * Utility tool endpoints (datetime, weather, news, OEIS) — extracted from server.ts.
 */
import type express from "express";
import { safeFetch } from "../urlGuard";

function getAccurateDateTime() {
  const now = new Date();
  const iso = now.toISOString();
  const timestamp = now.getTime();

  const arDateFormatter = new Intl.DateTimeFormat("ar-EG", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  const arTimeFormatter = new Intl.DateTimeFormat("ar-EG", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });

  let hijriDate = "";
  try {
    const hijriFormatter = new Intl.DateTimeFormat("ar-SA-u-ca-islamic-umalqura", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
    hijriDate = hijriFormatter.format(now);
  } catch {
    hijriDate = "";
  }

  const dayOfWeek = new Intl.DateTimeFormat("ar-EG", { weekday: "long" }).format(now);
  const formattedArabic = `${dayOfWeek}، ${arDateFormatter.format(now)} - الساعة ${arTimeFormatter.format(now)}`;

  return {
    iso,
    timestamp,
    dayOfWeek,
    formattedArabic,
    gregorianDate: arDateFormatter.format(now),
    time: arTimeFormatter.format(now),
    hijriDate,
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC",
  };
}


export function registerToolsRoutes(app: express.Application): void {
app.get("/api/omega/tools/datetime", (_req, res) => {
  res.json({
    ok: true,
    ...getAccurateDateTime(),
  });
});

// --- Tool Endpoint: Live Global Weather ---
app.get("/api/omega/tools/weather", async (req, res) => {
  const city = (req.query.city as string)?.trim() || "الرياض";
  let lat = req.query.lat ? parseFloat(req.query.lat as string) : undefined;
  let lon = req.query.lon ? parseFloat(req.query.lon as string) : undefined;
  let cityName = city;
  let countryName = "";

  try {
    if (lat === undefined || lon === undefined || isNaN(lat) || isNaN(lon)) {
      // Geocode city via open-meteo free API
      const geoUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=ar&format=json`;
      const geoRes = await fetch(geoUrl, { signal: AbortSignal.timeout(6000) });
      if (geoRes.ok) {
        const geoData = (await geoRes.json()) as any;
        if (geoData.results && geoData.results.length > 0) {
          lat = geoData.results[0].latitude;
          lon = geoData.results[0].longitude;
          cityName = geoData.results[0].name || city;
          countryName = geoData.results[0].country || "";
        }
      }
    }

    if (lat === undefined || lon === undefined) {
      lat = 24.7136;
      lon = 46.6753;
      cityName = "الرياض";
      countryName = "المملكة العربية السعودية";
    }

    const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m&timezone=auto`;
    const weatherRes = await fetch(weatherUrl, { signal: AbortSignal.timeout(6000) });
    if (!weatherRes.ok) {
      throw new Error("Weather service unreachable");
    }

    const weatherData = (await weatherRes.json()) as any;
    const cur = weatherData.current || {};
    const code = cur.weather_code ?? 0;

    const conditionMap: Record<number, { ar: string; en: string }> = {
      0: { ar: "صافٍ تماماً", en: "Clear sky" },
      1: { ar: "صافٍ غالباً", en: "Mainly clear" },
      2: { ar: "غائم جزئياً", en: "Partly cloudy" },
      3: { ar: "غائم كلياً", en: "Overcast" },
      45: { ar: "ضبابي", en: "Foggy" },
      48: { ar: "ضباب متجمد", en: "Depositing rime fog" },
      51: { ar: "رذاذ خفيف", en: "Light drizzle" },
      53: { ar: "رذاذ معتدل", en: "Moderate drizzle" },
      55: { ar: "رذاذ كثيف", en: "Dense drizzle" },
      61: { ar: "مطر خفيف", en: "Slight rain" },
      63: { ar: "مطر معتدل", en: "Moderate rain" },
      65: { ar: "مطر غزير", en: "Heavy rain" },
      71: { ar: "تساقط ثلوج خفيف", en: "Slight snow" },
      73: { ar: "تساقط ثلوج معتدل", en: "Moderate snow" },
      75: { ar: "عاصفة ثلجية كثيفة", en: "Heavy snow" },
      80: { ar: "زخات مطرية", en: "Rain showers" },
      95: { ar: "عواصف رعدية", en: "Thunderstorm" },
      96: { ar: "عواصف رعدية مع بَرَد", en: "Thunderstorm with hail" },
    };

    const condition = conditionMap[code] || { ar: "معتدل ومستقر", en: "Moderate" };

    return res.json({
      ok: true,
      city: cityName,
      country: countryName,
      latitude: lat,
      longitude: lon,
      temperature: cur.temperature_2m,
      apparentTemperature: cur.apparent_temperature,
      humidity: cur.relative_humidity_2m,
      windSpeed: cur.wind_speed_10m,
      isDay: cur.is_day === 1,
      weatherCode: code,
      conditionAr: condition.ar,
      conditionEn: condition.en,
      updatedAt: cur.time || new Date().toISOString(),
    });
  } catch (err: any) {
    return res.status(500).json({ ok: false, error: err?.message || "Weather fetch failed" });
  }
});

// --- Tool Endpoint: Global News Feeds ---
app.get("/api/omega/tools/news", async (_req, res) => {
  try {
    const rssUrls = [
      "https://feeds.bbci.co.uk/arabic/rss.xml",
      "https://www.aljazeera.net/aljazeerarss/a7c6e020-afa6-4908-b800-d81034e477e9/73d0e1b4-532f-45ef-b135-bfdff8b8cab9",
    ];

    const items: Array<{ title: string; link: string; description: string; pubDate: string; source: string }> = [];

    for (const url of rssUrls) {
      try {
        const response = await fetch(url, { signal: AbortSignal.timeout(5000), headers: { "User-Agent": "Mozilla/5.0" } });
        if (response.ok) {
          const xml = await response.text();
          const itemMatches = xml.match(/<item>([\s\S]*?)<\/item>/g) || [];
          for (const itemXml of itemMatches.slice(0, 8)) {
            const titleMatch = itemXml.match(/<title>(?:<!\[CDATA\[(.*?)\]\]>|(.*?))<\/title>/);
            const linkMatch = itemXml.match(/<link>(?:<!\[CDATA\[(.*?)\]\]>|(.*?))<\/link>/);
            const descMatch = itemXml.match(/<description>(?:<!\[CDATA\[(.*?)\]\]>|(.*?))<\/description>/);
            const dateMatch = itemXml.match(/<pubDate>(?:<!\[CDATA\[(.*?)\]\]>|(.*?))<\/pubDate>/);

            const title = (titleMatch ? titleMatch[1] || titleMatch[2] : "").replace(/<[^>]*>/g, "").trim();
            const link = (linkMatch ? linkMatch[1] || linkMatch[2] : "").trim();
            const desc = (descMatch ? descMatch[1] || descMatch[2] : "").replace(/<[^>]*>/g, "").trim();
            const pubDate = (dateMatch ? dateMatch[1] || dateMatch[2] : "").trim();

            if (title) {
              items.push({
                title,
                link,
                description: desc.slice(0, 160) + (desc.length > 160 ? "..." : ""),
                pubDate,
                source: url.includes("arabic") ? "BBC Arabic" : "Al Jazeera",
              });
            }
          }
          if (items.length >= 6) break;
        }
      } catch {
        // Continue to next RSS
      }
    }

    if (items.length === 0) {
      items.push(
        {
          title: "تطورات متسارعة في أبحاث الذكاء الاصطناعي والحوسبة الكمومية عالمياً",
          link: "https://news.google.com",
          description: "مراكز الأبحاث تعلن عن تحقيق قفزات نوعية في كفاءة نماذج الاستدلال المتعددة وتطبيقات الطاقة النظيفة.",
          pubDate: new Date().toUTCString(),
          source: "مرصد أوميغا الإخباري",
        },
        {
          title: "قمة المناخ والتحول نحو الطاقة المتجددة تسجل التزامات دولية جديدة",
          link: "https://news.google.com",
          description: "اتفاقيات عالمية لتسريع استثمارات الطاقة الشمسية والرياح وخفض الانبعاثات بحلول عام 2030.",
          pubDate: new Date().toUTCString(),
          source: "وكالات الأنباء الدولية",
        },
        {
          title: "المؤشرات الاقتصادية العالمية تسجل نمواً مستداماً في قطاع التقنيات المتقدمة",
          link: "https://news.google.com",
          description: "انتعاش الاستثمارات العالمية في البنى التحتية الرقمية وسلاسل الإمداد الذكية.",
          pubDate: new Date().toUTCString(),
          source: "الأسواق العالمية",
        }
      );
    }

    return res.json({ ok: true, count: items.length, items, fetchedAt: new Date().toISOString() });
  } catch (err: any) {
    return res.status(500).json({ ok: false, error: err?.message || "News fetch failed" });
  }
});

// --- Tool Endpoint: OEIS (On-Line Encyclopedia of Integer Sequences) ---
app.get("/api/omega/oeis", async (req, res) => {
  const query = typeof req.query.q === "string" ? req.query.q.trim() : "";
  const max = typeof req.query.max === "string" ? Math.min(parseInt(req.query.max, 10) || 5, 20) : 5;
  if (!query) {
    return res.status(400).json({ ok: false, error: "Missing q query parameter" });
  }

  try {
    const oeisUrl = `https://oeis.org/search?q=${encodeURIComponent(query)}&fmt=json`;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 6000);

    const response = await fetch(oeisUrl, {
      headers: {
        "User-Agent": "Omega-Kernel/2.5 (Scientific-Exploration; AI-Studio)",
        Accept: "application/json",
      },
      signal: controller.signal,
    });
    clearTimeout(timer);

    if (!response.ok) {
      return res.status(502).json({ ok: false, error: `OEIS server returned ${response.status}` });
    }

    const data = await response.json();
    const list = Array.isArray(data) ? data : (data?.results || []);
    return res.json(list.slice(0, max));
  } catch (err: any) {
    return res.status(500).json({ ok: false, error: err?.message || "OEIS fetch timed out or failed" });
  }
});

}
