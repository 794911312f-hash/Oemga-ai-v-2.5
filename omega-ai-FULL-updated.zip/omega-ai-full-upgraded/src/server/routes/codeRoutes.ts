/**
 * src/server/routes/codeRoutes.ts
 * Isolated JS/TS execution API (extracted from server.ts).
 */
import type express from "express";
import { requireAuthenticatedUser } from "../security";
import { runUntrustedJs } from "../sandbox";

export function registerCodeRoutes(app: express.Application): void {
  app.post("/api/omega/code/execute", async (req, res) => {
    try {
      // P0 security: code execution must not be anonymous.
      const userId = requireAuthenticatedUser(req, res);
      if (!userId) return;

      const { code, language = "javascript" } = req.body ?? {};
      if (!code) {
        return res.status(400).json({ ok: false, error: "No code provided" });
      }
      if (typeof code !== "string" || code.length > 50_000) {
        return res.status(413).json({
          ok: false,
          error: "Code must be a string no longer than 50,000 characters",
        });
      }

      if (language === "javascript" || language === "js" || language === "ts") {
        const r = await runUntrustedJs(code);
        return res.json({
          ok: r.ok,
          output:
            (r as any).output ||
            (r as any).stdout ||
            (r.error
              ? "Execution failed before producing output."
              : "Executed successfully with no console output."),
          error: r.error,
          timedOut: (r as any).timedOut,
          userId,
          sandbox: "isolated-process",
          debugSuggested: r.error
            ? `Self-debugging fix suggested: Check syntax and handle runtime exceptions for: ${r.error}`
            : null,
        });
      }

      return res.status(501).json({
        ok: false,
        error: `No ${language} runtime is configured. Only JavaScript/TypeScript isolated-process execution is available.`,
        executionMode: "unsupported",
      });
    } catch (err: any) {
      res.status(500).json({ ok: false, error: err?.message || "Sandbox error" });
    }
  });
}
