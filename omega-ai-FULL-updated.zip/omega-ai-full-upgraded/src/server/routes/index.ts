/**
 * src/server/routes/index.ts
 * Modular route registration (Phase 12.3+ — server.ts decomposition)
 */
import type express from "express";
import { registerHybridEvolutionRoutes } from "./hybridEvolutionRoutes";
import { registerGraphRoutes } from "./graphRoutes";
import { registerModelRouterRoutes } from "./modelRouterRoutes";
import { registerCodeRoutes } from "./codeRoutes";
import { registerToolsRoutes } from "./toolsRoutes";
import { registerMediaRoutes, type MediaRouteDeps } from "./mediaRoutes";
import { registerInferenceRoutes, type InferenceRouteDeps } from "./inferenceRoutes";
import { registerBridgeRoutes, type BridgeRouteDeps } from "./bridgeRoutes";
import { registerWorkspaceRoutes } from "../workspaceRoutes";

export type ModularRouteDeps = MediaRouteDeps & InferenceRouteDeps & BridgeRouteDeps;

/**
 * Registers all extracted route modules.
 * Pass `deps` from server.ts composition root (getGemini, voiceManager, …).
 */
export function registerModularRoutes(
  app: express.Application,
  deps: ModularRouteDeps = {} as ModularRouteDeps
): void {
  registerToolsRoutes(app);
  registerCodeRoutes(app);
  registerMediaRoutes(app, deps);
  registerInferenceRoutes(app, deps);
  registerBridgeRoutes(app, deps);
  registerHybridEvolutionRoutes(app);
  registerGraphRoutes(app);
  registerModelRouterRoutes(app);
}

export {
  registerHybridEvolutionRoutes,
  registerGraphRoutes,
  registerModelRouterRoutes,
  registerCodeRoutes,
  registerToolsRoutes,
  registerMediaRoutes,
  registerInferenceRoutes,
  registerBridgeRoutes,
  registerWorkspaceRoutes,
};
