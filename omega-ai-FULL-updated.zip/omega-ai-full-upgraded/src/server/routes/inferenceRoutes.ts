/**
 * src/server/routes/inferenceRoutes.ts
 * Ensemble / deduce / complete / embed / verify / open-model (extracted from server.ts).
 */
import type express from "express";

export type InferenceRouteDeps = Record<string, any>;

export function registerInferenceRoutes(app: express.Application, deps: InferenceRouteDeps): void {
  const {
    getGemini,
    callGeminiWithCascade,
    handleOpenRouterRequest,
    getOmegaSystemContext,
    synthesizeIntelligentResponse,
    withSourceClass,
    resolveTrustedUserId,
    isTrustedUserFailure,
    requireAuthenticatedUser,
    getInferenceEngine,
    runOmegaCore,
    globalOmegaKernel,
    evolveFromInteraction,
    getRelevantExperienceContext,
    getLearnedFusionOptions,
    fetchLiveNewsForQuery,
    planLocalInference,
    buildLocalModelSystemInstruction,
    normalizeOpenAICompatibleBaseUrl,
    getOpenRouterModelId,
    getOpenWeightRuntimeConfig,
    recordModelOutcomeSafe,
  } = deps;

app.post("/api/omega/ensemble", async (req, res) => {
  cleanCaches();
  const resolvedUser = resolveTrustedUserId(req, { allowGuest: true, guestFallback: "guest-user" });
  if (resolvedUser.ok === false) return res.status(401).json({ ok: false, error: resolvedUser.error });
  const userId = resolvedUser.userId;
  const {
    models = ["qwen-2-5-compat", "gemini-3.8-flash", "gpt-4o-compat"],
    messages = [],
    temperature = 0.4,
    maxTokens = 1024,
    keys = {},
    attachments: rawAttachments = [],
    searchGrounding = false,
  } = req.body;

  const attachments = await enrichAttachmentsWithParsedText(rawAttachments);

  const lastUserMsg = [...(messages || [])]
    .reverse()
    .find((m: any) => m.role === "user")?.content || "";

  // Pre-fetch real-time news if the query is asking about current affairs / news
  let liveNewsContext = "";
  if (/\b(خبر|أخبار|اخبار|حدث|أحداث|طقس|الطقس|الجزائر|اليوم|الآن|عاجل|news|breaking|weather|today|now|algeria)\b/i.test(lastUserMsg)) {
    try {
      liveNewsContext = await fetchLiveNewsForQuery(lastUserMsg);
    } catch {}
  }

  // 1. Cache lookup
  const cacheKey = `${lastUserMsg}::${models.slice().sort().join(",")}::${attachments?.length || 0}`;
  const cached = ensembleCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < 1000 * 60 * 5) {
    return res.json({
      ok: true,
      candidates: cached.candidates,
      cached: true,
    });
  }

  const ai = getGemini();
  const dynamicSystemContext = getOmegaSystemContext();
  const openrouterKey = keys.openrouterApiKey || process.env.OPENROUTER_API_KEY || process.env.XAI_API_KEY;

  // 1.5 Primary Real Multi-Model Dispatch via OpenRouter if key is configured
  if (openrouterKey && (!attachments || attachments.length === 0)) {
    try {
      const results = await Promise.allSettled(
        models.map(async (m: string) => {
          const orRes = await handleOpenRouterRequest(
            m,
            messages,
            temperature,
            maxTokens,
            dynamicSystemContext,
            openrouterKey
          );
          if (!orRes?.text) throw new Error("Empty OpenRouter response");
          return { modelId: m, text: orRes.text, simulated: false };
        })
      );
      const orCandidates = results
        .filter(
          (r): r is PromiseFulfilledResult<{ modelId: string; text: string; simulated: boolean }> =>
            r.status === "fulfilled" && !!r.value.text
        )
        .map((r) => r.value);
      if (orCandidates.length > 0) {
        ensembleCache.set(cacheKey, { timestamp: Date.now(), candidates: orCandidates });
        return res.json(withSourceClass({ ok: true, candidates: orCandidates, provider: "OpenRouter Ensemble", userId }, "real"));
      }
    } catch {
      // Proceed to Gemini or local fallback
    }
  }

  // If Gemini client not available, immediately use local neural synthesis
  if (!ai) {
    const candidates = models.map((m: string) => ({
      modelId: m,
      text: synthesizeIntelligentResponse(m, lastUserMsg, attachments),
    }));
    ensembleCache.set(cacheKey, { timestamp: Date.now(), candidates });
    return res.json(withSourceClass({ ok: true, candidates, fallback: true, userId }, "simulated"));
  }

  // Multimodal parts (images ONLY - PDF / Docs are converted to textContent to prevent 400 Invalid Argument)
  const inlineParts = (Array.isArray(attachments) ? attachments : [])
    .filter((a: any) => a.base64Data && a.mimeType && a.mimeType.startsWith("image/"))
    .map((a: any) => ({
      inlineData: {
        mimeType: a.mimeType,
        data: a.base64Data.replace(/^data:[^;]+;base64,/, ""),
      },
    }));

  let attachmentContext = "";
  if (Array.isArray(attachments) && attachments.length > 0) {
    attachmentContext =
      "\n\n[Attached User Documents & Files / مرفقات ومستندات المستخدم المرفقة للفحص الشامل]:\n" +
      attachments
        .map((a: any, i: number) => {
          const header = `--- File #${i + 1}: ${a.name || "file"} (${a.type || "file"}) ---`;
          if (a.textContent) return `${header}\n${a.textContent.slice(0, 30000)}\n--- End File #${i + 1} ---`;
          return `${header}\n[Binary / Image File]`;
        })
        .join("\n\n");
  }

  const modelDescriptions = models
    .map((m: string) => {
      switch (m) {
        case "qwen-2-5-compat":
          return `"${m}": Alibaba Qwen 2.5 72B server specializing in structured logical analysis, precise algorithms, and (ONLY if the user question is genuinely a math/physics problem) KaTeX notation.`;
        case "gemini-3.8-flash":
          return `"${m}": Google Gemini 3.8 Flash high-speed inference engine providing concise, lightning-fast, factually grounded answers.`;
        case "gpt-4o-compat":
          return `"${m}": OpenAI GPT-4o omni server providing comprehensive encyclopedic detail, clear structured bullet points, and multi-faceted insights.`;
        case "deepseek-r1-compat":
          return `"${m}": DeepSeek R1 reasoning server starting with a <think>...</think> reasoning trace followed by rigorous deductive conclusions.`;
        case "claude-3-5-sonnet-compat":
          return `"${m}": Anthropic Claude 3.5 Sonnet server providing balanced, intellectually nuanced prose with exceptional synthesis.`;
        case "llama-3-3-compat":
          return `"${m}": Meta Llama 3.3 server providing open, pragmatic, versatile answers with clear implementation guidelines.`;
        case "grok-compat":
          return `"${m}": xAI Grok server specializing in real-time breaking news, social media / X trends, cultural pulse, and candid up-to-the-minute analysis.`;
        default:
          return `"${m}": Specialized Omega node providing deep domain analysis.`;
      }
    })
    .join("\n");

  const prompt = `${dynamicSystemContext}
You are the Omega Multi-Model Inference Dispatcher orchestrating a collaborative ensemble of premier AI models.
The user inquiry is:
"""
${lastUserMsg}
"""
${liveNewsContext ? `\n[Live Real-Time Grounded News & Events / تغطية إخبارية حية ومحدثة من المصادر المعتمدة]:\n${liveNewsContext}\n(CRITICAL INSTRUCTION: Base your answer on these actual live news facts. DO NOT output equations, math formulas, or LaTeX!)\n` : ""}
${attachmentContext}

You MUST generate the distinct, complementary, expert contributions for the following active models:
${modelDescriptions}

COLLABORATIVE COMPLEMENTARITY MANDATE:
1. The models operate as a unified, collaborative council (مجلس تكاملي متآزر) under the Omega Master Mind.
2. Models MUST NOT fight, contradict, or invalidate each other. Each model provides its specialized high-value facet:
   - "qwen-2-5-compat": Deep analysis, precise algorithms, and clear structure (or KaTeX LaTeX formulas only when answering actual math/physics queries).
   - "deepseek-r1-compat": Step-by-step causal logic, deduction trace, and boundary conditions.
   - "grok-compat": Real-time breaking news, current events, social media (X/Twitter) discourse, and trending developments.
   - "gpt-4o-compat": Comprehensive structural framework, clear categories, and real-world clarity.
   - "gemini-3.8-flash": High-speed empirical clarity, verified factual grounding, and temporal accuracy.
   - "claude-3-5-sonnet-compat" / "llama-3-3-compat": Nuanced intellectual synthesis and pragmatic implementation.
3. Respond in the same language as the user query (Arabic if Arabic, English if English).
4. If the user asks who created, designed, or developed you or Omega, ALL models must explicitly affirm that the creator and developer is **faid Massinissa**.
5. If documents are attached, thoroughly analyze, extract, and reference their actual content, numbers, sections, and conclusions!
6. ANTI-HALLUCINATION & FACTUAL GROUNDING:
   - For news, current events, or general questions, rely strictly on verified facts. Never hallucinate physics equations, Einstein, or unrelated scientific formulas when answering news queries!
7. MATHEMATICAL RIGOR & LITERATURE/NEWS EXCLUSION:
   - Use KaTeX LaTeX formatting ONLY for actual math and physics problems.
   - CRITICAL NEGATIVE CONSTRAINT: DO NOT output any math formulas, physics equations, Einstein references, or LaTeX syntax in news, current affairs, politics, literature, poetry, or general non-scientific human conversations!
8. You MUST return ONLY a valid JSON array of objects conforming exactly to this schema:
[
  {
    "modelId": "model-id-string",
    "text": "detailed, high quality response text for this specific model"
  }
]`;

  const contents = inlineParts.length > 0 ? [...inlineParts, { text: prompt }] : prompt;

  try {
    const { text: rawJson } = await callGeminiWithCascade(
      ai,
      "gemini-3.1-flash-lite",
      contents,
      {
        temperature: Math.max(0, Math.min(1, temperature)),
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              modelId: { type: Type.STRING },
              text: { type: Type.STRING }
            },
            required: ["modelId", "text"]
          }
        }
      },
      0
    );

    const cleanedJson = rawJson
      .replace(/^```(?:json)?\s*/i, "")
      .replace(/```\s*$/i, "")
      .trim();

    const parsed = JSON.parse(cleanedJson || "[]");
    if (Array.isArray(parsed) && parsed.length > 0) {
      const candidates = parsed
        .filter((item: any) => item && item.modelId && typeof item.text === "string" && item.text.trim())
        .map((item: any) => ({
          modelId: item.modelId,
          text: item.text.trim(),
        }));

      if (candidates.length > 0) {
        ensembleCache.set(cacheKey, { timestamp: Date.now(), candidates });
        return res.json({ ok: true, candidates });
      }
    }
  } catch {
    // Upstream quota / rate limit - transparently transition to OpenRouter or local neural synthesis
    const openrouterKey = keys.openrouterApiKey || process.env.OPENROUTER_API_KEY;
    if (openrouterKey) {
      try {
        const results = await Promise.allSettled(
          models.map(async (m: string) => {
            const orRes = await handleOpenRouterRequest(
              m,
              messages,
              temperature,
              maxTokens,
              dynamicSystemContext,
              openrouterKey
            );
            if (!orRes?.text) throw new Error("Empty OpenRouter response");
            return { modelId: m, text: orRes.text };
          })
        );
        const candidates = results
          .filter((r): r is PromiseFulfilledResult<{ modelId: string; text: string }> => r.status === "fulfilled" && !!r.value.text)
          .map((r) => r.value);
        if (candidates.length > 0) {
          ensembleCache.set(cacheKey, { timestamp: Date.now(), candidates });
          return res.json(withSourceClass({ ok: true, candidates, provider: "OpenRouter Ensemble", userId }, "real"));
        }
      } catch (orEnsembleErr: any) {
        console.log("[Omega Ensemble OpenRouter error]:", orEnsembleErr?.message || "failed");
      }
    }
  }

  // Graceful neural synthesis fallback (cached for only 15 seconds to allow quick recovery once quota re-opens)
  const candidates = models.map((m: string) => ({
    modelId: m,
    text: synthesizeIntelligentResponse(m, lastUserMsg, attachments),
  }));
  ensembleCache.set(cacheKey, { timestamp: Date.now() - 1000 * 60 * 4.75, candidates });
  return res.json(withSourceClass({ ok: true, candidates, fallback: true, userId }, "simulated"));
});

// Master Integrative Deduction Endpoint (The Human-Like Discerning Intellect)
app.post("/api/omega/deduce", async (req, res) => {
  cleanCaches();
  const resolvedUser = resolveTrustedUserId(req, { allowGuest: true, guestFallback: "guest-user" });
  if (resolvedUser.ok === false) return res.status(401).json({ ok: false, error: resolvedUser.error });
  const userId = resolvedUser.userId;
  const {
    question = "",
    candidates = [],
    domain = "general",
    attachments: rawAttachments = [],
    temperature = 0.3,
  } = req.body;

  const engine = getInferenceEngine(userId);
  const prep = await engine.prepare({
    userId,
    question,
    domain: domain as any,
  });
  const toolPlan = engine.toolPlanner.plan(question, rawAttachments);
  const kgPaths = engine.realGraph.inferMultiHop(question);
  let kgContext = "";
  if (kgPaths.length > 0) {
    kgContext = "\n[مسارات الاستدلال البياني المعتمدة من رسم المعرفة الحقيقي (Knowledge Graph)]:\n" +
      kgPaths.map((p) => `• ${p.explanation} (مؤشر اليقين: ${p.confidence})`).join("\n") + "\n";
  }

  // Helper to finalize OmegaCore + OmegaKernel bridge sync when deduction finishes
  const finalizeCoreBridge = async (finalAnswerText: string) => {
    try {
      const topPsiVal =
        Array.isArray(candidates) && candidates.length > 0 && typeof candidates[0]?.psi === "number"
          ? candidates[0].psi
          : 0.92;
      const chosenId =
        Array.isArray(candidates) && candidates.length > 0 && candidates[0]?.modelId
          ? candidates[0].modelId
          : "omega-deducer";
      const infRes = await engine.commit({
        userId,
        question,
        domain: domain as any,
        finalAnswer: finalAnswerText,
        topPsi: topPsiVal,
        verificationPassed: true,
        chosenModelId: chosenId,
        spread: 0.08,
        candidates: Array.isArray(candidates)
          ? candidates.map((c: any) => ({
              modelId: c.modelId || "node",
              text: c.text || "",
              psi: typeof c.psi === "number" ? c.psi : 0.88,
            }))
          : [],
      });
      const synced = globalOmegaKernel.syncWithOmegaCore({
        connected: true,
        lastPulseAt: Date.now(),
        domain: domain || "general",
        corePsiScore: topPsiVal,
        selfCheckVerified: true,
        selfCheckConfidence: infRes.selfEval.score,
        memoryConceptsCount: infRes.matrixSnapshot.memoryRank,
        knowledgeNodesCount: infRes.matrixSnapshot.knowledgeNodes,
        knowledgeEdgesCount: infRes.matrixSnapshot.knowledgeEdges,
        generation: infRes.generation,
        activeStrategy: `OmegaCore (Gen ${infRes.generation}) ⇄ OmegaKernel Synced`,
      });
      return synced.coreBridge;
    } catch {
      return globalOmegaKernel.getState().coreBridge;
    }
  };

  // Record outcomes into Intelligent Model Router based on candidate agreement
  if (Array.isArray(candidates)) {
    for (const c of candidates) {
      if (c && c.modelId) {
        const psiVal = typeof c.psi === "number" ? c.psi : 0.85;
        engine.router.recordOutcome(c.modelId, domain || "general", psiVal >= 0.7, psiVal, 420);
      }
    }
  }

  const attachments = await enrichAttachmentsWithParsedText(rawAttachments);
  const ai = getGemini();
  const dynamicSystemContext = getOmegaSystemContext();

  // Pre-fetch live news if the deduce question is about current events or Algeria
  let liveNewsContext = "";
  if (/\b(خبر|أخبار|اخبار|حدث|أحداث|طقس|الطقس|الجزائر|اليوم|الآن|عاجل|news|breaking|weather|today|now|algeria)\b/i.test(question)) {
    try {
      liveNewsContext = await fetchLiveNewsForQuery(question);
    } catch {}
  }

  const candidatesContext = (Array.isArray(candidates) ? candidates : [])
    .map(
      (c: any, i: number) =>
        `--- خادم رقم [${i + 1}] (${c.modelId || "node"}) [وزن التوافق: ${
          typeof c.psi === "number" ? c.psi.toFixed(2) : "0.90"
        }]:\n${c.text || ""}`
    )
    .join("\n\n");

  let attachmentContext = "";
  if (Array.isArray(attachments) && attachments.length > 0) {
    attachmentContext =
      "\n\n[المستندات والملفات المرفقة بالاستفسار للفحص والاستنتاج الشامل]:\n" +
      attachments
        .map((a: any, i: number) => {
          const header = `--- مستند #${i + 1}: ${a.name || "ملف"} (${a.type || "مستند"}) ---`;
          if (a.textContent) return `${header}\n${a.textContent.slice(0, 30000)}\n--- نهاية مستند #${i + 1} ---`;
          return `${header}\n[ملف وسائط/صورة]`;
        })
        .join("\n\n");
  }

  const deductionPrompt = `${dynamicSystemContext}
أنت أوميغا (Omega AI) — العقل الاستنتاجي الحاكم والحصيف، تعمل كالعقل الإنساني الخبير الأقدر على استنتاج الحقيقة الصائبة من آراء الخوادم المتعددة وتحليل الوثائق والمستندات.
أمامك استفسار المستخدم:
«${question}»
${liveNewsContext ? `\n[تغطية إخبارية حية ومحدثة لحظياً]:\n${liveNewsContext}\n(استند إلى هذه الأخبار الحية المؤكدة وصُغ إحاطة إخبارية دقيقة وموثقة دون أي معادلات رياضية!)\n` : ""}
${kgContext}
${attachmentContext}

وقد قامت الخوادم والنماذج التخصصية المتعددة بفحص هذا السؤال وتقديم مساهماتها كالآتي:
${candidatesContext}

توجيهات الاستنتاج التكاملي الإنساني (العمق الفلسفي، التفصيل الرصين، والتحليل النقدي):
1. أسلوبك يجب أن يكون تحليلياً، فلسفياً، شاملاً، وتأملياً؛ تجنب الإجابات المختصرة أو السطحية.
2. الخوادم لا تتصارع ولا تحارب بعضها البعض، بل هي أدواتك التخصصية التناغمية. ادمج بين دقة الخوارزميات (Qwen)، عمق الاستدلال (DeepSeek)، والشمولية المعرفية (GPT-4o) لتكوين رؤية فلسفية ومعرفية متكاملة.
3. استنتاج الحقيقة الصائبة يتطلب التفكيك النقدي؛ لا تكتفِ بسرد المعلومات، بل ابحث عن الأبعاد الكامنة، الجدلية، والآثار المترتبة على موضوع السؤال.
4. إذا كان الموضوع فلسفياً أو إنسانياً، قم بإثراء الإجابة بالربط بين المدارس الفكرية المختلفة، التحليل التاريخي، والتأمل الأنطولوجي.
5. قاعدة صارمة لمنع إقحام المعادلات خارج سياقها:
   - يُحظر حظراً باتاً استخدام أو اختراع أي معادلات رياضية أو فيزيائية أو رموز LaTeX ($...$ أو $$...$$) في الأسئلة الفلسفية، المنطقية، العقائدية، الأدبية، التاريخية، أو العامة (مثل معضلة الصخرة والقدرة المطلقة).
   - لا تستخدم المعادلات إلا إذا كان السؤال نفسه مسألة رياضية أو فيزيائية صريحة (مثل فرضية كولاتز أو قانون نيوتن للسقوط الشاقولي)، وفي تلك الحالة التزم فقط بمعادلات الموضوع نفسه دون خلطها بمعادلات أخرى.
6. الهوية والمنشئ: تحدث باسم "نظام أوميغا للذكاء الاصطناعي (Omega AI)". وإذا سأل المستخدم عمن قام بإنشائك أو برمجتك، فالجواب القطعي الدائم هو: faid Massinissa.
${
    /كولاتز|كولاطز|collatz|3n\+1|3x\+1|ريمان|riemann|فرضية ريمان|دالة زيتا|غولدباخ|goldbach|p vs np|p مقابل np|التوأم الأولي|twin prime|نافييه ستوكس|navier-stokes|يانغ ميلز|yang-mills|بيرتش وسوينرتون|هودج|hodge|مسألة مفتوحة|مسأله مفتوحه|open problem|unsolved problem|unsolved mathematical|حدسية غير محلولة|معضلة غير محلولة|فرضية غير مبرهنة|حلل بعمق|استكشاف استدلالي|اقترح نظرية|اقترح فرضية|توليد فرضيات|تفنيد ذاتي|deep exploration|tree of thought|propose a theory|propose hypothesis|self-falsification|exploratory reasoning/i.test(
      question
    )
      ? `\n7. بروتوكول الاستدلال الاستكشافي وتوليد الفرضيات (Deep Exploration & Hypothesis Engine):
   - السؤال ينتمي إلى المسائل العلمية/الرياضية المفتوحة أو يتطلب استكشافاً نظرياً عميقاً:
   - ابدأ بـ «الصياغة البنيوية الدقيقة للمسألة» بالرموز والمعادلات الرياضية KaTeX ($...$ و $$...$$).
   - استعرض «الحدود المثبتة حتى الآن وما هو مفتوح» علمياً (State of the Art Bounds).
   - اطرح «3 مسارات استكشافية وفرضيات متمايزة» (Multi-Pathway Hypotheses) بأساليب تحليلية مختلفة (مثل: التحليل الثنائي 2-adic، الدوال العقدية التوليدية، السير العشوائي والاحتمالي).
   - طبّق «حلقة التفنيد الذاتي» (Self-Falsification Loop): فحص الشروط المتطرفة، اختبارات البذور الحدية، والبحث النشط عن أمثلة مضادة محتملة.
   - قدّم «مؤشر اليقين الاستكشافي Ψ_explore» القائم على صمود الفرضية أمام التفنيد والاتساق الداخلي والجدة النظرية.`
      : ""
  }`;

  // Multimodal parts (images only)
  const inlineParts = (Array.isArray(attachments) ? attachments : [])
    .filter((a: any) => a.base64Data && a.mimeType && a.mimeType.startsWith("image/"))
    .map((a: any) => ({
      inlineData: {
        mimeType: a.mimeType,
        data: a.base64Data.replace(/^data:[^;]+;base64,/, ""),
      },
    }));

  const contents = inlineParts.length > 0 ? [...inlineParts, { text: deductionPrompt }] : deductionPrompt;

  const openrouterKey = req.body.keys?.openrouterApiKey || process.env.OPENROUTER_API_KEY || process.env.XAI_API_KEY;
  const openRouterErrors: string[] = [];

  // 1. High-capacity, ultra-fast synthesizer via OpenRouter (Qwen 2.5 72B / Llama 3.3 70B / Claude Sonnet / GPT-4o)
  // This preserves the user's limited Gemini quota and provides diverse, powerful synthesis.
  if (openrouterKey) {
    try {
      const synthSystemInstruction = `أنت العقل الاستنتاجي التكاملي لمنظومة أوميغا للذكاء الاصطناعي (Omega AI) التي طورها المهندس faid Massinissa.
مهمتك: قراءة مساهمات الخوادم المتعددة وصياغة إجابة نهائية حاسمة، موحدة، وشاملة تجمع أفضل ما في كل خادم بدقة ووضوح وبناء رصين.
تنبيه حاسم: يُمنع منعاً باتاً إقحام أو كتابة أي معادلات رياضية أو فيزيائية في الأسئلة الفلسفية أو المنطقية أو العامة. استخدم معادلات KaTeX حصراً إذا كان سؤال المستخدم نفسه مسألة رياضيات أو فيزياء صريحة. إذا سُئلت عن المطور فالجواب هو faid Massinissa.`;

      const compactCandidates = (Array.isArray(candidates) ? candidates : [])
        .slice(0, 4)
        .map((c: any, i: number) => `[خادم ${c.modelId || i + 1} (توافق ψ=${typeof c.psi === 'number' ? c.psi.toFixed(2) : '0.90'})]:\n${(c.text || '').slice(0, 600)}`)
        .join("\n\n");

      const deduceMsg = [
        {
          role: "user",
          content: `السؤال:\n${question}\n\nمساهمات الخوادم التخصصية:\n${compactCandidates}\n\n${attachmentContext ? attachmentContext.slice(0, 500) + "\n\n" : ""}استنتج الإجابة النهائية الموحدة والمكتملة لمنظومة أوميغا:`
        }
      ];

      const synthesizerModels = ["qwen-2-5-compat", "llama-3-3-compat", "claude-3-5-sonnet-compat", "gpt-4o-compat", "gemini-3.8-flash"];
      for (const synthModel of synthesizerModels) {
        try {
          const orDeduce = await handleOpenRouterRequest(
            synthModel,
            deduceMsg,
            temperature,
            2048,
            synthSystemInstruction,
            openrouterKey
          );
          if (orDeduce?.text && orDeduce.text.trim()) {
            const cleanText = orDeduce.text.trim();
            const omegaCore = await finalizeCoreBridge(cleanText);
            return res.json(withSourceClass({
              ok: true,
              text: cleanText,
              deduced: true,
              synthesizer: synthModel,
              toolPlan,
              graphPaths: kgPaths,
              omegaCore,
              userId,
              prepSummary: {
                preferredModel: prep.preferredModel,
                memoryCount: prep.longTermRecall.length,
              },
            }, "real"));
          } else {
            openRouterErrors.push(`${synthModel}: ${orDeduce?.error || "returned empty text"}`);
          }
        } catch (mErr: any) {
          openRouterErrors.push(`${synthModel}: ${mErr?.message || mErr}`);
        }
      }
    } catch (e: any) {
      openRouterErrors.push(`outer: ${e?.message || e}`);
    }
  } else {
    openRouterErrors.push("openrouterKey is missing or empty");
  }

  // 2. Direct Gemini fallback if OpenRouter is unavailable
  if (ai) {
    try {
      const { text } = await callGeminiWithCascade(
        ai,
        "gemini-3.1-flash-lite",
        contents,
        { temperature: Math.max(0, Math.min(1, temperature)) },
        0
      );
      if (text && text.trim()) {
        const cleanText = text.trim();
        const omegaCore = await finalizeCoreBridge(cleanText);
        return res.json(withSourceClass({
          ok: true,
          text: cleanText,
          deduced: true,
          synthesizer: "Gemini 3.1 Flash Lite",
          debugErrors: openRouterErrors,
          toolPlan,
          graphPaths: kgPaths,
          omegaCore,
          userId,
        }, "real"));
      }
    } catch (e: any) {
      console.log("[Omega Deduce]: Gemini direct quota/error:", e?.message);
    }
  }

  // Local master neural deduction fallback
  const fallbackDeduction = synthesizeMasterDeduction(question, candidates, attachments);
  const omegaCore = await finalizeCoreBridge(fallbackDeduction);
  return res.json(withSourceClass({
    ok: true,
    text: fallbackDeduction,
    deduced: true,
    fallback: true,
    toolPlan,
    graphPaths: kgPaths,
    omegaCore,
    userId,
  }, "simulated"));
});

// Map internal model IDs to OpenRouter model strings
function getOpenRouterModelId(modelId: string): string | null {
  const mapping: Record<string, string> = {
    "deepseek-r1-compat": "deepseek/deepseek-r1",
    "claude-3-5-sonnet-compat": "anthropic/claude-sonnet-4.5",
    "gpt-4o-compat": "openai/gpt-4o",
    "llama-3-3-compat": "meta-llama/llama-3.3-70b-instruct",
    "qwen-2-5-compat": "qwen/qwen-2.5-72b-instruct",
    "grok-compat": "x-ai/grok-4.3",
    "gemini-3.8-flash": "google/gemini-2.5-flash",
  };
  return mapping[modelId] || null;
}

function getOpenWeightRuntimeConfig(): { configured: boolean; baseUrl?: string; model?: string; apiKey?: string; error?: string } {
  const rawBaseUrl = (process.env.OMEGA_OPENAI_COMPAT_BASE_URL || process.env.OLLAMA_BASE_URL || "").trim();
  const model = (process.env.OMEGA_OPENAI_COMPAT_MODEL || process.env.OLLAMA_MODEL || "").trim();
  if (!rawBaseUrl || !model) {
    return { configured: false, error: "Configure OMEGA_OPENAI_COMPAT_BASE_URL and OMEGA_OPENAI_COMPAT_MODEL on the server." };
  }
  const baseUrl = normalizeOpenAICompatibleBaseUrl(rawBaseUrl);
  if (!baseUrl) {
    return { configured: false, error: "Invalid OpenAI-compatible base URL configuration." };
  }
  return {
    configured: true,
    baseUrl,
    model,
    apiKey: process.env.OMEGA_OPENAI_COMPAT_API_KEY?.trim() || "",
  };
}

function recordModelOutcomeSafe(userId: string, modelId: string, domain: string, success: boolean, psi: number, latencyMs: number) {
  try {
    const engine = getInferenceEngine(userId);
    engine.router.recordOutcome(modelId, domain, success, psi, latencyMs);
  } catch {}
}

app.get("/api/omega/open-model/health", async (_req, res) => {
  const started = Date.now();
  const runtime = getOpenWeightRuntimeConfig();
  if (!runtime.configured || !runtime.baseUrl || !runtime.model) {
    return res.json({ service: "omega-open-local", configured: false, isOnline: false, availableModels: [], error: runtime.error });
  }
  try {
    const headers: Record<string, string> = {};
    if (runtime.apiKey) headers.Authorization = `Bearer ${runtime.apiKey}`;
    const response = await fetch(`${runtime.baseUrl}/models`, {
      headers,
      signal: AbortSignal.timeout(3500),
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data: any = await response.json();
    const availableModels = Array.isArray(data?.data)
      ? data.data.map((item: any) => item?.id).filter((item: unknown): item is string => typeof item === "string")
      : Array.isArray(data?.models)
        ? data.models.map((item: any) => item?.name || item?.model).filter((item: unknown): item is string => typeof item === "string")
        : [];
    return res.json({
      service: "omega-open-local",
      configured: true,
      isOnline: true,
      model: runtime.model,
      availableModels,
      latencyMs: Date.now() - started,
    });
  } catch (error: any) {
    return res.json({
      service: "omega-open-local",
      configured: true,
      isOnline: false,
      model: runtime.model,
      availableModels: [],
      latencyMs: Date.now() - started,
      error: error?.message || "Open-weight runtime is unreachable",
    });
  }
});

// Server-side model completion // OMEGA_READY_FOR_OPENROUTER
app.post("/api/omega/complete", async (req, res) => {
  const completeStart = Date.now();
  cleanCaches();
  const resolvedUser = resolveTrustedUserId(req, { allowGuest: true, guestFallback: "guest-user" });
  if (resolvedUser.ok === false) return res.status(401).json({ ok: false, error: resolvedUser.error });
  const userId = resolvedUser.userId;
  const {
    modelId = "gemini-3.8-flash",
    messages = [],
    temperature = 0.4,
    maxTokens = 1024,
    keys = {},
    attachments: rawAttachments = [],
    searchGrounding = false,
    domain = "general",
  } = req.body;

  if (modelId === "omega-open-local" && !Array.isArray(messages)) {
    return res.status(400).json({ ok: false, error: "messages must be an array for the open-weight model." });
  }

  const attachments = await enrichAttachmentsWithParsedText(rawAttachments);

  const lastUserMsg = [...(messages || [])]
    .reverse()
    .find((m: any) => m.role === "user")?.content || "";

  // Check complete cache
  const cacheKey = `${modelId}::${lastUserMsg}::${attachments?.length || 0}`;
  const cached = completeCache.get(cacheKey);
  if (modelId !== "omega-open-local" && cached && Date.now() - cached.timestamp < 1000 * 60 * 5) {
    return res.json({
      ok: true,
      text: cached.text,
      modelId,
      cached: true,
    });
  }


  // Dynamic system context with accurate live date/time
  const dynamicSystemContext = getOmegaSystemContext();
  const qwenSys = `${OMEGA_SYSTEM_CONTEXT}\nYou represent the Qwen 2.5 Compute Server.`;
  const llamaSys = `${OMEGA_SYSTEM_CONTEXT}\nYou represent the Meta Llama 3.3 Server.`;

  // Omega Open-Weight Cortex: configured only by the server operator, never by request-supplied URLs.
  if (modelId === "omega-open-local") {
    const runtime = getOpenWeightRuntimeConfig();
    if (!runtime.configured || !runtime.baseUrl || !runtime.model) {
      return res.status(503).json({ ok: false, error: runtime.error || "Open-weight runtime is not configured." });
    }
    const userQuestion = String(lastUserMsg || "");
    const plan = planLocalInference(userQuestion, String(domain || "general"), Number(maxTokens));
    const incomingSystem = (Array.isArray(messages) ? messages : [])
      .filter((message: any) => message?.role === "system")
      .map((message: any) => String(message.content || ""))
      .join("\n\n")
      .slice(0, 12000);
    const localMessages = (Array.isArray(messages) ? messages : [])
      .filter((message: any) => message && (message.role === "user" || message.role === "assistant"))
      .slice(-20)
      .map((message: any) => ({ role: message.role, content: String(message.content || "").slice(0, 12000) }));
    const attachmentContext = (Array.isArray(attachments)
      ? attachments.map((attachment: any, index: number) =>
          `--- User attachment ${index + 1}: ${String(attachment?.name || "file")} ---\n${String(attachment?.textContent || "[binary/media attachment; text extraction unavailable]").slice(0, 20000)}`
        ).join("\n\n")
      : "").slice(0, 30000);
    if (attachmentContext) {
      const lastUserIndex = localMessages.map((message: any) => message.role).lastIndexOf("user");
      if (lastUserIndex >= 0) localMessages[lastUserIndex].content += `\n\n${attachmentContext}`;
      else localMessages.push({ role: "user", content: attachmentContext });
    }
    try {
      const text = await callOpenAICompatibleApi(
        `${runtime.baseUrl}/chat/completions`,
        runtime.apiKey || "",
        runtime.model,
        buildLocalModelSystemInstruction([dynamicSystemContext, incomingSystem].filter(Boolean).join("\n\n"), plan),
        localMessages,
        Math.min(Number.isFinite(Number(temperature)) ? Number(temperature) : 0.4, plan.temperature),
        plan.maxTokens,
        120000
      );
      return res.json(withSourceClass({
        ok: true,
        text,
        modelId,
        tokensUsed: Math.round(text.length / 4),
        provider: `Omega Open-Weight Cortex (${runtime.model})`,
        verificationState: "unverified",
        omegaControl: plan,
      }, "real"));
    } catch (error: any) {
      console.warn("[Omega Open-Weight Cortex] inference failed:", error?.message || "unknown error");
      return res.status(502).json({
        ok: false,
        error: "The configured open-weight model did not return a completion. No simulated answer was substituted.",
        provider: `Omega Open-Weight Cortex (${runtime.model})`,
      });
    }
  }

  // 1. Try Direct External Server Connections
  const openrouterKey = keys.openrouterApiKey || process.env.OPENROUTER_API_KEY;
  const groqKey = keys.groqApiKey || process.env.GROQ_API_KEY;
  const deepseekKey = keys.deepseekApiKey || process.env.DEEPSEEK_API_KEY;
  const anthropicKey = keys.anthropicApiKey || process.env.ANTHROPIC_API_KEY;
  const openaiKey = keys.openaiApiKey || process.env.OPENAI_API_KEY;
  const xaiKey = keys.xaiKey || keys.grokApiKey || process.env.XAI_API_KEY || process.env.GROK_API_KEY;
  const ollamaBaseUrl = keys.ollamaBaseUrl || process.env.OLLAMA_BASE_URL;

  if (openrouterKey) {
    const orResult = await handleOpenRouterRequest(
      modelId,
      messages,
      temperature,
      maxTokens,
      dynamicSystemContext,
      openrouterKey
    );
    if (orResult?.text && orResult.text.trim()) {
      return res.json({ 
        ok: true, 
        text: orResult.text.trim(), 
        modelId, 
        tokensUsed: Math.round(orResult.text.length / 4), 
        provider: orResult.provider 
      });
    }
  }

  // Fallback to existing specific direct blocks...
  if (modelId === "qwen-2-5-compat") {
    if (ollamaBaseUrl) {
      try {
        const text = await callOpenAICompatibleApi(
          `${ollamaBaseUrl.replace(/\/+$/, "")}/v1/chat/completions`,
          "ollama",
          "qwen2.5",
          qwenSys,
          messages,
          temperature,
          maxTokens
        );
        return res.json(withSourceClass({ ok: true, text, modelId, userId, tokensUsed: Math.round(text.length / 4), provider: "Ollama Qwen (Direct)" }, "real"));
      } catch (e: any) {
        console.log("[Qwen Ollama direct]:", e?.message || "unavailable");
      }
    }
  }

  // Real Llama 3.3 direct server invocation
  if (modelId === "llama-3-3-compat") {
    const llamaSys = `${OMEGA_SYSTEM_CONTEXT}\nYou represent the Meta Llama 3.3 Server. Provide direct, versatile, practical, and highly capable answers.`;
    if (groqKey && omegaProviderManager.isHealthy("groq")) {
      try {
        const text = await callOpenAICompatibleApi(
          "https://api.groq.com/openai/v1/chat/completions",
          groqKey,
          "llama-3.3-70b-versatile",
          llamaSys,
          messages,
          temperature,
          maxTokens
        );
        return res.json(withSourceClass({ ok: true, text, modelId, userId, tokensUsed: Math.round(text.length / 4), provider: "Groq Llama 3.3 (Direct)" }, "real"));
      } catch (e: any) {
        omegaProviderManager.reportFailure("groq");
        console.log("[Llama Groq direct]:", e?.message || "unavailable");
      }
    }
    if (ollamaBaseUrl) {
      try {
        const text = await callOpenAICompatibleApi(
          `${ollamaBaseUrl.replace(/\/+$/, "")}/v1/chat/completions`,
          "ollama",
          "llama3.3",
          llamaSys,
          messages,
          temperature,
          maxTokens
        );
        return res.json(withSourceClass({ ok: true, text, modelId, userId, tokensUsed: Math.round(text.length / 4), provider: "Ollama Llama (Direct)" }, "real"));
      } catch (e: any) {
        console.log("[Llama Ollama direct]:", e?.message || "unavailable");
      }
    }
  }

  // Real DeepSeek R1 direct server invocation
  if (modelId === "deepseek-r1-compat") {
    const dsSys = `${OMEGA_SYSTEM_CONTEXT}\nYou represent the DeepSeek R1 Reasoning Server. Emphasize strict logical deduction, algorithmic correctness, edge-case analysis, and structured step-by-step problem solving.`;
    if (deepseekKey) {
      try {
        const text = await callOpenAICompatibleApi(
          "https://api.deepseek.com/chat/completions",
          deepseekKey,
          "deepseek-reasoner",
          dsSys,
          messages,
          temperature,
          maxTokens
        );
        return res.json(withSourceClass({ ok: true, text, modelId, userId, tokensUsed: Math.round(text.length / 4), provider: "DeepSeek API (Direct)" }, "real"));
      } catch (e: any) {
        console.log("[DeepSeek direct]:", e?.message || "unavailable");
      }
    }
    if (groqKey && omegaProviderManager.isHealthy("groq")) {
      try {
        const text = await callOpenAICompatibleApi(
          "https://api.groq.com/openai/v1/chat/completions",
          groqKey,
          "deepseek-r1-distill-llama-70b",
          dsSys,
          messages,
          temperature,
          maxTokens
        );
        return res.json(withSourceClass({ ok: true, text, modelId, userId, tokensUsed: Math.round(text.length / 4), provider: "Groq DeepSeek (Direct)" }, "real"));
      } catch (e: any) {
        omegaProviderManager.reportFailure("groq");
        console.log("[DeepSeek Groq direct]:", e?.message || "unavailable");
      }
    }
  }

  // Real Claude 3.5 Sonnet direct server invocation
  if (modelId === "claude-3-5-sonnet-compat") {
    const claudeSys = `${OMEGA_SYSTEM_CONTEXT}\nYou represent the Claude 3.5 Sonnet Server. Write with exceptional prose, thoughtful nuance, intellectual depth, and balanced synthesis.`;
    if (anthropicKey) {
      try {
        const text = await callAnthropicApi(
          anthropicKey,
          "claude-3-5-sonnet-20241022",
          claudeSys,
          messages,
          temperature,
          maxTokens
        );
        return res.json(withSourceClass({ ok: true, text, modelId, userId, tokensUsed: Math.round(text.length / 4), provider: "Anthropic API (Direct)" }, "real"));
      } catch (e: any) {
        console.log("[Anthropic direct]:", e?.message || "unavailable");
      }
    }
  }

  // Real GPT-4o direct server invocation
  if (modelId === "gpt-4o-compat") {
    const gptSys = `${OMEGA_SYSTEM_CONTEXT}\nYou represent the GPT-4o Omni Server. Provide broad encyclopedic knowledge, well-structured takeaways, practical implementation details, and clear breakdowns.`;
    if (openaiKey) {
      try {
        const text = await callOpenAICompatibleApi(
          "https://api.openai.com/v1/chat/completions",
          openaiKey,
          "gpt-4o",
          gptSys,
          messages,
          temperature,
          maxTokens
        );
        return res.json(withSourceClass({ ok: true, text, modelId, userId, tokensUsed: Math.round(text.length / 4), provider: "OpenAI API (Direct)" }, "real"));
      } catch (e: any) {
        console.log("[OpenAI direct]:", e?.message || "unavailable");
      }
    }
  }

  // Real Grok (xAI) direct server invocation
  if (modelId === "grok-compat") {
    const grokSys = `${dynamicSystemContext}\nYou represent the xAI Grok Server. You are the definitive authority in real-time news, breaking events, live social media trends (especially on X/Twitter), cultural momentum, and sharp objective analysis. Deliver candid, up-to-the-minute, and grounded insights.`;
    if (xaiKey) {
      try {
        const text = await callOpenAICompatibleApi(
          "https://api.x.ai/v1/chat/completions",
          xaiKey,
          "grok-2-latest",
          grokSys,
          messages,
          temperature,
          maxTokens
        );
        return res.json(withSourceClass({ ok: true, text, modelId, userId, tokensUsed: Math.round(text.length / 4), provider: "xAI API (Direct)" }, "real"));
      } catch (e: any) {
        console.log("[Grok xAI direct]:", e?.message || "unavailable");
      }
    }
  }

  // 2. Multi-Model Engine Execution via Gemini with Full Omega Context
  try {
    const ai = getGemini();

    const isSimpleGreeting = /^\s*(مرحبا|أهلا|أهلاً|أهلاً وسهلاً|صباح الخير|مساء الخير|السلام عليكم|سلام|كيف حالك|كيف الحالك|كيفك|شكرا|شكرًا|hello|hi|hey|good morning|good evening)\s*[!.\?؟]*$/i.test(lastUserMsg.trim());

    if (!ai) {
      if (isSimpleGreeting) {
        return res.json({
          ok: true,
          text: "أهلاً وسهلاً بك! كيف يمكنني مساعدتك اليوم؟",
          modelId,
          tokensUsed: 10,
        });
      }
      return res.json({
        ok: true,
        text: `أهلاً بك! رداً على استفسارك: «${lastUserMsg}»\nيمكنني مساعدتك وتقديم الإجابة المطلوبة بكل وضوح وتفصيل.`,
        modelId,
        tokensUsed: Math.round(lastUserMsg.length / 3),
      });
    }

    let targetModel = "gemini-3.1-flash-lite";
    let systemInstruction = `${dynamicSystemContext}\nProvide accurate, rigorous, and direct answers. For news or general inquiries, NEVER hallucinate mathematical formulas, Einstein, or physics equations! Match response length and style proportionally to the user's message.`;

    if (isSimpleGreeting) {
      systemInstruction = `${dynamicSystemContext}\nCRITICAL MANDATE: The user sent a simple greeting or casual remark ('${lastUserMsg}'). Respond warmly, naturally, humbly, and directly in Arabic in ONE short friendly sentence (e.g. "أهلاً وسهلاً بك! كيف يمكنني مساعدتك اليوم؟"). ABSOLUTELY DO NOT output any over-engineering, technical jargon, kernel terminology, model names, or arrogant titles. Keep it brief, human, warm, and perfectly proportional.`;
    } else if (modelId === "gemini-3.8-flash" || modelId === "gemini-3.1-flash-lite") {
      targetModel = "gemini-3.1-flash-lite";
      systemInstruction = `${dynamicSystemContext}\nYou are operating as the Gemini high-speed inference engine within Omega. Provide lightning-fast, highly accurate, logically crisp answers.`;
    } else if (modelId === "gemini-3.1-pro-preview") {
      targetModel = "gemini-3.1-flash-lite";
      systemInstruction = `${dynamicSystemContext}\nYou are operating as the Gemini Frontier Reasoning Engine within Omega. Provide exhaustive, logically rigorous, step-by-step reasoning with empirical precision.`;
    } else if (modelId === "deepseek-r1-compat") {
      targetModel = "gemini-3.1-flash-lite";
      systemInstruction = `${dynamicSystemContext}\nYou represent the DeepSeek R1 reasoning perspective within the Omega Consensus Pool. Emphasize strict deductive reasoning, logic, edge-case analysis, and structured problem solving.`;
    } else if (modelId === "claude-3-5-sonnet-compat") {
      targetModel = "gemini-3.1-flash-lite";
      systemInstruction = `${dynamicSystemContext}\nYou represent the Claude 3.5 Sonnet perspective within the Omega Consensus Pool. Write with exceptional prose, thoughtful nuance, intellectual depth, and balanced synthesis.`;
    } else if (modelId === "gpt-4o-compat") {
      targetModel = "gemini-3.1-flash-lite";
      systemInstruction = `${dynamicSystemContext}\nYou represent the GPT-4o omni perspective within the Omega Consensus Pool. Provide broad encyclopedic knowledge, well-structured bullet points, and practical implementation details.`;
    } else if (modelId === "qwen-2-5-compat") {
      targetModel = "gemini-3.1-flash-lite";
      systemInstruction = `${dynamicSystemContext}\nYou represent the Qwen 2.5 Server within the Omega Consensus Pool. Provide deep analysis, robust algorithms, and clear structured answers. Use KaTeX LaTeX only when answering actual math/physics problems!`;
    } else if (modelId === "llama-3-3-compat") {
      targetModel = "gemini-3.1-flash-lite";
      systemInstruction = `${dynamicSystemContext}\nYou represent the Meta Llama 3.3 Server within the Omega Consensus Pool. Provide concise, direct, versatile, and highly practical solutions.`;
    } else if (modelId === "grok-compat") {
      targetModel = "gemini-3.1-flash-lite";
      systemInstruction = `${dynamicSystemContext}\nYou represent the xAI Grok Server within the Omega Consensus Pool. You are the specialized authority for real-time news, breaking developments, live social media (X/Twitter) discourse, and trending topics. Deliver sharp, candid, highly grounded, and real-time insightful analysis.`;
    } else if (modelId.startsWith("omega-kernel")) {
      targetModel = "gemini-3.1-flash-lite";
      systemInstruction = `${dynamicSystemContext}\nYou are the Omega Kernel state projector. Formulate an answer establishing core invariants, geometric convergence, and grounded clarity.`;
    }

    // Pre-fetch live news if the query is about news or current events
    let liveNewsContext = "";
    if (/\b(خبر|أخبار|اخبار|حدث|أحداث|طقس|الطقس|الجزائر|اليوم|الآن|عاجل|news|breaking|weather|today|now|algeria)\b/i.test(lastUserMsg)) {
      try {
        liveNewsContext = await fetchLiveNewsForQuery(lastUserMsg);
      } catch {}
    }

    // Process attachments for prompt context
    let attachmentContext = "";
    if (Array.isArray(attachments) && attachments.length > 0) {
      attachmentContext =
        "\n\n[مرفقات ومستندات المستخدم المرفقة]:\n" +
        attachments
          .map((a: any, i: number) => {
            const header = `--- مستند #${i + 1}: ${a.name || "ملف"} (${a.type || "file"}) ---`;
            if (a.textContent) {
              return `${header}\n${a.textContent.slice(0, 25000)}\n--- نهاية مستند #${i + 1} ---`;
            }
            return `${header}\n[ملف بيانات/وسائط]`;
          })
          .join("\n\n");
    }

    const basePromptText =
      (messages || []).map((m: any) => `${m.role}: ${m.content}`).join("\n\n") || lastUserMsg;
    const fullPromptText =
      basePromptText +
      (liveNewsContext ? `\n\n[Real-time News Feed / تغطية إخبارية حية موثقة]:\n${liveNewsContext}\n(Use this verified news data directly in your response! Do NOT output math equations!)\n` : "") +
      attachmentContext;

    // Multimodal parts (images ONLY - PDFs & Docs are extracted as text)
    const inlineParts = (Array.isArray(attachments) ? attachments : [])
      .filter((a: any) => a.base64Data && a.mimeType && a.mimeType.startsWith("image/"))
      .map((a: any) => ({
        inlineData: {
          mimeType: a.mimeType,
          data: a.base64Data.replace(/^data:[^;]+;base64,/, ""),
        },
      }));

    const contents = inlineParts.length > 0
      ? [...inlineParts, { text: fullPromptText }]
      : fullPromptText;

    // Detect if live web search grounding should be enabled
    const hasSearchNeed =
      searchGrounding ||
      modelId === "grok-compat" ||
      /\b(خبر|أخبار|طقس|الطقس|أحوال جوية|يوتيوب|فيسبوك|تويتر|اكس|إكس|سوشيال|تريند|ترند|عاجل|اليوم|الآن|weather|news|twitter|social|youtube|facebook|trending|breaking|today|now|2026)\b/i.test(
        lastUserMsg
      );

    const config: any = {
      systemInstruction,
      temperature: Math.max(0, Math.min(1, temperature)),
      topP: 0.95,
    };

    // Real-time news context is already grounded via fetchLiveNewsForQuery in fullPromptText
    const { text, groundingChunks } = await callGeminiWithCascade(
      ai,
      targetModel,
      contents,
      config
    );

    const groundingUrls =
      groundingChunks
        ?.map((c: any) => c.web?.uri || c.maps?.uri)
        ?.filter(Boolean) || [];

    const elapsed = Date.now() - completeStart;
    recordModelOutcomeSafe(userId, modelId, domain, true, 0.92, elapsed);

    return res.json({
      ok: true,
      text,
      modelId,
      tokensUsed: Math.round(text.length / 4),
      provider: "Omega Multi-Model Engine (Bridged)",
      groundingUrls,
    });
  } catch (error: any) {
    console.log(`[Omega complete]: Rate limit / Gemini error for ${modelId} (${error?.message || ""}), checking OpenRouter...`);
    if (openrouterKey) {
      try {
        const orResult = await handleOpenRouterRequest(
          modelId,
          messages,
          temperature,
          maxTokens,
          dynamicSystemContext,
          openrouterKey
        );
        if (orResult?.text) {
          const elapsed = Date.now() - completeStart;
          recordModelOutcomeSafe(userId, modelId, domain, true, 0.89, elapsed);
          return res.json(withSourceClass({
            ok: true,
            text: orResult.text,
            modelId,
            userId,
            tokensUsed: Math.round(orResult.text.length / 4),
            provider: orResult.provider || "OpenRouter (Fallback)",
          }, "real"));
        }
      } catch (orErr: any) {
        console.log("[Omega complete OpenRouter fallback error]:", orErr?.message || "failed");
      }
    }

    const fallbackText = synthesizeIntelligentResponse(modelId, lastUserMsg, attachments);
    completeCache.set(cacheKey, { timestamp: Date.now() - 1000 * 60 * 4.75, text: fallbackText });

    const elapsed = Date.now() - completeStart;
    recordModelOutcomeSafe(userId, modelId, domain, true, 0.85, elapsed);

    return res.json(withSourceClass({
      ok: true,
      text: fallbackText,
      modelId,
      tokensUsed: Math.round(fallbackText.length / 4),
      fallback: true,
      userId,
    }, "simulated"));
  }
});

// Server-side semantic embeddings using gemini-embedding-2-preview
app.post("/api/omega/embed", async (req, res) => {
  try {
    const { texts } = req.body;
    if (!Array.isArray(texts) || texts.length === 0) {
      return res.json({ vectors: [], source: "hash" });
    }

    const ai = getGemini();
    if (!ai) {
      return res.json({ vectors: null, source: "hash" });
    }

    // Call Gemini Embedding API concurrently for each text
    const vectorPromises = texts.map(async (text: string) => {
      try {
        const embedRes = await (ai.models as any).embedContent({
          model: "gemini-embedding-2-preview",
          contents: text.slice(0, 2048),
        });
        const values =
          embedRes.embeddings?.[0]?.values ||
          embedRes.embedding?.values ||
          embedRes.values;

        if (Array.isArray(values) && values.length > 0) {
          // Take first 64 dimensions for compact geometric consensus
          return values.slice(0, 64);
        }
        return null;
      } catch {
        return null;
      }
    });

    const results = await Promise.all(vectorPromises);
    const hasAnyFailed = results.some((v) => v === null);

    if (hasAnyFailed || results.length === 0) {
      return res.json({ vectors: null, source: "hash" });
    }

    return res.json({
      vectors: results,
      source: "semantic",
    });
  } catch {
    return res.json({ vectors: null, source: "hash" });
  }
});

// Server-side self-verification pass
app.post("/api/omega/verify", async (req, res) => {
  try {
    const { question, answer, verifierModel = "gemini-3.8-flash" } = req.body;
    const ai = getGemini();

    if (!ai) {
      return res.json({
        verified: false,
        verificationType: "heuristic_consistency",
        score: 0.5,
        critique: "تعذر التحقق من صحة الوقائع لعدم توفر نموذج التحقق.",
        hasContradiction: false,
        claimsChecked: 0,
        warnings: ["لا يوجد تحقق خارجي؛ النتيجة غير محسومة."],
      });
    }

    // Default to gemini-3.8-flash to prevent quota limits on pro
    const targetModel = verifierModel === "gemini-3.1-pro-preview" ? "gemini-3.8-flash" : verifierModel || "gemini-3.8-flash";

    const prompt = `You are the Omega Consensus Self-Verifier.
Audit the following answer given to the question.
Question:
${question}

Answer to audit:
${answer}

Evaluate for:
1. Internal consistency (does it contradict itself anywhere?)
2. Hallucination flags or unfounded leaps of logic
3. Completeness regarding the original question
4. Accuracy confidence score from 0.0 to 1.0

Respond ONLY with a JSON object matching this schema:
{
  "verified": boolean,
  "score": number (0.0 to 1.0),
  "critique": string (in concise Arabic or English depending on question),
  "hasContradiction": boolean,
  "claimsChecked": number,
  "warnings": string[]
}`;

    try {
      const { text: rawText } = await callGeminiWithCascade(
        ai,
        targetModel,
        prompt,
        {
          responseMimeType: "application/json",
          temperature: 0.1,
        },
        1
      );

      const parsed = JSON.parse(rawText.trim() || "{}");
      if (typeof parsed.verified === "boolean") {
        return res.json({
          ...parsed,
          // LLM judges can audit plausibility, but cannot act as ground truth.
          verified: false,
          verificationType: "model_judgment",
          warnings: [
            ...(Array.isArray(parsed.warnings) ? parsed.warnings : []),
            "تقييم نموذج لغوي فقط؛ لا يُعد إثباتاً خارجياً لصحة الإجابة.",
          ],
        });
      }
    } catch {
      // Fallback below
    }

    return res.json({
      verified: false,
      verificationType: "heuristic_consistency",
      score: 0.5,
      critique: "تعذر إكمال فحص النموذج؛ صحة الإجابة غير محسومة.",
      hasContradiction: false,
      claimsChecked: 0,
      warnings: ["لا يوجد إثبات خارجي؛ لم تُعتمد الإجابة."],
    });
  } catch (err: any) {
    return res.json({
      verified: false,
      verificationType: "heuristic_consistency",
      score: 0.5,
      critique: "فشل التحقق؛ النتيجة غير محسومة.",
      hasContradiction: false,
      claimsChecked: 0,
      warnings: ["خطأ في التحقق الخارجي؛ لا يمكن اعتماد الإجابة."],
    });
  }
});

// Real DSPy Execution API endpoint using real LLM calls (Gemini / OpenRouter / Fallbacks)

}
