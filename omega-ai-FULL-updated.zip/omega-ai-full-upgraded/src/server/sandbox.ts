/**
 * Untrusted JavaScript runner.
 *
 * node:vm is NOT a security boundary. The previous in-process sandbox leaked host
 * constructors (String/Number/Math -> Function), which allowed reading process.env.
 *
 * Defense in depth here:
 *  1. Code runs in a separate Node process started with the permission model
 *     (no fs, no child_process, no worker_threads, no addons, no WASI).
 *  2. The child gets an EMPTY environment, so there are no secrets to steal.
 *  3. Hard wall-clock kill, heap cap, and output cap.
 *  4. Inside the child, code runs in a vm context that receives NO host objects
 *     (console is created inside the context), as an extra layer.
 *
 * Known limit: Node's permission model does not restrict outbound network.
 * Run the server in a container/network policy that blocks egress to internal ranges.
 */
import { spawn } from "node:child_process";

export interface SandboxResult {
  ok: boolean;
  output: string;
  error: string | null;
  timedOut: boolean;
  truncated: boolean;
}

const MAX_OUTPUT_BYTES = 64 * 1024;

const RUNNER = String.raw`
const vm = require("node:vm");
let src = "";
process.stdin.setEncoding("utf8");
process.stdin.on("data", (c) => (src += c));
process.stdin.on("end", () => {
  const out = { ok: true, logs: [], result: null, error: null };
  try {
    const ctx = vm.createContext(Object.create(null), { codeGeneration: { strings: false, wasm: false } });
    new vm.Script(
      "var __logs=[];" +
      "var __fmt=function(a){try{return typeof a==='object'&&a!==null?JSON.stringify(a):String(a)}catch(e){return '[unserializable]'}};" +
      "var console={log:function(){__logs.push(Array.prototype.map.call(arguments,__fmt).join(' '))}," +
      "error:function(){__logs.push('[ERROR] '+Array.prototype.map.call(arguments,__fmt).join(' '))}," +
      "warn:function(){__logs.push('[WARN] '+Array.prototype.map.call(arguments,__fmt).join(' '))}};"
    ).runInContext(ctx);
    const r = new vm.Script(src, { filename: "user-code.js" }).runInContext(ctx, { timeout: 1500 });
    ctx.__r = r;
    out.result = new vm.Script(
      "(function(){var r=__r;if(r===undefined)return null;try{return typeof r==='object'&&r!==null?JSON.stringify(r):String(r)}catch(e){return '[unserializable]'}})()"
    ).runInContext(ctx, { timeout: 500 });
    out.logs = String(new vm.Script("__logs.join('\\n')").runInContext(ctx, { timeout: 500 }));
  } catch (e) {
    out.ok = false;
    out.error = String((e && e.message) || "Execution error").slice(0, 500);
  }
  process.stdout.write(JSON.stringify(out));
});
`;

export function runUntrustedJs(
  code: string,
  opts: { wallMs?: number; heapMb?: number } = {},
): Promise<SandboxResult> {
  const wallMs = opts.wallMs ?? 3000;
  const heapMb = opts.heapMb ?? 64;

  return new Promise((resolve) => {
    const child = spawn(
      process.execPath,
      ["--permission", `--max-old-space-size=${heapMb}`, "-e", RUNNER],
      { env: {}, stdio: ["pipe", "pipe", "pipe"], windowsHide: true },
    );

    let stdout = "";
    let bytes = 0;
    let truncated = false;
    let timedOut = false;
    let settled = false;

    const finish = (r: SandboxResult) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve(r);
    };

    const timer = setTimeout(() => {
      timedOut = true;
      child.kill("SIGKILL");
    }, wallMs);

    child.stdout.on("data", (d: Buffer) => {
      bytes += d.length;
      if (bytes > MAX_OUTPUT_BYTES) {
        truncated = true;
        child.kill("SIGKILL");
        return;
      }
      stdout += d.toString("utf8");
    });
    child.stderr.on("data", () => {}); // never forward child stderr (may contain paths)

    child.on("error", (e) =>
      finish({ ok: false, output: "", error: `Sandbox failed to start: ${e.message}`, timedOut: false, truncated: false }),
    );

    child.on("close", () => {
      if (timedOut) return finish({ ok: false, output: "", error: "Execution timed out", timedOut: true, truncated });
      if (truncated) return finish({ ok: false, output: "", error: "Output too large", timedOut: false, truncated: true });
      try {
        const p = JSON.parse(stdout);
        const output = [p.logs, p.result != null ? `Return Value: ${p.result}` : ""].filter(Boolean).join("\n");
        finish({ ok: !!p.ok, output, error: p.error ?? null, timedOut: false, truncated: false });
      } catch {
        finish({ ok: false, output: "", error: "Sandbox crashed (memory limit or fatal error)", timedOut: false, truncated: false });
      }
    });

    child.stdin.on("error", () => {});
    child.stdin.end(code);
  });
}
