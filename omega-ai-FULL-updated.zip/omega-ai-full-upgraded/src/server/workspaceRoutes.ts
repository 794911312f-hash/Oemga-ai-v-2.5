/**
 * src/server/workspaceRoutes.ts
 * =============================================================================
 * Cognitive Workspace HTTP API (Phase 11.7)
 * =============================================================================
 *
 * Routes:
 *   POST /api/omega/workspace          — run a full cognitive cycle
 *   POST /api/omega/workspace/plan     — plan only (no execution)
 *   GET  /api/omega/workspace/trace/:id — fetch a stored trace
 *   GET  /api/omega/workspace/health   — lightweight readiness
 *
 * Security:
 *   - Trusted userId via resolveTrustedUserId (body userId ignored)
 *   - Guests allowed on fast/balanced; deep requires auth
 *   - Question length capped; depth validated
 */

import type express from "express";
import {
  resolveTrustedUserId, isTrustedUserFailure,
  requireAuthenticatedUser,
} from "./security";
import {
  runCognitiveWorkspace,
  createCognitivePlan,
  configForDepth,
  type ReasoningDepth,
  type WorkspaceResult,
  type CognitiveTrace,
  getCoreBridgeStatus,
} from "../lib/omega/cognitiveWorkspace";

// ---------------------------------------------------------------------------
// In-memory trace store (process lifetime). Optional Firebase later.
// ---------------------------------------------------------------------------


/** Opaque guest session scope — never trust body; header or cookie only */
function resolveGuestSessionId(req: express.Request): string | null {
  const hdr =
    (typeof req.headers["x-omega-guest-session"] === "string" &&
      req.headers["x-omega-guest-session"].trim()) ||
    (typeof req.headers["x-guest-session"] === "string" &&
      req.headers["x-guest-session"].trim()) ||
    "";
  if (hdr && /^[a-zA-Z0-9._-]{8,128}$/.test(hdr)) return hdr;
  const cookie = req.headers.cookie || "";
  const m = cookie.match(/(?:^|;\s*)omega_guest_session=([a-zA-Z0-9._-]{8,128})/);
  if (m) return m[1];
  return null;
}

function scopeUserId(userId: string, isGuest: boolean, req: express.Request): string {
  if (!isGuest) return userId;
  const sid = resolveGuestSessionId(req);
  // Unscoped guest: use ephemeral per-request id so traces are not cross-readable
  if (!sid) {
    const ephemeral =
      typeof globalThis.crypto?.randomUUID === "function"
        ? globalThis.crypto.randomUUID()
        : `ephemeral_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    return `guest:${ephemeral}`;
  }
  return `guest:${sid}`;
}

const TRACE_TTL_MS = 1000 * 60 * 60; // 1 hour
const TRACE_MAX = 200;

interface StoredTrace {
  trace: CognitiveTrace;
  storedAt: number;
  userId: string;
}

const traceStore = new Map<string, StoredTrace>();

function storeTrace(userId: string, trace: CognitiveTrace): void {
  // Evict expired / overflow
  const now = Date.now();
  if (traceStore.size >= TRACE_MAX) {
    for (const [id, entry] of traceStore) {
      if (now - entry.storedAt > TRACE_TTL_MS) traceStore.delete(id);
    }
  }
  if (traceStore.size >= TRACE_MAX) {
    // drop oldest
    const oldest = [...traceStore.entries()].sort(
      (a, b) => a[1].storedAt - b[1].storedAt
    )[0];
    if (oldest) traceStore.delete(oldest[0]);
  }
  traceStore.set(trace.workspaceId, {
    trace,
    storedAt: now,
    userId,
  });
}

function getTrace(id: string, userId: string, isGuest: boolean): CognitiveTrace | null {
  const entry = traceStore.get(id);
  if (!entry) return null;
  if (nowExpired(entry)) {
    traceStore.delete(id);
    return null;
  }
  // Guests can only read their own guest traces; auth users their own
  if (entry.userId !== userId) return null;
  return entry.trace;
}

function nowExpired(entry: StoredTrace): boolean {
  return Date.now() - entry.storedAt > TRACE_TTL_MS;
}

// ---------------------------------------------------------------------------
// Validation helpers
// ---------------------------------------------------------------------------

const ALLOWED_DEPTHS: ReasoningDepth[] = ["fast", "balanced", "deep"];

function parseDepth(value: unknown): ReasoningDepth {
  if (typeof value === "string" && ALLOWED_DEPTHS.includes(value as ReasoningDepth)) {
    return value as ReasoningDepth;
  }
  return "balanced";
}

function parseQuestion(body: any): string | null {
  const q = body?.question ?? body?.q ?? body?.prompt;
  if (typeof q !== "string") return null;
  const trimmed = q.trim();
  if (!trimmed) return null;
  if (trimmed.length > 12_000) return null;
  return trimmed;
}

function withSourceClass<T extends Record<string, any>>(
  payload: T,
  sourceClass: string
): T & { sourceClass: string } {
  return { ...payload, sourceClass };
}

// ---------------------------------------------------------------------------
// Register routes
// ---------------------------------------------------------------------------

export function registerWorkspaceRoutes(app: express.Application): void {
  /**
   * GET /api/omega/workspace/health
   */
  app.get("/api/omega/workspace/health", (_req, res) => {
    res.json({
      ok: true,
      module: "cognitiveWorkspace",
      phases: ["11.0", "11.1", "11.2", "11.3", "11.4", "11.5", "11.6", "11.7", "12.0", "12.1"],
      tracesStored: traceStore.size,
      depths: ALLOWED_DEPTHS,
      coreBridge: getCoreBridgeStatus(),
    });
  });

  /**
   * POST /api/omega/workspace/plan
   * Plan only — no tools, no models, pure local planner.
   */
  app.post("/api/omega/workspace/plan", (req, res) => {
    try {
      const resolved = resolveTrustedUserId(req, {
        allowGuest: true,
        guestFallback: "guest-user",
      });
      if (resolved.ok === false) {
        return res.status(401).json({ ok: false, error: resolved.error });
      }

      const question = parseQuestion(req.body);
      if (!question) {
        return res.status(400).json({
          ok: false,
          error: "question is required (string, max 12000 chars)",
        });
      }

      const depth = parseDepth(req.body?.depth);
      const { plan, domainRoute } = createCognitivePlan({
        question,
        depth,
        config: configForDepth(depth),
        forcedDomain: req.body?.domain,
      });

      return res.json(
        withSourceClass(
          {
            ok: true,
            userId: resolved.userId,
            plan,
            domain: domainRoute.domain,
            models: domainRoute.models,
            matchedKeywords: domainRoute.matchedKeywords,
          },
          "real"
        )
      );
    } catch (err: any) {
      return res.status(500).json({ ok: false, error: err?.message ?? String(err) });
    }
  });

  /**
   * POST /api/omega/workspace
   * Full cognitive cycle.
   */
  app.post("/api/omega/workspace", async (req, res) => {
    try {
      const depth = parseDepth(req.body?.depth);

      // deep is more expensive — require authenticated user
      let userId: string;
      let isGuest = false;
      if (depth === "deep") {
        const authId = requireAuthenticatedUser(req, res);
        if (!authId) return; // response already sent
        userId = authId;
      } else {
        const resolved = resolveTrustedUserId(req, {
          allowGuest: true,
          guestFallback: "guest-user",
        });
        if (resolved.ok === false) {
          return res.status(401).json({ ok: false, error: resolved.error });
        }
        userId = resolved.userId;
        isGuest = resolved.isGuest;
      }

      const question = parseQuestion(req.body);
      if (!question) {
        return res.status(400).json({
          ok: false,
          error: "question is required (string, max 12000 chars)",
        });
      }

      // Guests: force tighter tool budget
      const maxToolCalls =
        typeof req.body?.maxToolCalls === "number"
          ? Math.max(0, Math.min(isGuest ? 3 : 12, Math.floor(req.body.maxToolCalls)))
          : undefined;

      const enableTools =
        req.body?.enableTools === false ? false : depth === "fast" ? true : true;
      const enableMultiAgent =
        depth === "deep" && req.body?.enableMultiAgent !== false;
      const enableReflection =
        depth !== "fast" && req.body?.enableReflection !== false;

      const storageUserId = scopeUserId(userId, isGuest, req);

      const result: WorkspaceResult = await runCognitiveWorkspace({
        userId: storageUserId,
        question,
        history: Array.isArray(req.body?.history) ? req.body.history : undefined,
        domain: req.body?.domain,
        models: Array.isArray(req.body?.models) ? req.body.models : undefined,
        depth,
        config: {
          depth,
          enableTools,
          enableMultiAgent,
          enableReflection,
          ...(maxToolCalls !== undefined ? { maxToolCalls } : {}),
        },
      });

      storeTrace(storageUserId, result.trace);

      return res.json(
        withSourceClass(
          {
            ok: true,
            userId,
            answer: result.answer,
            confidence: result.confidence,
            psi: result.psi,
            trace: result.trace,
            workspaceId: result.trace.workspaceId,
            depth,
          },
          result.sourceClass
        )
      );
    } catch (err: any) {
      console.error("[/api/omega/workspace Error]:", err);
      return res.status(500).json(
        withSourceClass(
          { ok: false, error: err?.message ?? String(err) },
          "failed"
        )
      );
    }
  });

  /**
   * GET /api/omega/workspace/trace/:id
   */
  app.get("/api/omega/workspace/trace/:id", (req, res) => {
    try {
      const resolved = resolveTrustedUserId(req, {
        allowGuest: true,
        guestFallback: "guest-user",
      });
      if (resolved.ok === false) {
        return res.status(401).json({ ok: false, error: resolved.error });
      }

      const id = String(req.params.id || "").trim();
      if (!id || id.length > 128) {
        return res.status(400).json({ ok: false, error: "invalid trace id" });
      }

      const storageUserId = scopeUserId(
        resolved.userId,
        resolved.isGuest,
        req
      );
      // Guests without a stable session cannot look up traces (prevents cross-guest reads)
      if (resolved.isGuest && !resolveGuestSessionId(req)) {
        return res.status(401).json({
          ok: false,
          error:
            "Guest session required to fetch traces. Send X-Omega-Guest-Session header.",
        });
      }
      const trace = getTrace(id, storageUserId, resolved.isGuest);
      if (!trace) {
        return res.status(404).json({
          ok: false,
          error: "trace not found or expired or not owned by this user",
        });
      }

      return res.json(
        withSourceClass(
          {
            ok: true,
            userId: resolved.userId,
            trace,
            workspaceId: trace.workspaceId,
          },
          "real"
        )
      );
    } catch (err: any) {
      return res.status(500).json({ ok: false, error: err?.message ?? String(err) });
    }
  });
}
