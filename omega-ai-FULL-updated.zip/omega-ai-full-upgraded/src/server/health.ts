import type express from "express";

export interface HealthDependencies {
  getGeminiConfigured?: () => boolean;
  now?: () => number;
}

export function registerHealthRoute(
  app: express.Application,
  dependencies: HealthDependencies = {},
): void {
  app.get("/api/health", (_req, res) => {
    res.json({
      status: "ok",
      timestamp: (dependencies.now ?? Date.now)(),
      hasGeminiKey: dependencies.getGeminiConfigured?.() ?? Boolean(process.env.GEMINI_API_KEY),
    });
  });
}
