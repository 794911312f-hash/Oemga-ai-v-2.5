/**
 * ReasoningTraceGraph — Phase 12.1
 * Visual vertical pipeline of the cognitive reasoning path.
 */

import React, { useMemo } from "react";
import {
  HelpCircle,
  ListTree,
  Database,
  Network,
  Wrench,
  Brain,
  Users,
  ShieldCheck,
  Sparkles,
  MessageSquare,
  Circle,
} from "lucide-react";

export interface TraceStepLike {
  name: string;
  durationMs?: number;
  status?: "ok" | "warn" | "error" | "skipped" | string;
  detail?: string;
}

export interface TraceTaskLike {
  id: string;
  title: string;
  type: string;
  status: string;
}

interface Props {
  steps?: TraceStepLike[];
  tasks?: TraceTaskLike[];
  /** Highlight current / last active node */
  activeName?: string;
  className?: string;
}

const PIPELINE: Array<{
  id: string;
  labelAr: string;
  labelEn: string;
  match: (name: string) => boolean;
  icon: React.ReactNode;
}> = [
  {
    id: "question",
    labelAr: "السؤال",
    labelEn: "Question",
    match: (n) => n === "question",
    icon: <HelpCircle className="w-4 h-4" />,
  },
  {
    id: "plan",
    labelAr: "المخطّط",
    labelEn: "Planner",
    match: (n) => /intent|plan/i.test(n),
    icon: <ListTree className="w-4 h-4" />,
  },
  {
    id: "memory",
    labelAr: "الذاكرة / الرسم",
    labelEn: "Memory + Graph",
    match: (n) => /memory|graph|retrieve/i.test(n),
    icon: <Database className="w-4 h-4" />,
  },
  {
    id: "tools",
    labelAr: "الأدوات",
    labelEn: "Tools",
    match: (n) => /tool/i.test(n),
    icon: <Wrench className="w-4 h-4" />,
  },
  {
    id: "reason",
    labelAr: "الاستدلال",
    labelEn: "Models / Core",
    match: (n) => /reason|core|model/i.test(n),
    icon: <Brain className="w-4 h-4" />,
  },
  {
    id: "synthesize",
    labelAr: "التركيب",
    labelEn: "Synthesize",
    match: (n) => /synth/i.test(n),
    icon: <Sparkles className="w-4 h-4" />,
  },
  {
    id: "agents",
    labelAr: "الوكلاء",
    labelEn: "Agents",
    match: (n) => /agent/i.test(n),
    icon: <Users className="w-4 h-4" />,
  },
  {
    id: "verify",
    labelAr: "التحقق / التأمل",
    labelEn: "Verify / Reflect",
    match: (n) => /verify|reflect/i.test(n),
    icon: <ShieldCheck className="w-4 h-4" />,
  },
  {
    id: "confidence",
    labelAr: "الثقة",
    labelEn: "Confidence",
    match: (n) => /confidence/i.test(n),
    icon: <Network className="w-4 h-4" />,
  },
  {
    id: "answer",
    labelAr: "الإجابة",
    labelEn: "Answer",
    match: (n) => /answer|final/i.test(n),
    icon: <MessageSquare className="w-4 h-4" />,
  },
];

function statusStyle(status?: string): {
  ring: string;
  bg: string;
  text: string;
} {
  switch (status) {
    case "ok":
    case "done":
      return {
        ring: "ring-emerald-500/50",
        bg: "bg-emerald-500/15",
        text: "text-emerald-300",
      };
    case "warn":
    case "skipped":
      return {
        ring: "ring-amber-500/40",
        bg: "bg-amber-500/10",
        text: "text-amber-300",
      };
    case "error":
    case "failed":
      return {
        ring: "ring-rose-500/50",
        bg: "bg-rose-500/15",
        text: "text-rose-300",
      };
    default:
      return {
        ring: "ring-slate-600/40",
        bg: "bg-slate-700/20",
        text: "text-slate-400",
      };
  }
}

export const ReasoningTraceGraph: React.FC<Props> = ({
  steps = [],
  tasks = [],
  activeName,
  className = "",
}) => {
  const nodes = useMemo(() => {
    return PIPELINE.map((p) => {
      const step = steps.find((s) => p.match(s.name));
      const relatedTasks = tasks.filter(
        (t) =>
          p.match(t.type) ||
          p.match(t.id) ||
          (p.id === "plan" && t.type) // show all under plan optionally
      );
      return {
        ...p,
        step,
        status: step?.status,
        durationMs: step?.durationMs,
        detail: step?.detail,
        taskCount: relatedTasks.length,
        present: Boolean(step) || p.id === "question" || p.id === "answer",
      };
    });
  }, [steps, tasks]);

  return (
    <div className={`w-full ${className}`} dir="rtl">
      <div className="flex flex-col items-center gap-0 py-2">
        {nodes.map((node, idx) => {
          const st = statusStyle(node.status);
          const isActive =
            activeName && node.match(activeName) ? true : false;
          const dimmed = !node.present && node.id !== "question";

          return (
            <React.Fragment key={node.id}>
              {/* Node */}
              <div
                className={`relative w-full max-w-md rounded-xl border border-[#1a3a3e] px-4 py-3 transition-all ${
                  st.bg
                } ${isActive ? `ring-2 ${st.ring}` : ""} ${
                  dimmed ? "opacity-40" : ""
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`flex items-center justify-center w-9 h-9 rounded-lg border border-[#1a3a3e] bg-[#061416] ${st.text}`}
                  >
                    {node.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-sm font-medium text-slate-100">
                        {node.labelAr}
                      </span>
                      <span className="text-[10px] font-mono text-slate-500">
                        {node.labelEn}
                      </span>
                      {node.status && (
                        <span
                          className={`text-[10px] font-mono px-1.5 py-0.5 rounded border border-[#1a3a3e] ${st.text}`}
                        >
                          {node.status}
                        </span>
                      )}
                    </div>
                    {(node.detail || node.durationMs != null) && (
                      <p className="text-[11px] text-slate-400 mt-0.5 truncate">
                        {node.durationMs != null && (
                          <span className="font-mono text-slate-500">
                            {node.durationMs}ms
                          </span>
                        )}
                        {node.detail && (
                          <span className="ms-2">{node.detail}</span>
                        )}
                      </p>
                    )}
                  </div>
                  {!node.present && node.id !== "question" && (
                    <Circle className="w-3 h-3 text-slate-600" />
                  )}
                </div>
              </div>

              {/* Connector */}
              {idx < nodes.length - 1 && (
                <div className="flex flex-col items-center h-6 w-full max-w-md">
                  <div
                    className={`w-0.5 flex-1 ${
                      node.status === "ok" || node.status === "done"
                        ? "bg-emerald-500/40"
                        : node.status === "error"
                          ? "bg-rose-500/40"
                          : "bg-[#1a3a3e]"
                    }`}
                  />
                  <div
                    className={`w-0 h-0 border-l-[5px] border-r-[5px] border-t-[6px] border-l-transparent border-r-transparent ${
                      node.status === "ok" || node.status === "done"
                        ? "border-t-emerald-500/50"
                        : "border-t-[#2a4a4e]"
                    }`}
                  />
                </div>
              )}
            </React.Fragment>
          );
        })}
      </div>

      <p className="text-center text-[10px] text-slate-500 font-mono mt-2">
        Reasoning Trace · Phase 12.1
      </p>
    </div>
  );
};

export default ReasoningTraceGraph;
