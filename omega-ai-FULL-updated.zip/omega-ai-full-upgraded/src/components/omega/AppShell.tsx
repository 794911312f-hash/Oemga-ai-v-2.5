import React, { useState, useEffect } from "react";
import {
  MessageSquare,
  Brain,
  Database,
  GitBranch,
  Sliders,
  Zap,
  UserCheck,
  LogIn,
  ExternalLink,
  Calculator,
  Cpu,
  Sparkles,
  Network,
  PanelRightClose,
  PanelRightOpen,
  Menu,
  X,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { OmegaMark } from "./OmegaMark";
import { ModelBar } from "./ModelBar";
import { ChatView } from "./ChatView";
import { KernelLab } from "./KernelLab";
import { MemoryView } from "./MemoryView";
import { LineageView } from "./LineageView";
import { OptimizerLab } from "./OptimizerLab";
import { SymbolicCASWorkbench } from "./SymbolicCASWorkbench";
import { AdvancedOrchestratorLab } from "./AdvancedOrchestratorLab";
import { OmegaEvolutionLab } from "./OmegaEvolutionLab";
import { CognitiveWorkspaceLab } from "./CognitiveWorkspaceLab";
import { OmegaAutonomousAgentTab } from "./OmegaAutonomousAgentTab";
import { AuthModal, type OmegaUser } from "./AuthModal";
import { DEFAULT_OMEGA_CONFIG, type OmegaConfig } from "../../lib/omega/optimizer";
import type { FusionResult } from "../../lib/omega/fusion";

export type NavTab =
  | "chat"
  | "kernel"
  | "autonomous"
  | "memory"
  | "lineage"
  | "optimizer"
  | "cas"
  | "orchestrator"
  | "evolution"
  | "workspace";

/** جاهز | تجريبي | مخطط (staged/blueprint) */
type PathStatus = "ready" | "experimental" | "blueprint";

type NavItem = {
  id: NavTab;
  label: string;
  subLabel: string;
  icon: LucideIcon;
  status: PathStatus;
};

type NavGroup = {
  id: string;
  label: string;
  items: NavItem[];
};

const PATH_STATUS_META: Record<
  PathStatus,
  { label: string; className: string; title: string }
> = {
  ready: {
    label: "جاهز",
    className: "bg-emerald-950/80 border-emerald-500/45 text-emerald-300",
    title: "مسار جاهز للاستخدام الفعلي",
  },
  experimental: {
    label: "تجريبي",
    className: "bg-amber-950/70 border-amber-500/40 text-amber-300",
    title: "مسار تجريبي — يعمل جزئياً أو يعتمد على محاكاة",
  },
  blueprint: {
    label: "مخطط",
    className: "bg-[#3a2c22]/90 border-[#d6a06c]/45 text-[#edc49b]",
    title: "مخطط / staged — غير مفعّل في مسار الاستدلال",
  },
};

const NAV_GROUPS: NavGroup[] = [
  {
    id: "conversation",
    label: "محادثة",
    items: [
      {
        id: "chat",
        label: "محادثة",
        subLabel: "Fusion Chat",
        icon: MessageSquare,
        // مسار المنتج الأساسي: اندماج حقيقي عند توفر مزودات + fallback محاكى موثّق
        status: "ready",
      },
    ],
  },
  {
    id: "analysis",
    label: "تحليل",
    items: [
      {
        id: "kernel",
        label: "نواة",
        subLabel: "Kernel Lab",
        icon: Brain,
        // تحليل طيفي ورياضيات محلية مختبرة
        status: "ready",
      },
      {
        id: "memory",
        label: "ذاكرة",
        subLabel: "Memory Bank",
        icon: Database,
        // ذاكرة محلية تعمل في الواجهة
        status: "ready",
      },
      {
        id: "lineage",
        label: "نسب",
        subLabel: "Lineage Graph",
        icon: GitBranch,
        // واجهة رسم نسب؛ المصدر والتجميع ما زالا تجريبيين
        status: "experimental",
      },
      {
        id: "optimizer",
        label: "معايرة",
        subLabel: "Optimizer",
        icon: Sliders,
        // ضبط إعدادات محلي يعمل
        status: "ready",
      },
    ],
  },
  {
    id: "tools",
    label: "أدوات",
    items: [
      {
        id: "cas",
        label: "CAS",
        subLabel: "Symbolic CAS",
        icon: Calculator,
        // يعتمد على خلفية SymPy/مسارات خادم
        status: "experimental",
      },
      {
        id: "orchestrator",
        label: "أوركسترا",
        subLabel: "Orchestrator Lab",
        icon: Cpu,
        // محاكاة ووكلاء متقدمون
        status: "experimental",
      },
      {
        id: "workspace",
        label: "مساحة عمل",
        subLabel: "Cognitive Workspace",
        icon: Network,
        // مساحة معرفية متعددة المراحل — scaffolding
        status: "experimental",
      },
    ],
  },
  {
    id: "experiments",
    label: "تجارب",
    items: [
      {
        id: "autonomous",
        label: "وكيل مستقل",
        subLabel: "Autonomous Agent",
        icon: Zap,
        // تخطيط وتصحيح ذاتي — تجريبي
        status: "experimental",
      },
      {
        id: "evolution",
        label: "تطور",
        subLabel: "Self-Evolving Core",
        icon: Sparkles,
        // LoRA staged بلا loader؛ معايير محاكاة
        status: "blueprint",
      },
    ],
  },
];

export const AppShell: React.FC = () => {
  const [activeTab, setActiveTab] = useState<NavTab>("chat");
  const [config, setConfig] = useState<OmegaConfig>(DEFAULT_OMEGA_CONFIG);
  const [inspectedResult, setInspectedResult] = useState<FusionResult | null>(null);
  const [currentUser, setCurrentUser] = useState<OmegaUser | null>(null);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  useEffect(() => {
    try {
      const saved = localStorage.getItem("omega_auth_user");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.email) {
          setCurrentUser(parsed);
        }
      }
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    try {
      const saved = localStorage.getItem("omega_sidebar_collapsed");
      if (saved === "1") setSidebarCollapsed(true);
    } catch {
      // ignore
    }
  }, []);

  const toggleSidebarCollapsed = () => {
    setSidebarCollapsed((prev) => {
      const next = !prev;
      try {
        localStorage.setItem("omega_sidebar_collapsed", next ? "1" : "0");
      } catch {
        // ignore
      }
      return next;
    });
  };

  const handleLogin = (user: OmegaUser) => {
    setCurrentUser(user);
  };

  const handleLogout = () => {
    try {
      localStorage.removeItem("omega_auth_user");
    } catch {
      // ignore
    }
    setCurrentUser(null);
  };

  const handleOpenKernelWithResult = (result: FusionResult) => {
    setInspectedResult(result);
    setActiveTab("kernel");
  };

  const selectTab = (id: NavTab) => {
    setActiveTab(id);
    setMobileNavOpen(false);
  };

  const activeItem =
    NAV_GROUPS.flatMap((g) => g.items).find((i) => i.id === activeTab) ?? null;

  const renderNavGroups = (opts: { collapsed: boolean; onSelect: (id: NavTab) => void }) => (
    <nav className="flex flex-col gap-3 px-2 py-3" aria-label="تنقل أوميغا">
      {NAV_GROUPS.map((group) => (
        <div key={group.id}>
          {!opts.collapsed && (
            <div className="px-2 mb-1 text-[10px] font-mono uppercase tracking-wide text-[#527478]">
              {group.label}
            </div>
          )}
          <ul className="flex flex-col gap-0.5">
            {group.items.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              const statusMeta = PATH_STATUS_META[item.status];
              return (
                <li key={item.id}>
                  <button
                    type="button"
                    onClick={() => opts.onSelect(item.id)}
                    title={`${item.label} — ${item.subLabel} · ${statusMeta.title}`}
                    className={`w-full flex items-center gap-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                      opts.collapsed ? "justify-center px-2 py-2.5" : "px-2.5 py-2"
                    } ${
                      isActive
                        ? "bg-[#12383b] border border-[#59e5de]/40 text-[#b8f0ed] shadow-sm"
                        : "text-slate-400 hover:text-slate-200 hover:bg-[#0d282c] border border-transparent"
                    }`}
                  >
                    <Icon
                      className={`w-4 h-4 shrink-0 ${
                        isActive ? "text-[#59e5de]" : "text-slate-500"
                      }`}
                    />
                    {!opts.collapsed && (
                      <>
                        <span className="flex-1 text-right truncate">{item.label}</span>
                        <span
                          className={`text-[9px] font-mono font-bold leading-none px-1 py-0.5 rounded border shrink-0 ${statusMeta.className}`}
                          title={statusMeta.title}
                        >
                          {statusMeta.label}
                        </span>
                      </>
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      ))}
    </nav>
  );

  return (
    <div
      className="omega-shell-surface min-h-[100dvh] flex flex-col text-slate-100 selection:bg-cyan-300 selection:text-[#07171b]"
      dir="rtl"
    >
      {/* ── Top bar (simplified on mobile; logo/status on all sizes) ── */}
      <header className="sticky top-0 z-40 bg-[#07171b]/95 backdrop-blur-md border-b border-[#28464a]/70">
        <div className="flex items-center justify-between h-14 px-3 sm:px-4 gap-2">
          <div className="flex items-center gap-2 min-w-0">
            {/* Mobile hamburger */}
            <button
              type="button"
              className="lg:hidden flex items-center justify-center w-9 h-9 rounded-xl border border-[#28464a] bg-[#0b2529] text-slate-200 hover:border-[#59e5de]/40 cursor-pointer"
              onClick={() => setMobileNavOpen(true)}
              aria-label="فتح القائمة"
              data-testid="button-mobile-nav"
            >
              <Menu className="w-4 h-4" />
            </button>

            <OmegaMark size="md" />
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 flex-wrap">
                <h1 className="text-sm sm:text-base font-extrabold tracking-tight text-[#e8f3f2] truncate">
                  نظام أوميغا
                </h1>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#3a2c22] border border-[#d6a06c]/45 text-[#edc49b] font-bold shrink-0">
                  CONTROL ROOM
                </span>
              </div>
              {activeItem && (
                <p className="text-[11px] text-slate-400 truncate lg:hidden">
                  {activeItem.label}
                  <span className="text-[#527478]"> · </span>
                  {PATH_STATUS_META[activeItem.status].label}
                </p>
              )}
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 text-xs shrink-0">
            <div
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#0b2529] border border-[#3e686a]/80 text-slate-300 font-mono text-[11px]"
              data-testid="status-local-kernel"
            >
              <span className="w-2 h-2 rounded-full bg-[#59e5de] omega-signal" />
              <span className="hidden md:inline">النواة المحلية جاهزة</span>
              <span className="text-[#527478] hidden md:inline">|</span>
              <span className="text-[#8bd8d4]">OVO</span>
            </div>

            <a
              href={typeof window !== "undefined" ? window.location.href : "#"}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => {
                e.preventDefault();
                try {
                  window.open(window.location.href, "_blank", "noopener,noreferrer");
                } catch {
                  // fallback
                }
              }}
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-[#59e5de]/35 bg-[#0b2529]/90 hover:bg-[#12383b] text-[#b8f0ed] hover:border-[#59e5de] text-xs font-semibold transition-all cursor-pointer shadow-sm"
              data-testid="link-open-window"
              title="فتح في نافذة جديدة"
            >
              <ExternalLink className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span className="hidden md:inline">صفحة جديدة</span>
            </a>

            <button
              type="button"
              onClick={() => setIsAuthOpen(true)}
              data-testid="button-auth"
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                currentUser
                  ? "bg-[#3a2c22]/80 border-[#d6a06c]/50 text-[#edc49b] hover:bg-[#493426]"
                  : "bg-[#0b2529] hover:bg-[#12383b] border-[#28464a] text-slate-200 hover:border-[#d6a06c]/50"
              }`}
              title={currentUser ? `مسجل كـ: ${currentUser.email}` : "الدخول بالبريد الإلكتروني"}
            >
              {currentUser ? (
                <>
                  <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="max-w-[100px] truncate hidden sm:inline">
                    {currentUser.name || currentUser.email}
                  </span>
                </>
              ) : (
                <>
                  <LogIn className="w-3.5 h-3.5 text-purple-400" />
                  <span className="hidden sm:inline">الدخول</span>
                </>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* ── Body: sidebar (desktop) + content ── */}
      <div className="flex flex-1 min-h-0">
        {/* Desktop sidebar */}
        <aside
          className={`hidden lg:flex flex-col shrink-0 border-l border-[#28464a]/70 bg-[#07171b]/95 sticky top-14 h-[calc(100dvh-3.5rem)] transition-[width] duration-200 ease-out ${
            sidebarCollapsed ? "w-[4.25rem]" : "w-56"
          }`}
          data-testid="desktop-sidebar"
        >
          <div className="flex items-center justify-between gap-1 px-2 py-2 border-b border-[#10282b]">
            {!sidebarCollapsed && (
              <span className="text-[10px] font-mono text-[#527478] px-1">التنقل</span>
            )}
            <button
              type="button"
              onClick={toggleSidebarCollapsed}
              className="flex items-center justify-center w-8 h-8 rounded-lg border border-[#28464a] text-slate-400 hover:text-[#b8f0ed] hover:border-[#59e5de]/40 cursor-pointer ms-auto"
              title={sidebarCollapsed ? "توسيع القائمة" : "طي القائمة"}
              aria-label={sidebarCollapsed ? "توسيع القائمة" : "طي القائمة"}
              data-testid="button-sidebar-collapse"
            >
              {sidebarCollapsed ? (
                <PanelRightOpen className="w-4 h-4" />
              ) : (
                <PanelRightClose className="w-4 h-4" />
              )}
            </button>
          </div>

          <div className="flex-1 overflow-y-auto no-scrollbar">
            {renderNavGroups({
              collapsed: sidebarCollapsed,
              onSelect: selectTab,
            })}
          </div>

          {!sidebarCollapsed && (
            <div
              className="border-t border-[#10282b] px-3 py-2.5 space-y-1.5"
              data-testid="path-status-legend"
            >
              <div className="text-[10px] text-[#527478] font-mono mb-1">حالة المسار</div>
              <div className="flex flex-wrap gap-1">
                {(Object.keys(PATH_STATUS_META) as PathStatus[]).map((key) => {
                  const m = PATH_STATUS_META[key];
                  return (
                    <span
                      key={key}
                      className={`text-[9px] font-mono font-bold leading-none px-1.5 py-0.5 rounded border ${m.className}`}
                      title={m.title}
                    >
                      {m.label}
                    </span>
                  );
                })}
              </div>
            </div>
          )}
        </aside>

        {/* Main column */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Model Bar */}
          <div className="bg-[#081d21]/70 border-b border-[#10282b] px-3 sm:px-4">
            <ModelBar />
          </div>

          {/* Provenance strip */}
          <div className="border-b border-[#10282b] bg-[#07171b]/70 px-3 py-1.5 sm:px-4">
            <div
              className="flex flex-wrap items-center justify-between gap-2 text-[10px] font-mono text-[#8bb5b6]"
              data-testid="status-provenance-legend"
            >
              <span className="omega-kicker" dir="ltr">
                OMEGA / EVIDENCE LEDGER
              </span>
              <span className="flex flex-wrap items-center gap-x-3 gap-y-1" dir="ltr">
                <span className="text-[#8bd8d4]">LOCAL CONTROL + ANALYSIS</span>
                <span className="text-[#d6a06c]">TELEMETRY MAY BE SIMULATED</span>
                <span className="text-[#c3a7a3] hidden sm:inline">
                  PROVIDER OUTPUT ONLY WHEN SUPPLIED
                </span>
              </span>
            </div>
          </div>

          <main className="flex-1 flex flex-col min-h-0">
            {activeTab === "chat" && (
              <ChatView
                config={config}
                onOpenKernelWithResult={handleOpenKernelWithResult}
                onOpenOptimizer={() => setActiveTab("optimizer")}
              />
            )}
            {activeTab === "kernel" && (
              <KernelLab initialResult={inspectedResult} />
            )}
            {activeTab === "autonomous" && <OmegaAutonomousAgentTab />}
            {activeTab === "memory" && <MemoryView />}
            {activeTab === "lineage" && <LineageView />}
            {activeTab === "optimizer" && (
              <OptimizerLab config={config} onChangeConfig={setConfig} />
            )}
            {activeTab === "cas" && (
              <div className="max-w-7xl mx-auto w-full p-4 sm:p-6 space-y-6">
                <SymbolicCASWorkbench />
              </div>
            )}
            {activeTab === "orchestrator" && <AdvancedOrchestratorLab />}
            {activeTab === "workspace" && <CognitiveWorkspaceLab />}
            {activeTab === "evolution" && <OmegaEvolutionLab />}
          </main>
        </div>
      </div>

      {/* ── Mobile drawer overlay ── */}
      {mobileNavOpen && (
        <div className="lg:hidden fixed inset-0 z-50" data-testid="mobile-nav-drawer">
          <button
            type="button"
            className="absolute inset-0 bg-black/60 backdrop-blur-sm cursor-pointer"
            aria-label="إغلاق القائمة"
            onClick={() => setMobileNavOpen(false)}
          />
          <div className="absolute top-0 bottom-0 end-0 w-[min(18rem,88vw)] bg-[#07171b] border-s border-[#28464a] shadow-2xl flex flex-col">
            <div className="flex items-center justify-between h-14 px-3 border-b border-[#10282b]">
              <span className="text-sm font-bold text-[#e8f3f2]">القائمة</span>
              <button
                type="button"
                onClick={() => setMobileNavOpen(false)}
                className="flex items-center justify-center w-9 h-9 rounded-xl border border-[#28464a] text-slate-300 hover:border-[#59e5de]/40 cursor-pointer"
                aria-label="إغلاق"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">
              {renderNavGroups({ collapsed: false, onSelect: selectTab })}
            </div>
            <div className="border-t border-[#10282b] px-3 py-3 space-y-1.5">
              <div className="text-[10px] text-[#527478] font-mono mb-1">حالة المسار</div>
              <div className="flex flex-wrap gap-1">
                {(Object.keys(PATH_STATUS_META) as PathStatus[]).map((key) => {
                  const m = PATH_STATUS_META[key];
                  return (
                    <span
                      key={key}
                      className={`text-[9px] font-mono font-bold leading-none px-1.5 py-0.5 rounded border ${m.className}`}
                      title={m.title}
                    >
                      {m.label}
                    </span>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        currentUser={currentUser}
        onLogin={handleLogin}
        onLogout={handleLogout}
      />
    </div>
  );
};
