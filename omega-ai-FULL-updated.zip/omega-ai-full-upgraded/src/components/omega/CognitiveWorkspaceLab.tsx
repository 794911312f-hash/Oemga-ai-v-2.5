/**
 * CognitiveWorkspaceLab — Phase 11.8 UI
 * Trace viewer + runner for Omega Cognitive Workspace
 */

import React, { useMemo, useState } from "react";
import {
  BrainCircuit,
  Play,
  ListTree,
  ShieldCheck,
  Wrench,
  Users,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Network,
  RefreshCw,
  ChevronDown,
  ChevronRight,
} from "lucide-react";
import { ReasoningTraceGraph } from "./ReasoningTraceGraph";

type Depth = "fast" | "balanced" | "deep";

interface TraceStep {
  name: string;
  startedAt: number;
  durationMs: number;
  status: "ok" | "warn" | "error" | "skipped";
  detail?: string;
}

interface WorkspaceApiResponse {
  ok: boolean;
  answer?: string;
  confidence?: {
    psi: number;
    confidence: number;
    evidence: string[];
    risk: string[];
    unknowns: string[];
    sourceClass: string;
    verified: boolean | null;
  };
  psi?: number;
  sourceClass?: string;
  workspaceId?: string;
  depth?: Depth;
  trace?: {
    workspaceId: string;
    startedAt: number;
    finishedAt?: number;
    depth: Depth;
    plan: {
      goal: {
        originalQuestion: string;
        refinedGoal: string;
        domain: string;
        successCriteria: string[];
        constraints: string[];
        complexity: string;
      };
      tasks: Array<{
        id: string;
        title: string;
        type: string;
        status: string;
        durationMs?: number;
        error?: string;
      }>;
      estimatedComplexity: string;
    };
    memory?: {
      episodic: unknown[];
      semantic: unknown[];
      procedural: string[];
      graphNodes: Array<{ id: string; label: string; type?: string }>;
      graphEdges: unknown[];
      workingKeys: string[];
    };
    toolCalls?: Array<{
      toolId: string;
      success: boolean;
      latencyMs: number;
      sourceClass: string;
      error?: string;
      output?: unknown;
    }>;
    agentOpinions?: Array<{
      agentId: string;
      role: string;
      answer: string;
      confidence: number;
      critiques: string[];
    }>;
    reflectionNotes?: Array<{
      type: string;
      message: string;
      severity: string;
    }>;
    confidence?: WorkspaceApiResponse["confidence"];
    finalAnswer?: string;
    steps: TraceStep[];
    error?: string;
  };
  error?: string;
}

const PRESETS: Array<{ label: string; q: string; depth: Depth }> = [
  {
    label: "فيزياء · متوازن",
    q: "اشرح قانون نيوتن الثاني مع مثال عددي بسيط",
    depth: "balanced",
  },
  {
    label: "رياضيات · CAS",
    q: "احسب مشتقة x^3 - 2x + 1",
    depth: "balanced",
  },
  {
    label: "غاز مثالي · سريع",
    q: "ما هو قانون الغاز المثالي؟",
    depth: "fast",
  },
  {
    label: "نقد علمي · عميق",
    q: "ناقش فرضية ريمان وقدم نقداً علمياً موجزاً",
    depth: "deep",
  },
];

function statusColor(status: string): string {
  switch (status) {
    case "ok":
    case "done":
    case "passed":
      return "text-emerald-400";
    case "warn":
    case "skipped":
      return "text-amber-400";
    case "error":
    case "failed":
      return "text-rose-400";
    case "running":
    case "in_progress":
      return "text-cyan-400";
    default:
      return "text-slate-400";
  }
}

function sourceBadge(src?: string): string {
  switch (src) {
    case "real":
      return "bg-emerald-500/15 text-emerald-300 border-emerald-500/30";
    case "mixed":
      return "bg-amber-500/15 text-amber-300 border-amber-500/30";
    case "simulated":
      return "bg-violet-500/15 text-violet-300 border-violet-500/30";
    case "failed":
      return "bg-rose-500/15 text-rose-300 border-rose-500/30";
    default:
      return "bg-slate-500/15 text-slate-300 border-slate-500/30";
  }
}

const Section: React.FC<{
  title: string;
  icon: React.ReactNode;
  defaultOpen?: boolean;
  children: React.ReactNode;
  badge?: string;
}> = ({ title, icon, defaultOpen = true, children, badge }) => {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="rounded-xl border border-[#1a3a3e] bg-[#0a1c20]/80 overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="w-full flex items-center gap-2 px-4 py-3 text-right hover:bg-[#0f282c]/60 transition-colors"
      >
        {open ? (
          <ChevronDown className="w-4 h-4 text-[#59e5de]" />
        ) : (
          <ChevronRight className="w-4 h-4 text-slate-500" />
        )}
        <span className="text-[#59e5de]">{icon}</span>
        <span className="font-medium text-slate-100 flex-1">{title}</span>
        {badge && (
          <span className="text-[10px] font-mono px-2 py-0.5 rounded border border-[#1a3a3e] text-[#8bb5b6]">
            {badge}
          </span>
        )}
      </button>
      {open && <div className="px-4 pb-4 pt-1 border-t border-[#122a2e]">{children}</div>}
    </div>
  );
};

export const CognitiveWorkspaceLab: React.FC = () => {
  const [question, setQuestion] = useState(PRESETS[0].q);
  const [depth, setDepth] = useState<Depth>("balanced");
  const [loading, setLoading] = useState(false);
  const [planOnly, setPlanOnly] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<WorkspaceApiResponse | null>(null);
  const [planPreview, setPlanPreview] = useState<any | null>(null);

  const totalDuration = useMemo(() => {
    const steps = result?.trace?.steps;
    if (!steps?.length) return null;
    return steps.reduce((s, x) => s + (x.durationMs || 0), 0);
  }, [result]);

  const runWorkspace = async () => {
    if (!question.trim()) return;
    setLoading(true);
    setError(null);
    setResult(null);
    setPlanPreview(null);
    try {
      if (planOnly) {
        const res = await fetch("/api/omega/workspace/plan", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ question, depth }),
        });
        const data = await res.json();
        if (!data.ok) throw new Error(data.error || "plan failed");
        setPlanPreview(data);
      } else {
        const res = await fetch("/api/omega/workspace", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ question, depth }),
        });
        const data: WorkspaceApiResponse = await res.json();
        if (!data.ok) throw new Error(data.error || "workspace failed");
        setResult(data);
      }
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  };

  const conf = result?.confidence ?? result?.trace?.confidence;
  const trace = result?.trace;

  return (
    <div className="max-w-7xl mx-auto w-full p-4 sm:p-6 space-y-5" dir="rtl">
      {/* Header */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 text-[#59e5de]">
            <BrainCircuit className="w-5 h-5" />
            <h2 className="text-lg font-semibold text-slate-100">
              مساحة العمل المعرفية
            </h2>
          </div>
          <p className="text-sm text-slate-400 mt-1">
            Cognitive Workspace · Planner → Memory → Tools → Agents → Verify → Confidence
          </p>
        </div>
        <span className="text-[10px] font-mono px-2 py-1 rounded border border-[#1a3a3e] text-[#8bb5b6]">
          PHASE 11.8
        </span>
      </div>

      {/* Input card */}
      <div className="rounded-xl border border-[#1a3a3e] bg-[#0a1c20]/90 p-4 space-y-3">
        <textarea
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          rows={3}
          className="w-full rounded-lg bg-[#061416] border border-[#1a3a3e] text-slate-100 text-sm p-3 focus:outline-none focus:border-[#59e5de]/50 resize-y min-h-[80px]"
          placeholder="اكتب سؤالك هنا…"
        />

        <div className="flex flex-wrap gap-2">
          {PRESETS.map((p) => (
            <button
              key={p.label}
              type="button"
              onClick={() => {
                setQuestion(p.q);
                setDepth(p.depth);
              }}
              className="text-[11px] px-2.5 py-1 rounded-full border border-[#1a3a3e] text-slate-300 hover:border-[#59e5de]/40 hover:text-[#59e5de] transition-colors"
            >
              {p.label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-3 justify-between">
          <div className="flex flex-wrap items-center gap-3">
            <label className="text-xs text-slate-400 flex items-center gap-2">
              العمق
              <select
                value={depth}
                onChange={(e) => setDepth(e.target.value as Depth)}
                className="bg-[#061416] border border-[#1a3a3e] rounded-md text-slate-200 text-xs px-2 py-1.5"
              >
                <option value="fast">fast</option>
                <option value="balanced">balanced</option>
                <option value="deep">deep (يتطلب مصادقة)</option>
              </select>
            </label>
            <label className="text-xs text-slate-400 flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={planOnly}
                onChange={(e) => setPlanOnly(e.target.checked)}
                className="rounded border-slate-600"
              />
              تخطيط فقط
            </label>
          </div>

          <button
            type="button"
            onClick={runWorkspace}
            disabled={loading || !question.trim()}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#124e4c] hover:bg-[#176360] disabled:opacity-50 text-sm text-[#c8fffb] border border-[#1f6f6a] transition-colors"
          >
            {loading ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <Play className="w-4 h-4" />
            )}
            {planOnly ? "إنشاء خطة" : "تشغيل الدورة"}
          </button>
        </div>
      </div>

      {error && (
        <div className="rounded-lg border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-200 flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Plan-only preview */}
      {planPreview && (
        <Section title="معاينة الخطة" icon={<ListTree className="w-4 h-4" />} badge={planPreview.domain}>
          <div className="space-y-2 text-sm text-slate-300">
            <p>
              <span className="text-slate-500">النطاق:</span> {planPreview.domain} ·{" "}
              <span className="text-slate-500">التعقيد:</span>{" "}
              {planPreview.plan?.estimatedComplexity}
            </p>
            <ol className="list-decimal list-inside space-y-1">
              {(planPreview.plan?.tasks || []).map((t: any) => (
                <li key={t.id}>
                  <span className="text-[#59e5de]">[{t.type}]</span> {t.title}
                </li>
              ))}
            </ol>
          </div>
        </Section>
      )}

      {/* Full result */}
      {result && (
        <div className="space-y-4">
          {/* Summary strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div className="rounded-lg border border-[#1a3a3e] bg-[#0a1c20] p-3">
              <div className="text-[10px] text-slate-500 font-mono">Ψ / CONF</div>
              <div className="text-lg text-[#59e5de] font-mono">
                {(conf?.psi ?? result.psi ?? 0).toFixed(2)}
                <span className="text-slate-500 text-sm">
                  {" "}
                  / {(conf?.confidence ?? 0).toFixed(2)}
                </span>
              </div>
            </div>
            <div className="rounded-lg border border-[#1a3a3e] bg-[#0a1c20] p-3">
              <div className="text-[10px] text-slate-500 font-mono">SOURCE</div>
              <div
                className={`inline-block mt-1 text-xs px-2 py-0.5 rounded border ${sourceBadge(
                  result.sourceClass || conf?.sourceClass
                )}`}
              >
                {result.sourceClass || conf?.sourceClass || "—"}
              </div>
            </div>
            <div className="rounded-lg border border-[#1a3a3e] bg-[#0a1c20] p-3">
              <div className="text-[10px] text-slate-500 font-mono">VERIFIED</div>
              <div className="mt-1 flex items-center gap-1 text-sm">
                {conf?.verified === true ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-300">نعم</span>
                  </>
                ) : conf?.verified === false ? (
                  <>
                    <AlertTriangle className="w-4 h-4 text-amber-400" />
                    <span className="text-amber-300">لا</span>
                  </>
                ) : (
                  <span className="text-slate-400">null</span>
                )}
              </div>
            </div>
            <div className="rounded-lg border border-[#1a3a3e] bg-[#0a1c20] p-3">
              <div className="text-[10px] text-slate-500 font-mono">DURATION</div>
              <div className="text-sm text-slate-200 flex items-center gap-1 mt-1">
                <Clock className="w-3.5 h-3.5 text-slate-500" />
                {totalDuration != null ? `${totalDuration} ms` : "—"}
              </div>
            </div>
          </div>

          {/* Reasoning path graph — Phase 12.1 */}
          <Section
            title="مسار التفكير"
            icon={<Network className="w-4 h-4" />}
            badge="trace graph"
          >
            <ReasoningTraceGraph
              steps={trace?.steps || []}
              tasks={trace?.plan?.tasks || []}
            />
          </Section>

          {/* Answer */}
          <Section title="الإجابة النهائية" icon={<Sparkles className="w-4 h-4" />}>
            <pre className="whitespace-pre-wrap text-sm text-slate-200 leading-relaxed font-sans">
              {result.answer || trace?.finalAnswer || "—"}
            </pre>
            {result.workspaceId && (
              <p className="mt-2 text-[10px] font-mono text-slate-500">
                workspaceId: {result.workspaceId}
              </p>
            )}
          </Section>

          {/* Confidence detail */}
          {conf && (
            <Section
              title="تقرير الثقة"
              icon={<ShieldCheck className="w-4 h-4" />}
              badge={`ψ=${conf.psi?.toFixed?.(3) ?? conf.psi}`}
            >
              <div className="grid sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <div className="text-emerald-400/90 mb-1 font-medium">Evidence</div>
                  <ul className="space-y-1 text-slate-300">
                    {(conf.evidence || []).map((e, i) => (
                      <li key={i}>• {e}</li>
                    ))}
                    {!(conf.evidence || []).length && (
                      <li className="text-slate-500">—</li>
                    )}
                  </ul>
                </div>
                <div>
                  <div className="text-amber-400/90 mb-1 font-medium">Risk</div>
                  <ul className="space-y-1 text-slate-300">
                    {(conf.risk || []).map((e, i) => (
                      <li key={i}>• {e}</li>
                    ))}
                    {!(conf.risk || []).length && (
                      <li className="text-slate-500">لا مخاطر مسجّلة</li>
                    )}
                  </ul>
                </div>
                <div>
                  <div className="text-slate-400 mb-1 font-medium">Unknowns</div>
                  <ul className="space-y-1 text-slate-300">
                    {(conf.unknowns || []).map((e, i) => (
                      <li key={i}>• {e}</li>
                    ))}
                    {!(conf.unknowns || []).length && (
                      <li className="text-slate-500">—</li>
                    )}
                  </ul>
                </div>
              </div>
            </Section>
          )}

          {/* Timeline */}
          {trace?.steps && (
            <Section
              title="خط الزمن"
              icon={<Clock className="w-4 h-4" />}
              badge={`${trace.steps.length} steps`}
            >
              <div className="space-y-2">
                {trace.steps.map((s, i) => (
                  <div
                    key={`${s.name}-${i}`}
                    className="flex flex-wrap items-center gap-2 text-xs border-b border-[#122a2e] pb-2 last:border-0"
                  >
                    <span className={`font-mono ${statusColor(s.status)}`}>
                      {s.status}
                    </span>
                    <span className="text-slate-200 font-medium">{s.name}</span>
                    <span className="text-slate-500 font-mono">{s.durationMs}ms</span>
                    {s.detail && (
                      <span className="text-slate-400 truncate max-w-full">
                        {s.detail}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </Section>
          )}

          {/* Plan tasks */}
          {trace?.plan && (
            <Section
              title="خطة المهام"
              icon={<ListTree className="w-4 h-4" />}
              badge={trace.plan.goal.domain}
              defaultOpen={false}
            >
              <p className="text-xs text-slate-400 mb-2">
                التعقيد: {trace.plan.estimatedComplexity} · الهدف:{" "}
                {trace.plan.goal.refinedGoal}
              </p>
              <div className="space-y-1.5">
                {trace.plan.tasks.map((t) => (
                  <div
                    key={t.id}
                    className="flex flex-wrap items-center gap-2 text-xs bg-[#061416] rounded-md px-2.5 py-1.5 border border-[#122a2e]"
                  >
                    <span className={`font-mono ${statusColor(t.status)}`}>
                      {t.status}
                    </span>
                    <span className="text-[#59e5de]">[{t.type}]</span>
                    <span className="text-slate-200">{t.title}</span>
                    {t.durationMs != null && (
                      <span className="text-slate-500 font-mono ms-auto">
                        {t.durationMs}ms
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </Section>
          )}

          {/* Tools */}
          {!!trace?.toolCalls?.length && (
            <Section
              title="استدعاءات الأدوات"
              icon={<Wrench className="w-4 h-4" />}
              badge={`${trace.toolCalls.length}`}
              defaultOpen={false}
            >
              <div className="space-y-2">
                {trace.toolCalls.map((tc, i) => (
                  <div
                    key={i}
                    className="text-xs border border-[#122a2e] rounded-md p-2.5 bg-[#061416]"
                  >
                    <div className="flex flex-wrap gap-2 items-center mb-1">
                      <span className="text-[#59e5de] font-mono">{tc.toolId}</span>
                      <span className={statusColor(tc.success ? "ok" : "error")}>
                        {tc.success ? "success" : "failed"}
                      </span>
                      <span
                        className={`text-[10px] px-1.5 py-0.5 rounded border ${sourceBadge(
                          tc.sourceClass
                        )}`}
                      >
                        {tc.sourceClass}
                      </span>
                      <span className="text-slate-500 font-mono">{tc.latencyMs}ms</span>
                    </div>
                    {tc.error && (
                      <p className="text-rose-300/90">{tc.error}</p>
                    )}
                  </div>
                ))}
              </div>
            </Section>
          )}

          {/* Memory / Graph */}
          {trace?.memory && (
            <Section
              title="الذاكرة والرسم المعرفي"
              icon={<Network className="w-4 h-4" />}
              badge={`n=${trace.memory.graphNodes?.length ?? 0}`}
              defaultOpen={false}
            >
              <div className="grid sm:grid-cols-2 gap-3 text-xs text-slate-300">
                <div>
                  <div className="text-slate-500 mb-1">إحصاء</div>
                  <ul className="space-y-0.5">
                    <li>عرضي: {trace.memory.episodic?.length ?? 0}</li>
                    <li>دلالي: {trace.memory.semantic?.length ?? 0}</li>
                    <li>إجرائي: {trace.memory.procedural?.length ?? 0}</li>
                    <li>عقد: {trace.memory.graphNodes?.length ?? 0}</li>
                    <li>علاقات: {trace.memory.graphEdges?.length ?? 0}</li>
                  </ul>
                </div>
                <div>
                  <div className="text-slate-500 mb-1">عقد مطابقة</div>
                  <ul className="space-y-0.5">
                    {(trace.memory.graphNodes || []).slice(0, 8).map((n) => (
                      <li key={n.id}>
                        • {n.label}{" "}
                        <span className="text-slate-500">({n.type || "concept"})</span>
                      </li>
                    ))}
                    {!(trace.memory.graphNodes || []).length && (
                      <li className="text-slate-500">لا عقد</li>
                    )}
                  </ul>
                </div>
              </div>
            </Section>
          )}

          {/* Agents */}
          {!!trace?.agentOpinions?.length && (
            <Section
              title="آراء الوكلاء"
              icon={<Users className="w-4 h-4" />}
              badge={`${trace.agentOpinions.length}`}
              defaultOpen={false}
            >
              <div className="space-y-2">
                {trace.agentOpinions.map((op, i) => (
                  <div
                    key={i}
                    className="text-xs border border-[#122a2e] rounded-md p-2.5 bg-[#061416]"
                  >
                    <div className="flex flex-wrap gap-2 mb-1">
                      <span className="text-[#59e5de]">{op.role}</span>
                      <span className="text-slate-500 font-mono">
                        conf={op.confidence.toFixed(2)}
                      </span>
                    </div>
                    <p className="text-slate-300 whitespace-pre-wrap">{op.answer}</p>
                    {!!op.critiques?.length && (
                      <ul className="mt-1 text-amber-200/80">
                        {op.critiques.map((c, j) => (
                          <li key={j}>• {c}</li>
                        ))}
                      </ul>
                    )}
                  </div>
                ))}
              </div>
            </Section>
          )}

          {/* Reflection */}
          {!!trace?.reflectionNotes?.length && (
            <Section
              title="ملاحظات التأمل"
              icon={<ShieldCheck className="w-4 h-4" />}
              badge={`${trace.reflectionNotes.length}`}
              defaultOpen={false}
            >
              <ul className="space-y-1.5 text-xs">
                {trace.reflectionNotes.map((n, i) => (
                  <li key={i} className="flex gap-2">
                    <span className={statusColor(n.severity === "error" ? "error" : n.severity === "warn" ? "warn" : "ok")}>
                      [{n.severity}]
                    </span>
                    <span className="text-slate-300">
                      <span className="text-slate-500">{n.type}:</span> {n.message}
                    </span>
                  </li>
                ))}
              </ul>
            </Section>
          )}
        </div>
      )}

      {!result && !planPreview && !loading && !error && (
        <div className="text-center py-12 text-slate-500 text-sm border border-dashed border-[#1a3a3e] rounded-xl">
          شغّل دورة معرفية لعرض الخط الزمني والخطة وتقرير الثقة هنا.
        </div>
      )}
    </div>
  );
};

export default CognitiveWorkspaceLab;
