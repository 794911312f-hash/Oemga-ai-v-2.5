/**
 * HyperGridLab.tsx
 * Phase 9 — Neural-Symbolic Hyper-Grid Interactive Workbench
 */

import React, { useState } from "react";
import {
  Network,
  BrainCircuit,
  Binary,
  GitMerge,
  Play,
  RefreshCw,
  ShieldCheck,
  Zap,
  ArrowRightLeft,
  Activity,
} from "lucide-react";

type GridPath = "auto" | "neural" | "symbolic" | "hybrid";

interface HyperGridResult {
  ok?: boolean;
  finalAnswer?: string;
  chosenPath?: string;
  confidence?: number;
  gridDecisionReason?: string;
  totalLatencyMs?: number;
  pathResults?: Array<{
    path: string;
    answer: string;
    confidence: number;
    latencyMs: number;
    verified?: boolean;
    evidence?: string[];
  }>;
  distillation?: {
    success: boolean;
    direction: string;
    message: string;
  };
  metadata?: {
    neuralUsed: boolean;
    symbolicUsed: boolean;
    hybridUsed: boolean;
    verificationPassed: boolean;
  };
  error?: string;
}

export const HyperGridLab: React.FC = () => {
  const [question, setQuestion] = useState(
    "حل المعادلة x^2 - 5x + 6 = 0 واشرح الخطوات"
  );
  const [preferredPath, setPreferredPath] = useState<GridPath>("auto");
  const [enableDistillation, setEnableDistillation] = useState(true);
  const [distillDirection, setDistillDirection] = useState<
    "symbolic_to_neural" | "neural_to_symbolic"
  >("symbolic_to_neural");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<HyperGridResult | null>(null);
  const [routeOnly, setRouteOnly] = useState<any | null>(null);

  const runHyperGrid = async () => {
    setLoading(true);
    setResult(null);
    try {
      const res = await fetch("/api/omega/hypergrid/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question,
          preferredPath,
          userId: "user_main",
          distillation: {
            enabled: enableDistillation,
            direction: distillDirection,
          },
        }),
      });
      const data = await res.json();
      setResult(data);
    } catch (err: any) {
      setResult({ ok: false, error: err.message || "Request failed" });
    } finally {
      setLoading(false);
    }
  };

  const previewRoute = async () => {
    try {
      const res = await fetch("/api/omega/hypergrid/route", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question, preferredPath }),
      });
      const data = await res.json();
      setRouteOnly(data.decision || data);
    } catch (err) {
      setRouteOnly({ error: String(err) });
    }
  };

  const pathColor = (path?: string) => {
    switch (path) {
      case "symbolic":
        return "text-cyan-300 bg-cyan-500/15 border-cyan-500/30";
      case "neural":
        return "text-violet-300 bg-violet-500/15 border-violet-500/30";
      case "hybrid":
        return "text-amber-300 bg-amber-500/15 border-amber-500/30";
      default:
        return "text-zinc-300 bg-zinc-700/40 border-zinc-600";
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-xl bg-gradient-to-br from-cyan-500/20 to-violet-500/20">
          <Network className="w-6 h-6 text-cyan-300" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-white">
            Neural-Symbolic Hyper-Grid
          </h2>
          <p className="text-sm text-zinc-400">
            Phase 9 — توجيه ديناميكي + تقطير ثنائي الاتجاه بين المسارات العصبية والرمزية
          </p>
        </div>
      </div>

      {/* Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-zinc-900/70 border border-zinc-700 rounded-xl p-5 space-y-4">
          <label className="text-sm text-zinc-400">السؤال / المهمة</label>
          <textarea
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            rows={4}
            className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white resize-none focus:outline-none focus:border-cyan-500/50"
            placeholder="اكتب سؤالاً رياضياً أو منطقياً أو عاماً..."
          />

          <div className="flex flex-wrap gap-2">
            {(
              [
                ["auto", "تلقائي"],
                ["symbolic", "رمزي"],
                ["neural", "عصبي"],
                ["hybrid", "هجين"],
              ] as const
            ).map(([value, label]) => (
              <button
                key={value}
                onClick={() => setPreferredPath(value)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition ${
                  preferredPath === value
                    ? pathColor(value === "auto" ? "hybrid" : value)
                    : "bg-zinc-800 text-zinc-400 border-zinc-700 hover:border-zinc-500"
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-4 text-sm">
            <label className="flex items-center gap-2 text-zinc-300 cursor-pointer">
              <input
                type="checkbox"
                checked={enableDistillation}
                onChange={(e) => setEnableDistillation(e.target.checked)}
                className="rounded border-zinc-600"
              />
              تفعيل التقطير
            </label>

            {enableDistillation && (
              <select
                value={distillDirection}
                onChange={(e) =>
                  setDistillDirection(e.target.value as typeof distillDirection)
                }
                className="bg-zinc-800 border border-zinc-700 rounded-lg px-2 py-1 text-xs text-zinc-300"
              >
                <option value="symbolic_to_neural">رمزي → عصبي</option>
                <option value="neural_to_symbolic">عصبي → رمزي</option>
              </select>
            )}
          </div>

          <div className="flex gap-3">
            <button
              onClick={runHyperGrid}
              disabled={loading || !question.trim()}
              className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-cyan-600 to-violet-600 hover:from-cyan-500 hover:to-violet-500 disabled:opacity-50 rounded-xl text-sm font-semibold text-white transition"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  جاري التنفيذ...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  تشغيل Hyper-Grid
                </>
              )}
            </button>

            <button
              onClick={previewRoute}
              className="flex items-center gap-2 px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 border border-zinc-600 rounded-xl text-sm text-zinc-300 transition"
            >
              <Activity className="w-4 h-4" />
              معاينة التوجيه فقط
            </button>
          </div>
        </div>

        {/* Path Legend */}
        <div className="bg-zinc-900/70 border border-zinc-700 rounded-xl p-5 space-y-3">
          <h3 className="text-sm font-semibold text-zinc-300">المسارات</h3>
          <div className="space-y-2 text-xs">
            <div className="flex items-center gap-2 p-2 rounded-lg bg-cyan-500/10 border border-cyan-500/20">
              <Binary className="w-4 h-4 text-cyan-300" />
              <div>
                <div className="text-cyan-200 font-medium">Symbolic</div>
                <div className="text-zinc-500">KG + CAS + قواعد</div>
              </div>
            </div>
            <div className="flex items-center gap-2 p-2 rounded-lg bg-violet-500/10 border border-violet-500/20">
              <BrainCircuit className="w-4 h-4 text-violet-300" />
              <div>
                <div className="text-violet-200 font-medium">Neural</div>
                <div className="text-zinc-500">Inference Engine + Adapters</div>
              </div>
            </div>
            <div className="flex items-center gap-2 p-2 rounded-lg bg-amber-500/10 border border-amber-500/20">
              <GitMerge className="w-4 h-4 text-amber-300" />
              <div>
                <div className="text-amber-200 font-medium">Hybrid</div>
                <div className="text-zinc-500">دمج + ترجيح ذكي</div>
              </div>
            </div>
            <div className="flex items-center gap-2 p-2 rounded-lg bg-zinc-800 border border-zinc-700">
              <ArrowRightLeft className="w-4 h-4 text-zinc-400" />
              <div>
                <div className="text-zinc-300 font-medium">Distillation</div>
                <div className="text-zinc-500">نقل معرفة ثنائي الاتجاه</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Route Preview */}
      {routeOnly && (
        <div className="bg-zinc-900/60 border border-zinc-700 rounded-xl p-4 text-sm">
          <div className="text-zinc-400 mb-1">قرار التوجيه</div>
          <pre className="text-xs text-zinc-300 overflow-auto">
            {JSON.stringify(routeOnly, null, 2)}
          </pre>
        </div>
      )}

      {/* Results */}
      {result && (
        <div className="space-y-4">
          {result.error || result.ok === false ? (
            <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4 text-red-300 text-sm">
              {result.error || "فشل التنفيذ"}
            </div>
          ) : (
            <>
              {/* Summary Cards */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="bg-zinc-900/70 border border-zinc-700 rounded-xl p-3">
                  <div className="text-[11px] text-zinc-500 mb-1">المسار المختار</div>
                  <div
                    className={`inline-flex px-2 py-0.5 rounded text-xs font-medium border ${pathColor(
                      result.chosenPath
                    )}`}
                  >
                    {result.chosenPath}
                  </div>
                </div>
                <div className="bg-zinc-900/70 border border-zinc-700 rounded-xl p-3">
                  <div className="text-[11px] text-zinc-500 mb-1">الثقة</div>
                  <div className="text-white font-semibold">
                    {((result.confidence || 0) * 100).toFixed(1)}%
                  </div>
                </div>
                <div className="bg-zinc-900/70 border border-zinc-700 rounded-xl p-3">
                  <div className="text-[11px] text-zinc-500 mb-1">الزمن</div>
                  <div className="text-white font-semibold">
                    {result.totalLatencyMs ?? "—"} ms
                  </div>
                </div>
                <div className="bg-zinc-900/70 border border-zinc-700 rounded-xl p-3">
                  <div className="text-[11px] text-zinc-500 mb-1">التحقق</div>
                  <div className="flex items-center gap-1 text-sm">
                    {result.metadata?.verificationPassed ? (
                      <>
                        <ShieldCheck className="w-4 h-4 text-emerald-400" />
                        <span className="text-emerald-300">نجح</span>
                      </>
                    ) : (
                      <span className="text-zinc-400">غير مؤكد</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Final Answer */}
              <div className="bg-zinc-900/70 border border-zinc-700 rounded-xl p-5">
                <div className="flex items-center gap-2 mb-3">
                  <Zap className="w-4 h-4 text-amber-400" />
                  <h3 className="text-sm font-semibold text-white">الإجابة النهائية</h3>
                </div>
                <div className="text-sm text-zinc-200 whitespace-pre-wrap leading-relaxed">
                  {result.finalAnswer || "—"}
                </div>
                {result.gridDecisionReason && (
                  <div className="mt-3 text-xs text-zinc-500">
                    سبب التوجيه: {result.gridDecisionReason}
                  </div>
                )}
              </div>

              {/* Path Results */}
              {result.pathResults && result.pathResults.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {result.pathResults.map((pr, idx) => (
                    <div
                      key={idx}
                      className="bg-zinc-900/60 border border-zinc-700 rounded-xl p-4 space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <span
                          className={`text-xs px-2 py-0.5 rounded border ${pathColor(
                            pr.path
                          )}`}
                        >
                          {pr.path}
                        </span>
                        <span className="text-xs text-zinc-500">
                          {(pr.confidence * 100).toFixed(0)}% · {pr.latencyMs}ms
                        </span>
                      </div>
                      <div className="text-xs text-zinc-300 line-clamp-6 whitespace-pre-wrap">
                        {pr.answer}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Distillation */}
              {result.distillation && (
                <div
                  className={`rounded-xl border p-4 text-sm ${
                    result.distillation.success
                      ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-200"
                      : "bg-zinc-800/60 border-zinc-700 text-zinc-400"
                  }`}
                >
                  <div className="font-medium mb-1">
                    تقطير ({result.distillation.direction})
                  </div>
                  <div className="text-xs">{result.distillation.message}</div>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default HyperGridLab;
