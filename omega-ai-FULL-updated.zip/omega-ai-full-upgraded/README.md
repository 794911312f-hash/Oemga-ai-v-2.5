# Omega AI

نظام تجريبي متعدد النماذج للمحادثة والتخطيط السينمائي وتحليل الفيديو.

## تشغيل محلي

```bash
npm install
npm run dev
```

ثم افتح `http://localhost:3000`.

## التحقق

```bash
npm run build
npm run typecheck
```

## المرحلة الأولى: إعادة تنظيم الخادم

تم فصل حدود الخادم الأساسية من `server.ts` إلى وحدات قابلة لإعادة الاستخدام:

- `src/server/middleware.ts`: محددات المعدل، مصادقة queue، وتحضير JSON middleware.
- `src/server/health.ts`: مسار `/api/health` مع اعتماديات قابلة للاختبار.

تم الحفاظ على نفس عقود API والسلوك الحالي. التحقق المنفذ: `npm run typecheck`، `npm run build`، واختبار HTTP لمسار health على خادم الإنتاج. هذه بداية تقسيم تدريجي للخادم الكبير دون نقل المسارات المعقدة قبل تثبيت حدود اعتمادياتها.

## المرحلة الثانية: الموثوقية والتحقق الدائم

تم ربط `IntelligentModelRouter` بسجل أداء دائم اختياري في `omega_model_performance` عبر `src/lib/omega/modelLedger.ts`. يقوم المحرك بتحميل السجل مرة واحدة قبل التوجيه، ويحفظ تحديثات `success`, `Psi`, و`latency` بعد دورة التحقق. عند غياب `FIREBASE_SERVICE_ACCOUNT` أو `GOOGLE_APPLICATION_CREDENTIALS` يعمل السجل محليًا دون محاولة Firestore غير موثقة أو إسقاط الخادم.

كما أصبحت سجلات النماذج مرتبطة بحساب Hybrid Ψ داخل `OmegaCore`: الجودة السابقة، عدم اليقين، وعدد العينات تؤثر بوزن محدود، بينما تبقى القيمة محايدة عند عدم وجود تاريخ. نتائج التحقق غير المتاحة لا تُسجل نجاحًا افتراضيًا.

## المرحلة الثالثة: الذاكرة والرسم المعرفي

تم تحسين استرجاع الذاكرة طويلة الأمد بترتيب مركب يجمع التشابه الدلالي (`65%`)، الحداثة الزمنية (`20%`) والثقة (`15%`) بدل ترتيب التشابه وحده. كما أصبح fallback المحلي صريحًا عند غياب اعتماد Firebase.

أضيفت قابلية `serialize/load` إلى `RealKnowledgeGraph`، وربطت دورة `OmegaInferenceEngine` بتحميل الرسم لكل مستخدم مرة واحدة وحفظه بعد دورة الاستدلال في مجموعة `omega_graphs`. التحقق حافظ على المعرفة الأساسية عند الاستعادة من snapshot الكامل، مع دعم العقد والعلاقات المضافة لاحقًا.

## المرحلة الرابعة: الأدوات الحقيقية والصدق التنفيذي

تم تصحيح `code/execute` بحيث ينفذ JavaScript/TypeScript فقط داخل Node VM مع حد أقصى لحجم الكود وبدون تعريض `setTimeout` أو واجهات النظام. أصبحت قيمة `ok` تعكس نجاح التنفيذ الحقيقي، وأخطاء الكود تعيد تفاصيل الفشل. اللغات غير المهيأة، مثل Python في هذه النسخة، تعيد `501 Not Implemented` بدل رسالة نجاح محاكية.

تم أيضًا تحديث `SymPyLeanBridge`: حسابات Nerdamer/MathJS ما زالت فعلية، لكن فحص Lean يعلن الآن صراحة أن النتيجة `heuristic` وأن `kernelVerified=false` لأن Lean غير مثبت في بيئة التشغيل. لا تُرفع درجة النتيجة إلى 1.0 إلا عند وجود تحقق Kernel فعلي.

## المرحلة الخامسة: أمان API والمصادقة

تمت إضافة `src/server/security.ts` لتوفير رؤوس حماية قياسية (`nosniff`, `SAMEORIGIN`, `Referrer-Policy`, `Permissions-Policy`) ومنع تخزين استجابات API الحساسة في المتصفح. تمت إضافة تطبيع آمن لمعرفات المستخدم لمنع تمرير قيم غير صالحة إلى طبقات التخزين.

أصبح إدخال مفاتيح OpenRouter يتحقق من الطول والمحارف غير المرئية، ولا يمكن تغيير المفتاح إلا بطلب إداري يحمل queue token صالحًا أو Firebase admin claim. تبقى حالة المزود متاحة للقراءة مع إخفاء المفتاح.

المرحلة لا تفرض تسجيل دخول على مسارات الضيف العادية، لكنها تغلق مسار تغيير الأسرار الإداري افتراضيًا.

## المرحلة السادسة: تحليل الفيديو الفعلي وOVO

تمت إضافة `src/lib/omega/videoProbe.ts` ومسار `POST /api/omega/video/analyze`. يقبل المسار فيديو Base64 حتى 12MB، يحفظه مؤقتًا داخل مساحة معزولة، يستخرج metadata بواسطة `ffprobe`، ثم يستخرج حتى 24 إطارًا منخفض الدقة عبر `ffmpeg`. تُحوّل الإطارات إلى طاقات مناطق وحركة مشتقة من فرق الإضاءة، ثم تُرسل إلى OVO بوضع `measured`.

النتيجة تفرّق بين `executionMode: measured_ffmpeg` ونتائج السيناريو الاصطناعي. التقرير يوضح القيود: لا يوجد تعرّف وجه/هوية شخصية، وقياس الحركة الحالي ليس Optical Flow كاملًا. يبقى `/api/omega/generate-video` صريحًا بأنه Blueprint فقط عندما لا يكون مزود توليد فيديو متصلًا.

## المرحلة السابعة: الاختبارات الآلية وCI

تمت إضافة `tests/omega-phase7.test.ts` وأمر `npm test` باستخدام Node Test Runner و`tsx`. تغطي الاختبارات تطبيع الهوية والتحقق من الأسرار، تصنيف OVO بين `synthetic` و`measured`، وضع Lean heuristic، تحليل فيديو حقيقي عبر FFmpeg/FFprobe، فك Base64، وحارس الصلاحيات الإدارية. آخر تشغيل نجح بـ **6 اختبارات من 6**.

تمت إضافة `.github/workflows/omega-ci.yml` لتشغيل `npm ci` ثم `npm run typecheck` و`npm test` و`npm run build` تلقائيًا على Push وPull Request إلى `main` أو `master`.

## تطوير نواة Omega

أضيفت طبقة `src/lib/omega/kernelResearch.ts` مستوحاة من مصادر الإجماع الطيفي ودمج الثقة والتحكم الواعي بالموارد:

- **Historical reliability:** يمكن لكل مرشح تمرير `historicalReliability` يحتوي `score` و`uncertainty` و`samples`. عند غياب السجل تستخدم النواة قيمة محايدة، لذلك لا تتغير استجابات العملاء الحاليين.
- **Resource-aware planning:** يمكن تمرير `resourceBudget` إلى `OmegaCoreRequest` لحساب الجولات والتكلفة المتوقعة وسبب الإيقاف قبل استهلاك الميزانية.
- **Observed spectral trace:** تقبل `runOmegaKernelExtended` اختياريًا `consensusTrace` وتعيد تقديرًا تجريبيًا لمعدل انكماش الاختلاف. لا تُسمى النتيجة شهادة كاملة إلا إذا توفرت آثار زمنية كافية، وتظل القيود مرفقة بالمخرج.
- **LatentMAS غير مفعّل:** التعاون عبر hidden states وKV-cache يحتاج أوزان نماذج محلية ووصولًا إلى الطبقات الداخلية، وهو غير متاح لمزودي API المغلقين؛ لذلك بقي مسارًا بحثيًا منفصلًا.

مثال ميزانية:

```ts
resourceBudget: {
  remainingTokens: 10000,
  estimatedRoundCost: 1200,
  disagreement: 0.8,
  disagreementThreshold: 0.2,
  consensusTolerance: 0.05
}
```

## ملاحظات مهمة عن الفيديو وOVO

- مسار `/api/omega/video-engine` ينشئ **مخطط فيديو** ولا يولد ملف فيديو ما لم يتم ربط مزود فيديو فعلي.
- مسار `/api/omega/ovo` يقبل `frameObservations` مثل `patchEnergies` أو `luminanceSamples` أو `imageData` ويعيد قياسات OVO فعلية من البيانات المرسلة.
- عند تمرير `frameObservations` إلى `/api/omega/video-engine` تصبح النتيجة `measured_telemetry` بدل `blueprint_only`، ولا تصبح `externally_audited` إلا مع qualityEvidence خارجي.
- القياسات البكسلية لا تثبت وحدها التزام النموذج بالـ prompt أو ثبات هوية الوجه؛ يجب تزويد `qualityEvidence` خارجي عند توفر Benchmark أو Face Embedding فعلي.

## حالة الإنتاج

قبل الإطلاق التجاري يجب إضافة Firebase Authentication حقيقي، مزود فيديو متصل، اختبارات API، وتحليل MP4/Face Embedding فعلي، وسجل موثوقية دائم لكل نموذج ونطاق.

## المصادر البحثية

- [Koopman spectral certification](https://arxiv.org/html/2608.05956v1)
- [Confidence-weighted consensus](https://arxiv.org/html/2509.16839v2)
- [LatentMAS](https://arxiv.org/html/2511.20639v1)
- [Agent-Kernel](https://github.com/ZJU-LLMs/Agent-Kernel)
- [Agent Memory Techniques](https://github.com/NirDiamant/Agent_Memory_Techniques)
- [Resource-aware consensus](https://arxiv.org/html/2608.25099v1)

---

## Phase 8 — Hybrid Self-Evolution + Population Archive (Added)

تم إضافة طبقة التطور الذاتي الهجين:

### الملفات الجديدة
- `src/lib/omega/hybridSelfEvolution.ts` — المحرك الكامل (Harness + ORPO/DPO + Population + Pareto + Lineage)
- `tests/hybrid-evolution.test.ts` — اختبارات أساسية
- `training/` — مجلد خدمة التدريب الخارجية (ORPO/DPO)

### الميزات
- اختيار طريقة التحسين على الأوزان: **ORPO** (افتراضي) أو **DPO**
- توليد بيانات Preference ذاتية من مسارات AutonomousAgent
- أرشيف سكاني (Population) مع Tournament Selection
- Pareto Front متعدد الأهداف
- شجرة نسب (Lineage)
- حفظ الـ Adapters في Firebase
- تكامل مع `AutoBenchmarkEngine` و `getInferenceEngine().runCycle`
- تبويب **Hybrid Evolution** في واجهة Evolution Lab

### API Endpoints الجديدة
- `GET  /api/omega/hybrid-evolution/status`
- `POST /api/omega/hybrid-evolution/run`
- `GET  /api/omega/hybrid-evolution/population`
- `GET  /api/omega/hybrid-evolution/lineage`
- `GET  /api/omega/hybrid-evolution/pareto`
- `POST /api/omega/hybrid-evolution/select-parent`
- `POST /api/omega/hybrid-evolution/promote`
- `DELETE /api/omega/hybrid-evolution/individual/:id`
- وغيرها...

### ملاحظات
يجب إضافة مسارات الـ API في `server.ts` وربط التبويب في `OmegaEvolutionLab.tsx` حسب الكود المقدم في المحادثة.

---

## Phase 9 — Neural-Symbolic Hyper-Grid & Distillation Engine

تم إضافة محرك الشبكة العصبية-الرمزية الفائقة:

### الملف الجديد
- `src/lib/omega/neuralSymbolicHyperGrid.ts`

### المكونات
- **HyperGridRouter** — يختار المسار الأمثل (Neural / Symbolic / Hybrid)
- **SymbolicPathExecutor** — يستفيد من Knowledge Graph + CAS
- **NeuralPathExecutor** — يستخدم Inference Engine
- **HybridPathExecutor** — دمج المسارين مع ترجيح ذكي
- **DistillationEngine** — تقطير ثنائي الاتجاه (Neural ↔ Symbolic)
- تكامل مع Hybrid Self-Evolution (تغذية Preference pairs)

### اختبارات
- `tests/hypergrid.test.ts`

### الاستخدام السريع
```ts
import { getNeuralSymbolicHyperGrid } from "./src/lib/omega/neuralSymbolicHyperGrid";

const grid = getNeuralSymbolicHyperGrid();
const result = await grid.run({
  question: "حل المعادلة وشرح الخطوات",
  preferredPath: "auto",
  distillation: { enabled: true, direction: "symbolic_to_neural" },
});
```

### Phase 9.1 — API Integration
تمت إضافة المسارات التالية في `server.ts`:

- `POST /api/omega/hypergrid/run` — تشغيل الشبكة الكاملة
- `GET  /api/omega/hypergrid/status` — حالة المحرك
- `POST /api/omega/hypergrid/route` — معرفة المسار المختار فقط (بدون تنفيذ)

مثال:
```bash
curl -X POST http://localhost:3000/api/omega/hypergrid/run \
  -H "Content-Type: application/json" \
  -d '{"question":"حل المعادلة x^2-4=0","preferredPath":"auto","distillation":{"enabled":true}}'
```

### Phase 9.2 — UI + Deeper Integration
- تمت إضافة المكون `src/components/omega/HyperGridLab.tsx`
- تم ربط تبويب **Hyper-Grid** داخل `OmegaEvolutionLab`
- يمكن تجربة التوجيه + التنفيذ + التقطير من الواجهة مباشرة

### Phase 9.3 — Stronger Symbolic + Decision Ledger
- تعزيز `SymbolicPathExecutor` لاستدعاء `symbolicEngine` + Knowledge Graph + RealKnowledgeGraph + وجود SymPyLeanBridge
- تسجيل كل قرار Hyper-Grid في:
  - `modelLedger` (إشارات أداء المسار)
  - مجموعة Firebase `omega_hypergrid_decisions`
- Endpoint جديد: `GET /api/omega/hypergrid/history`

### Phase 10.0 — Security Hardening (P0 partial)

تم تطبيق رقعة أمنية أولية:

1. `src/server/security.ts`
   - `resolveTrustedUserId()` — لا يثق بـ body/header userId للمستخدمين الضيوف
   - `requireAuthenticatedUser()` — يرفض العمليات الحساسة بدون توثيق

2. مسارات محمية الآن:
   - `POST /api/omega/memory/consolidate` — يتطلب مستخدم موثق
   - `POST /api/omega/graph/add-node` — يتطلب مستخدم موثق
   - `POST /api/omega/graph/add-edge` — يتطلب مستخدم موثق
   - `GET  /api/omega/graph/snapshot` — يسمح للضيف لكن بهوية guest ثابتة (لا من query)
   - `POST /api/omega/graph/infer` — نفس السياسة

3. اختبار HyperGrid:
   - لم يعد يبتلع الأخطاء افتراضيًا
   - التجاوز فقط إذا `OMEGA_ALLOW_INTEGRATION_SKIP=1`

**ما لم يُكتمل في هذه الجلسة:** تشغيل `npm run typecheck/test/build` بسبب بطء/تعطل تثبيت الاعتماديات في البيئة الحالية. يجب تشغيلها محليًا:

```bash
npm ci
npm run typecheck
npm test
npm run build
```

### Phase 10.1 — Expanded identity hardening

Protected / identity-scoped additional routes:

**Require authentication (write / evolve):**
- `POST /api/omega/evolve`
- `POST /api/omega/memory/consolidate`
- `POST /api/omega/graph/add-node`
- `POST /api/omega/graph/add-edge`
- hierarchical memory write actions (`set_working` / episodic / axioms)

**Trusted identity (guest allowed only as fixed `guest-user`):**
- `GET  /api/omega/kernel/evolution`
- `POST /api/omega/experience/context`
- `GET  /api/omega/learned-config`
- `GET  /api/omega/inference/state`
- `POST /api/omega/benchmark/run`
- `GET  /api/omega/benchmark/history`
- `GET  /api/omega/graph/snapshot`
- `POST /api/omega/graph/infer`
- `POST /api/omega/core` (+ process)

**OmegaCore response now includes:**
- `sourceClass`: `real` | `mixed` | `simulated` | `failed`
- trusted `userId`

Remaining routes still using body/query `userId` defaults (debate, mcts, tools, some inference helpers) should be migrated next.

### Phase 10.2 — Full identity sweep + sourceClass on main inference paths

**Identity:**
- تم ترحيل جميع المسارات المتبقية التي كانت تأخذ `userId` من body/query
- المتبقي من الأنماط الضعيفة: **0**

**sourceClass على المسارات الرئيسية:**
- `POST /api/omega/core` → `real | mixed | simulated | failed`
- `POST /api/omega/complete` → `real` للمزودين المباشرين/OpenRouter، `simulated` للـ fallback المحلي
- `POST /api/omega/ensemble` → `real` لـ OpenRouter، `simulated` عند fallback
- `POST /api/omega/deduce` → `real` عند نجاح OR/Gemini، `simulated` للتركيب المحلي

**دالة مساعدة:** `withSourceClass(payload, sourceClass)` في `server.ts`

### Phase 10.3 — Critical security fixes (Claude audit)

**P0 fixed:**
1. `/api/omega/code/execute`
   - Requires authenticated user (`requireAuthenticatedUser`)
   - Removed host `Array` / `Object` / `Date` / `Function` from VM sandbox
   - Pre-blocks `process`, `require`, `eval`, `Function(`, prototype escapes
   - `codeGeneration: { strings: false, wasm: false }`, timeout 2s
   - Dedicated rate limit: 10 req/min

2. `/v1/*`
   - Under global rate limiter + `queueAuthMiddleware`
   - `/v1/chat/completions` under AI compute limiter
   - Guests cannot drain OpenRouter/paid keys (401)
   - `userId` from body ignored; trusted identity only

3. Middleware
   - `express.json` registered **before** auth middleware (body was previously always undefined in auth)
   - Queue token compare uses `crypto.timingSafeEqual`
   - JSON limit 20mb (base64 video headroom)
   - `TRUST_PROXY=1` optional for reverse proxies
   - Guest identity fixed to `guest-user` (no more body/header spoofing in middleware)

**Honesty note:** Hybrid-evolution HTTP routes from Phase 8 design are **not** all present in `server.ts` unless added explicitly; the engine module exists under `src/lib/omega/hybridSelfEvolution.ts`. Treat README feature lists as design inventory until each route is confirmed in `server.ts`.

### Phase 10.4 — Security tests + Hybrid Evolution routes

**Tests:** `tests/security-phase10.test.ts`
- `resolveTrustedUserId` / `requireAuthenticatedUser` / guest isolation
- static contract for `code/execute` sandbox (no host Array/Object, auth required)
- middleware covers `/v1` + code exec rate limit
- asserts hybrid-evolution routes exist in `server.ts`

**Hybrid Evolution HTTP API (now in server.ts):**
- GET  `/api/omega/hybrid-evolution/status`
- POST `/api/omega/hybrid-evolution/run`
- POST `/api/omega/hybrid-evolution/config` (admin)
- POST `/api/omega/hybrid-evolution/reset` (admin)
- POST `/api/omega/hybrid-evolution/trajectory`
- GET  `/api/omega/hybrid-evolution/population`
- GET  `/api/omega/hybrid-evolution/lineage`
- GET  `/api/omega/hybrid-evolution/pareto`
- POST `/api/omega/hybrid-evolution/select-parent`
- POST `/api/omega/hybrid-evolution/promote`
- DELETE `/api/omega/hybrid-evolution/individual/:id` (admin)

```bash
npm test
# or
npx tsx --test tests/security-phase10.test.ts
```

### Phase 10.5 — Correction + real fixes (supersedes parts of 10.3)

**تصحيح:** ادعاء "P0 fixed" لـ `/api/omega/code/execute` في 10.3 كان غير صحيح. تم إثبات الهروب فعلياً:
`String.constructor("return pro"+"cess")()` تجاوز قائمة المنع وقرأ `process` الخاص بالخادم، لأن كائنات الخادم (`String/Number/Math`) كانت داخل الـ sandbox. `node:vm` ليس حدّاً أمنياً.

**الإصلاحات:**
- `src/server/sandbox.ts`: تنفيذ الكود في عملية Node منفصلة بنموذج الصلاحيات (`--permission`: لا fs ولا child_process ولا worker)، بيئة فارغة (لا أسرار)، مهلة قتل، سقف ذاكرة وسقف مخرجات. أُزيلت قائمة regex لأنها قابلة للالتفاف.
- `src/server/urlGuard.ts`: حماية SSRF (http/https فقط، منافذ 80/443، رفض العناوين الخاصة وlink-local وmetadata، إعادة فحص كل redirect). مستخدمة في `/api/omega/browser-use` ومحرك `browserUseEngine`.
- `/api/omega/browser-use` يتطلب مصادقة.
- `routeGuard` في `security.ts`: يمنع الضيف من المسارات المكلفة (صور/فيديو/صوت/open-sora/openhands/pipeline/avatar...) ويجعل `self-play/toggle|cycle` للمشرف فقط. القائمتان قابلتان للتعديل.
- اختبارات سلوكية: `tests/sandbox-escape.test.ts` (محاولات هروب فعلية) و`tests/route-guard.test.ts`.

**حدود معروفة:** نموذج صلاحيات Node لا يقيّد الشبكة الصادرة؛ يُنصح بتشغيل الخادم في حاوية مع منع الخروج للشبكات الداخلية. وSSRF guard لا يغلق DNS-rebinding بالكامل. لم يُشغَّل `typecheck/build` في بيئة المراجعة (بلا تثبيت اعتماديات) — شغّلهما محلياً.

---

## Phase 11 — Omega Cognitive Workspace (Started)

طبقة تنسيق معرفية موحدة فوق `OmegaCore` تحول المشروع من مجموعة محركات إلى نظام يخطط ويتذكر ويتحقق من نفسه.

### ما تم إنجازه (11.0 → 11.8) — Phase 11 مكتمل

**الملفات الجديدة:**
```
src/lib/omega/cognitiveWorkspace/
  ├── index.ts              # تصدير عام
  ├── types.ts              # نظام الأنواع الكامل
  ├── trace.ts              # CognitiveTraceRecorder
  ├── planner.ts            # Intent → Goal → Task Graph
  ├── memoryBridge.ts       # Hierarchical + Episodic + Semantic + Procedural
  ├── graphBridge.ts        # RealKnowledgeGraph query + multi-hop
  ├── toolOrchestrator.ts   # توحيد CAS / Code / Search / arXiv / Calculator
  ├── synthesizer.ts        # دمج الذاكرة/الأدوات/المرشّحين في إجابة نهائية
  ├── confidence.ts         # Ψ + Evidence + Risk + Unknowns
  ├── reflector.ts          # selfVerify + تأمل محلي + حاشية صدق
  ├── agentCoordinator.ts   # لجنة وكلاء + نقاش خصومي
  └── workspace.ts          # CognitiveWorkspace orchestrator

src/server/workspaceRoutes.ts   # تسجيل مسارات HTTP
src/components/omega/CognitiveWorkspaceLab.tsx  # واجهة Trace Viewer
```

**مسارات API (11.7):**
- `POST /api/omega/workspace` — دورة معرفية كاملة
- `POST /api/omega/workspace/plan` — تخطيط فقط
- `GET  /api/omega/workspace/trace/:id` — استرجاع Trace
- `GET  /api/omega/workspace/health` — جاهزية الوحدة

```bash
curl -s -X POST http://localhost:3000/api/omega/workspace \
  -H 'Content-Type: application/json' \
  -d '{"question":"ما هو قانون نيوتن الثاني؟","depth":"balanced"}'
```

**الاختبارات:**
- `tests/cognitive-workspace-planner.test.ts`
- `tests/cognitive-workspace-memory-graph.test.ts`
- `tests/cognitive-workspace-tools.test.ts`
- `tests/cognitive-workspace-synthesis.test.ts`
- `tests/cognitive-workspace-reflector.test.ts`
- `tests/cognitive-workspace-agents.test.ts`
- `tests/cognitive-workspace-api.test.ts`

### القدرات الحالية
- تحليل النية والنطاق (عبر `domainRouting` الموجود)
- تقدير التعقيد (low / medium / high)
- بناء خطة مهام مرتبة بالاعتماديات (retrieve → tools? → reason → agents? → synthesize → verify → reflect?)
- ثلاثة مستويات عمق: `fast` | `balanced` | `deep`
- تسجيل Trace كامل لكل خطوة
- **Memory Bridge**: Working + Episodic + Axiomatic + Semantic + Procedural
- **Graph Bridge**: استعلام العقد/العلاقات + استدلال متعدد القفزات + دمج في MemoryContext
- كتابة راجعة (write-back) للنتائج الناجحة في الذاكرة
- **Tool Orchestrator**: تخطيط + تنفيذ موحد للأدوات:
  - `symbolic_cas` (nerdamer / SymPyLeanBridge)
  - `code_sandbox` (SafeCodeSandbox JS/TS)
  - `web_search` (BrowserUseEngine)
  - `arxiv` (searchArxiv)
  - `calculator` (تقييم عددي/رمزي سريع)
  - كل استدعاء يُسجَّل في `ToolCallRecord` داخل الـ Trace
- **Synthesizer**: دمج إجابة النواة + الأدوات + الرسم المعرفي + الذاكرة
  - مسارات: `core_only` | `core_plus_tools` | `tools_primary` | `memory_fallback` | `plan_placeholder`
- **Confidence Estimator**: تقرير غني (Ψ، confidence، evidence، risk، unknowns، sourceClass، verified)
- **Reflector + selfVerify**:
  - استدعاء `verifyAnswer` (شبكي أو خوارزمي محلي)
  - فحص تغطية معايير النجاح والقيود
  - كشف توترات داخلية وفشل الأدوات
  - حاشية صدق اختيارية (balanced/deep)
  - تعديل confidence عبر `confidenceDelta`
- **AgentCoordinator**:
  - أدوار حسب النطاق (scientist / critic / programmer / …)
  - نقاش خصومي (Proponent / Sceptic / Arbiter) عبر `AdversarialDebateEngine`
  - آراء محلية صادقة بدون مفاتيح؛ دعم `callModel` اختياري
  - دمج ثقة اللجنة في تقرير الثقة النهائي
- **HTTP API**: هوية موثوقة، ضيف على fast/balanced، deep يتطلب مصادقة، تخزين Trace مؤقت
- **UI Trace Viewer** (`CognitiveWorkspaceLab`): تبويب في AppShell لتشغيل الدورات وعرض الخطة والخط الزمني والثقة والأدوات والوكلاء

### الاستخدام السريع
```ts
import { runCognitiveWorkspace, configForDepth } from "./src/lib/omega/cognitiveWorkspace";

const result = await runCognitiveWorkspace({
  userId: "user-1",
  question: "اشرح قانون نيوتن الثاني مع مثال",
  depth: "balanced",
});

console.log(result.answer);
console.log(result.confidence);
console.log(result.trace.plan.tasks);
```

### المراحل الفرعية المتبقية
| المرحلة | المحتوى |
|---------|---------|
| ~~11.2~~ | ~~MemoryBridge + GraphBridge~~ ✅ |
| ~~11.3~~ | ~~ToolOrchestrator~~ ✅ |
| ~~11.4~~ | ~~Synthesizer + Confidence Estimator~~ ✅ |
| ~~11.5~~ | ~~Reflector + selfVerify~~ ✅ |
| ~~11.6~~ | ~~AgentCoordinator~~ ✅ |
| ~~11.7~~ | ~~API routes~~ ✅ |
| ~~11.8~~ | ~~UI Trace Viewer~~ ✅ |

### مبادئ التصميم
- لا يستبدل `OmegaCore` — يبني فوقه
- كل خطوة تسجل `sourceClass` و`verified`
- فشل أداة أو وكيل لا يسقط الدورة
- Feature flags عبر `WorkspaceConfig`


---

## Phase 12.0 + 12.1 — Core Bridge & Reasoning Trace Graph

### 12.0 Core Bridge
- `src/lib/omega/cognitiveWorkspace/coreBridge.ts`
- `registerCoreRunner` من `server.ts` يربط `runOmegaCore` بمساحة العمل
- `GET /api/omega/workspace/health` يعرض `coreBridge.wired`
- توثيق: `docs/ARCHITECTURE-COGNITIVE-WORKSPACE.md`

### 12.1 Reasoning Trace Visualization
- `src/components/omega/ReasoningTraceGraph.tsx`
- مدمج في `CognitiveWorkspaceLab` كقسم «مسار التفكير»

```bash
# اختبار جسر النواة
npx tsx --test tests/cognitive-workspace-core-bridge.test.ts
```


## Phase 12.3 — Modular routes + HTTP/security tests

- `src/server/routes/` — Hybrid Evolution, Knowledge Graph, Model Router extracted from `server.ts`
- `registerModularRoutes(app)` in `server.ts`
- `tests/workspace-http-security.test.ts` (HTTP integration)
- `tests/workspace-security-logic.test.ts` (logic without Express)

```bash
npm install
npx tsx --test tests/workspace-http-security.test.ts tests/workspace-security-logic.test.ts
```
