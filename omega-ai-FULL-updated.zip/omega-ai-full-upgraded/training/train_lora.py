"""Authenticated LoRA preference-training service for Omega.

DPO loss:
  -log sigmoid(beta * ((log pi(y+|x)-log pi(y-|x))
                         -(log pi_ref(y+|x)-log pi_ref(y-|x))))

ORPO loss:
  NLL(y+) + beta * -log sigmoid(log odds_pi(y+) - log odds_pi(y-))

Only preference pairs carrying independent, two-sided verification evidence
are accepted. Model weights are saved as a PEFT adapter; the base model is not
modified.
"""
from __future__ import annotations

import hmac
import os
import re
import threading
import time
import uuid
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field, model_validator

app = FastAPI(title="Omega Verified LoRA Trainer", version="1.0.0")
_training_lock = threading.Lock()


class Evidence(BaseModel):
    source: Literal["cas", "lean", "tool", "human"]
    proofId: str = Field(min_length=3, max_length=1000)
    outcome: bool
    confidence: float = Field(ge=0.9, le=1.0)


class PreferencePair(BaseModel):
    prompt: str = Field(min_length=1, max_length=16000)
    chosen: str = Field(min_length=1, max_length=16000)
    rejected: str = Field(min_length=1, max_length=16000)
    scoreDiff: float = Field(gt=0, le=1)
    verified: bool
    chosenEvidence: Evidence
    rejectedEvidence: Evidence

    @model_validator(mode="after")
    def require_two_sided_proof(self):
        if not self.verified:
            raise ValueError("pair is not marked verified")
        if self.chosenEvidence.outcome is not True:
            raise ValueError("chosen answer lacks positive verification")
        if self.rejectedEvidence.outcome is not False:
            raise ValueError("rejected answer lacks negative verification")
        if self.chosen.strip() == self.rejected.strip():
            raise ValueError("chosen and rejected answers are identical")
        return self


class TrainRequest(BaseModel):
    baseModel: str = Field(min_length=1, max_length=300)
    preferencePairs: list[PreferencePair] = Field(min_length=2, max_length=2000)
    method: Literal["orpo", "dpo"] = "orpo"
    rank: int = Field(default=16, ge=1, le=128)
    alpha: int = Field(default=32, ge=1, le=256)
    learningRate: float = Field(default=8e-6, gt=0, le=1e-3)
    numEpochs: int = Field(default=1, ge=1, le=5)
    beta: float = Field(default=0.1, gt=0, le=2)
    maxPairs: int = Field(default=400, ge=2, le=2000)
    outputName: str = Field(default="omega-adapter", min_length=1, max_length=100)
    maxLength: int = Field(default=1024, ge=128, le=4096)
    batchSize: int = Field(default=1, ge=1, le=8)

    @model_validator(mode="after")
    def require_unique_prompt_answer_triplets(self):
        if len(self.preferencePairs) > self.maxPairs:
            self.preferencePairs = self.preferencePairs[: self.maxPairs]
        seen: set[tuple[str, str, str]] = set()
        unique = []
        for pair in self.preferencePairs:
            key = (pair.prompt, pair.chosen, pair.rejected)
            if key not in seen:
                seen.add(key)
                unique.append(pair)
        self.preferencePairs = unique
        if len(self.preferencePairs) < 2:
            raise ValueError("at least two unique verified preference pairs are required")
        return self


def _authenticate(authorization: str | None) -> None:
    expected = os.environ.get("OMEGA_TRAINING_SECRET", "")
    if not expected:
        raise HTTPException(status_code=503, detail="OMEGA_TRAINING_SECRET is not configured")
    supplied = (authorization or "").removeprefix("Bearer ")
    if not hmac.compare_digest(supplied, expected):
        raise HTTPException(status_code=401, detail="Invalid training-service credentials")


@app.get("/health")
def health():
    return {"ok": True, "service": "omega-verified-lora-trainer", "secretConfigured": bool(os.environ.get("OMEGA_TRAINING_SECRET"))}


def _sequence_logps(model, input_ids, attention_mask, labels):
    """Return summed and mean token log-probability for response tokens only."""
    import torch
    import torch.nn.functional as F

    logits = model(input_ids=input_ids, attention_mask=attention_mask).logits[:, :-1, :]
    targets = labels[:, 1:]
    mask = targets.ne(-100)
    safe_targets = targets.masked_fill(~mask, 0)
    token_logps = F.log_softmax(logits.float(), dim=-1).gather(
        dim=-1, index=safe_targets.unsqueeze(-1)
    ).squeeze(-1)
    token_logps = token_logps * mask
    counts = mask.sum(dim=-1).clamp_min(1)
    return token_logps.sum(dim=-1), token_logps.sum(dim=-1) / counts, counts


def _prepare_sample(tokenizer, prompt: str, answer: str, max_length: int):
    import torch

    prompt_ids = tokenizer(prompt, add_special_tokens=True, truncation=False)["input_ids"]
    answer_ids = tokenizer(answer, add_special_tokens=False, truncation=False)["input_ids"]
    if tokenizer.eos_token_id is not None:
        answer_ids = answer_ids + [tokenizer.eos_token_id]
    answer_ids = answer_ids[:max_length]
    if not answer_ids:
        raise ValueError("answer tokenization is empty")
    prompt_budget = max(0, max_length - len(answer_ids))
    prompt_ids = prompt_ids[-prompt_budget:] if prompt_budget else []
    ids = prompt_ids + answer_ids
    labels = [-100] * len(prompt_ids) + answer_ids
    return torch.tensor(ids, dtype=torch.long), torch.tensor(labels, dtype=torch.long)


def _collate(samples, pad_id: int, device):
    import torch

    ids_list, labels_list = zip(*samples)
    width = max(x.numel() for x in ids_list)
    input_ids = torch.full((len(samples), width), pad_id, dtype=torch.long)
    labels = torch.full((len(samples), width), -100, dtype=torch.long)
    attention = torch.zeros((len(samples), width), dtype=torch.long)
    for i, (ids, row_labels) in enumerate(zip(ids_list, labels_list)):
        input_ids[i, : ids.numel()] = ids
        labels[i, : row_labels.numel()] = row_labels
        attention[i, : ids.numel()] = 1
    return input_ids.to(device), attention.to(device), labels.to(device)


def _train(request: TrainRequest) -> dict:
    import torch
    import torch.nn.functional as F
    from peft import LoraConfig, get_peft_model
    from transformers import AutoModelForCausalLM, AutoTokenizer

    model_name = request.baseModel
    tokenizer = AutoTokenizer.from_pretrained(model_name, use_fast=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    dtype = torch.bfloat16 if device.type == "cuda" and torch.cuda.is_bf16_supported() else (
        torch.float16 if device.type == "cuda" else torch.float32
    )
    model = AutoModelForCausalLM.from_pretrained(model_name, torch_dtype=dtype)
    model.config.use_cache = False
    model.gradient_checkpointing_enable()
    if hasattr(model, "enable_input_require_grads"):
        model.enable_input_require_grads()

    lora = LoraConfig(
        r=request.rank,
        lora_alpha=request.alpha,
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    )
    model = get_peft_model(model, lora)
    model.to(device)
    model.train()

    prepared = []
    for pair in request.preferencePairs:
        chosen = _prepare_sample(tokenizer, pair.prompt, pair.chosen, request.maxLength)
        rejected = _prepare_sample(tokenizer, pair.prompt, pair.rejected, request.maxLength)
        prepared.append((chosen, rejected))

    optimizer = torch.optim.AdamW(
        [p for p in model.parameters() if p.requires_grad],
        lr=request.learningRate,
        weight_decay=0.01,
    )
    optimizer.zero_grad(set_to_none=True)
    losses: list[float] = []
    step = 0
    for _epoch in range(request.numEpochs):
        # Deterministic ordering makes run-to-run debugging auditable.
        for start in range(0, len(prepared), request.batchSize):
            batch = prepared[start : start + request.batchSize]
            chosen_inputs = _collate([row[0] for row in batch], tokenizer.pad_token_id, device)
            rejected_inputs = _collate([row[1] for row in batch], tokenizer.pad_token_id, device)
            chosen_ids, chosen_mask, chosen_labels = chosen_inputs
            rejected_ids, rejected_mask, rejected_labels = rejected_inputs

            chosen_sum, chosen_mean, chosen_count = _sequence_logps(
                model, chosen_ids, chosen_mask, chosen_labels
            )
            rejected_sum, rejected_mean, _ = _sequence_logps(
                model, rejected_ids, rejected_mask, rejected_labels
            )

            if request.method == "dpo":
                # PEFT disables only the trainable adapter, giving a frozen reference
                # policy without duplicating the base-model weights in memory.
                with torch.no_grad(), model.disable_adapter():
                    ref_chosen, _, _ = _sequence_logps(model, chosen_ids, chosen_mask, chosen_labels)
                    ref_rejected, _, _ = _sequence_logps(model, rejected_ids, rejected_mask, rejected_labels)
                loss = -F.logsigmoid(
                    request.beta * ((chosen_sum - rejected_sum) - (ref_chosen - ref_rejected))
                ).mean()
            else:
                # ORPO combines chosen-response NLL and a length-normalized odds-ratio term.
                chosen_nll = -chosen_sum / chosen_count
                eps = 1e-6
                chosen_prob = chosen_mean.exp().clamp(eps, 1 - eps)
                rejected_prob = rejected_mean.exp().clamp(eps, 1 - eps)
                chosen_log_odds = torch.log(chosen_prob) - torch.log1p(-chosen_prob)
                rejected_log_odds = torch.log(rejected_prob) - torch.log1p(-rejected_prob)
                preference_loss = -F.logsigmoid(chosen_log_odds - rejected_log_odds)
                loss = (chosen_nll + request.beta * preference_loss).mean()

            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                [p for p in model.parameters() if p.requires_grad], max_norm=1.0
            )
            optimizer.step()
            optimizer.zero_grad(set_to_none=True)
            step += 1
            losses.append(float(loss.detach().float().cpu()))

    safe_name = re.sub(r"[^A-Za-z0-9_.-]", "_", request.outputName)[:100]
    adapter_id = f"{safe_name}-{uuid.uuid4().hex[:8]}"
    output_root = Path(os.environ.get("OMEGA_ADAPTER_DIR", "./adapters")).resolve()
    output_dir = output_root / adapter_id
    output_dir.mkdir(parents=True, exist_ok=False)
    model.save_pretrained(output_dir)
    tokenizer.save_pretrained(output_dir)
    return {
        "success": True,
        "adapterId": adapter_id,
        "adapterPath": str(output_dir),
        "trainedPairs": len(prepared),
        "steps": step,
        "finalLoss": losses[-1] if losses else None,
        "method": request.method,
        "baseModel": model_name,
        "createdAt": int(time.time() * 1000),
    }


@app.post("/train")
def train(request: TrainRequest, authorization: str | None = Header(default=None)):
    _authenticate(authorization)
    if not _training_lock.acquire(blocking=False):
        raise HTTPException(status_code=409, detail="A training run is already in progress")
    try:
        result = _train(request)
        return result
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Training failed: {type(exc).__name__}: {exc}") from exc
    finally:
        _training_lock.release()
