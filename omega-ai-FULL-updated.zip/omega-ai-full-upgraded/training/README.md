# Omega verified preference training (LoRA)

This directory contains the actual authenticated training service called by `HybridSelfEvolutionEngine`. It creates a PEFT/LoRA adapter from independently verified preference pairs; it never edits the base model weights.

## Requirements and startup

Python 3.10+ is recommended. Install dependencies into an isolated environment and configure a long random secret **before** starting the service:

```bash
cd training
python -m venv .venv
source .venv/bin/activate              # Windows: .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
export OMEGA_TRAINING_SECRET="$(python -c 'import secrets; print(secrets.token_urlsafe(48))')"
export OMEGA_ADAPTER_DIR="./adapters"
uvicorn train_lora:app --host 127.0.0.1 --port 8000
```

Keep the service on loopback or behind a private authenticated network. Do not expose port 8000 publicly. `/health` reports readiness; `/train` requires `Authorization: Bearer <OMEGA_TRAINING_SECRET>`.

Set the matching values in the Omega server environment:

```dotenv
OMEGA_LORA_TRAINING_ENDPOINT=http://127.0.0.1:8000/train
OMEGA_TRAINING_SECRET=<same random secret>
OMEGA_BASE_MODEL=Qwen/Qwen2.5-7B-Instruct
```

Use a model that fits the available hardware. Training loads the base model and saves only adapter weights. The included implementation has no dependency on TRL: it implements the objectives directly with PyTorch, Transformers, and PEFT.

## Objectives

For DPO, with policy `πθ`, frozen reference `πref`, prompt `x`, preferred answer `y+`, rejected answer `y−`, and temperature `β`, the optimized per-pair loss is:

`−log σ(β[(log πθ(y+|x) − log πθ(y−|x)) − (log πref(y+|x) − log πref(y−|x))])`.

The reference is evaluated by disabling the LoRA adapter, avoiding a second copy of base weights. ORPO combines chosen-answer token NLL with a log-odds preference loss:

`NLL(y+) + β · −log σ(log oddsπ(y+|x) − log oddsπ(y−|x))`.

ORPO uses response-length-normalized log probabilities for its odds term; DPO uses sequence log-probability sums. Gradients are clipped to norm 1.0, and optimizer weight decay is 0.01. These are transparent baselines, not a promise of improvement: retain an adapter only after evaluation on a held-out benchmark.

## Fail-closed data contract

Every pair must include `verified: true`, non-empty and distinct chosen/rejected answers, a positive proof for the chosen answer, and an independent negative proof for the rejected answer. Accepted evidence sources are `cas`, `lean`, `tool`, or `human`; each proof must include a unique `proofId` and confidence ≥ 0.90. Unverified trajectories and text-length heuristics are never sent to training. An unknown answer is not treated as an incorrect answer.

Trusted verifier integrations can submit a pair to `/api/omega/hybrid-evolution/verified-pair`; that route requires administrative authentication, and the engine checks proof shape and verdict polarity. Do not expose this administrative route or treat caller-supplied proof metadata as cryptographic verification: the trusted verifier is responsible for producing the evidence.

The API enforces these fields again using Pydantic validation. The service refuses requests with fewer than two unique verified pairs. Training failures do not produce an adapter success response.

## Outputs and evaluation

Adapters are saved under `OMEGA_ADAPTER_DIR/<adapter-id>/` and returned as `adapterPath`, with `trainedPairs`, `steps`, `method`, and `finalLoss`. The service does not publish adapters or upload model data. Omega's benchmark gate should decide whether the adapter is retained/promoted; training loss by itself is not evidence of improved factual accuracy.

The current Omega inference path does not load LoRA adapters yet. Accordingly, generated adapters are reported as **staged**, not active; they are not counted as successful evolution and promotion is blocked until a serving-time adapter loader and an adapter-specific held-out benchmark are connected. This prevents measuring the unchanged base model and incorrectly attributing its score to the adapter.

Minimal syntax check:

```bash
python -m py_compile train_lora.py
```
