# Omega Benchmark Dataset v1.1

- **Items:** 50
- **Seed:** 42
- **Version:** 1.1.0

## Categories
See `index.json`.

## Fusion policy comparison
```bash
npm run benchmark:compare
```

## Full suite
```bash
npm run benchmark:offline
npm run benchmark   # requires providers + Core Bridge
```

## Rules
- Do not tune Ψ/router constants on this set when claiming gains
- Offline reports are harness-only evidence

---

## ملاحظة تدقيق (2026-10-17)

أسلوب التحقق في العناصر هو `expect.type = "contains_any"` — مطابقة كلمات مفتاحية على النص،
وليست حكماً دلالياً على صحة الإجابة. القيود أعلاه ("harness-only evidence") صحيحة، ويُضاف إليها:
أي رقم مستخرج من هذه المجموعة يصف أداء المُقيّم النصّي أكثر مما يصف قدرة النموذج.
يُفضّل استبداله بمطابقة قابلة للتحقق (اختبار تنفيذي) أو حَكَم مستقل.
