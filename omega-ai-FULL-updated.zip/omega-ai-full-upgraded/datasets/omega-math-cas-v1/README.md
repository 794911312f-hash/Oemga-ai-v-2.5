# Omega Math+CAS Benchmark (closed set)

**Product path:** symbolic / numeric math answers with executive scoring.  
**Not** a general LLM leaderboard. Holdout-style fixed items; no training on this set.

## Scoring

| expect.type | Rule |
|-------------|------|
| `exact_number` | Parse a number from the answer; must match `value` within `tol` (default 1e-6). |
| `numeric_close` | Same as exact_number with explicit relative/absolute tolerance. |
| `expression_normalized` | Normalize text (strip spaces, `**`→`^`, unicode superscripts) and require all `must_include` substrings; optional `must_not`. |
| `exact_string` | Case-insensitive trimmed equality (after Arabic-Indic digit normalization). |

Items must **not** use loose `contains_any` alone for promotion claims.

## Run

```bash
npx tsx scripts/run-math-cas-benchmark.ts
npx tsx scripts/run-math-cas-benchmark.ts --offline   # fixture answers only (CI)
```

Report: `docs/reports/math-cas-benchmark-*.md`
