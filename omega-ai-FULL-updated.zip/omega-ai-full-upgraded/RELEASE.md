# Omega AI — Release notes

## Honest algorithm fixes (post Claude review)

- Hyper-Grid: `normalizeArabic`, prefix stripping, no substring false positives
- Ψ_hybrid: pure-arithmetic check with operator precedence; style capped
- `textSanityProxy` (not falsification)
- Evolution gate: PASS requires `sha256` + `latest` + `expiresAt` (24h)
- UI restored: Cognitive Workspace lab + trace graph + workspace tab
- Arithmetic answers may explain steps if the expected number appears

## Quick checks

```bash
npm install
npx tsx --test tests/evidence-psi.test.ts tests/evolution-gate-status.test.ts tests/hypergrid.test.ts
npm run evolution-gate
```

## Evidence tiers

See `docs/evidence/EVIDENCE-TIERS.md`. Offline reports do not authorize promote.
