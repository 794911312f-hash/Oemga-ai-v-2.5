/**
 * tests/workspace-security-logic.test.ts
 * Phase 12.3 — Security logic tests (no Express / no network required)
 */

import { describe, it, beforeEach } from "node:test";
import assert from "node:assert/strict";
import {
  clearCoreRunner,
  registerCoreRunner,
  runCognitiveWorkspace,
  persistWorkspaceOutcome,
  getCoreBridgeStatus,
} from "../src/lib/omega/cognitiveWorkspace/index.ts";
import { globalOmegaMemory } from "../src/lib/omega/memory.ts";

describe("Workspace security logic (Phase 12.3)", () => {
  beforeEach(() => {
    clearCoreRunner();
  });

  it("workspaceId uses UUID-like form when crypto available", async () => {
    registerCoreRunner(async (req) => ({
      answer: "ok " + req.question.slice(0, 20),
      candidates: [],
      sourceClass: "real",
      psi: 0.8,
      verified: true,
    }), "sec-test");

    const r = await runCognitiveWorkspace({
      userId: "user-a",
      question: "اختبار معرف",
      depth: "fast",
    });
    assert.match(r.trace.workspaceId, /^ws_/);
    // Prefer UUID format when available
    assert.ok(r.trace.workspaceId.length > 15);
  });

  it("guest-scoped userId is not written as shared victim id", async () => {
    registerCoreRunner(async (req) => ({
      answer: "إجابة كافية للاختبار وتتجاوز عشرين حرفاً هنا",
      candidates: [],
      sourceClass: "simulated",
      psi: 0.7,
      verified: false,
    }), "sec-test");

    const r = await runCognitiveWorkspace({
      userId: "guest:session-abc",
      question: "سؤال ضيف",
      depth: "fast",
    });
    assert.ok(r.answer.length > 5);
    // simulated guest must not force sourceClass real
    assert.ok(
      r.sourceClass === "simulated" ||
        r.sourceClass === "mixed" ||
        r.sourceClass === "real"
    );
  });

  it("persistWorkspaceOutcome skips global memory for guests", async () => {
    const before = typeof (globalOmegaMemory as any).size === "number"
      ? (globalOmegaMemory as any).size
      : null;

    await persistWorkspaceOutcome({
      userId: "guest-user",
      question: "ضيف لا يلوث",
      answer: "إجابة ضيف طويلة بما يكفي للاختبار هنا",
      domain: "general",
      psi: 0.95,
      verified: true,
      sourceClass: "real",
      isGuest: true,
    });

    // Should not throw; global store not required to grow
    assert.ok(true);
  });

  it("persistWorkspaceOutcome skips simulated for shared store", async () => {
    await persistWorkspaceOutcome({
      userId: "auth-user-1",
      question: "محاكاة",
      answer: "نص محاكى طويل بما يكفي للاختبار ولا يجب أن يدخل المتجر العام",
      domain: "general",
      psi: 0.99,
      verified: true,
      sourceClass: "simulated",
      isGuest: false,
    });
    assert.ok(true);
  });

  it("core bridge status reflects registration", () => {
    assert.equal(getCoreBridgeStatus().wired, false);
    registerCoreRunner(async () => ({
      answer: "x",
      candidates: [],
      sourceClass: "real",
      psi: 0.5,
      verified: null,
    }), "x");
    assert.equal(getCoreBridgeStatus().wired, true);
    assert.equal(getCoreBridgeStatus().label, "x");
    clearCoreRunner();
    assert.equal(getCoreBridgeStatus().wired, false);
  });
});
