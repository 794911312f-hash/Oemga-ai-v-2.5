/** Behavioral security tests (no network needed). These ACTUALLY try to escape. */
import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { runUntrustedJs } from "../src/server/sandbox";
import { assertPublicHttpUrl, isPrivateAddress, UnsafeUrlError } from "../src/server/urlGuard";

describe("runUntrustedJs", () => {
  it("runs normal code", async () => {
    const r = await runUntrustedJs(`console.log("hi", [1,2].map(x=>x*2)); 1+2`);
    assert.equal(r.ok, true);
    assert.match(r.output, /hi \[2,4\]/);
    assert.match(r.output, /Return Value: 3/);
  });

  it("known escape (String.constructor) cannot read host env/secrets", async () => {
    process.env.OMEGA_TEST_SECRET = "TOP-SECRET-123";
    const attempts = [
      `String.constructor("return pro"+"cess")().env.OMEGA_TEST_SECRET`,
      `(function(){}).constructor("return this.process")()`,
      `this.constructor.constructor("return process")().env.OMEGA_TEST_SECRET`,
      `Object.getPrototypeOf(console.log).constructor("return process")().env.OMEGA_TEST_SECRET`,
    ];
    for (const code of attempts) {
      const r = await runUntrustedJs(code);
      assert.doesNotMatch(r.output + (r.error ?? ""), /TOP-SECRET-123/, code);
    }
    delete process.env.OMEGA_TEST_SECRET;
  });

  it("even a full escape has no filesystem or child_process access", async () => {
    const r = await runUntrustedJs(
      `String.constructor("return pro"+"cess")().mainModule.require("fs").readFileSync("/etc/passwd","utf8")`,
    );
    assert.doesNotMatch(r.output, /root:/);
  });

  it("kills infinite loops", async () => {
    const r = await runUntrustedJs(`while(true){}`, { wallMs: 1500 });
    assert.equal(r.ok, false);
  });

  it("caps runaway output", async () => {
    const r = await runUntrustedJs(`for(var i=0;i<2e5;i++)console.log("x".repeat(200))`, { wallMs: 5000 });
    assert.equal(r.ok, false);
  });
});

describe("urlGuard", () => {
  it("classifies private addresses", () => {
    for (const ip of ["127.0.0.1", "10.1.2.3", "172.16.0.1", "192.168.1.1", "169.254.169.254", "::1", "fd00::1", "::ffff:127.0.0.1", "100.64.0.1"]) {
      assert.equal(isPrivateAddress(ip), true, ip);
    }
    for (const ip of ["8.8.8.8", "1.1.1.1", "2606:4700:4700::1111"]) assert.equal(isPrivateAddress(ip), false, ip);
  });

  it("rejects dangerous URLs", async () => {
    for (const u of [
      "http://169.254.169.254/latest/meta-data/", "http://127.0.0.1:3000/api/health", "http://localhost/",
      "http://[::1]/", "file:///etc/passwd", "ftp://example.com/", "http://user:pw@8.8.8.8/", "http://8.8.8.8:6379/", "not a url",
    ]) {
      await assert.rejects(() => assertPublicHttpUrl(u), UnsafeUrlError, u);
    }
  });

  it("allows public literal IPs", async () => {
    const u = await assertPublicHttpUrl("https://8.8.8.8/");
    assert.equal(u.hostname, "8.8.8.8");
  });
});
