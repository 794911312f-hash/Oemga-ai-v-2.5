/**
 * tests/cognitive-workspace-tools.test.ts
 * Phase 11.3 — ToolOrchestrator unit tests
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  getToolOrchestrator,
  runToolsForQuestion,
  runCognitiveWorkspace,
} from "../src/lib/omega/cognitiveWorkspace/index.ts";

describe("Tool Orchestrator (Phase 11.3)", () => {
  it("plans symbolic_cas for a derivative question", () => {
    const orch = getToolOrchestrator();
    const plan = orch.plan("احسب مشتقة x^2 + 3x");
    assert.equal(plan.primaryTool, "symbolic_cas");
    assert.ok(plan.confidence >= 0.9);
  });

  it("plans code_sandbox for an execute-code question", () => {
    const orch = getToolOrchestrator();
    const plan = orch.plan("نفذ كود JavaScript يحسب مجموع الأعداد من 1 إلى 10");
    assert.equal(plan.primaryTool, "code_sandbox");
  });

  it("runs calculator / CAS on a simple expression (local, no network)", async () => {
    const result = await runToolsForQuestion("بسّط 2+2*3", {
      maxToolCalls: 2,
      offlineOnly: true,
      perToolTimeoutMs: 5000,
    });

    assert.ok(result.records.length >= 1 || result.plan.primaryTool === "symbolic_cas");
    // At least the plan should prefer CAS / calculator path
    assert.ok(
      ["symbolic_cas", "direct_synthesis", "code_sandbox"].includes(
        result.plan.primaryTool
      )
    );
  });

  it("runs code_sandbox on a trivial JS snippet", async () => {
    const codeQ = "نفذ الكود:\n```js\nreturn 1 + 2 + 3;\n```";
    const result = await runToolsForQuestion(codeQ, {
      maxToolCalls: 2,
      offlineOnly: true,
      perToolTimeoutMs: 8000,
    });

    const codeRec = result.records.find((r) => r.toolId === "code_sandbox");
    // Planner should have selected code_sandbox
    assert.equal(result.plan.primaryTool, "code_sandbox");
    if (codeRec) {
      // If executed, it should succeed or report a clear error
      assert.ok(typeof codeRec.success === "boolean");
      assert.ok(typeof codeRec.latencyMs === "number");
    }
  });

  it("respects maxToolCalls = 0", async () => {
    const result = await runToolsForQuestion("احسب 1+1", {
      maxToolCalls: 0,
      offlineOnly: true,
    });
    assert.equal(result.results.length, 0);
    assert.equal(result.records.length, 0);
  });

  it("invoke calculator directly", async () => {
    const orch = getToolOrchestrator();
    const r = await orch.invoke(
      { toolId: "calculator", input: "1+1" },
      { perToolTimeoutMs: 3000 }
    );
    assert.ok(r.toolId === "calculator");
    assert.ok(typeof r.success === "boolean");
    assert.ok(typeof r.latencyMs === "number");
  });
});

describe("Workspace + Tools integration (11.3)", () => {
  it("workspace cycle records tool calls for a math question", async () => {
    const result = await runCognitiveWorkspace({
      userId: "test-ws-tools",
      question: "احسب مشتقة x^3",
      depth: "balanced",
    });

    assert.ok(result.trace);
    const toolsStep = result.trace.steps.find((s) => s.name === "tools");
    // tools step should exist when enableTools is on
    assert.ok(toolsStep, "expected tools step in trace");

    // Confidence evidence or unknowns should mention tools
    const allText = [
      ...result.confidence.evidence,
      ...result.confidence.risk,
      ...result.confidence.unknowns,
    ].join(" ");
    assert.ok(
      /أداة|أدوات|tools|symbolic|CAS/i.test(allText) ||
        result.trace.toolCalls.length >= 0
    );
  });
});
