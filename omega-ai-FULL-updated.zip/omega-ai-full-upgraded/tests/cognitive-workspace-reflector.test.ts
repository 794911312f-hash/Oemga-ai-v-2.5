/**
 * tests/cognitive-workspace-reflector.test.ts
 * Phase 11.5 — Reflector + selfVerify
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  reflectOnAnswer,
  createCognitivePlan,
  configForDepth,
  runCognitiveWorkspace,
  type SynthesisResult,
} from "../src/lib/omega/cognitiveWorkspace/index.ts";

describe("Reflector (Phase 11.5)", () => {
  it("verifies a coherent Arabic answer", async () => {
    const { plan } = createCognitivePlan({
      question: "ما هو قانون نيوتن الثاني؟",
      depth: "balanced",
      config: configForDepth("balanced"),
    });

    const synthesis: SynthesisResult = {
      answer:
        "قانون نيوتن الثاني ينص على أن القوة المحصلة تساوي حاصل ضرب الكتلة في التسارع. الصيغة: F = m a. هذا القانون أساسي في الميكانيكا الكلاسيكية ويصف كيف تتغير حركة الأجسام تحت تأثير القوى.",
      method: "core_only",
      sourceClass: "real",
      notes: [],
      injectedSections: [],
    };

    const result = await reflectOnAnswer({
      question: "ما هو قانون نيوتن الثاني؟",
      answer: synthesis.answer,
      plan,
      synthesis,
      tools: null,
      depth: "balanced",
    });

    assert.ok(result.verification);
    assert.ok(typeof result.verified === "boolean");
    assert.ok(Array.isArray(result.notes));
    assert.ok(result.notes.length >= 1);
    // Coherent answer should not be marked as contradiction
    assert.equal(result.verification.hasContradiction, false);
  });

  it("flags empty or tiny answers", async () => {
    const { plan } = createCognitivePlan({
      question: "اشرح النظرية النسبية بالتفصيل",
      depth: "deep",
      config: configForDepth("deep"),
    });

    const synthesis: SynthesisResult = {
      answer: "نعم.",
      method: "plan_placeholder",
      sourceClass: "failed",
      notes: [],
      injectedSections: [],
    };

    const result = await reflectOnAnswer({
      question: "اشرح النظرية النسبية بالتفصيل",
      answer: synthesis.answer,
      plan,
      synthesis,
      depth: "deep",
    });

    assert.ok(result.notes.some((n) => n.severity === "error" || n.severity === "warn"));
    assert.ok(result.confidenceDelta <= 0);
  });

  it("appends honesty footer on balanced depth when issues exist", async () => {
    const { plan } = createCognitivePlan({
      question: "موضوع معقد يحتاج تفصيلاً",
      depth: "balanced",
      config: configForDepth("balanced"),
    });

    const synthesis: SynthesisResult = {
      answer: "قصير",
      method: "memory_fallback",
      sourceClass: "simulated",
      notes: [],
      injectedSections: [],
    };

    const result = await reflectOnAnswer({
      question: "موضوع معقد يحتاج تفصيلاً",
      answer: synthesis.answer,
      plan,
      synthesis,
      depth: "balanced",
    });

    // Footer or improved flag when issues
    assert.ok(
      result.improved || result.notes.some((n) => n.severity !== "info")
    );
  });
});

describe("Workspace integration (11.5)", () => {
  it("runs verify_and_reflect step on balanced depth", async () => {
    const result = await runCognitiveWorkspace({
      userId: "test-ws-reflect",
      question: "ما هو قانون الغاز المثالي باختصار؟",
      depth: "balanced",
    });

    const step = result.trace.steps.find(
      (s) => s.name === "verify_and_reflect" || s.name === "verify"
    );
    assert.ok(step, "expected verify/reflect step");

    assert.ok(
      result.confidence.verified === true ||
        result.confidence.verified === false ||
        result.confidence.verified === null
    );

    // Reflection notes may be present on the trace
    assert.ok(Array.isArray(result.trace.reflectionNotes));
  });
});
