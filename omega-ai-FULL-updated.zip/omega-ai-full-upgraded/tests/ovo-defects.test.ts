import { test } from "node:test";
import assert from "node:assert/strict";
import { OmegaDefectDetector, extractDefectFeatures, DEFECT_W, DEFECT_H } from "../src/lib/omega/ovoDefects";
import { runClosedLoop } from "../src/lib/omega/ovoActuation";

const N = DEFECT_W * DEFECT_H;
function frame(seed: number, opts: { gain?: number; block?: boolean; blur?: boolean; shift?: number } = {}) {
  const f = new Uint8Array(N);
  for (let y = 0; y < DEFECT_H; y++) for (let x = 0; x < DEFECT_W; x++) {
    let v = 120 + 40 * Math.sin((x + seed * 0.2) / 5) + 30 * Math.cos(y / 4) + ((x * 7 + y * 13) % 11) * 2; // texture
    if (opts.blur) v = 120 + 40 * Math.sin((x + seed * 0.2) / 5) + 30 * Math.cos(y / 4) + 10; // texture removed
    if (opts.block && x >= 20 && x < 32 && y >= 10 && y < 20) v = 240;
    v = v * (opts.gain ?? 1) + (opts.shift ?? 0);
    f[y * DEFECT_W + x] = Math.max(0, Math.min(255, Math.round(v)));
  }
  return f;
}
function run(special: (i: number) => Parameters<typeof frame>[1], from = 12, total = 20) {
  const det = new OmegaDefectDetector();
  let prev: Uint8Array | null = null, alarms: string[][] = [];
  for (let i = 0; i < total; i++) {
    const f = frame(i, i >= from ? special(i) : {});
    const m = det.evaluate(extractDefectFeatures(f, prev));
    if (i >= from && m.alarm) alarms.push(m.channels);
    prev = f;
  }
  return alarms.flat();
}

test("clean slowly-moving texture raises no alarm", () => assert.deepEqual(run(() => ({})), []));
test("brightness shift raises luma", () => assert.ok(run(() => ({ shift: -60 })).includes("luma")));
test("local block raises local or change", () => {
  const a = run(() => ({ block: true }));
  assert.ok(a.includes("local") || a.includes("change"));
});
test("texture loss raises detailDrop", () => assert.ok(run(() => ({ blur: true })).includes("detailDrop")));

test("closed loop: defect alarm triggers regeneration with mapped parameters; clean does not", async () => {
  const mk = (bad: boolean) => Array.from({ length: 20 }, (_, i) => {
    const f = frame(i, bad && i >= 12 ? { blur: true } : {});
    return { f };
  });
  const frames = (bad: boolean) => {
    let prev: Uint8Array | null = null;
    return mk(bad).map(({ f }, i) => {
      const d = extractDefectFeatures(f, prev); prev = f;
      return { frameIndex: i + 1, patchEnergies: Array(8).fill(0.125), rawVelocity: 0.3, colorDrift: 0.02, defect: d };
    });
  };
  const videos: Record<string, any[]> = { v0: frames(true), v1: frames(false) };
  let n = 0; const calls: any[] = [];
  const deps = {
    generate: async (req: any) => { calls.push(req); return { id: `v${n}`, videoUrl: `v${n++}`, config: { seed: 9 } } as any; },
    fetchVideo: async (u: string) => Buffer.from(u),
    analyze: async (b: Buffer) => ({ metadata: {} as any, limitations: [], frameObservations: videos[b.toString()] }),
  };
  const r = await runClosedLoop(deps, { prompt: "a cat", cfgScale: 7, numSamplingSteps: 30 });
  assert.equal(calls.length, 2);
  assert.ok(calls[1].cfgScale > 7);
  assert.match(calls[1].prompt, /sharp coherent textures/);
  assert.equal(r.actuated, true);

  n = 0; calls.length = 0; videos.v0 = frames(false);
  const r2 = await runClosedLoop(deps, { prompt: "a cat" });
  assert.equal(calls.length, 1);
  assert.equal(r2.actuated, false);
});
