/**
 * tests/hybrid-evolution.test.ts
 * Basic tests for Omega Hybrid Self-Evolution Engine (Phase 8 + Population)
 */

import { describe, it, beforeEach } from "node:test";
import assert from "node:assert/strict";
import {
  HybridSelfEvolutionEngine,
  getHybridEvolutionEngine,
  resetHybridEvolutionEngine,
} from "../src/lib/omega/hybridSelfEvolution";

describe("HybridSelfEvolutionEngine", () => {
  beforeEach(() => {
    resetHybridEvolutionEngine();
  });

  it("should create engine with default ORPO method", () => {
    const engine = getHybridEvolutionEngine();
    const status = engine.getStatus();

    assert.equal(status.method, "orpo");
    assert.equal(status.generation, 0);
    assert.equal(status.activeAdapters, 0);
    assert.equal(status.isRunning, false);
  });

  it("should allow switching between ORPO and DPO", () => {
    const engine = getHybridEvolutionEngine();

    engine.setPreferenceMethod("dpo");
    assert.equal(engine.getPreferenceMethod(), "dpo");

    engine.setPreferenceMethod("orpo");
    assert.equal(engine.getPreferenceMethod(), "orpo");
  });

  it("should record trajectories and generate preference pairs", () => {
    const engine = getHybridEvolutionEngine();

    for (let i = 0; i < 8; i++) {
      engine.recordTrajectory({
        id: `traj_${i}`,
        task: "احسب مجموع مصفوفة",
        fullTrace: `trace version ${i}`,
        finalAnswer: `answer ${i}`,
        score: 0.4 + i * 0.07,
        latencyMs: 800 + i * 50,
        modelId: "test-model",
        harnessVersion: "v0-base",
        timestamp: Date.now(),
      });
    }

    const status = engine.getStatus();
    assert.ok(status.trajectories >= 8);
    assert.ok(status.preferencePairs >= 0);
  });

  it("accepts only two-sided independently verified preference pairs", () => {
    const engine = getHybridEvolutionEngine();
    const basePair = {
      prompt: "احسب 2+2",
      chosen: "4",
      rejected: "5",
      scoreDiff: 0.7,
      verified: true,
      chosenEvidence: {
        source: "cas" as const,
        proofId: "cas:add:4",
        outcome: true,
        confidence: 0.99,
      },
      rejectedEvidence: {
        source: "tool" as const,
        proofId: "tool:reject:5",
        outcome: false,
        confidence: 0.96,
      },
    };

    assert.equal(engine.recordVerifiedPreferencePair({
      ...basePair,
      rejectedEvidence: undefined,
    }), false);
    assert.equal(engine.recordVerifiedPreferencePair(basePair), true);
    assert.equal(engine.recordVerifiedPreferencePair(basePair), false);
    assert.equal(engine.getStatus().preferencePairs, 1);
  });

  it("should run a full evolution cycle and return a generation report", async () => {
    const engine = getHybridEvolutionEngine({
      preferenceMethod: "orpo",
      loRARank: 8,
      maxPairsPerTraining: 50,
    });

    const fakeEvaluate = async () => ({
      id: "test-bench",
      timestamp: Date.now(),
      generation: 1,
      overallScore: 78.5,
      deltaScore: 2.3,
      status: "improved" as const,
      categories: {},
      totalTests: 7,
      passedTests: 6,
      avgLatencyMs: 950,
      recommendations: ["Test passed"],
    });

    const result = await engine.runEvolutionCycle(fakeEvaluate);

    assert.equal(result.generation, 1);
    assert.ok(["harness", "weights_partial", "hybrid", "memory"].includes(result.target));
    assert.equal(result.method, "orpo");
    assert.ok(typeof result.accepted === "boolean");
    assert.ok(result.benchmarkReport.overallScore > 0);
    assert.ok(result.reason.length > 0);

    const status = engine.getStatus();
    assert.equal(status.generation, 1);
    assert.equal(status.archive.length, 1);
  });

  it("should prevent concurrent evolution cycles", async () => {
    const engine = getHybridEvolutionEngine();

    const fakeEvaluate = async () => ({
      id: "concurrent-test",
      timestamp: Date.now(),
      generation: 1,
      overallScore: 70,
      deltaScore: 0.5,
      status: "stable" as const,
      categories: {},
      totalTests: 5,
      passedTests: 4,
      avgLatencyMs: 1000,
      recommendations: [],
    });

    const p1 = engine.runEvolutionCycle(fakeEvaluate);

    await assert.rejects(
      async () => engine.runEvolutionCycle(fakeEvaluate),
      /قيد التشغيل/
    );

    await p1;
  });

  it("stages a trained adapter instead of claiming an untested inference improvement", async () => {
    const engine = getHybridEvolutionEngine({ maxPairsPerTraining: 50 });
    for (let i = 0; i < 60; i++) {
      engine.recordVerifiedPreferencePair({
        prompt: `math question ${i}`,
        chosen: `correct ${i}`,
        rejected: `incorrect ${i}`,
        scoreDiff: 0.6,
        verified: true,
        chosenEvidence: {
          source: "cas", proofId: `cas-${i}`, outcome: true, confidence: 0.99,
        },
        rejectedEvidence: {
          source: "tool", proofId: `tool-${i}`, outcome: false, confidence: 0.95,
        },
      });
    }

    const originalFetch = globalThis.fetch;
    globalThis.fetch = (async (input: RequestInfo | URL) => {
      const url = String(input);
      if (url === "/api/omega/dspy") {
        return new Response(JSON.stringify({ outputs: { improved_prompt: "verified prompt" } }), { status: 200 });
      }
      return new Response(JSON.stringify({
        success: true,
        adapterId: "test-adapter",
        trainedPairs: 50,
        adapterPath: "/tmp/test-adapter",
        finalLoss: 0.2,
      }), { status: 200 });
    }) as typeof fetch;

    const fakeEvaluate = async () => ({
      id: "base-model-benchmark",
      timestamp: Date.now(),
      generation: 3,
      overallScore: 90,
      deltaScore: 5,
      status: "improved" as const,
      categories: {},
      totalTests: 5,
      passedTests: 5,
      avgLatencyMs: 500,
      recommendations: [],
    });

    try {
      await engine.runEvolutionCycle(fakeEvaluate);
      await engine.runEvolutionCycle(fakeEvaluate);
      const result = await engine.runEvolutionCycle(fakeEvaluate);
      assert.equal(result.target, "hybrid");
      assert.equal(result.adapter?.id, "test-adapter");
      assert.equal(result.accepted, false);
      assert.match(result.reason, /staged|not activated/i);
      assert.equal(engine.getStatus().activeAdapters, 0);
      assert.equal(engine.getStatus().stagedAdapters, 1);
    } finally {
      globalThis.fetch = originalFetch;
    }
  });

  it("should respect safety rollback threshold", async () => {
    const engine = getHybridEvolutionEngine({
      safetyRollbackThreshold: -0.5,
    });

    const badEvaluate = async () => ({
      id: "rollback-test",
      timestamp: Date.now(),
      generation: 1,
      overallScore: 55,
      deltaScore: -3.2,
      status: "regressed" as const,
      categories: {},
      totalTests: 7,
      passedTests: 3,
      avgLatencyMs: 1400,
      recommendations: ["Regression detected"],
    });

    const result = await engine.runEvolutionCycle(badEvaluate);

    assert.equal(result.accepted, false);
    assert.ok(
      result.reason.toLowerCase().includes("roll") ||
        result.reason.includes("رجوع") ||
        result.reason.includes("Rolled") ||
        result.reason.includes("elimination")
    );
  });

  it("should maintain a population and lineage after multiple cycles", async () => {
    const engine = getHybridEvolutionEngine();

    const fakeEvaluate = async () => ({
      id: "pop-test",
      timestamp: Date.now(),
      generation: 1,
      overallScore: 75 + Math.random() * 10,
      deltaScore: (Math.random() - 0.3) * 3,
      status: "improved" as const,
      categories: {},
      totalTests: 7,
      passedTests: 6,
      avgLatencyMs: 1000,
      recommendations: [],
    });

    await engine.runEvolutionCycle(fakeEvaluate);
    await engine.runEvolutionCycle(fakeEvaluate);
    await engine.runEvolutionCycle(fakeEvaluate);

    const population = engine.getPopulation();
    const lineage = engine.getLineage();
    const best = engine.getBestIndividual();

    assert.ok(population.length >= 1);
    assert.ok(lineage.length >= 3);
    assert.ok(best !== null);
    assert.ok(typeof best!.compositeScore === "number");
  });
});
