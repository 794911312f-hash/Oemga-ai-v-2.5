/**
 * Unit tests for consensusEval metrics: AUROC mid-ranks, small-n cohesion contract.
 */
import test from "node:test";
import assert from "node:assert/strict";
import { auroc, binomialSE, wilsonCI, mcnemar } from "../src/lib/omega/consensusEval";
import { computeSpectralConsensus } from "../src/lib/omega/spectralConsensus";

const close = (a: number, b: number, tol = 1e-9) =>
  assert.ok(Math.abs(a - b) <= tol, `expected ${b}, got ${a}`);

test("auroc: perfect separation → 1", () => {
  close(auroc([0, 1, 2, 3], [0, 0, 1, 1]), 1);
});

test("auroc: inverted scores → 0", () => {
  close(auroc([3, 2, 1, 0], [0, 0, 1, 1]), 0);
});

test("auroc: all ties → 0.5", () => {
  close(auroc([1, 1, 1, 1], [0, 1, 0, 1]), 0.5);
});

test("auroc: pairwise tie between pos and neg contributes 0.5 (mid-ranks)", () => {
  // One clear neg (score 0), one clear pos (score 2), one tied pair at score 1 (pos+neg)
  // Without mid-ranks the result depends on sort stability; with mid-ranks it is exact.
  const scores = [0, 1, 1, 2];
  const labels = [0, 1, 0, 1];
  const auc = auroc(scores, labels);
  // Manual: ranks with mid for the two 1's → ranks 1, 2.5, 2.5, 4
  // pos at indices of labels 1: scores 1 and 2 → ranks 2.5 and 4 → sum 6.5
  // nPos=2,nNeg=2 → (6.5 - 2*3/2) / 4 = (6.5-3)/4 = 0.875
  close(auc, 0.875);
});

test("auroc: order of tied labels does not change result", () => {
  const a = auroc([1, 1], [0, 1]);
  const b = auroc([1, 1], [1, 0]);
  close(a, 0.5);
  close(b, 0.5);
});

test("spectral n=2 orthogonal: cohesion << 1 and spectralSufficient=false", () => {
  const res = computeSpectralConsensus([
    [1, 0, 0, 0],
    [0, 1, 0, 0],
  ]);
  assert.equal(res.spectralSufficient, false);
  assert.ok(res.cohesion < 0.5, `got cohesion=${res.cohesion}`);
  assert.equal(res.relaxationTime, Infinity);
});

test("spectral n=2 identical: high cohesion, still spectralSufficient=false", () => {
  const res = computeSpectralConsensus([
    [1, 2, 3],
    [1, 2, 3],
  ]);
  assert.equal(res.spectralSufficient, false);
  assert.ok(res.cohesion > 0.99, `got cohesion=${res.cohesion}`);
});

test("binomialSE: p=0.5 n=100 → 0.05", () => {
  close(binomialSE(0.5, 100), 0.05);
});

test("wilsonCI: contains the MLE and is inside [0,1]", () => {
  const { low, high } = wilsonCI(38, 50);
  assert.ok(low < 0.76 && high > 0.76);
  assert.ok(low >= 0 && high <= 1);
  assert.ok(low < high);
});

test("mcnemar: identical outcomes → chi2=0, p=1 path", () => {
  const a = [true, true, false, false];
  const b = [true, true, false, false];
  const r = mcnemar(a, b);
  assert.equal(r.n10, 0);
  assert.equal(r.n01, 0);
  assert.equal(r.pValue, null); // disc < 5
});

test("mcnemar: clear superiority produces large chi2", () => {
  const a = Array.from({ length: 20 }, (_, i) => i < 15);
  const b = Array.from({ length: 20 }, (_, i) => i < 5);
  // A better on many items
  const r = mcnemar(
    a.map((x, i) => x || (i >= 5 && i < 15)), // more true
    b
  );
  // Just ensure function runs and discordant count is positive
  assert.ok(r.n10 + r.n01 >= 0);
});
