/**
 * SSRF suite for src/server/urlGuard.ts — no network, no extra dependencies.
 * dns.lookup and global fetch are mocked, so every redirect hop and every
 * resolver answer is under the test's control.
 *
 * IPv4-mapped hex forms and DNS-pin behaviour are asserted as required security
 * properties (previously KNOWN-GAP, fixed in urlGuard hardening).
 */
import test, { mock, afterEach, beforeEach } from "node:test";
import assert from "node:assert/strict";
import dns from "node:dns/promises";
import { assertPublicHttpUrl, isPrivateAddress, safeFetch, UnsafeUrlError, setPinnedDispatcherFactory } from "../src/server/urlGuard.ts";

type Answers = Record<string, string[]>;
const PUBLIC = "93.184.216.34";

function mockDns(map: Answers) {
  return mock.method(dns, "lookup", async (host: string) => {
    const a = map[host];
    if (!a) throw Object.assign(new Error("ENOTFOUND"), { code: "ENOTFOUND" });
    return a.map((address) => ({ address, family: address.includes(":") ? 6 : 4 }));
  });
}

afterEach(() => {
  mock.restoreAll();
  setPinnedDispatcherFactory(null);
});

beforeEach(() => {
  ensureTestDispatcher();
});


/**
 * Unit suite always mocks global fetch, so inject a stub dispatcher that
 * still exposes pin intent (dispatcher present) without requiring undici.
 * Integration coverage of real Agent+lookup belongs in a separate live test.
 */
function ensureTestDispatcher(): void {
  setPinnedDispatcherFactory((_addresses) => ({
    close() {},
  }));
}


// ───────────────────────── isPrivateAddress ─────────────────────────
test("isPrivateAddress: IPv4 private/reserved ranges and their boundaries", () => {
  const blocked = [
    "0.0.0.0", "0.255.255.255", "10.0.0.1", "10.255.255.255", "100.64.0.1", "100.127.255.255",
    "127.0.0.1", "127.255.255.254", "169.254.169.254", "172.16.0.0", "172.31.255.255",
    "192.0.0.1", "192.0.2.5", "192.168.0.1", "192.168.255.255", "198.18.0.1", "198.19.255.255",
    "198.51.100.7", "203.0.113.9", "224.0.0.1", "239.255.255.255", "240.0.0.1", "255.255.255.255",
  ];
  for (const ip of blocked) assert.equal(isPrivateAddress(ip), true, `${ip} must be blocked`);

  const allowed = ["8.8.8.8", "1.1.1.1", PUBLIC, "172.15.255.255", "172.32.0.0", "100.63.255.255", "100.128.0.0", "11.0.0.1", "192.169.0.1", "198.20.0.1"];
  for (const ip of allowed) assert.equal(isPrivateAddress(ip), false, `${ip} must be allowed`);
});

test("isPrivateAddress: IPv6 loopback / ULA / link-local / multicast / dotted v4-mapped", () => {
  for (const ip of ["::", "::1", "fc00::1", "fd12:3456::1", "fe80::1", "febf::1", "ff02::1", "::ffff:127.0.0.1", "::ffff:10.0.0.1", "::ffff:169.254.169.254"]) {
    assert.equal(isPrivateAddress(ip), true, `${ip} must be blocked`);
  }
  for (const ip of ["2606:4700:4700::1111", "2001:4860:4860::8888", "::ffff:8.8.8.8"]) {
    assert.equal(isPrivateAddress(ip), false, `${ip} must be allowed`);
  }
});

test("isPrivateAddress: non-IP input is treated as unsafe", () => {
  for (const s of ["", "example.com", "999.1.1.1", "1.2.3", "::gg"]) assert.equal(isPrivateAddress(s), true);
});

// KNOWN-GAP: these encodings reach loopback/metadata but the guard only recognises the dotted ::ffff:a.b.c.d form.
const V6_BYPASS: Array<[string, string]> = [
  ["::ffff:7f00:1", "IPv4-mapped loopback in hex form (what URL() produces for [::ffff:127.0.0.1])"],
  ["::ffff:a9fe:a9fe", "IPv4-mapped 169.254.169.254 in hex form"],
  ["::127.0.0.1", "IPv4-compatible loopback"],
  ["64:ff9b::7f00:1", "NAT64 embedding of 127.0.0.1"],
  ["2002:7f00:1::", "6to4 embedding of 127.0.0.1"],
  ["fec0::1", "deprecated site-local"],
];
for (const [ip, why] of V6_BYPASS) {
  test(`isPrivateAddress blocks ${ip} — ${why}`, () => {
    assert.equal(isPrivateAddress(ip), true);
  });
}

// ───────────────────────── assertPublicHttpUrl ─────────────────────────
test("assertPublicHttpUrl: rejects malformed, non-http schemes, credentials and odd ports", async () => {
  mockDns({ "example.com": [PUBLIC] });
  const bad = [
    "not a url", "", "file:///etc/passwd", "ftp://example.com/", "gopher://example.com/", "javascript:alert(1)",
    "data:text/plain,hi", "http://user:pw@example.com/", "http://user@example.com/",
    "http://example.com:8080/", "https://example.com:22/", "http://example.com:6379/",
  ];
  for (const u of bad) await assert.rejects(() => assertPublicHttpUrl(u), UnsafeUrlError, u);
  await assert.doesNotReject(() => assertPublicHttpUrl("http://example.com:80/"));
  await assert.doesNotReject(() => assertPublicHttpUrl("https://example.com:443/x?y=1#z"));
});

test("assertPublicHttpUrl: local hostnames and every IP literal encoding of loopback/metadata", async () => {
  mockDns({});
  const bad = [
    "http://localhost/", "http://LOCALHOST/", "http://foo.localhost/", "http://svc.internal/",
    "http://127.0.0.1/", "http://127.1/", "http://2130706433/", "http://0x7f000001/", "http://0177.0.0.1/",
    "http://0x7f.0.0.1/", "http://[::1]/", "http://[::]/", "http://0.0.0.0/",
    "http://169.254.169.254/latest/meta-data/", "http://[fd00:ec2::254]/",
    "http://10.0.0.5/", "http://192.168.1.1/", "http://172.16.5.5/",
  ];
  for (const u of bad) await assert.rejects(() => assertPublicHttpUrl(u), UnsafeUrlError, u);
});

// CONFIRMED BYPASS: URL() rewrites [::ffff:127.0.0.1] to [::ffff:7f00:1], which isPrivateAddress() does not recognise.
for (const raw of ["http://[::ffff:127.0.0.1]/", "http://[::ffff:169.254.169.254]/latest/meta-data/", "http://[::ffff:10.0.0.1]/", "http://[::ffff:192.168.1.1]/"]) {
  test(`assertPublicHttpUrl rejects IPv4-mapped IPv6 literal ${raw}`, async () => {
    mockDns({});
    await assert.rejects(() => assertPublicHttpUrl(raw), UnsafeUrlError);
  });
}

test("assertPublicHttpUrl: trailing-dot 'localhost.' is rejected (via resolved 127.0.0.1)", async () => {
  mockDns({ "localhost.": ["127.0.0.1"] });
  await assert.rejects(() => assertPublicHttpUrl("http://localhost./"), UnsafeUrlError);
});

test("assertPublicHttpUrl: hostname resolving to ANY private answer is rejected (mixed A/AAAA)", async () => {
  mockDns({
    "mixed.test": [PUBLIC, "10.1.2.3"],
    "v6.test": ["2606:4700:4700::1111", "::1"],
    "cloud.test": ["169.254.169.254"],
    "ok.test": [PUBLIC, "2606:4700:4700::1111"],
  });
  for (const h of ["mixed.test", "v6.test", "cloud.test"]) {
    await assert.rejects(() => assertPublicHttpUrl(`http://${h}/`), UnsafeUrlError, h);
  }
  await assert.doesNotReject(() => assertPublicHttpUrl("http://ok.test/"));
});

test("assertPublicHttpUrl: unresolvable host and empty answer fail closed", async () => {
  mockDns({ "empty.test": [] });
  await assert.rejects(() => assertPublicHttpUrl("http://nxdomain.test/"), /did not resolve/);
  await assert.rejects(() => assertPublicHttpUrl("http://empty.test/"), /did not resolve/);
});

test("assertPublicHttpUrl: DNS lookup hang/timeout surfaces as an error, not a pass", async () => {
  mock.method(dns, "lookup", async () => { throw Object.assign(new Error("timeout"), { code: "ETIMEOUT" }); });
  await assert.rejects(() => assertPublicHttpUrl("http://slow.test/"), UnsafeUrlError);
});

// ───────────────────────── safeFetch: redirects ─────────────────────────
function mockFetch(handler: (url: string, init: RequestInit) => Response | Promise<Response>) {
  return mock.method(globalThis, "fetch", async (input: any, init: RequestInit = {}) => handler(String(input), init));
}
const redirect = (to: string, status = 302) => new Response(null, { status, headers: { location: to } });

test("safeFetch: public → 302 → private IP is blocked before the second request is sent", async () => {
  mockDns({ "good.test": [PUBLIC] });
  const f = mockFetch((u) => (u.startsWith("http://good.test") ? redirect("http://169.254.169.254/latest/meta-data/") : new Response("SECRET")));
  await assert.rejects(() => safeFetch("http://good.test/"), UnsafeUrlError);
  assert.equal(f.mock.callCount(), 1, "the private target must never be requested");
});

test("safeFetch: every redirect status (301/302/303/307/308) is re-validated", async () => {
  for (const status of [301, 302, 303, 307, 308]) {
    mockDns({ "good.test": [PUBLIC] });
    const f = mockFetch(() => redirect("http://127.0.0.1:80/admin", status));
    await assert.rejects(() => safeFetch("http://good.test/"), UnsafeUrlError, `status ${status}`);
    assert.equal(f.mock.callCount(), 1);
    mock.restoreAll();
  }
});

test("safeFetch: redirect to localhost / file:// / ftp:// / credentials / bad port is blocked", async () => {
  for (const target of ["http://localhost/x", "file:///etc/passwd", "ftp://good.test/x", "http://u:p@good.test/", "http://good.test:6379/", "gopher://good.test/"]) {
    mockDns({ "good.test": [PUBLIC] });
    const f = mockFetch(() => redirect(target));
    await assert.rejects(() => safeFetch("http://good.test/"), UnsafeUrlError, target);
    assert.equal(f.mock.callCount(), 1, target);
    mock.restoreAll();
  }
});

test("safeFetch: redirect to a hostname that resolves private is blocked", async () => {
  mockDns({ "good.test": [PUBLIC], "evil.test": ["10.0.0.9"] });
  const f = mockFetch((u) => (u.includes("good.test") ? redirect("http://evil.test/") : new Response("SECRET")));
  await assert.rejects(() => safeFetch("http://good.test/"), /private\/internal/);
  assert.equal(f.mock.callCount(), 1);
});

test("safeFetch: relative Location is resolved against the current URL and validated", async () => {
  mockDns({ "good.test": [PUBLIC] });
  const seen: string[] = [];
  mockFetch((u) => {
    seen.push(u);
    return seen.length === 1 ? redirect("/next?a=1") : new Response("ok");
  });
  const r = await safeFetch("http://good.test/start");
  assert.equal(await r.text(), "ok");
  assert.deepEqual(seen, ["http://good.test/start", "http://good.test/next?a=1"]);
});

test("safeFetch: protocol-relative Location (//127.0.0.1/) is validated, not followed blindly", async () => {
  mockDns({ "good.test": [PUBLIC] });
  const f = mockFetch(() => redirect("//127.0.0.1/admin"));
  await assert.rejects(() => safeFetch("http://good.test/"), UnsafeUrlError);
  assert.equal(f.mock.callCount(), 1);
});

test("safeFetch: redirect chain limit — 3 hops allowed, the 4th redirect throws", async () => {
  mockDns({ "good.test": [PUBLIC] });
  let n = 0;
  mockFetch(() => redirect(`http://good.test/hop${++n}`));
  await assert.rejects(() => safeFetch("http://good.test/"), /Too many redirects/);
  assert.equal(n, 4, "initial request + 3 followed hops");

  mock.restoreAll();
  mockDns({ "good.test": [PUBLIC] });
  let m = 0;
  mockFetch(() => (++m <= 3 ? redirect(`http://good.test/hop${m}`) : new Response("done")));
  assert.equal(await (await safeFetch("http://good.test/")).text(), "done");
});

test("safeFetch: redirect loop terminates", async () => {
  mockDns({ "a.test": [PUBLIC], "b.test": [PUBLIC] });
  mockFetch((u) => redirect(u.includes("a.test") ? "http://b.test/" : "http://a.test/"));
  await assert.rejects(() => safeFetch("http://a.test/"), /Too many redirects/);
});

test("safeFetch: always requests with redirect:'manual' and preserves caller init (signal/headers)", async () => {
  mockDns({ "good.test": [PUBLIC] });
  const f = mockFetch(() => new Response("ok"));
  const ac = new AbortController();
  await safeFetch("http://good.test/", { headers: { "x-t": "1" }, signal: ac.signal });
  const init = f.mock.calls[0].arguments[1] as RequestInit;
  assert.equal(init.redirect, "manual");
  assert.deepEqual(init.headers, { "x-t": "1" });
  assert.equal(init.signal, ac.signal);
});

test("safeFetch: 3xx without Location, and non-redirect statuses, are returned as-is", async () => {
  mockDns({ "good.test": [PUBLIC] });
  mockFetch(() => new Response(null, { status: 304 }));
  assert.equal((await safeFetch("http://good.test/")).status, 304);
  mock.restoreAll(); mockDns({ "good.test": [PUBLIC] });
  mockFetch(() => new Response("x", { status: 500 }));
  assert.equal((await safeFetch("http://good.test/")).status, 500);
});

test("safeFetch: upstream error / abort propagates (provider failure mode)", async () => {
  mockDns({ "good.test": [PUBLIC] });
  mockFetch(() => { throw Object.assign(new Error("socket hang up"), { code: "ECONNRESET" }); });
  await assert.rejects(() => safeFetch("http://good.test/"), /socket hang up/);

  mock.restoreAll(); mockDns({ "good.test": [PUBLIC] });
  mockFetch((_u, init) => new Promise((_res, rej) => init.signal?.addEventListener("abort", () => rej(init.signal!.reason))));
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(new DOMException("timed out", "TimeoutError")), 50); // ref'd: keeps the loop alive
  await assert.rejects(() => safeFetch("http://good.test/", { signal: ac.signal }), (e: any) => e?.name === "TimeoutError");
  clearTimeout(timer);
});

// ───────────────────────── DNS rebinding ─────────────────────────
test("DNS rebinding: URL keeps hostname; TCP is pinned via undici dispatcher", async () => {
  // Attacker DNS: first answer public (passes validation), second answer private.
  // Pinning must prevent the second lookup from being used for TCP connect —
  // without rewriting the URL (so TLS SNI / cert ALTNAME stay valid).
  let lookups = 0;
  mock.method(dns, "lookup", async () => [{ address: ++lookups === 1 ? PUBLIC : "127.0.0.1", family: 4 }]);
  const f = mockFetch(() => new Response("ok"));
  await safeFetch("http://rebind.test/");
  assert.equal(lookups, 1);
  const target = new URL(String(f.mock.calls[0].arguments[0]));
  const init = f.mock.calls[0].arguments[1] as any;
  assert.equal(target.hostname, "rebind.test", "hostname must stay for SNI/cert validation");
  assert.equal(Boolean(init?.dispatcher) || Boolean(init?.agent), true, "must pin via dispatcher/agent");
});

test("DNS rebinding pin: second DNS answer cannot divert the connection", async () => {
  let lookups = 0;
  mock.method(dns, "lookup", async () => [{ address: ++lookups === 1 ? PUBLIC : "127.0.0.1", family: 4 }]);
  const f = mockFetch(() => new Response("ok"));
  await safeFetch("http://rebind.test/");
  const target = new URL(String(f.mock.calls[0].arguments[0]));
  const init = f.mock.calls[0].arguments[1] as any;
  // Secure: original host + dispatcher, or (legacy) IP literal pin
  const pinned =
    (target.hostname === "rebind.test" && (Boolean(init?.dispatcher) || Boolean(init?.agent))) ||
    target.hostname === PUBLIC;
  assert.equal(pinned, true);
});

test("DNS rebinding on redirect hop: the second hop is re-resolved and re-validated", async () => {
  const calls: Record<string, number> = {};
  mock.method(dns, "lookup", async (h: string) => {
    calls[h] = (calls[h] ?? 0) + 1;
    return [{ address: h === "b.test" ? "10.0.0.1" : PUBLIC, family: 4 }];
  });
  mockFetch((u) => (u.includes("a.test") ? redirect("http://b.test/") : new Response("SECRET")));
  await assert.rejects(() => safeFetch("http://a.test/"), UnsafeUrlError);
  assert.equal(calls["b.test"], 1);
});
