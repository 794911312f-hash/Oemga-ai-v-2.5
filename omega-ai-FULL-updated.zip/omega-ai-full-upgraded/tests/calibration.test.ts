/**
 * tests/calibration.test.ts — Brier & ECE unit checks
 */
import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  brierScore,
  expectedCalibrationError,
  evaluateCalibration,
  fitTemperature,
  applyTemperature,
  calibrateScoreOnHoldout,
} from "../src/lib/omega/calibration.ts";

describe("brierScore", () => {
  it("is 0 for perfect predictions", () => {
    assert.equal(
      brierScore([
        { y: 1, p: 1 },
        { y: 0, p: 0 },
      ]),
      0
    );
  });

  it("is 0.25 for always-0.5 on balanced labels", () => {
    const s = brierScore([
      { y: 1, p: 0.5 },
      { y: 0, p: 0.5 },
    ]);
    assert.ok(Math.abs(s - 0.25) < 1e-9);
  });
});

describe("ECE", () => {
  it("is ~0 when p matches y in two bins", () => {
    const pairs = [
      { y: 1 as const, p: 0.9 },
      { y: 1 as const, p: 0.95 },
      { y: 0 as const, p: 0.05 },
      { y: 0 as const, p: 0.1 },
    ];
    const { ece } = expectedCalibrationError(pairs, 10);
    assert.ok(ece < 0.15);
  });
});

describe("evaluateCalibration", () => {
  it("flags overconfidence when p high and y low", () => {
    const r = evaluateCalibration([
      { y: 0, p: 0.9 },
      { y: 0, p: 0.95 },
      { y: 0, p: 0.85 },
    ]);
    assert.ok(r.confidenceGap > 0.5);
    assert.ok(r.brier > 0.5);
  });
});


describe("temperature scaling", () => {
  it("T=1 leaves p nearly unchanged", () => {
    const p = applyTemperature(0.8, 1);
    assert.ok(Math.abs(p - 0.8) < 1e-6);
  });

  it("T>1 pulls extreme p toward 0.5", () => {
    const p = applyTemperature(0.95, 3);
    assert.ok(p < 0.95 && p > 0.5);
  });

  it("fitTemperature prefers softer T on overconfident train", () => {
    const train = [
      { y: 0 as const, p: 0.9 },
      { y: 0 as const, p: 0.85 },
      { y: 1 as const, p: 0.9 },
      { y: 0 as const, p: 0.8 },
    ];
    const { T } = fitTemperature(train);
    assert.ok(T > 1, `expected T>1, got ${T}`);
  });

  it("holdout calibration keeps accuracy fixed", () => {
    const train = [
      { y: 1 as const, p: 0.9 },
      { y: 0 as const, p: 0.8 },
      { y: 1 as const, p: 0.7 },
      { y: 0 as const, p: 0.75 },
    ];
    const holdout = [
      { y: 1 as const, p: 0.88 },
      { y: 0 as const, p: 0.82 },
    ];
    const r = calibrateScoreOnHoldout(train, holdout, { claimEligible: false });
    assert.equal(r.rawHoldout.accuracy, r.calibratedHoldout.accuracy);
    assert.equal(r.claimEligible, false);
  });
});
