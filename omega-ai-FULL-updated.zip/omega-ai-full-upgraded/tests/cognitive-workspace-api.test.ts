/**
 * tests/cognitive-workspace-api.test.ts
 * Phase 11.7 — Workspace API (unit-level: planner + module presence)
 *
 * Full HTTP tests require a running server; here we validate the route module
 * exports and that plan/run still work from the library side with the same
 * contracts the HTTP layer uses.
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  createCognitivePlan,
  configForDepth,
  runCognitiveWorkspace,
} from "../src/lib/omega/cognitiveWorkspace/index.ts";
import { registerWorkspaceRoutes } from "../src/server/workspaceRoutes.ts";

describe("Workspace API module (Phase 11.7)", () => {
  it("exports registerWorkspaceRoutes", () => {
    assert.equal(typeof registerWorkspaceRoutes, "function");
  });

  it("plan contract matches HTTP /workspace/plan shape", () => {
    const depth = "balanced" as const;
    const question = "ما هو قانون نيوتن الثاني؟";
    const { plan, domainRoute } = createCognitivePlan({
      question,
      depth,
      config: configForDepth(depth),
    });

    const payload = {
      ok: true,
      userId: "guest-user",
      plan,
      domain: domainRoute.domain,
      models: domainRoute.models,
      matchedKeywords: domainRoute.matchedKeywords,
      sourceClass: "real",
    };

    assert.equal(payload.ok, true);
    assert.ok(payload.plan.tasks.length >= 3);
    assert.ok(Array.isArray(payload.models));
  });

  it("full run returns workspaceId for trace lookup", async () => {
    const result = await runCognitiveWorkspace({
      userId: "api-test-user",
      question: "اشرح الغاز المثالي باختصار",
      depth: "fast",
    });

    assert.ok(result.trace.workspaceId);
    assert.ok(result.trace.workspaceId.startsWith("ws_"));
    assert.ok(typeof result.answer === "string");
    assert.ok(result.confidence);
  });
});
