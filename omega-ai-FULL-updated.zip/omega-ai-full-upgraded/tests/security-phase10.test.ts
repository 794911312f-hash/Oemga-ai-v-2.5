/**
 * tests/security-phase10.test.ts
 * Path registration checks after modular route extraction.
 */
import { describe, it } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

describe("security-phase10 modular routes", () => {
  it("hybrid-evolution routes live in src/server/routes/hybridEvolutionRoutes.ts", () => {
    const routeFile = path.join(
      root,
      "src/server/routes/hybridEvolutionRoutes.ts"
    );
    assert.ok(fs.existsSync(routeFile), "hybridEvolutionRoutes.ts must exist");
    const body = fs.readFileSync(routeFile, "utf-8");
    assert.match(body, /hybrid-evolution|hybridEvolution|promote/i);

    // Must not require the paths to still be only in monolithic server.ts
    const serverPath = path.join(root, "server.ts");
    if (fs.existsSync(serverPath)) {
      const server = fs.readFileSync(serverPath, "utf-8");
      const hasRegister =
        /registerModularRoutes|hybridEvolutionRoutes|from ["'].*routes/.test(
          server
        );
      // Either modular registration or routes file is authoritative
      assert.ok(
        hasRegister || body.length > 50,
        "server should register modular routes or routes file carries handlers"
      );
    }
  });
});
