/**
 * tests/psi-sensitivity.test.ts
 * حساسية Ψ — تُختبر الآن الدوال الإنتاجية نفسها من src/lib/omega/psi.ts.
 * قبل الإصلاح كان الملف يعيد تعريف الصيغة محليًا (psiFamily) فلا يلمس الكود المُنتَج.
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { computePsiAffine, computeOmegaV2Psi, psiDivergence } from "../src/lib/omega/psi.ts";
import { clipExpPsi } from "../src/lib/omega/math.ts";

describe("Ψ — المسار التوافقي (computePsiAffine)", () => {
  it("زيادة alpha تُليّن العقوبة عند delta و sigma ثابتين", () => {
    assert.ok(computePsiAffine(0.3, 0.2, 2.0, 0.05) >= computePsiAffine(0.3, 0.2, 1.0, 0.05));
  });

  it("زيادة beta ترفع Ψ لنفس delta", () => {
    assert.ok(computePsiAffine(0.4, 0.1, 1.5, 0.1) >= computePsiAffine(0.4, 0.1, 1.5, 0.01));
  });

  it("math.ts::clipExpPsi يفوّض إلى نفس الدالة بالحرف (لا صيغة مكرّرة)", () => {
    for (const sigma of [0, 0.05, 0.2, 1.15]) {
      for (const delta of [0, 0.01, 0.3, 1, 3]) {
        assert.strictEqual(clipExpPsi(delta, sigma), computePsiAffine(delta, sigma, 1.5, 0.05));
      }
    }
  });

  it("ترتيب delta محفوظ على شبكة alpha × beta", () => {
    for (const alpha of [1.0, 1.5, 2.0]) {
      for (const beta of [0.01, 0.05, 0.1]) {
        assert.ok(computePsiAffine(0.1, 0.2, alpha, beta) >= computePsiAffine(0.4, 0.2, alpha, beta));
      }
    }
  });
});

describe("Ψ — المسار القياسي (computeOmegaV2Psi)", () => {
  it("غير متزايدة في delta لـ sigma ثابت", () => {
    for (const sigma of [0.05, 0.2, 1.15]) {
      let prev = computeOmegaV2Psi(0, sigma);
      for (let d = 0.05; d <= 3; d += 0.05) {
        const cur = computeOmegaV2Psi(d, sigma);
        assert.ok(cur <= prev + 1e-15, "psi(" + d + ")=" + cur + " > " + prev);
        prev = cur;
      }
    }
  });

  it("محصورة في [psiMin, psiMax] بما فيها sigma = 0", () => {
    for (const sigma of [0, 1e-12, 0.01, 0.5, 2]) {
      for (const d of [0, 0.1, 0.5, 1, 5, 100]) {
        const p = computeOmegaV2Psi(d, sigma);
        assert.ok(p >= 0.05 && p <= 0.99, "p=" + p);
      }
    }
  });

  it("زيادة p تُشدّد الاضمحلال عند d/sigma > 1", () => {
    const d = 1.5 * 1.15;
    assert.ok(computeOmegaV2Psi(d, 1.15, 1.2, 2) < computeOmegaV2Psi(d, 1.15, 1.2, 1));
  });

  it("زيادة c تُشدّد الاضمحلال", () => {
    assert.ok(computeOmegaV2Psi(1.15, 1.15, 2.0) < computeOmegaV2Psi(1.15, 1.15, 0.6));
  });
});

describe("فرق الصيغتين موثّق ومقيس (سبب الإصلاح)", () => {
  it("عند sigma=1.15 و d/sigma=1 يبلغ الفرق ~22 نقطة مئوية", () => {
    const g = Math.abs(psiDivergence(1.15, 1.15).gapPoints);
    assert.ok(g > 18 && g < 26, "gapPoints=" + g);
  });

  it("الفرق الأقصى على الشبكة يتجاوز 30 نقطة مئوية", () => {
    let max = 0;
    for (const s of [0.2, 0.5, 1.15, 2]) {
      for (const r of [0.25, 0.5, 1, 1.5, 2, 3]) {
        max = Math.max(max, Math.abs(psiDivergence(r * s, s).gapPoints));
      }
    }
    assert.ok(max > 30, "max gap=" + max);
  });

  it("الصيغتان غير متكافئتين (لا يجوز استخدام إحداهما مكان الأخرى)", () => {
    assert.ok(Math.abs(psiDivergence(1.15, 1.15).gapPoints) > 0);
  });
});
