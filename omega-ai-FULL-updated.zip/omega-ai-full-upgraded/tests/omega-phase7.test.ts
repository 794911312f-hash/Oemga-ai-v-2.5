import assert from "node:assert/strict";
import { execFile } from "node:child_process";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { promisify } from "node:util";
import { test } from "node:test";
import { isPrivilegedRequest, sanitizeUserId, validateSecretInput } from "../src/server/security";
import { globalSymPyLeanBridge } from "../src/lib/omega/sympyLeanBridge";
import { globalOmegaVideoOptimizer } from "../src/lib/omega/ovoEngine";
import { analyzeVideoBuffer, decodeVideoBase64 } from "../src/lib/omega/videoProbe";

const execFileAsync = promisify(execFile);

test("security helpers reject unsafe identity and secret inputs", () => {
  assert.equal(sanitizeUserId("alice_01"), "alice_01");
  assert.equal(sanitizeUserId("../../admin"), "guest-user");
  assert.equal(validateSecretInput("or-test-key"), "or-test-key");
  assert.equal(validateSecretInput("bad\nkey"), null);
  assert.equal(validateSecretInput(""), null);
});

test("OVO labels synthetic and measured telemetry correctly", () => {
  const synthetic = globalOmegaVideoOptimizer.runInferenceOptimizationLoop({ prompt: "regression", numSteps: 6 });
  assert.equal(synthetic.measurement.source, "synthetic");
  assert.equal(synthetic.measurement.input, "synthetic_scenario");
  assert.equal(synthetic.stepsTrace.length, 6);

  const measured = globalOmegaVideoOptimizer.runInferenceOptimizationLoop({
    prompt: "measured",
    frameObservations: [
      { patchEnergies: [0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1], rawVelocity: 0.1 },
      { patchEnergies: [0.2, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1], rawVelocity: 0.4 },
    ],
  });
  assert.equal(measured.measurement.source, "measured");
  assert.equal(measured.measurement.framesReceived, 2);
  assert.equal(measured.stepsTrace.length, 2);
  assert.ok(measured.measurement.limitations.length > 0);
});

test("SymPy/Lean bridge reports heuristic mode without a Lean kernel", async () => {
  const result = await globalSymPyLeanBridge.solveAndVerify("x + 1", "demo", "theorem demo : x + 1 = x + 1", ["rfl"]);
  assert.equal(result.leanTheorem.verificationMode, "heuristic");
  assert.equal(result.leanTheorem.kernelVerified, false);
  assert.ok(result.overallScore < 1);
});

test("ffprobe/ffmpeg video probe produces measured OVO observations", async () => {
  const dir = await mkdtemp(join(tmpdir(), "omega-test-"));
  const fixture = join(dir, "fixture.mp4");
  try {
    await execFileAsync("ffmpeg", ["-v", "error", "-f", "lavfi", "-i", "testsrc2=size=96x64:rate=6", "-t", "1", "-pix_fmt", "yuv420p", "-c:v", "libx264", "-y", fixture]);
    const result = await analyzeVideoBuffer(await readFile(fixture), 4);
    assert.equal(result.metadata.codec, "h264");
    assert.equal(result.metadata.width, 96);
    assert.equal(result.metadata.height, 64);
    assert.ok(result.frameObservations.length > 0);
    assert.ok(result.frameObservations[0].patchEnergies?.length === 8);
    assert.ok(result.limitations.length >= 2);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test("video base64 decoder rejects malformed payloads", () => {
  assert.throws(() => decodeVideoBase64("not base64 %%"), /Invalid base64/);
  assert.throws(() => decodeVideoBase64(undefined), /must be a string/);
});

test("privileged request detection only accepts administrative claims", () => {
  assert.equal(isPrivilegedRequest({ user: { role: "admin" } } as any), true);
  assert.equal(isPrivilegedRequest({ user: { isGuest: true } } as any), false);
});
