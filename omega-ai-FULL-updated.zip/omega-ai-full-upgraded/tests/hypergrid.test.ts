/**
 * tests/hypergrid.test.ts — Hyper-Grid Arabic routing
 */
import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  DistillationEngine,
  HyperGridRouter,
  normalizeArabic,
} from "../src/lib/omega/neuralSymbolicHyperGrid.ts";

describe("normalizeArabic", () => {
  it("strips tashkeel and unifies letters", () => {
    assert.equal(normalizeArabic("حلّ"), "حل");
    assert.equal(normalizeArabic("معادلة"), "معادله");
    assert.ok(normalizeArabic("أثبت").includes("ا"));
  });
});

describe("HyperGridRouter symbolic preference", () => {
  const router = new HyperGridRouter();

  it("should prefer symbolic path for math questions", () => {
    const cases = [
      "حل المعادلة x^2-4=0 وبسط النتيجة",
      "وحل المعادلة التالية",
      "هل يمكنك حلّ المعادلة؟",
      "احسب محدد المصفوفة",
    ];
    for (const q of cases) {
      const d = router.decide({ question: q });
      assert.equal(
        d.primaryPath,
        "symbolic",
        `expected symbolic for: ${q} got ${d.primaryPath} (${d.reason})`
      );
    }
  });

  it("does not treat تحليل as حل", () => {
    const d = router.decide({ question: "اشرح لي تحليل الأسواق" });
    assert.notEqual(
      d.primaryPath,
      "symbolic",
      `تحليل must not route symbolic: ${d.reason}`
    );
  });
});

describe("verified symbolic-to-neural distillation", () => {
  const distiller = new DistillationEngine();
  const chosenEvidence = {
    source: "cas" as const,
    proofId: "cas:chosen:1",
    outcome: true,
    confidence: 0.99,
  };
  const rejectedEvidence = {
    source: "tool" as const,
    proofId: "tool:rejected:1",
    outcome: false,
    confidence: 0.95,
  };

  it("refuses a pair if the rejected answer was merely not verified", async () => {
    const result = await distiller.distillSymbolicToNeural("q", "correct", "unknown", {
      symbolicEvidence: chosenEvidence,
    });
    assert.equal(result.success, false);
    assert.match(result.message, /independent proof|positive and negative verification|positive|negative/i);
  });

  it("builds an evidence-weighted margin independent of answer length", async () => {
    const short = await distiller.distillSymbolicToNeural("q", "yes", "no", {
      symbolicEvidence: chosenEvidence,
      neuralEvidence: rejectedEvidence,
    });
    const long = await distiller.distillSymbolicToNeural("q", "yes ".repeat(100), "no ".repeat(200), {
      symbolicEvidence: chosenEvidence,
      neuralEvidence: rejectedEvidence,
    });
    assert.equal(short.success, true);
    assert.equal(long.success, true);
    assert.equal(
      short.distilledArtifact?.content.scoreDiff,
      long.distilledArtifact?.content.scoreDiff
    );
    assert.equal(short.distilledArtifact?.content.verified, true);
  });
});
