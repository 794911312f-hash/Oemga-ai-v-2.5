/**
 * Phase 12.0 — Core Bridge unit tests
 */

import { describe, it, beforeEach } from "node:test";
import assert from "node:assert/strict";
import {
  registerCoreRunner,
  clearCoreRunner,
  runBoundCore,
  getCoreBridgeStatus,
  normalizeCoreResponse,
  runCognitiveWorkspace,
} from "../src/lib/omega/cognitiveWorkspace/index.ts";

describe("Core Bridge (Phase 12.0)", () => {
  beforeEach(() => {
    clearCoreRunner();
  });

  it("reports unwired status by default", () => {
    const s = getCoreBridgeStatus();
    assert.equal(s.wired, false);
    assert.equal(s.label, "unregistered");
  });

  it("runBoundCore returns null when not registered", async () => {
    const r = await runBoundCore({
      userId: "t",
      question: "test",
    });
    assert.equal(r, null);
  });

  it("uses registered runner", async () => {
    registerCoreRunner(async (req) => {
      return {
        answer: `echo:${req.question}`,
        candidates: [
          {
            modelId: "gemini-3.8-flash" as any,
            text: `echo:${req.question}`,
            simulated: false,
            psi: 0.9,
          },
        ],
        sourceClass: "real",
        psi: 0.9,
        verified: true,
      };
    }, "test-runner");

    const s = getCoreBridgeStatus();
    assert.equal(s.wired, true);
    assert.equal(s.label, "test-runner");

    const r = await runBoundCore({ userId: "u", question: "hello" });
    assert.ok(r);
    assert.equal(r!.answer, "echo:hello");
    assert.equal(r!.sourceClass, "real");
  });

  it("normalizeCoreResponse maps ensembleMode", () => {
    const n = normalizeCoreResponse({
      answer: "x",
      candidates: [{ modelId: "m", text: "x", simulated: false }],
      ensembleMode: "real_multi_provider",
      psi: 0.8,
      verified: true,
    });
    assert.equal(n.sourceClass, "real");
    assert.equal(n.psi, 0.8);
    assert.equal(n.verified, true);
  });

  it("workspace uses bridge when registered", async () => {
    registerCoreRunner(async (req) => ({
      answer: `core-says: ${req.question.slice(0, 40)}`,
      candidates: [
        {
          modelId: "gemini-3.8-flash" as any,
          text: "c",
          simulated: false,
          psi: 0.85,
        },
      ],
      sourceClass: "real",
      psi: 0.85,
      verified: null,
    }), "ws-test");

    const result = await runCognitiveWorkspace({
      userId: "bridge-user",
      question: "ما هو قانون نيوتن؟",
      depth: "fast",
    });

    assert.ok(result.answer.includes("core-says") || result.answer.length > 5);
    const reason = result.trace.steps.find((s) => s.name === "reason");
    assert.ok(reason);
    // Should not warn about unregistered when bridge is set
    assert.ok(reason!.status === "ok" || reason!.status === "warn");
  });
});
