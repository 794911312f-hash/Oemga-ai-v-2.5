import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { completeWithModel } from "../src/lib/omega/providers";

const userMessage = [{ role: "user" as const, content: "Hello" }];

describe("Omega open-weight provider", () => {
  it("returns the actual server-backed completion and metadata", async () => {
    const previousFetch = globalThis.fetch;
    globalThis.fetch = (async () => new Response(JSON.stringify({
      ok: true,
      text: "Local model answer",
      provider: "Omega Open-Weight Cortex (test-model)",
      verificationState: "unverified",
      omegaControl: { complexity: 0.4, temperature: 0.3, maxTokens: 700, verificationMode: "consistency", independentAuditRecommended: false },
    }), { status: 200 })) as typeof fetch;
    try {
      const result = await completeWithModel("omega-open-local", userMessage);
      assert.equal(result.ok, true);
      if (result.ok) {
        assert.equal(result.text, "Local model answer");
        assert.equal(result.provider, "Omega Open-Weight Cortex (test-model)");
        assert.equal(result.verificationState, "unverified");
      }
    } finally {
      globalThis.fetch = previousFetch;
    }
  });

  it("fails closed instead of returning a synthetic perspective when the runtime is down", async () => {
    const previousFetch = globalThis.fetch;
    globalThis.fetch = (async () => new Response(JSON.stringify({ ok: false, error: "runtime offline" }), { status: 503 })) as typeof fetch;
    try {
      const result = await completeWithModel("omega-open-local", userMessage);
      assert.equal(result.ok, false);
      if (!result.ok) assert.match(result.error, /runtime offline/);
    } finally {
      globalThis.fetch = previousFetch;
    }
  });
});
