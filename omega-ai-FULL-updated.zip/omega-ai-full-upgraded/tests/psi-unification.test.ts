/**
 * tests/psi-unification.test.ts
 * حارس إصلاح توحيد Ψ: يمنع عودة التعريفات المحلية المتنكّرة، ويثبّت أن كل
 * مستهلك يستدعي الدالة نفسها (هوية مرجعية واحدة).
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { computeOmegaV2Psi as fromPsi, PSI_SOURCE_OF_TRUTH } from "../src/lib/omega/psi.ts";
import { computeOmegaV2Psi as fromOvoEngine } from "../src/lib/omega/ovoEngine.ts";

const here = dirname(fileURLToPath(import.meta.url));
const OMEGA_DIR = join(here, "..", "src", "lib", "omega");

function tsFiles(dir: string): string[] {
  return readdirSync(dir, { withFileTypes: true }).flatMap((e) =>
    e.isDirectory()
      ? tsFiles(join(dir, e.name))
      : e.name.endsWith(".ts") && !e.name.endsWith(".d.ts")
      ? [join(dir, e.name)]
      : []
  );
}

describe("حارس توحيد Ψ", () => {
  const files = tsFiles(OMEGA_DIR);

  it("تعريف واحد فقط لكل دالة Ψ داخل src/lib/omega", () => {
    const defs: Record<string, string[]> = {};
    for (const f of files) {
      const txt = readFileSync(f, "utf8");
      for (const name of ["computeOmegaV2Psi", "computePsiAffine", "clipExpPsi"]) {
        const hits = txt.match(new RegExp("(export )?function\\s+" + name + "\\b", "g")) || [];
        if (hits.length) {
          if (!defs[name]) defs[name] = [];
          defs[name].push(f.replace(OMEGA_DIR, "") + " x" + hits.length);
        }
      }
    }
    assert.strictEqual((defs["computeOmegaV2Psi"] || []).length, 1, "تعريفات: " + JSON.stringify(defs));
    assert.strictEqual((defs["computePsiAffine"] || []).length, 1, "تعريفات: " + JSON.stringify(defs));
    assert.strictEqual((defs["clipExpPsi"] || []).length, 1, "تعريفات: " + JSON.stringify(defs));
  });

  it("mediaOrchestrator لم يعد يعرّف Ψ محليًا ويستورد الموحّد", () => {
    const src = readFileSync(join(OMEGA_DIR, "mediaOrchestrator.ts"), "utf8");
    assert.ok(!/function\s+clipExpPsi\b/.test(src), "لا يجوز أن يعود التعريف المحلي");
    assert.ok(/from "\.\/psi(\.ts)?"/.test(src), "يجب أن يستورد من ./psi");
    assert.ok(src.includes("computeOmegaV2Psi(mismatch)"), "يجب أن يستخدم الدالة الموحّدة");
  });

  it("ovoEngine يعيد تصدير نفس الدالة (هوية مرجعية واحدة، لا نسخة)", () => {
    assert.strictEqual(fromOvoEngine, fromPsi);
  });

  it("القيم متطابقة على شبكة كاملة بين المصدرين", () => {
    for (const s of [0.2, 0.5, 1.15, 2]) {
      for (const d of [0, 0.1, 0.575, 1.15, 2.3]) {
        assert.strictEqual(fromOvoEngine(d, s), fromPsi(d, s));
      }
    }
  });

  it("PSI_SOURCE_OF_TRUTH يشير إلى الملف الموحّد", () => {
    assert.strictEqual(PSI_SOURCE_OF_TRUTH, "src/lib/omega/psi.ts");
  });
});
