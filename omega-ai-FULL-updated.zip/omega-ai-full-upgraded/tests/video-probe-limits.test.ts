import { test } from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { analyzeVideoBuffer, MAX_VIDEO_BYTES } from "../src/lib/omega/videoProbe";

test("rejects buffers above MAX_VIDEO_BYTES before touching ffmpeg", async () => {
  await assert.rejects(analyzeVideoBuffer(Buffer.alloc(MAX_VIDEO_BYTES + 1)), /analysis limit/);
});

test("a phone-sized (>12 MB, 1080p) clip is analysed directly", async () => {
  const dir = mkdtempSync(join(tmpdir(), "probe-lim-"));
  try {
    const out = join(dir, "big.mp4");
    execFileSync("ffmpeg", ["-v", "error", "-y", "-f", "lavfi", "-i", "testsrc2=s=1920x1080:r=30:d=6",
      "-vf", "noise=alls=30:allf=t", "-c:v", "libx264", "-preset", "ultrafast", "-b:v", "25M", "-maxrate", "25M", "-bufsize", "25M", out]);
    const buf = readFileSync(out);
    assert.ok(buf.length > 12 * 1024 * 1024, `fixture is ${buf.length} bytes`);
    const r = await analyzeVideoBuffer(buf, 24);
    assert.ok(r.frameObservations.length >= 10);
    assert.ok(r.frameObservations.every((o) => o.defect));
    assert.equal(r.metadata.width, 1920);
  } finally { rmSync(dir, { recursive: true, force: true }); }
});
