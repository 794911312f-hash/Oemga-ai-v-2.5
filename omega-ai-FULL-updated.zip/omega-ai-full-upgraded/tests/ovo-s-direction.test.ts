import { test } from "node:test";
import assert from "node:assert/strict";
import { OmegaFrameController } from "../src/lib/omega/ovoEngine";

function warm(c: OmegaFrameController, base: number[]) {
  for (let t = 1; t <= 10; t++) c.evaluateFrame(t, base.map((x) => x * (1 + 0.01 * Math.sin(t))));
}
const uniform = (L: number) => Array(L).fill(1 / L);
const concentrated = (L: number) => {
  const a = Array(L).fill(0.04 / (L - 2));
  a[0] = 0.5; a[1] = 0.46;
  return a;
};

for (const L of [8, 64]) {
  test(`S > 0 and ω rises when energy concentrates (L=${L})`, () => {
    const c = new OmegaFrameController();
    warm(c, uniform(L));
    const m = c.evaluateFrame(11, concentrated(L));
    assert.ok(m.geometricShiftScoreS > 0.3);
    assert.ok(m.omegaBlendWeight > 0.3);
    assert.equal(m.stationaryRegime, false);
  });

  test(`negative S (uniformization) is silent: ω at base, regime stationary (L=${L})`, () => {
    const c = new OmegaFrameController();
    const mild = uniform(L).map((_, i) => (i < L / 2 ? 1.5 : 0.5) / L);
    warm(c, mild);
    const m = c.evaluateFrame(11, uniform(L));
    assert.ok(m.geometricShiftScoreS < -0.08);
    assert.equal(m.omegaBlendWeight, 0.15);
    assert.equal(m.stationaryRegime, true, "negative S must not be reported as non-stationary");
  });

  test(`KL and entropy channels are the same signal: dKl = ln(L)·dH (L=${L})`, () => {
    const c = new OmegaFrameController();
    warm(c, uniform(L));
    const m = c.evaluateFrame(11, concentrated(L));
    assert.ok(Math.abs(m.dKl - Math.log(L) * m.dH) < 2e-3);
  });
}

test("S is invariant to global energy scale (blur/gain that scales all patches equally is invisible)", () => {
  const a = new OmegaFrameController(), b = new OmegaFrameController();
  warm(a, uniform(16)); warm(b, uniform(16));
  const ev = concentrated(16);
  assert.equal(
    a.evaluateFrame(11, ev).geometricShiftScoreS,
    b.evaluateFrame(11, ev.map((x) => x * 0.2)).geometricShiftScoreS,
  );
});
