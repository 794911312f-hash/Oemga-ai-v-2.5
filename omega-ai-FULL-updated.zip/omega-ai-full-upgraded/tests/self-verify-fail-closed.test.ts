import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { algorithmicVerification } from "../src/lib/omega/selfVerify.ts";

describe("self verification fail-closed behavior", () => {
  it("does not call a plausible answer verified without external proof", () => {
    const result = algorithmicVerification(
      "What is the capital of France?",
      "The capital of France is Paris.",
      "test-model" as any
    );
    assert.equal(result.verified, false);
    assert.equal(result.verificationType, "heuristic_consistency");
    assert.ok(result.warnings.some((warning) => warning.includes("لا يوجد إثبات")));
  });

  it("does not equate verbosity with higher verification", () => {
    const concise = algorithmicVerification("q", "A concise factual claim.", "test-model" as any);
    const verbose = algorithmicVerification("q", "A factual claim. ".repeat(100), "test-model" as any);
    assert.equal(concise.verified, false);
    assert.equal(verbose.verified, false);
    assert.equal(concise.score, verbose.score);
  });
});
