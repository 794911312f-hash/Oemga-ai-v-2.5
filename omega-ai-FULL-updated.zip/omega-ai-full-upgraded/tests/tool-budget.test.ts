/**
 * Tool cost budget + selectWithinBudget (MATH-SECURITY-ROADMAP A1).
 */
import test from "node:test";
import assert from "node:assert/strict";
import {
  TOOL_COST,
  toolCost,
  selectWithinBudget,
  type ToolInvocation,
} from "../src/lib/omega/cognitiveWorkspace/toolOrchestrator";

test("TOOL_COST: code_sandbox is most expensive among common tools", () => {
  assert.ok(toolCost("code_sandbox") >= toolCost("web_search"));
  assert.ok(toolCost("code_sandbox") > toolCost("calculator"));
  assert.equal(toolCost("direct_synthesis"), 0);
});

test("selectWithinBudget: respects maxCount", () => {
  const invs: ToolInvocation[] = [
    { toolId: "calculator", input: "1+1" },
    { toolId: "symbolic_cas", input: "x^2" },
    { toolId: "code_sandbox", input: "1" },
  ];
  const { selected, skipped, totalCost } = selectWithinBudget(invs, 2);
  assert.equal(selected.length, 2);
  assert.equal(skipped.length, 1);
  assert.equal(skipped[0].toolId, "code_sandbox");
  assert.equal(totalCost, TOOL_COST.calculator + TOOL_COST.symbolic_cas);
});

test("selectWithinBudget: respects maxCost and skips code_sandbox when budget tight", () => {
  const invs: ToolInvocation[] = [
    { toolId: "calculator", input: "1+1" },
    { toolId: "code_sandbox", input: "console.log(1)" },
    { toolId: "web_search", input: "test" },
  ];
  // budget 3: calculator(1) fits, code_sandbox(3) makes total 4 > 3 → skip, web_search(2) makes 1+2=3 fits
  const { selected, skipped, totalCost } = selectWithinBudget(invs, 10, 3);
  assert.deepEqual(
    selected.map((s) => s.toolId),
    ["calculator", "web_search"]
  );
  assert.deepEqual(
    skipped.map((s) => s.toolId),
    ["code_sandbox"]
  );
  assert.equal(totalCost, 3);
});

test("selectWithinBudget: zero budget selects only zero-cost tools", () => {
  const invs: ToolInvocation[] = [
    { toolId: "direct_synthesis", input: "x" },
    { toolId: "calculator", input: "1" },
  ];
  const { selected, totalCost } = selectWithinBudget(invs, 10, 0);
  assert.deepEqual(
    selected.map((s) => s.toolId),
    ["direct_synthesis"]
  );
  assert.equal(totalCost, 0);
});
