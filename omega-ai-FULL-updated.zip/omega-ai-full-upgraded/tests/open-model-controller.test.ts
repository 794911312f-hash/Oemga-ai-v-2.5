import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { buildLocalModelSystemInstruction, normalizeOpenAICompatibleBaseUrl, planLocalInference } from "../src/lib/omega/openModelController";

describe("Omega Local Cortex Controller", () => {
  it("normalizes base URLs while rejecting embedded credentials and non-HTTP schemes", () => {
    assert.equal(normalizeOpenAICompatibleBaseUrl("http://127.0.0.1:11434"), "http://127.0.0.1:11434/v1");
    assert.equal(normalizeOpenAICompatibleBaseUrl("http://localhost:1234/v1/"), "http://localhost:1234/v1");
    assert.equal(normalizeOpenAICompatibleBaseUrl("http://user:secret@localhost:1234/v1"), null);
    assert.equal(normalizeOpenAICompatibleBaseUrl("file:///etc/passwd"), null);
    assert.equal(normalizeOpenAICompatibleBaseUrl("http://localhost:1234/v1?next=secret"), null);
  });

  it("allocates a more precise and larger budget to complex symbolic questions", () => {
    const simple = planLocalInference("What is the capital of France?", "general", 2048);
    const complex = planLocalInference(
      "أثبت خطوة بخطوة ثم حلل المعادلة: ∫(x^2 + 3x) dx = 0",
      "math_logic",
      2048,
    );
    assert.equal(complex.verificationMode, "symbolic");
    assert.ok(complex.complexity > simple.complexity);
    assert.ok(complex.temperature < simple.temperature);
    assert.ok(complex.maxTokens > simple.maxTokens);
    assert.equal(complex.independentAuditRecommended, true);
  });

  it("caps token allocation at the caller's budget and distinguishes evidence tasks", () => {
    const plan = planLocalInference("Give sources for the latest climate data", "science_factual", 512);
    assert.equal(plan.verificationMode, "evidence");
    assert.equal(plan.maxTokens, 512);
    assert.equal(plan.independentAuditRecommended, true);
  });

  it("does not let the generative model claim Omega independently verified its answer", () => {
    const plan = planLocalInference("2 + 2 = ?", "math_logic");
    const instruction = buildLocalModelSystemInstruction("base", plan);
    assert.match(instruction, /not its verifier/i);
    assert.match(instruction, /Do not claim Omega's CAS verified/i);
    assert.doesNotMatch(instruction, /guaranteed correct/i);
  });
});
