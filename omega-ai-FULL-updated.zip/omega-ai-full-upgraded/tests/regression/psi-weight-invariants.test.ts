/**
 * Regression: weights from Ψ form a convex combination.
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { clipExpPsi } from "../../src/lib/omega/math.ts";

function weightsFromDeltas(deltas: number[], sigma: number): number[] {
  const psi = deltas.map((d) => clipExpPsi(d, sigma));
  const sum = psi.reduce((a, b) => a + b, 0);
  if (sum < 1e-9) return psi.map(() => 1 / psi.length);
  return psi.map((p) => p / sum);
}

describe("Ψ weight invariants", () => {
  it("non-negative and sum to 1", () => {
    const cases = [
      [0, 0, 0],
      [0.1, 0.2, 0.5],
      [0, 1, 2],
      [0.3, 0.3, 0.3, 0.3],
    ];
    for (const deltas of cases) {
      const w = weightsFromDeltas(deltas, 0.2);
      for (const x of w) assert.ok(x >= -1e-12);
      const s = w.reduce((a, b) => a + b, 0);
      assert.ok(Math.abs(s - 1) < 1e-9, `sum=${s}`);
    }
  });
});
