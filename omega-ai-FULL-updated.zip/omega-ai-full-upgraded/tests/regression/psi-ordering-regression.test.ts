/**
 * Regression: fixed (delta, sigma) pairs must keep Ψ ordering.
 * If clipExpPsi constants change behavior enough to reverse ranks → FAIL.
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { clipExpPsi } from "../../src/lib/omega/math.ts";

/** Golden pairs: [deltaLow, deltaHigh, sigma] — low must score ≥ high */
const GOLDEN_ORDER: Array<[number, number, number]> = [
  [0.0, 0.2, 0.15],
  [0.05, 0.4, 0.2],
  [0.1, 0.5, 0.3],
  [0.2, 0.8, 0.1],
  [0.01, 1.0, 0.05],
];

describe("Ψ ordering regression", () => {
  for (const [dLow, dHigh, sigma] of GOLDEN_ORDER) {
    it(`preserves order δ=${dLow} ≼ δ=${dHigh} at σ=${sigma}`, () => {
      const pLow = clipExpPsi(dLow, sigma);
      const pHigh = clipExpPsi(dHigh, sigma);
      assert.ok(
        pLow >= pHigh - 1e-12,
        `Ordering regression: Ψ(${dLow})=${pLow} < Ψ(${dHigh})=${pHigh}`
      );
    });
  }
});
