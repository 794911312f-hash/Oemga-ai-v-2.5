/**
 * Offline comparison: Consensus Ψ ranking vs simple fusion baselines.
 *
 * Uses synthetic embedding geometry (no API). Measures whether Ψ ranking
 * recovers the "true" nearest-to-centroid member more often than majority
 * on a bag-of-tokens toy vote, and reports rank correlation patterns.
 *
 * This is NOT a claim of statistical superiority on real LLMs — it is a
 * controlled geometry check + baseline wiring for future provider runs.
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { clipExpPsi, cosine, normalize } from "../../src/lib/omega/math.ts";

function centroid(vecs: number[][]): number[] {
  const d = vecs[0].length;
  const c = new Array(d).fill(0);
  for (const v of vecs) for (let i = 0; i < d; i++) c[i] += v[i] / vecs.length;
  return c;
}

function psiRanks(vecs: number[][]): number[] {
  const c = centroid(vecs);
  const delta = vecs.map((v) => 1 - cosine(v, c));
  const mean = delta.reduce((a, b) => a + b, 0) / delta.length;
  const variance =
    delta.reduce((a, x) => a + (x - mean) ** 2, 0) / delta.length;
  const sigma = Math.sqrt(variance);
  const psi = delta.map((x) => clipExpPsi(x, sigma));
  // rank 0 = best (highest psi)
  return argsortDesc(psi);
}

function argsortDesc(scores: number[]): number[] {
  return scores
    .map((s, i) => [s, i] as const)
    .sort((a, b) => b[0] - a[0])
    .map(([, i]) => i);
}

/** Majority on quantized orthant labels (toy "vote") */
function majorityRank(vecs: number[][]): number[] {
  const labels = vecs.map((v) => v.map((x) => (x >= 0 ? 1 : 0)).join(""));
  const counts = new Map<string, number>();
  for (const L of labels) counts.set(L, (counts.get(L) || 0) + 1);
  const score = labels.map((L) => counts.get(L) || 0);
  return argsortDesc(score);
}

/** Borda: each voter ranks others by cosine; accumulate points */
function bordaRank(vecs: number[][]): number[] {
  const n = vecs.length;
  const points = new Array(n).fill(0);
  for (let i = 0; i < n; i++) {
    const sims = vecs.map((v, j) => (i === j ? -Infinity : cosine(vecs[i], v)));
    const order = argsortDesc(sims);
    order.forEach((idx, rank) => {
      if (Number.isFinite(sims[idx])) points[idx] += n - 1 - rank;
    });
  }
  return argsortDesc(points);
}

/** RRF on cosine-to-centroid ranking (single list → identity with k=60 dampening) */
function rrfFromCentroid(vecs: number[][]): number[] {
  const c = centroid(vecs);
  const sims = vecs.map((v) => cosine(v, c));
  const order = argsortDesc(sims);
  const rrf = new Array(vecs.length).fill(0);
  order.forEach((idx, rank) => {
    rrf[idx] += 1 / (60 + rank + 1);
  });
  return argsortDesc(rrf);
}

/** Self-consistency proxy: fraction of others within cosine threshold of candidate */
function selfConsistencyRank(vecs: number[][], thr = 0.85): number[] {
  const scores = vecs.map((v, i) => {
    let ok = 0;
    for (let j = 0; j < vecs.length; j++) {
      if (i === j) continue;
      if (cosine(v, vecs[j]) >= thr) ok++;
    }
    return ok / Math.max(1, vecs.length - 1);
  });
  return argsortDesc(scores);
}

function topMatches(truth: number, ranks: number[]): boolean {
  return ranks[0] === truth;
}

describe("Ψ vs fusion baselines (synthetic geometry)", () => {
  it("Ψ top pick matches nearest-to-centroid on a clear cluster+outlier", () => {
    const cluster = [
      normalize([1, 0.05, 0, 0]),
      normalize([0.98, 0.1, 0, 0]),
      normalize([0.96, 0.08, 0.02, 0]),
    ];
    const outlier = normalize([0, 0, 1, 0]);
    const vecs = [...cluster, outlier];
    const c = centroid(vecs);
    // true best = max cosine to centroid
    let best = 0;
    let bestSim = -Infinity;
    vecs.forEach((v, i) => {
      const s = cosine(v, c);
      if (s > bestSim) {
        bestSim = s;
        best = i;
      }
    });
    assert.equal(psiRanks(vecs)[0], best);
    // outlier should not win under Ψ
    assert.notEqual(psiRanks(vecs)[0], 3);
  });

  it("records comparative top-1 agreement rates on random trials", () => {
    let n = 0;
    let psiOk = 0;
    let majOk = 0;
    let bordaOk = 0;
    let rrfOk = 0;
    let scOk = 0;

    // Deterministic pseudo-random from fixed seed
    let seed = 42;
    const rnd = () => {
      seed = (seed * 1664525 + 1013904223) >>> 0;
      return seed / 0xffffffff;
    };

    for (let t = 0; t < 40; t++) {
      const k = 4;
      const d = 8;
      const vecs: number[][] = [];
      for (let i = 0; i < k; i++) {
        const raw = Array.from({ length: d }, () => rnd() * 2 - 1);
        vecs.push(normalize(raw));
      }
      const c = centroid(vecs);
      let truth = 0;
      let bestSim = -Infinity;
      vecs.forEach((v, i) => {
        const s = cosine(v, c);
        if (s > bestSim) {
          bestSim = s;
          truth = i;
        }
      });

      n++;
      if (topMatches(truth, psiRanks(vecs))) psiOk++;
      if (topMatches(truth, majorityRank(vecs))) majOk++;
      if (topMatches(truth, bordaRank(vecs))) bordaOk++;
      if (topMatches(truth, rrfFromCentroid(vecs))) rrfOk++;
      if (topMatches(truth, selfConsistencyRank(vecs))) scOk++;
    }

    // Ψ and RRF-on-centroid both optimize geometry toward centroid — expect high recovery
    assert.ok(psiOk / n >= 0.9, `Ψ recovery ${psiOk}/${n}`);
    assert.ok(rrfOk / n >= 0.9, `RRF recovery ${rrfOk}/${n}`);
    // Majority on orthant labels is weaker in continuous geometry
    assert.ok(
      psiOk >= majOk,
      `expected Ψ (${psiOk}) >= majority (${majOk}) on this synthetic task`
    );

    // Smoke: all methods ran
    assert.ok(bordaOk >= 0 && scOk >= 0);
  });
});
