/**
 * Spectral Consensus — verified against closed-form spectra and theorems, not against the code's own output.
 */
import test from "node:test";
import assert from "node:assert/strict";
import {
  symmetricEigen, buildAffinity, graphLaplacian, normalizedLaplacian, degrees, computeSpectralConsensus, type Matrix,
} from "../src/lib/omega/spectralConsensus";

// deterministic PRNG (mulberry32)
function rng(seed: number) { let a = seed >>> 0; return () => { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const close = (a: number, b: number, tol = 1e-9, msg = "") => assert.ok(Math.abs(a - b) <= tol, `${msg} expected ${b}, got ${a}`);
const zeros = (n: number): Matrix => Array.from({ length: n }, () => new Array(n).fill(0));
const matvec = (A: Matrix, x: number[]) => A.map((r) => r.reduce((s, a, j) => s + a * x[j], 0));
const dot = (a: number[], b: number[]) => a.reduce((s, x, i) => s + x * b[i], 0);

function randomSym(n: number, r: () => number): Matrix {
  const A = zeros(n);
  for (let i = 0; i < n; i++) for (let j = i; j < n; j++) A[i][j] = A[j][i] = r() * 4 - 2;
  return A;
}
function adjacency(n: number, edges: Array<[number, number]>): Matrix {
  const W = zeros(n); for (const [i, j] of edges) W[i][j] = W[j][i] = 1; return W;
}

// ───────── eigensolver ─────────
test("symmetricEigen: 2x2 [[2,1],[1,2]] has eigenvalues 1 and 3", () => {
  const e = symmetricEigen([[2, 1], [1, 2]]);
  close(e.values[0], 1); close(e.values[1], 3);
});

test("symmetricEigen: A = V Λ Vᵀ, V orthonormal, A v = λ v, trace preserved (random symmetric, n=1..14)", () => {
  const r = rng(7);
  for (let n = 1; n <= 14; n++) {
    const A = randomSym(n, r);
    const { values, vectors } = symmetricEigen(A);
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) close(dot(vectors[i], vectors[j]), i === j ? 1 : 0, 1e-9, `orthonormal n=${n}`);
    for (let i = 0; i < n; i++) { const Av = matvec(A, vectors[i]); for (let k = 0; k < n; k++) close(Av[k], values[i] * vectors[i][k], 1e-8, `Av=λv n=${n}`); }
    close(values.reduce((s, x) => s + x, 0), A.reduce((s, row, i) => s + row[i], 0), 1e-9, "trace");
    for (let i = 1; i < n; i++) assert.ok(values[i] >= values[i - 1], "ascending");
  }
});

test("symmetricEigen: repeated eigenvalues (identity, diagonal) and zero matrix", () => {
  const I = symmetricEigen([[1, 0, 0], [0, 1, 0], [0, 0, 1]]);
  I.values.forEach((v) => close(v, 1));
  const D = symmetricEigen([[3, 0], [0, -1]]);
  close(D.values[0], -1); close(D.values[1], 3);
  symmetricEigen(zeros(4)).values.forEach((v) => close(v, 0));
});

test("symmetricEigen: rejects non-square, non-symmetric and non-finite input", () => {
  assert.throws(() => symmetricEigen([[1, 2, 3], [4, 5, 6]]), /square/);
  assert.throws(() => symmetricEigen([[1, 2], [0, 1]]), /symmetric/);
  assert.throws(() => symmetricEigen([[1, NaN], [NaN, 1]]), /non-finite/);
  assert.deepEqual(symmetricEigen([]).values, []);
});

// ───────── closed-form Laplacian spectra ─────────
test("Laplacian spectrum of the path graph P_n is 2 − 2cos(kπ/n), k=0..n−1", () => {
  for (const n of [2, 3, 5, 8, 11]) {
    const W = adjacency(n, Array.from({ length: n - 1 }, (_, i) => [i, i + 1] as [number, number]));
    const { values } = symmetricEigen(graphLaplacian(W));
    values.forEach((v, k) => close(v, 2 - 2 * Math.cos((k * Math.PI) / n), 1e-9, `P_${n} k=${k}`));
  }
});

test("Laplacian spectrum of the cycle C_n is {2 − 2cos(2πk/n)}", () => {
  for (const n of [3, 4, 6, 9]) {
    const W = adjacency(n, Array.from({ length: n }, (_, i) => [i, (i + 1) % n] as [number, number]));
    const got = symmetricEigen(graphLaplacian(W)).values;
    const want = Array.from({ length: n }, (_, k) => 2 - 2 * Math.cos((2 * Math.PI * k) / n)).sort((a, b) => a - b);
    got.forEach((v, i) => close(v, want[i], 1e-9, `C_${n}`));
  }
});

test("Laplacian spectrum of the complete graph K_n is {0, n×(n−1)}", () => {
  for (const n of [2, 4, 7]) {
    const W = zeros(n).map((r, i) => r.map((_, j) => (i === j ? 0 : 1)));
    const v = symmetricEigen(graphLaplacian(W)).values;
    close(v[0], 0); for (let i = 1; i < n; i++) close(v[i], n);
  }
});

test("multiplicity of eigenvalue 0 of L equals the number of connected components", () => {
  const two = adjacency(7, [[0, 1], [1, 2], [2, 0], [3, 4], [4, 5], [5, 6]]);
  const three = adjacency(8, [[0, 1], [2, 3], [3, 4], [5, 6], [6, 7]]);
  for (const [W, c] of [[two, 2], [three, 3]] as Array<[Matrix, number]>) {
    const z = symmetricEigen(graphLaplacian(W)).values.filter((x) => Math.abs(x) < 1e-9).length;
    assert.equal(z, c);
  }
});

test("normalised Laplacian: spectrum within [0,2]; D^{1/2}·1 is the 0-eigenvector", () => {
  const r = rng(11);
  for (let n = 3; n <= 9; n++) {
    const W = zeros(n);
    for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) W[i][j] = W[j][i] = 0.05 + r();
    const Ls = normalizedLaplacian(W);
    const { values } = symmetricEigen(Ls);
    assert.ok(values[0] > -1e-9 && values[0] < 1e-9, "λ0 = 0");
    assert.ok(values[n - 1] <= 2 + 1e-9, "λmax ≤ 2");
    const d = degrees(W), v = d.map(Math.sqrt);
    matvec(Ls, v).forEach((x) => close(x, 0, 1e-9, "L_sym D^{1/2} 1"));
    assert.ok(values[1] <= n / (n - 1) + 1e-9, "λ2 ≤ n/(n−1)");
  }
});

test("Cheeger inequality λ₂/2 ≤ h(G) ≤ √(2λ₂) holds against brute-force conductance (random weighted graphs)", () => {
  const r = rng(23);
  for (let trial = 0; trial < 12; trial++) {
    const n = 4 + (trial % 5);
    const W = zeros(n);
    for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) { const w = r() < 0.6 ? 0.1 + r() : 0; W[i][j] = W[j][i] = w; }
    for (let i = 0; i < n - 1; i++) if (W[i][i + 1] === 0) W[i][i + 1] = W[i + 1][i] = 0.2; // keep connected
    const d = degrees(W), vol = d.reduce((s, x) => s + x, 0);
    let h = Infinity;
    for (let mask = 1; mask < (1 << n) - 1; mask++) {
      let cut = 0, vs = 0;
      for (let i = 0; i < n; i++) { if (mask & (1 << i)) { vs += d[i]; for (let j = 0; j < n; j++) if (!(mask & (1 << j))) cut += W[i][j]; } }
      h = Math.min(h, cut / Math.min(vs, vol - vs));
    }
    const lam2 = symmetricEigen(normalizedLaplacian(W)).values[1];
    assert.ok(lam2 / 2 <= h + 1e-9, `lower bound trial ${trial}: ${lam2 / 2} ≤ ${h}`);
    assert.ok(h <= Math.sqrt(2 * lam2) + 1e-9, `upper bound trial ${trial}: ${h} ≤ ${Math.sqrt(2 * lam2)}`);
  }
});

// ───────── spectral consensus on vectors ─────────
function blobs(centers: number[][], perCluster: number, noise: number, seed: number): number[][] {
  const r = rng(seed); const out: number[][] = [];
  for (const c of centers) for (let i = 0; i < perCluster; i++) out.push(c.map((x) => x + (r() - 0.5) * noise));
  return out;
}
const axis = (d: number, i: number, mag = 3) => Array.from({ length: d }, (_, j) => (j === i ? mag : 0));

test("three well-separated groups: eigengap selects k=3 and clustering recovers them exactly", () => {
  const X = blobs([axis(8, 0), axis(8, 1), axis(8, 2)], 4, 0.1, 5);
  const res = computeSpectralConsensus(X);
  assert.equal(res.k, 3);
  for (let g = 0; g < 3; g++) { const ls = new Set(res.labels.slice(g * 4, g * 4 + 4)); assert.equal(ls.size, 1, `group ${g} split`); }
  assert.equal(new Set(res.labels).size, 3);
  assert.ok(res.cohesion < 0.8, "fragmented set has low cohesion");
});

test("single tight group: k=1, no outliers, cohesion near 1", () => {
  const res = computeSpectralConsensus(blobs([axis(8, 0)], 6, 0.02, 3));
  assert.equal(res.k, 1); assert.deepEqual(res.outliers, []); assert.ok(res.cohesion > 0.95, `cohesion ${res.cohesion}`);
});

test("identical answers: W≡1 ⇒ λ₂(L_sym)=n/(n−1), cohesion=1, uniform weights", () => {
  const v = [1, 2, 3, 4], n = 5;
  const res = computeSpectralConsensus(Array.from({ length: n }, () => v.slice()));
  close(res.spectralGap, n / (n - 1)); close(res.cohesion, 1); close(res.algebraicConnectivity, n);
  res.weights.forEach((w) => close(w, 1 / n, 1e-9)); assert.equal(res.k, 1);
  assert.equal(res.spectralSufficient, true);
});

test("an outlier among agreeing answers gets the lowest Perron weight and is flagged", () => {
  const X = blobs([axis(8, 0)], 5, 0.05, 9); X.push(axis(8, 4)); // index 5 is orthogonal to the rest
  const res = computeSpectralConsensus(X);
  assert.equal(res.weights.indexOf(Math.min(...res.weights)), 5);
  assert.deepEqual(res.lowSupport, [5], "singleton outlier has conductance≈1 so it is caught by Perron weight, not by clustering");
  assert.deepEqual(res.outliers, [5]);
  assert.notEqual(res.consensusIndex, 5);
});

test("no false positives: a uniformly noisy agreeing group has no low-support members", () => {
  for (const seed of [1, 2, 3, 4, 5]) {
    const res = computeSpectralConsensus(blobs([axis(8, 0)], 7, 0.5, seed));
    assert.deepEqual(res.lowSupport, [], `seed ${seed}`);
  }
});

test("a whole minority cluster (2 of 7) is flagged via clustering, not only via weights", () => {
  const X = [...blobs([axis(8, 0)], 5, 0.05, 51), ...blobs([axis(8, 3)], 2, 0.05, 52)];
  const res = computeSpectralConsensus(X);
  assert.equal(res.k, 2);
  assert.deepEqual(res.outliers, [5, 6]);
});

test("Perron weights: strictly positive, sum to 1, and satisfy W w = ρ w", () => {
  const X = blobs([axis(6, 0), axis(6, 1)], 5, 0.4, 13);
  const res = computeSpectralConsensus(X);
  const { W } = buildAffinity(X);
  close(res.weights.reduce((s, x) => s + x, 0), 1);
  res.weights.forEach((w) => assert.ok(w > 0));
  matvec(W, res.weights).forEach((x, i) => close(x, res.perronRoot * res.weights[i], 1e-8, "Perron eigen-equation"));
});

test("Fiedler vector sign pattern separates two clusters", () => {
  const X = blobs([axis(6, 0), axis(6, 1)], 5, 0.1, 17);
  const f = computeSpectralConsensus(X).fiedlerVector;
  const sA = f.slice(0, 5).map(Math.sign), sB = f.slice(5).map(Math.sign);
  assert.ok(sA.every((s) => s === sA[0]) && sB.every((s) => s === sB[0]) && sA[0] !== sB[0]);
});

test("invariances: permutation equivariance and scale invariance of the inputs", () => {
  const X = blobs([axis(6, 0), axis(6, 1), axis(6, 2)], 3, 0.15, 29);
  const base = computeSpectralConsensus(X);
  const perm = [4, 0, 8, 2, 6, 1, 7, 3, 5];
  const P = computeSpectralConsensus(perm.map((i) => X[i]));
  base.normalizedEigenvalues.forEach((v, i) => close(P.normalizedEigenvalues[i], v, 1e-7, "spectrum permutation-invariant"));
  perm.forEach((orig, newIdx) => close(P.weights[newIdx], base.weights[orig], 1e-6, "weights equivariant"));
  const S = computeSpectralConsensus(X.map((v, i) => v.map((x) => x * (1 + i))), { sigma: base.sigma });
  base.normalizedEigenvalues.forEach((v, i) => close(S.normalizedEigenvalues[i], v, 1e-7, "scale invariant"));
});

test("determinism: identical input ⇒ identical output", () => {
  const X = blobs([axis(6, 0), axis(6, 1)], 4, 0.2, 31);
  assert.deepEqual(computeSpectralConsensus(X), computeSpectralConsensus(X));
});

test("Cheeger certificate fields are consistent: lower ≤ upper, relaxation time = 1/λ₂", () => {
  const res = computeSpectralConsensus(blobs([axis(6, 0), axis(6, 1)], 4, 0.3, 37));
  assert.ok(res.cheeger.lower <= res.cheeger.upper);
  close(res.relaxationTime, 1 / res.spectralGap, 1e-9);
  assert.equal(res.normalizedEigenvalues.length, res.n);
  res.normalizedEigenvalues.forEach((v) => assert.ok(v > -1e-9 && v < 2 + 1e-9));
});

test("edge cases: n=1, n=2, zero vectors, ragged lengths, invalid input", () => {
  const one = computeSpectralConsensus([[1, 2, 3]]);
  assert.equal(one.k, 1); assert.deepEqual(one.weights, [1]); assert.equal(one.consensusIndex, 0);
  assert.equal(one.spectralSufficient, false);
  assert.equal(one.cohesion, 0, "n=1 has no pair — cohesion must not claim perfect agreement");
  assert.equal(one.relaxationTime, Infinity);

  const two = computeSpectralConsensus([[1, 0], [0, 1]]);
  assert.equal(two.k, 1); close(two.weights[0], 0.5); close(two.weights[1], 0.5);
  assert.equal(two.spectralSufficient, false);
  // Orthogonal unit vectors → affinity near exp(-‖u−v‖²/2σ²) with ‖u−v‖²=2 → small, not 1
  assert.ok(two.cohesion < 0.5, `n=2 orthogonal must not get cohesion=1, got ${two.cohesion}`);
  assert.equal(two.relaxationTime, Infinity, "K₂ walk oscillates — no finite relaxation time");

  const twoSame = computeSpectralConsensus([[1, 0, 0], [1, 0, 0]]);
  assert.equal(twoSame.spectralSufficient, false);
  assert.ok(twoSame.cohesion > 0.9, `n=2 identical should have high affinity cohesion, got ${twoSame.cohesion}`);

  const withZero = computeSpectralConsensus([[0, 0, 0], [1, 0, 0], [1, 0.01, 0]]);
  assert.ok(withZero.weights.every(Number.isFinite));
  assert.equal(withZero.spectralSufficient, true);
  const ragged = computeSpectralConsensus([[1, 0], [1, 0, 0], [0, 1]]);
  assert.ok(ragged.weights.every(Number.isFinite));
  assert.throws(() => computeSpectralConsensus([]), /at least one/);
  assert.throws(() => computeSpectralConsensus([[1, NaN], [1, 2]]), /non-finite/);
});

test("scales: n=60 runs well under a second and stays numerically sane", () => {
  const X = blobs([axis(16, 0), axis(16, 1), axis(16, 2), axis(16, 3)], 15, 0.2, 41);
  const t0 = Date.now(); const res = computeSpectralConsensus(X); const dt = Date.now() - t0;
  assert.ok(dt < 3000, `took ${dt}ms`);
  assert.equal(res.k, 4);
  close(res.weights.reduce((s, x) => s + x, 0), 1);
});
