/**
 * tests/psi-mathematical-properties.test.ts
 * Formal/numeric checks on clipExpPsi and consensus scoring.
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { clipExpPsi, cosine, normalize } from "../src/lib/omega/math.ts";

/** Same scoring path as omegaCore.scorePsi (hash-free unit vectors for control). */
function scorePsiFromVectors(vectors: number[][]): {
  psi: number[];
  sigma: number;
  delta: number[];
} {
  const dim = vectors[0]?.length ?? 0;
  const centroid = new Array(dim).fill(0);
  for (const v of vectors) {
    for (let i = 0; i < dim; i++) centroid[i] += v[i] / vectors.length;
  }
  const delta = vectors.map((v) => 1 - cosine(v, centroid));
  const mean = delta.reduce((a, b) => a + b, 0) / (delta.length || 1);
  const variance =
    delta.reduce((a, d) => a + (d - mean) ** 2, 0) / (delta.length || 1);
  const sigma = Math.sqrt(variance);
  const psi = delta.map((d) => clipExpPsi(d, sigma));
  return { psi, sigma, delta };
}

describe("clipExpPsi mathematical properties", () => {
  it("is monotonically non-increasing in delta for fixed sigma", () => {
    const sigma = 0.2;
    let prev = clipExpPsi(0, sigma);
    for (let d = 0.05; d <= 1.0; d += 0.05) {
      const cur = clipExpPsi(d, sigma);
      assert.ok(cur <= prev + 1e-12, `psi(${d})=${cur} > psi(prev)=${prev}`);
      prev = cur;
    }
  });

  it("approaches ~1 as delta → 0", () => {
    const p = clipExpPsi(0, 0.3);
    assert.ok(p >= 0.95 && p <= 1.0);
  });

  it("is bounded in [0.01, 1]", () => {
    for (const sigma of [0, 1e-12, 0.01, 0.5, 2]) {
      for (const d of [0, 0.1, 0.5, 1, 5, 100]) {
        const p = clipExpPsi(d, sigma);
        assert.ok(p >= 0.01 && p <= 1.0);
      }
    }
  });

  it("when sigma → 0, small delta still near 1; large delta collapses toward floor", () => {
    // effectiveSigma = max(sigma, 1e-6); denominator ≈ 1e-6*1.5 + 0.05 ≈ 0.05
    const near = clipExpPsi(0.001, 0);
    const far = clipExpPsi(2, 0);
    assert.ok(near > 0.9);
    assert.ok(far < near);
    assert.ok(far >= 0.01);
  });

  it("identical vectors ⇒ sigma=0 and uniform high psi", () => {
    const v = normalize([1, 2, 3, 4]);
    const { psi, sigma, delta } = scorePsiFromVectors([v, v, v]);
    assert.ok(sigma < 1e-9);
    for (const d of delta) assert.ok(Math.abs(d) < 1e-9);
    for (const p of psi) assert.ok(p >= 0.95);
  });

  it("one outlier gets lower psi than the tight cluster", () => {
    const a = normalize([1, 0, 0, 0]);
    const b = normalize([0.98, 0.1, 0, 0]);
    const outlier = normalize([0, 0, 0, 1]);
    const { psi } = scorePsiFromVectors([a, b, outlier]);
    const clusterAvg = (psi[0] + psi[1]) / 2;
    assert.ok(psi[2] < clusterAvg);
  });

  it("all-far spread yields flatter relative weights (less decisive)", () => {
    // Orthogonal-ish set → large deltas, psi compressed toward similar mid/low values
    const vecs = [
      normalize([1, 0, 0, 0]),
      normalize([0, 1, 0, 0]),
      normalize([0, 0, 1, 0]),
      normalize([0, 0, 0, 1]),
    ];
    const { psi } = scorePsiFromVectors(vecs);
    const max = Math.max(...psi);
    const min = Math.min(...psi);
    // Not a single near-1 winner dominating
    assert.ok(max - min < 0.5 || max < 0.95);
  });
});
