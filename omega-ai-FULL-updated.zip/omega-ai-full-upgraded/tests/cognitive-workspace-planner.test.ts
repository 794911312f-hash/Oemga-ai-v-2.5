/**
 * tests/cognitive-workspace-planner.test.ts
 * Phase 11.1 — Planner unit tests (no network, no side effects)
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  createCognitivePlan,
  getReadyTasks,
  updateTaskStatus,
  configForDepth,
} from "../src/lib/omega/cognitiveWorkspace/index.ts";

describe("Cognitive Planner (Phase 11.1)", () => {
  it("produces a valid plan for a simple Arabic question", () => {
    const { plan, domainRoute } = createCognitivePlan({
      question: "ما هو قانون نيوتن الثاني؟",
      depth: "balanced",
      config: configForDepth("balanced"),
    });

    assert.ok(plan.goal.originalQuestion.includes("نيوتن"));
    assert.ok(plan.tasks.length >= 3);
    assert.equal(plan.tasks[0].id, "t_retrieve");
    assert.equal(plan.tasks[0].status, "pending");
    assert.ok(
      ["science_factual", "math_logic", "general"].includes(plan.goal.domain)
    );
    assert.ok(domainRoute.models.length >= 1);
  });

  it("detects code domain and includes tool task", () => {
    const { plan } = createCognitivePlan({
      question: "اكتب دالة JavaScript لحساب فيبوناتشي ونفّذها",
      depth: "balanced",
      config: configForDepth("balanced"),
    });

    assert.equal(plan.goal.domain, "code");
    const toolTask = plan.tasks.find((t) => t.id === "t_tools");
    assert.ok(toolTask, "expected a tool task for code+execute request");
  });

  it("fast depth produces fewer tasks and no reflection", () => {
    const { plan } = createCognitivePlan({
      question: "كم يساوي 2+2؟",
      depth: "fast",
      config: configForDepth("fast"),
    });

    assert.ok(plan.tasks.length <= 6);
    const reflect = plan.tasks.find((t) => t.id === "t_reflect");
    assert.equal(reflect, undefined);
  });

  it("deep depth can include agent task", () => {
    const { plan } = createCognitivePlan({
      question: "ناقش بالتفصيل فرضية ريمان وقدم نقداً علمياً",
      depth: "deep",
      config: configForDepth("deep"),
    });

    assert.equal(plan.estimatedComplexity, "high");
    const agent = plan.tasks.find((t) => t.id === "t_agents");
    assert.ok(agent, "deep + critique question should include agent task");
  });

  it("getReadyTasks returns only tasks with satisfied dependencies", () => {
    const { plan } = createCognitivePlan({
      question: "اشرح الجاذبية",
      depth: "balanced",
      config: configForDepth("balanced"),
    });

    const ready1 = getReadyTasks(plan);
    assert.ok(ready1.some((t) => t.id === "t_retrieve"));
    assert.ok(!ready1.some((t) => t.id === "t_reason"));

    updateTaskStatus(plan, "t_retrieve", "done");
    const ready2 = getReadyTasks(plan);
    // After retrieve is done, either tools or reason should become ready
    assert.ok(
      ready2.some((t) => t.id === "t_reason" || t.id === "t_tools")
    );
  });

  it("updateTaskStatus sets timestamps correctly", () => {
    const { plan } = createCognitivePlan({
      question: "اختبار",
      depth: "fast",
      config: configForDepth("fast"),
    });

    updateTaskStatus(plan, "t_retrieve", "running");
    const t = plan.tasks.find((x) => x.id === "t_retrieve")!;
    assert.equal(t.status, "running");
    assert.ok(typeof t.startedAt === "number");

    updateTaskStatus(plan, "t_retrieve", "done", { ok: true });
    assert.equal(t.status, "done");
    assert.ok(typeof t.finishedAt === "number");
    assert.ok(typeof t.durationMs === "number");
    assert.deepEqual(t.result, { ok: true });
  });
});
