import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { routeGuard, AUTH_REQUIRED_PREFIXES } from "../src/server/security.ts";

function run(url: string, user: any) {
  const state: { status?: number; nexted: boolean } = { nexted: false };
  const res: any = {
    status(c: number) {
      state.status = c;
      return this;
    },
    json() {
      return this;
    },
  };
  routeGuard({ originalUrl: url, url, user } as any, res, () => {
    state.nexted = true;
  });
  return state;
}

const guest = { uid: "guest-user", isGuest: true };
const authed = { uid: "u1" };
const admin = { uid: "a1", role: "admin" };

describe("routeGuard", () => {
  it("blocks guests on costly/remote-fetch routes", () => {
    const urls = [
      "/api/omega/browser-use",
      "/api/omega/generate-video?x=1",
      "/api/omega/voice/synthesize",
      "/api/omega/open-sora",
      "/api/omega/open-sora/closed-loop",
      "/api/omega/video/analyze-upload?prompt=x",
      // P0: inference surfaces that burn provider quota — guests must auth
      "/api/omega/complete",
      "/api/omega/ensemble",
      "/api/omega/dspy",
      "/api/omega/core/process",
      "/api/omega/hybrid-evolution/run",
    ];
    for (const u of urls) {
      const r = run(u, guest);
      assert.equal(r.status, 401, u);
      assert.equal(r.nexted, false, u);
    }
  });

  it("AUTH_REQUIRED_PREFIXES includes primary inference paths", () => {
    for (const p of [
      "/api/omega/complete",
      "/api/omega/ensemble",
      "/api/omega/dspy",
      "/api/omega/core",
    ]) {
      assert.ok(
        AUTH_REQUIRED_PREFIXES.some((x) => p === x || p.startsWith(x)),
        `missing ${p}`
      );
    }
  });

  it("allows authenticated users on costly routes", () => {
    assert.equal(run("/api/omega/browser-use", authed).nexted, true);
    assert.equal(run("/api/omega/complete", authed).nexted, true);
  });

  it("self-play toggle/cycle are admin only", () => {
    assert.equal(run("/api/omega/self-play/toggle", authed).status, 403);
    assert.equal(run("/api/omega/self-play/cycle", guest).status, 403);
    assert.equal(run("/api/omega/self-play/toggle", admin).nexted, true);
  });

  it("leaves public / health-style guest routes alone", () => {
    // Not in AUTH_REQUIRED — guests may probe readiness without a Firebase token
    for (const u of [
      "/api/health",
      "/api/omega/workspace/health",
      "/api/omega/open-model/health",
      "/api/omega/video-models",
    ]) {
      const r = run(u, guest);
      assert.equal(r.nexted, true, u);
      assert.equal(r.status, undefined, u);
    }
  });
});
