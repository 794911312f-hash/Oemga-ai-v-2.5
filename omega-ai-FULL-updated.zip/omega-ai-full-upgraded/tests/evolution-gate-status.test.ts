
import { describe, it } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import crypto from "node:crypto";
import { readEvolutionGateStatus } from "../src/lib/omega/evolutionGateStatus.ts";

function setup(dir: string, report: string, status: object) {
  fs.mkdirSync(path.join(dir, "docs/reports"), { recursive: true });
  fs.writeFileSync(path.join(dir, "docs/reports", "benchmark-test-run.md"), report);
  fs.writeFileSync(
    path.join(dir, "docs/reports/.evolution-gate-status.json"),
    JSON.stringify(status, null, 2)
  );
}

describe("evolutionGateStatus", () => {
  it("rejects expired PASS", () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "omega-gate-"));
    const report = "# ok\n";
    const sha = crypto.createHash("sha256").update(report).digest("hex");
    setup(dir, report, {
      decision: "PASS",
      latest: "benchmark-test-run.md",
      sha256: sha,
      expiresAt: new Date(Date.now() - 1000).toISOString(),
    });
    const r = readEvolutionGateStatus(dir);
    assert.equal(r.decision, "REJECT");
    assert.match(r.reason || "", /expired/i);
  });

  it("rejects sha256 mismatch", () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "omega-gate-"));
    setup(dir, "# report A\n", {
      decision: "PASS",
      latest: "benchmark-test-run.md",
      sha256: "deadbeef",
      expiresAt: new Date(Date.now() + 86400000).toISOString(),
    });
    const r = readEvolutionGateStatus(dir);
    assert.equal(r.decision, "REJECT");
    assert.match(r.reason || "", /sha256/i);
  });

  it("rejects bare PASS without sha256/expiresAt", () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "omega-gate-"));
    fs.mkdirSync(path.join(dir, "docs/reports"), { recursive: true });
    fs.writeFileSync(
      path.join(dir, "docs/reports/.evolution-gate-status.json"),
      JSON.stringify({ decision: "PASS" })
    );
    const r = readEvolutionGateStatus(dir);
    assert.equal(r.decision, "REJECT");
    assert.match(r.reason || "", /sha256|expiresAt|requires/i);
  });

  it("accepts valid PASS", () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "omega-gate-"));
    const report = "# valid\n";
    const sha = crypto.createHash("sha256").update(report).digest("hex");
    setup(dir, report, {
      decision: "PASS",
      latest: "benchmark-test-run.md",
      sha256: sha,
      expiresAt: new Date(Date.now() + 86400000).toISOString(),
    });
    const r = readEvolutionGateStatus(dir);
    assert.equal(r.decision, "PASS");
  });
});
