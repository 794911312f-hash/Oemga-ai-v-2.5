import { test } from "node:test";
import assert from "node:assert/strict";
import { runClosedLoop, aggregateControls } from "../src/lib/omega/ovoActuation";
import { globalOmegaVideoOptimizer } from "../src/lib/omega/ovoEngine";

// Frame observations: calm or with a concentration spike in the middle.
const calm = (n: number) => Array.from({ length: n }, (_, i) => ({ frameIndex: i + 1, patchEnergies: Array(8).fill(0.125).map((x, j) => x * (1 + 0.005 * Math.sin(i + j))), rawVelocity: 0.3, colorDrift: 0.02 }));
const spiky = (n: number) => calm(n).map((o, i) => (i >= Math.floor(n / 2) ? { ...o, patchEnergies: [0.48, 0.04, 0.05, 0.03, 0.28, 0.04, 0.04, 0.04] } : o));

// Alternating spikes + high velocity: measures clearly worse (lower ψ, more interventions).
const worse = (n: number) => calm(n).map((o, i) => (i % 2 === 1 && i >= 3 ? { ...o, patchEnergies: [0.48, 0.04, 0.05, 0.03, 0.28, 0.04, 0.04, 0.04], rawVelocity: 0.9 } : o));

function makeDeps(videos: Record<string, any[]>) {
  const calls: any[] = [];
  let n = 0;
  return {
    calls,
    deps: {
      generate: async (req: any) => {
        calls.push(req);
        const url = `v${n++}`;
        return { id: url, videoUrl: url, config: { seed: 42 } } as any;
      },
      fetchVideo: async (url: string) => Buffer.from(url),
      analyze: async (buf: Buffer) => ({ metadata: {} as any, limitations: [], frameObservations: videos[buf.toString()] }),
    },
  };
}

test("stable clip: no second generation, parameters untouched", async () => {
  const { deps, calls } = makeDeps({ v0: calm(12) });
  const r = await runClosedLoop(deps, { prompt: "a cat" });
  assert.equal(r.actuated, false);
  assert.equal(calls.length, 1);
});

test("unstable clip: controller outputs are PASSED to the generator on pass 2", async () => {
  const { deps, calls } = makeDeps({ v0: spiky(12), v1: calm(12) });
  const r = await runClosedLoop(deps, { prompt: "a cat", cfgScale: 7, numSamplingSteps: 30 });
  assert.equal(calls.length, 2);
  assert.equal(r.actuated, true);
  assert.ok(calls[1].cfgScale > 7, "cfgScale raised");
  assert.ok(calls[1].numSamplingSteps > 30, "steps raised");
  assert.match(calls[1].prompt, /sharp coherent textures/);
  assert.equal(calls[1].seed, 42, "same seed isolates the parameter effect");
  assert.equal(r.chosenPass, 1);
  assert.ok(r.notApplied.length >= 3, "honestly lists what cannot be passed");
});

test("rolls back when pass 2 measures worse", async () => {
  const { deps } = makeDeps({ v0: spiky(12), v1: worse(12) });
  const r = await runClosedLoop(deps, { prompt: "a cat" });
  assert.equal(r.actuated, true);
  assert.equal(r.chosenPass, 0);
});

test("no video url (no endpoint) → no actuation, explicit reason", async () => {
  const deps = { generate: async () => ({ id: "x", config: { seed: 1 } } as any), fetchVideo: async () => Buffer.alloc(0), analyze: async () => ({} as any) };
  const r = await runClosedLoop(deps, { prompt: "a cat" });
  assert.equal(r.actuated, false);
  assert.match(r.reasonAr, /لم يُرجع ملف فيديو/);
});

test("aggregateControls stays inside controller bounds", () => {
  const rep = globalOmegaVideoOptimizer.runInferenceOptimizationLoop({ prompt: "p", frameObservations: spiky(12) });
  const a = aggregateControls(rep, { cfgScale: 7, numSamplingSteps: 30, motionScore: 4.5 });
  assert.ok(a.cfgScale >= 4.5 && a.cfgScale <= 11.5);
  assert.ok(a.numSamplingSteps <= 50);
  assert.ok(a.motionScore >= 1 && a.motionScore <= 10);
});
