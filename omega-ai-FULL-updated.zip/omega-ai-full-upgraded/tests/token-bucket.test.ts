import test from "node:test";
import assert from "node:assert/strict";
import { TokenBucket, TokenBucketRegistry } from "../src/server/security";

test("TokenBucket: capacity then reject", () => {
  const b = new TokenBucket(3, 0); // no refill
  assert.equal(b.tryTake(), true);
  assert.equal(b.tryTake(), true);
  assert.equal(b.tryTake(), true);
  assert.equal(b.tryTake(), false);
});

test("TokenBucket: refill restores tokens", async () => {
  const b = new TokenBucket(1, 100); // 100 tokens/sec
  assert.equal(b.tryTake(), true);
  assert.equal(b.tryTake(), false);
  await new Promise((r) => setTimeout(r, 30));
  assert.equal(b.tryTake(), true);
});

test("TokenBucketRegistry: keys are isolated", () => {
  const reg = new TokenBucketRegistry(1, 0);
  assert.equal(reg.tryTake("a"), true);
  assert.equal(reg.tryTake("a"), false);
  assert.equal(reg.tryTake("b"), true);
});
