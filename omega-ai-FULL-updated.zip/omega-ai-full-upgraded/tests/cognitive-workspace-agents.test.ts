/**
 * tests/cognitive-workspace-agents.test.ts
 * Phase 11.6 — AgentCoordinator
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  getAgentCoordinator,
  createCognitivePlan,
  configForDepth,
  runCognitiveWorkspace,
  type SynthesisResult,
} from "../src/lib/omega/cognitiveWorkspace/index.ts";

describe("AgentCoordinator (Phase 11.6)", () => {
  it("returns role opinions for a science question", async () => {
    const { plan } = createCognitivePlan({
      question: "اشرح قانون نيوتن الثاني بالتفصيل مع نقد",
      depth: "deep",
      config: configForDepth("deep"),
    });

    const synthesis: SynthesisResult = {
      answer:
        "قانون نيوتن الثاني: القوة تساوي الكتلة في التسارع. F = ma. ينطبق في الميكانيكا الكلاسيكية.",
      method: "core_only",
      sourceClass: "real",
      notes: [],
      injectedSections: [],
    };

    const panel = await getAgentCoordinator().run({
      question: plan.goal.originalQuestion,
      plan,
      draftAnswer: synthesis.answer,
      synthesis,
      tools: null,
      config: { maxAgents: 4, depth: "deep" },
    });

    assert.ok(panel.opinions.length >= 2);
    assert.ok(panel.opinions.some((o) => o.role === "critic"));
    assert.ok(typeof panel.panelConfidence === "number");
    assert.ok(panel.debate != null, "deep should run adversarial debate");
    assert.ok(Array.isArray(panel.notes));
  });

  it("selects programmer role for code domain", async () => {
    const { plan } = createCognitivePlan({
      question: "اكتب دالة JavaScript للفرز السريع",
      depth: "deep",
      config: configForDepth("deep"),
    });

    const synthesis: SynthesisResult = {
      answer: "function quicksort(a){...}",
      method: "core_only",
      sourceClass: "simulated",
      notes: [],
      injectedSections: [],
    };

    const panel = await getAgentCoordinator().run({
      question: plan.goal.originalQuestion,
      plan,
      draftAnswer: synthesis.answer,
      synthesis,
      config: { maxAgents: 4, depth: "balanced", forceDebate: false },
    });

    assert.ok(panel.opinions.some((o) => o.role === "programmer"));
  });
});

describe("Workspace integration (11.6)", () => {
  it("deep cycle records agent opinions", async () => {
    const result = await runCognitiveWorkspace({
      userId: "test-ws-agents",
      question: "ناقش فرضية ريمان وقدم نقداً علمياً",
      depth: "deep",
    });

    const agentStep = result.trace.steps.find((s) => s.name === "agents");
    assert.ok(agentStep, "expected agents step on deep");
    // Opinions may be empty only on failure; normally >= 1
    assert.ok(Array.isArray(result.trace.agentOpinions));
  });
});
