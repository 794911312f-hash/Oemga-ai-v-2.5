/**
 * tests/cognitive-workspace-memory-graph.test.ts
 * Phase 11.2 — MemoryBridge + GraphBridge unit tests
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  retrieveMemoryContext,
  persistWorkspaceOutcome,
  getMemoryManager,
  retrieveGraphContext,
  mergeGraphIntoMemory,
  getKnowledgeGraph,
  runCognitiveWorkspace,
} from "../src/lib/omega/cognitiveWorkspace/index.ts";

describe("Memory Bridge (Phase 11.2)", () => {
  it("returns a structured MemoryContext for a physics question", async () => {
    const result = await retrieveMemoryContext({
      userId: "test-user-mem",
      query: "ما هو قانون نيوتن الثاني للحركة؟",
      episodicLimit: 3,
      semanticLimit: 5,
    });

    assert.ok(result.context);
    assert.ok(Array.isArray(result.context.episodic));
    assert.ok(Array.isArray(result.context.semantic));
    assert.ok(Array.isArray(result.context.procedural));
    assert.ok(Array.isArray(result.context.workingKeys));
    assert.ok(typeof result.formattedBlock === "string");
    assert.ok(result.stats.axiomCount >= 0);
    // Newton axiom is seeded in HierarchicalMemoryManager
    assert.ok(
      result.stats.axiomCount >= 1 || result.context.semantic.length >= 1,
      "expected at least one axiom or semantic hit for Newton question"
    );
  });

  it("persistWorkspaceOutcome writes into working memory", async () => {
    const userId = "test-user-persist";
    await persistWorkspaceOutcome({
      userId,
      question: "اختبار حفظ النتيجة",
      answer: "هذه إجابة تجريبية عالية الثقة",
      domain: "general",
      psi: 0.88,
      verified: true,
    });

    const manager = getMemoryManager(userId);
    const working = manager.listWorking();
    assert.ok(working.length >= 1, "expected at least one working-memory entry");
  });
});

describe("Graph Bridge (Phase 11.2)", () => {
  it("finds nodes related to ideal gas / thermodynamics", async () => {
    const result = await retrieveGraphContext({
      userId: "test-user-graph",
      query: "اشرح قانون الغاز المثالي والعلاقة بين الضغط ودرجة الحرارة",
      maxNodes: 10,
      enableDeduction: true,
    });

    assert.ok(result.nodes.length >= 1, "expected matching graph nodes");
    assert.ok(result.stats.totalGraphNodes > 0);
    assert.ok(typeof result.formattedBlock === "string");
  });

  it("returns empty-ish result for unrelated query without crashing", async () => {
    const result = await retrieveGraphContext({
      userId: "test-user-graph-2",
      query: "وصفة كعكة الشوكولاتة بالتفصيل",
      enableDeduction: true,
    });

    assert.ok(Array.isArray(result.nodes));
    assert.ok(Array.isArray(result.edges));
    assert.ok(Array.isArray(result.paths));
  });

  it("mergeGraphIntoMemory attaches nodes and edges", async () => {
    const mem = await retrieveMemoryContext({
      userId: "test-merge",
      query: "نيوتن",
    });
    const graph = await retrieveGraphContext({
      userId: "test-merge",
      query: "نيوتن قوة تسارع",
    });

    const merged = mergeGraphIntoMemory(mem.context, graph);
    assert.equal(merged.graphNodes.length, graph.nodes.length);
    assert.equal(merged.graphEdges.length, graph.edges.length);
  });

  it("getKnowledgeGraph returns a usable instance", async () => {
    const g = await getKnowledgeGraph("test-user-kg");
    const snap = g.getSnapshot();
    assert.ok(snap.nodeCount > 0);
    assert.ok(snap.edgeCount > 0);
  });
});

describe("Workspace integration (11.1 + 11.2)", () => {
  it("runCognitiveWorkspace completes a full cycle with memory+graph", async () => {
    const result = await runCognitiveWorkspace({
      userId: "test-ws-full",
      question: "ما هو قانون الغاز المثالي؟",
      depth: "balanced",
    });

    assert.ok(result.answer.length > 0);
    assert.ok(result.trace);
    assert.ok(result.trace.plan.tasks.length >= 3);

    const retrieveTask = result.trace.plan.tasks.find((t) => t.id === "t_retrieve");
    assert.ok(retrieveTask);
    assert.ok(
      retrieveTask!.status === "done" || retrieveTask!.status === "failed",
      `retrieve status = ${retrieveTask!.status}`
    );

    // Memory step should appear in the trace
    const memStep = result.trace.steps.find((s) => s.name === "memory_and_graph");
    assert.ok(memStep, "expected memory_and_graph step in trace");

    // Confidence should mention domain
    assert.ok(result.confidence.evidence.some((e) => e.includes("النطاق")));
  });
});
