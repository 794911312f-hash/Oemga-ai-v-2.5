/**
 * tests/cognitive-workspace-synthesis.test.ts
 * Phase 11.4 — Synthesizer + Confidence Estimator
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  synthesizeAnswer,
  estimateConfidence,
  createCognitivePlan,
  configForDepth,
  runCognitiveWorkspace,
  type MemoryContext,
  type SynthesisResult,
} from "../src/lib/omega/cognitiveWorkspace/index.ts";
import type { OmegaCandidate } from "../src/lib/omega/omegaCore.ts";

function emptyMemory(): MemoryContext {
  return {
    episodic: [],
    semantic: [],
    procedural: [],
    graphNodes: [],
    graphEdges: [],
    workingKeys: [],
  };
}

describe("Synthesizer (Phase 11.4)", () => {
  it("prefers core answer when present (core_only)", () => {
    const { plan } = createCognitivePlan({
      question: "ما هي الجاذبية؟",
      depth: "balanced",
      config: configForDepth("balanced"),
    });

    const candidates: OmegaCandidate[] = [
      { modelId: "gemini-3.8-flash" as any, text: "الجاذبية قوة تجاذب بين الكتل.", simulated: false, psi: 0.82 },
    ];

    const result = synthesizeAnswer({
      plan,
      memory: emptyMemory(),
      tools: null,
      candidates,
      coreAnswer: "الجاذبية قوة تجاذب بين الكتل.",
      coreSourceClass: "real",
      corePsi: 0.82,
    });

    assert.equal(result.method, "core_only");
    assert.equal(result.sourceClass, "real");
    assert.ok(result.answer.includes("الجاذبية"));
  });

  it("uses tool output as primary when core is placeholder", () => {
    const { plan } = createCognitivePlan({
      question: "احسب 2+2",
      depth: "balanced",
      config: configForDepth("balanced"),
    });

    const result = synthesizeAnswer({
      plan,
      memory: emptyMemory(),
      tools: {
        plan: {
          primaryTool: "calculator",
          auxiliaryTools: [],
          steps: [],
          confidence: 0.9,
          rationale: "test",
          executionMode: "single_tool",
        },
        results: [
          {
            toolId: "calculator",
            success: true,
            output: "النتيجة العددية: 4",
            sourceClass: "real",
            latencyMs: 2,
          },
        ],
        records: [],
        formattedBlock: "النتيجة العددية: 4",
        toolsUsed: ["calculator"],
      },
      candidates: [],
      coreAnswer: "[Cognitive Workspace — Phase 11.1]\nplaceholder",
      coreSourceClass: "simulated",
      corePsi: 0.5,
    });

    assert.equal(result.method, "tools_primary");
    assert.ok(result.answer.includes("4"));
    assert.ok(result.injectedSections.includes("calculator"));
  });

  it("falls back to memory when nothing else is available", () => {
    const { plan } = createCognitivePlan({
      question: "قانون نيوتن",
      depth: "fast",
      config: configForDepth("fast"),
    });

    const memory = emptyMemory();
    memory.semantic.push({
      id: "ax1",
      userId: "u",
      topic: "قانون نيوتن الثاني",
      content: "F = m a",
      domain: "science_factual",
      confidence: 0.97,
      tags: ["axiom", "physics"],
      embedding: [],
      accessCount: 0,
      timestamp: Date.now(),
    });

    const result = synthesizeAnswer({
      plan,
      memory,
      tools: null,
      candidates: [],
      coreAnswer: "",
      coreSourceClass: "failed",
      corePsi: 0,
    });

    assert.equal(result.method, "memory_fallback");
    assert.ok(result.answer.includes("نيوتن") || result.answer.includes("F = m a"));
  });
});

describe("Confidence Estimator (Phase 11.4)", () => {
  it("produces higher confidence for real core + tools", () => {
    const { plan } = createCognitivePlan({
      question: "احسب مشتقة x^2",
      depth: "balanced",
      config: configForDepth("balanced"),
    });

    const synthesis: SynthesisResult = {
      answer: "2x",
      method: "core_plus_tools",
      sourceClass: "real",
      notes: ["دمجت مخرجات الأداة مع إجابة النواة"],
      injectedSections: ["symbolic_cas"],
    };

    const report = estimateConfidence({
      plan,
      memory: emptyMemory(),
      tools: {
        plan: {
          primaryTool: "symbolic_cas",
          auxiliaryTools: [],
          steps: [],
          confidence: 0.95,
          rationale: "cas",
          executionMode: "single_tool",
        },
        results: [
          {
            toolId: "symbolic_cas",
            success: true,
            output: "2x",
            sourceClass: "real",
            latencyMs: 5,
          },
        ],
        records: [],
        formattedBlock: "",
        toolsUsed: ["symbolic_cas"],
      },
      candidates: [
        { modelId: "deepseek-r1-compat" as any, text: "2x", simulated: false, psi: 0.9 },
      ],
      synthesis,
      corePsi: 0.88,
      coreVerified: null,
      depth: "balanced",
      domainKeywords: ["مشتقة"],
    });

    assert.ok(report.psi > 0.5);
    assert.ok(report.confidence > 0.5);
    assert.ok(report.evidence.length >= 3);
    assert.ok(report.evidence.some((e) => /أداة|symbolic/i.test(e)));
    assert.equal(report.sourceClass, "real");
  });

  it("lowers confidence for plan_placeholder", () => {
    const { plan } = createCognitivePlan({
      question: "؟؟؟",
      depth: "fast",
      config: configForDepth("fast"),
    });

    const synthesis: SynthesisResult = {
      answer: "لم أتمكن",
      method: "plan_placeholder",
      sourceClass: "failed",
      notes: [],
      injectedSections: [],
    };

    const report = estimateConfidence({
      plan,
      memory: emptyMemory(),
      tools: null,
      candidates: [],
      synthesis,
      corePsi: 0.2,
      coreVerified: null,
      depth: "fast",
    });

    assert.ok(report.confidence <= 0.35);
    assert.equal(report.sourceClass, "failed");
    assert.ok(report.risk.length >= 1);
  });
});

describe("Workspace integration (11.4)", () => {
  it("runCognitiveWorkspace returns rich confidence report", async () => {
    const result = await runCognitiveWorkspace({
      userId: "test-ws-conf",
      question: "ما هو قانون الغاز المثالي؟",
      depth: "balanced",
    });

    assert.ok(result.confidence);
    assert.ok(typeof result.confidence.psi === "number");
    assert.ok(Array.isArray(result.confidence.evidence));
    assert.ok(Array.isArray(result.confidence.risk));
    assert.ok(Array.isArray(result.confidence.unknowns));

    const synthStep = result.trace.steps.find((s) => s.name === "synthesize");
    assert.ok(synthStep, "expected synthesize step");
    assert.ok(synthStep!.status === "ok" || synthStep!.status === "warn");

    const confStep = result.trace.steps.find((s) => s.name === "confidence");
    assert.ok(confStep);
  });
});
