/**
 * tests/evidence-psi.test.ts — hybrid Ψ honesty tests
 */
import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  scoreEvidencePsi,
  trimmedCentroid,
  arithmeticCheck,
  structuralQuality,
  rankByHybridPsi,
  textSanityProxy,
} from "../src/lib/omega/evidencePsi.ts";
import { normalize, cosine } from "../src/lib/omega/math.ts";

describe("trimmedCentroid", () => {
  it("moves away from outlier when k>=3", () => {
    const a = normalize([1, 0, 0, 0]);
    const b = normalize([0.98, 0.1, 0, 0]);
    const far = normalize([0, 0, 0, 1]);
    const c = trimmedCentroid([a, b, far], 1);
    assert.ok(cosine(c, a) > cosine(c, far));
  });
});

describe("arithmeticCheck", () => {
  it("rewards correct product not repeated factors", () => {
    assert.equal(arithmeticCheck("احسب 17 × 23", "391"), 1);
    assert.equal(arithmeticCheck("احسب 17 × 23", "17 و 23 يعطيان 400 تقريبا"), 0);
  });

  it("respects operator precedence: 3 + 4 × 5 = 23", () => {
    assert.equal(arithmeticCheck("احسب 3 + 4 × 5", "23"), 1);
    assert.equal(arithmeticCheck("احسب 3 + 4 × 5", "7"), 0);
  });

  it("returns neutral 0.5 for algebra / non-pure expressions", () => {
    assert.equal(arithmeticCheck("حل x^2 - 4 = 0", "x=2 أو x=-2"), 0.5);
    assert.equal(arithmeticCheck("عاصمة فرنسا", "Paris"), 0.5);
  });

  it("accepts expected number inside an explanation", () => {
    assert.equal(
      arithmeticCheck("احسب 17 × 23", "391 لأن 17×20=340 و17×3=51"),
      1
    );
    assert.equal(arithmeticCheck("احسب 17 × 23", "391 (نحو 400)"), 1);
    assert.equal(arithmeticCheck("احسب 17 × 23", "17 × 23 = 391"), 1);
    assert.equal(arithmeticCheck("احسب 17 × 23", "391"), 1);
    assert.equal(arithmeticCheck("احسب 17 × 23", "401"), 0);
  });

  it("rejects decoy mentions of the correct number", () => {
    assert.equal(arithmeticCheck("احسب 17 × 23", "الجواب 401 وليس 391"), 0);
    assert.equal(arithmeticCheck("احسب 17 × 23", "ربما 400 أو 391 أو 401"), 0);
    assert.equal(
      arithmeticCheck("احسب 17 × 23", "الناتج 401. (ملاحظة: 391 غير صحيح)"),
      0
    );
    assert.equal(arithmeticCheck("احسب 17 × 23", "لا، ليس 391 بل 401"), 0);
  });

  it("accepts conclusion markers after step equations", () => {
    assert.equal(
      arithmeticCheck(
        "احسب 17 × 23",
        "17×20=340 و17×3=51 فالمجموع 391"
      ),
      1
    );
  });

  it("decisive arithmetic ranks correct above agreeing wrongs", () => {
    const r = scoreEvidencePsi(
      ["الجواب 400", "أعتقد 400", "391"],
      { question: "احسب 17 × 23", trimOutliers: true }
    );
    const rank = rankByHybridPsi(r);
    assert.equal(rank[0], 2, `hybrid=${JSON.stringify(r.psiHybrid)}`);
    assert.ok(
      r.psiHybrid[2] - Math.max(r.psiHybrid[0], r.psiHybrid[1]) >= 0.15,
      `margin too small: ${JSON.stringify(r.psiHybrid)}`
    );
  });
});

describe("scoreEvidencePsi honesty", () => {
  it("correct short math beats long wrong repeating numbers", () => {
    const q = "احسب 17 × 23";
    const wrong =
      "نبدأ بـ 17 ثم نضرب في 23. نفصل 17×20=340 و17×3=51 لكن الناتج النهائي 400 بعد تقريب.";
    const correct = "391";
    const r = scoreEvidencePsi([wrong, correct], { question: q, trimOutliers: true });
    const rank = rankByHybridPsi(r);
    assert.equal(rank[0], 1, `expected correct idx1 first, hybrid=${JSON.stringify(r.psiHybrid)}`);
  });

  it("long wrong capital does not beat short correct", () => {
    const q = "عاصمة فرنسا";
    const wrong =
      "فرنسا دولة أوروبية كبيرة عاصمتها التاريخية كانت مدناً متعددة وغالباً ما يخطئ الناس لكن الجواب ليون الكبرى حسب سرد مطوّل بلا أساس.";
    const correct = "Paris";
    const r = scoreEvidencePsi([wrong, correct], { question: q });
    assert.ok(
      r.psiHybrid[1] >= r.psiHybrid[0] * 0.85 || rankByHybridPsi(r)[0] === 1,
      `long wrong must not dominate: ${JSON.stringify(r.psiHybrid)}`
    );
  });

  it("two wrong vs one correct without external verify → uncertain", () => {
    const r = scoreEvidencePsi(
      ["الجواب 5", "أعتقد 5", "الجواب الصحيح 4"],
      { question: "احسب 2+2", trimOutliers: true, uncertainSpread: 0.15 }
    );
    assert.ok(
      r.uncertain === true || r.notes.some((n) => /uncertain/i.test(n)),
      `expected uncertain, got uncertain=${r.uncertain} notes=${r.notes} hybrid=${JSON.stringify(r.psiHybrid)}`
    );
  });
});

describe("structuralQuality", () => {
  it("penalizes empty, does not reward verbosity", () => {
    assert.ok(structuralQuality("") < structuralQuality("إجابة كافية الطول نسبياً هنا"));
    assert.ok(structuralQuality("x".repeat(500)) <= structuralQuality("إجابة عادية مناسبة"));
  });
});

describe("textSanityProxy", () => {
  it("is not a falsification test — low on empty", () => {
    assert.ok(textSanityProxy("") < 0.4);
  });
});
