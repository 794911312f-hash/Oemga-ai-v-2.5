/**
 * Concurrent code-execution suite for src/server/sandbox.ts (runUntrustedJs).
 * Real child processes, no mocks. Verifies isolation between simultaneous runs,
 * that hostile runs cannot starve well-behaved ones, and resource ceilings.
 */
import test from "node:test";
import assert from "node:assert/strict";
import { runUntrustedJs } from "../src/server/sandbox";

const WALL = 2500;

test("N parallel runs each get their OWN result (no cross-talk / shared state)", async () => {
  const N = 16;
  const res = await Promise.all(
    Array.from({ length: N }, (_, i) =>
      runUntrustedJs(`var secret = ${i}; console.log("run-${i}"); secret * 2`, { wallMs: 6000 }),
    ),
  );
  res.forEach((r, i) => {
    assert.equal(r.ok, true, `run ${i}: ${r.error}`);
    assert.match(r.output, new RegExp(`run-${i}\\b`));
    assert.match(r.output, new RegExp(`Return Value: ${i * 2}$`));
    for (let j = 0; j < N; j++) if (j !== i) assert.doesNotMatch(r.output, new RegExp(`run-${j}\\b`));
  });
});

test("globals written by one run are invisible to the next (fresh process per run)", async () => {
  const a = await runUntrustedJs(`globalThis.leak = "A"; "set"`);
  const b = await runUntrustedJs(`typeof globalThis.leak`);
  assert.equal(a.ok, true);
  assert.match(b.output, /undefined/);
});

test("infinite loops in parallel are all killed, and a healthy run still finishes promptly", async () => {
  const t0 = Date.now();
  const hostile = Array.from({ length: 6 }, () => runUntrustedJs("while(true){}", { wallMs: WALL }));
  const healthy = runUntrustedJs("1+1", { wallMs: 6000 });
  const [h, ...bad] = await Promise.all([healthy, ...hostile]);
  assert.equal(h.ok, true);
  assert.match(h.output, /Return Value: 2/);
  for (const r of bad) { assert.equal(r.ok, false); assert.match(r.error ?? "", /timed out|Execution/i); }
  assert.ok(Date.now() - t0 < WALL + 4000, "hostile runs must not extend total time beyond the wall clock + slack");
});

test("wall-clock ceiling: a never-resolving busy run returns within wallMs (+slack)", async () => {
  const t0 = Date.now();
  const r = await runUntrustedJs("for(;;){}", { wallMs: 800 });
  const dt = Date.now() - t0;
  assert.equal(r.ok, false);
  assert.ok(dt < 3000, `took ${dt}ms`);
});

test("memory bomb is contained to the child and reported as a crash, parent stays alive", async () => {
  const before = process.memoryUsage().rss;
  const r = await runUntrustedJs(`var a=[]; while(true){ a.push(new Array(1e6).fill("x".repeat(64))); }`, { wallMs: 4000, heapMb: 32 });
  assert.equal(r.ok, false);
  assert.match(r.error ?? "", /crashed|memory|timed out/i, `unexpected failure reason: ${r.error}`);
  const grew = process.memoryUsage().rss - before;
  assert.ok(grew < 200 * 1024 * 1024, `parent RSS grew by ${(grew / 1e6) | 0}MB`);
});

test("stdout cap: ~200KB of logs (under the heap limit) hits the 64KiB cap -> truncated, in parallel", async () => {
  const flood = `var s="x".repeat(1000); for(var i=0;i<200;i++){ console.log(s); }`;
  const res = await Promise.all(Array.from({ length: 4 }, () => runUntrustedJs(flood, { wallMs: 5000 })));
  for (const r of res) { assert.equal(r.truncated, true); assert.equal(r.ok, false); assert.equal(r.error, "Output too large"); }
});

test("heavy log flood (~200MB) exceeds the heap cap and is reported as a contained crash", async () => {
  const flood = `var s="x".repeat(1024); for(var i=0;i<200000;i++){ console.log(s); }`;
  const res = await Promise.all(Array.from({ length: 4 }, () => runUntrustedJs(flood, { wallMs: 5000 })));
  for (const r of res) { assert.equal(r.ok, false); assert.match(r.error ?? "", /crashed|too large|timed out/i); }
});

test("sandbox exposes no host capabilities (parallel probes)", async () => {
  const probes: Record<string, string> = {
    process: `typeof process`,
    require: `typeof require`,
    module: `typeof module`,
    fs: `typeof require==='function' ? 'has-require' : 'no-require'`,
    Buffer: `typeof Buffer`,
    fetch: `typeof fetch`,
    setTimeout: `typeof setTimeout`,
    globalThisProcess: `typeof globalThis.process`,
    ctorEscape: `(function(){ try { return this.constructor.constructor("return process")() } catch(e){ return "blocked:" + e.message } })()`,
    evalStr: `(function(){ try { return eval("1+1") } catch(e){ return "blocked" } })()`,
    fnCtor: `(function(){ try { return (function(){}).constructor("return 1")() } catch(e){ return "blocked" } })()`,
    // Extended leakage probes (MATH-SECURITY-ROADMAP A2)
    childProcess: `(function(){ try { return typeof require==='function' ? typeof require('child_process') : 'no-require' } catch(e){ return 'blocked:'+e.message } })()`,
    fsRead: `(function(){ try { if (typeof require!=='function') return 'no-require'; var fs=require('fs'); return typeof fs.readFileSync } catch(e){ return 'blocked:'+e.message } })()`,
    envKeys: `(function(){ try { return typeof process==='undefined' ? 'no-process' : Object.keys(process.env||{}).join(',') } catch(e){ return 'blocked' } })()`,
    workerThreads: `(function(){ try { return typeof require==='function' ? typeof require('worker_threads') : 'no-require' } catch(e){ return 'blocked:'+e.message } })()`,
    netConnect: `(function(){ try { return typeof require==='function' ? typeof require('net') : 'no-require' } catch(e){ return 'blocked:'+e.message } })()`,
    webAssembly: `(function(){ try { return typeof WebAssembly } catch(e){ return 'blocked' } })()`,
  };
  const out = await Promise.all(Object.entries(probes).map(async ([k, code]) => [k, await runUntrustedJs(code)] as const));
  for (const [k, r] of out) {
    const v = r.output + (r.error ?? "");
    assert.doesNotMatch(v, /\[object process\]|has-require|TOP-SECRET|function\b.*require/i, `${k}: ${v}`);
    if (["process", "require", "module", "Buffer", "fetch", "globalThisProcess"].includes(k)) {
      assert.match(v, /undefined/, `${k}: ${v}`);
    }
    if (["childProcess", "fsRead", "workerThreads", "netConnect"].includes(k)) {
      assert.match(v, /no-require|blocked|undefined/i, `${k} must not load host modules: ${v}`);
    }
    if (k === "envKeys") {
      assert.doesNotMatch(v, /PATH|HOME|OMEGA_|SECRET|KEY|TOKEN/i, `env must be empty: ${v}`);
    }
  }
});


test("environment is empty: no secrets reachable even if the parent has them", async () => {
  process.env.OMEGA_TEST_SECRET = "TOP-SECRET-VALUE";
  const r = await runUntrustedJs(`typeof process === "undefined" ? "no-process" : JSON.stringify(process.env)`);
  assert.doesNotMatch(r.output + (r.error ?? ""), /TOP-SECRET-VALUE/);
  delete process.env.OMEGA_TEST_SECRET;
});

test("syntax errors, thrown values and non-serialisable results are reported without crashing", async () => {
  const cases = ["var x = ;", "throw new Error('boom')", "throw 'str'", "var o={}; o.self=o; o", "Symbol('s')", "(function(){ return 1n })()"];
  const res = await Promise.all(cases.map((c) => runUntrustedJs(c)));
  for (const r of res) assert.equal(typeof r.ok, "boolean");
  assert.equal(res[0].ok, false);
  assert.match(res[1].error ?? "", /boom/);
});

test("burst of 40 concurrent runs completes with correct per-run results (no process leak)", async () => {
  const N = 40;
  const t0 = Date.now();
  const res = await Promise.all(Array.from({ length: N }, (_, i) => runUntrustedJs(`${i}+1`, { wallMs: 15000 })));
  const ok = res.filter((r, i) => r.ok && r.output.includes(`Return Value: ${i + 1}`)).length;
  console.log(`# burst: ${ok}/${N} correct in ${Date.now() - t0}ms`);
  assert.equal(ok, N);
});
