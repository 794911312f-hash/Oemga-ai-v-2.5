/**
 * tests/workspace-http-security.test.ts
 * Phase 12.3 — HTTP integration + security tests for Cognitive Workspace API
 *
 * Spins up a minimal Express app with only workspace routes (no full server.ts).
 */

import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import express from "express";
import type { Server } from "node:http";
import { registerWorkspaceRoutes } from "../src/server/workspaceRoutes.ts";
import {
  clearCoreRunner,
  registerCoreRunner,
} from "../src/lib/omega/cognitiveWorkspace/index.ts";

let server: Server;
let baseUrl: string;

function createTestApp() {
  const app = express();
  app.use(express.json({ limit: "1mb" }));
  // Guest by default (no req.user) — matches production guest path
  registerWorkspaceRoutes(app);
  return app;
}

async function request(
  method: string,
  path: string,
  body?: unknown,
  headers: Record<string, string> = {}
): Promise<{ status: number; json: any }> {
  const res = await fetch(`${baseUrl}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...headers,
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, json };
}

before(async () => {
  clearCoreRunner();
  // Lightweight bound core so reason step does not only placeholder
  registerCoreRunner(async (req) => ({
    answer: `اختبار: ${req.question.slice(0, 80)}`,
    candidates: [
      {
        modelId: "gemini-3.8-flash" as any,
        text: `اختبار: ${req.question.slice(0, 80)}`,
        simulated: false,
        psi: 0.8,
      },
    ],
    sourceClass: "real",
    psi: 0.8,
    verified: true,
  }), "http-test");

  const app = createTestApp();
  await new Promise<void>((resolve) => {
    server = app.listen(0, "127.0.0.1", () => resolve());
  });
  const addr = server.address();
  if (addr && typeof addr === "object") {
    baseUrl = `http://127.0.0.1:${addr.port}`;
  } else {
    throw new Error("failed to bind test server");
  }
});

after(async () => {
  clearCoreRunner();
  await new Promise<void>((resolve, reject) => {
    server.close((err) => (err ? reject(err) : resolve()));
  });
});

describe("Workspace HTTP — health & plan", () => {
  it("GET /api/omega/workspace/health", async () => {
    const { status, json } = await request("GET", "/api/omega/workspace/health");
    assert.equal(status, 200);
    assert.equal(json.ok, true);
    assert.ok(json.coreBridge);
    assert.equal(json.coreBridge.wired, true);
  });

  it("POST /plan requires question", async () => {
    const { status, json } = await request("POST", "/api/omega/workspace/plan", {});
    assert.equal(status, 400);
    assert.equal(json.ok, false);
  });

  it("POST /plan returns task graph", async () => {
    const { status, json } = await request("POST", "/api/omega/workspace/plan", {
      question: "ما هو قانون نيوتن الثاني؟",
      depth: "balanced",
    });
    assert.equal(status, 200);
    assert.equal(json.ok, true);
    assert.ok(json.plan?.tasks?.length >= 3);
    assert.ok(json.domain);
  });
});

describe("Workspace HTTP — security", () => {
  it("rejects empty question on full workspace", async () => {
    const { status, json } = await request("POST", "/api/omega/workspace", {
      question: "   ",
      depth: "fast",
    });
    assert.equal(status, 400);
    assert.equal(json.ok, false);
  });

  it("rejects oversized question", async () => {
    const { status, json } = await request("POST", "/api/omega/workspace", {
      question: "س".repeat(12_001),
      depth: "fast",
    });
    assert.equal(status, 400);
  });

  it("deep depth requires authentication", async () => {
    const { status, json } = await request("POST", "/api/omega/workspace", {
      question: "اشرح فرضية ريمان",
      depth: "deep",
    });
    // requireAuthenticatedUser → 401 without req.user
    assert.equal(status, 401);
    assert.equal(json.ok, false);
  });

  it("guest GET trace without session is rejected", async () => {
    // First run a fast cycle to get a workspaceId
    const run = await request("POST", "/api/omega/workspace", {
      question: "ما هو الغاز المثالي؟",
      depth: "fast",
    });
    assert.equal(run.status, 200);
    assert.ok(run.json.workspaceId);

    const { status, json } = await request(
      "GET",
      `/api/omega/workspace/trace/${run.json.workspaceId}`
    );
    assert.equal(status, 401);
    assert.match(String(json.error || ""), /session|Guest/i);
  });

  it("guest with session can store and read own trace only", async () => {
    const session = "testguestsession01";
    const run = await request(
      "POST",
      "/api/omega/workspace",
      { question: "قانون هوك؟", depth: "fast" },
      { "X-Omega-Guest-Session": session }
    );
    assert.equal(run.status, 200);
    const id = run.json.workspaceId;
    assert.ok(id);
    assert.match(String(id), /^ws_/);

    // Same session → allowed
    const ok = await request(
      "GET",
      `/api/omega/workspace/trace/${id}`,
      undefined,
      { "X-Omega-Guest-Session": session }
    );
    assert.equal(ok.status, 200);
    assert.equal(ok.json.ok, true);
    assert.ok(ok.json.trace);

    // Different session → not found / not owned
    const other = await request(
      "GET",
      `/api/omega/workspace/trace/${id}`,
      undefined,
      { "X-Omega-Guest-Session": "otherguestsession99" }
    );
    assert.ok(other.status === 404 || other.status === 401);
  });

  it("ignores attacker-controlled body userId for guests", async () => {
    const { status, json } = await request("POST", "/api/omega/workspace", {
      question: "اختبار هوية",
      depth: "fast",
      userId: "victim-user-should-be-ignored",
    });
    assert.equal(status, 200);
    // Response userId should not become the attacker-supplied victim id
    // (storage may be guest:… scoped; top-level userId from resolveTrustedUserId path)
    assert.notEqual(json.userId, "victim-user-should-be-ignored");
  });
});

describe("Workspace HTTP — happy path", () => {
  it("fast cycle returns answer + confidence + trace", async () => {
    const { status, json } = await request("POST", "/api/omega/workspace", {
      question: "ما هو قانون نيوتن الثاني؟",
      depth: "fast",
    });
    assert.equal(status, 200);
    assert.equal(json.ok, true);
    assert.ok(typeof json.answer === "string" && json.answer.length > 5);
    assert.ok(json.confidence);
    assert.ok(json.trace?.steps?.length >= 1);
    assert.ok(["real", "mixed", "simulated", "failed"].includes(json.sourceClass));
  });
});
