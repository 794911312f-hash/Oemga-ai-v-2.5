/**
 * Security threat-model regression tests.
 * These are deterministic unit checks, not a substitute for container/network
 * hardening or Firebase rules in production.
 */
import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { assertPublicHttpUrl, isPrivateAddress, UnsafeUrlError } from "../src/server/urlGuard.ts";
import {
  resolveTrustedUserId,
  sanitizeUserId,
  validateSecretInput,
  routeGuard,
} from "../src/server/security.ts";

describe("security threat model", () => {
  it("blocks private, loopback, link-local and mapped IPv4 destinations", () => {
    for (const ip of [
      "127.0.0.1",
      "10.0.0.8",
      "172.16.0.1",
      "192.168.1.1",
      "169.254.169.254",
      "::1",
      "::ffff:127.0.0.1",
      "fc00::1",
      "fe80::1",
    ]) {
      assert.equal(isPrivateAddress(ip), true, ip);
    }
    assert.equal(isPrivateAddress("8.8.8.8"), false);
  });

  it("rejects URL schemes, credentials, local hosts and non-standard ports", async () => {
    for (const url of [
      "file:///etc/passwd",
      "ftp://example.com/data",
      "http://user:pass@example.com/",
      "http://localhost/health",
      "http://127.0.0.1/health",
      "http://example.com:8080/",
    ]) {
      await assert.rejects(
        () => assertPublicHttpUrl(url),
        (error: unknown) => error instanceof UnsafeUrlError,
        url,
      );
    }
  });

  it("keeps guest identity isolated from attacker-controlled ids", () => {
    const req = { user: { isGuest: true }, body: { userId: "victim" }, headers: { "x-user-id": "victim" } } as any;
    assert.deepEqual(resolveTrustedUserId(req, { allowGuest: true }), {
      ok: true,
      userId: "guest-user",
      isGuest: true,
    });
    assert.equal(sanitizeUserId("../../victim"), "guest-user");
    assert.equal(sanitizeUserId("safe-user_1"), "safe-user_1");
  });

  it("rejects control characters and oversized secret inputs", () => {
    assert.equal(validateSecretInput("  valid-key  "), "valid-key");
    assert.equal(validateSecretInput("bad\u0000key"), null);
    assert.equal(validateSecretInput("x".repeat(513)), null);
    assert.equal(validateSecretInput(42), null);
  });

  it("requires authentication for paid/remote route prefixes", () => {
    let status = 0;
    let body: unknown;
    let nextCalled = false;
    const req = {
      originalUrl: "/api/omega/browser-use/search",
      url: "/browser-use/search",
      user: { isGuest: true },
    } as any;
    const res = {
      status(code: number) { status = code; return this; },
      json(value: unknown) { body = value; return this; },
    } as any;
    routeGuard(req, res, () => { nextCalled = true; });
    assert.equal(status, 401);
    assert.equal(nextCalled, false);
    assert.deepEqual(body, { ok: false, error: "Authentication required for this operation." });
  });
});
