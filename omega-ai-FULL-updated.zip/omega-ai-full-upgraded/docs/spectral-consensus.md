# Spectral Consensus — الأساس الرياضي

الملف: `src/lib/omega/spectralConsensus.ts` · الاختبارات: `tests/spectral-consensus.test.ts` (23 اختباراً)

| المفهوم | التعريف | ما يعطيه |
|---|---|---|
| التقارب | `W_ij = exp(-‖x̂_i−x̂_j‖²/2σ²)`، `σ=0.5` مطلق | رسم موزون بين الإجابات |
| لابلاسيان | `L = D−W`، `L_sym = I−D^{-1/2}WD^{-1/2}` | طيف الرسم |
| تحليل ذاتي | Jacobi الدوري | قيم ومتجهات ذاتية |
| عدد المكونات | تعدّد القيمة الذاتية 0 لـ `L` | الاتصال |
| `spectralGap` | `λ₂(L_sym)` | معدل تقارب السير العشوائي |
| `cohesion` | `λ₂(L_sym)/(n/(n−1))` ∈ [0,1] | اتفاق مطلق (1 = كلها متطابقة) |
| Cheeger | `λ₂/2 ≤ h ≤ √(2λ₂)` | حد على أضيق عنق في الرسم |
| `k` | أكبر فجوة بين القيم الذاتية (eigengap) | عدد المجموعات |
| التجميع | Ng–Jordan–Weiss: متجهات ذاتية → تطبيع صفوف → k-means | تسمية كل إجابة |
| `weights` | متجه Perron لـ `W` (موجب ومجموعه 1) | مركزية طيفية لكل إجابة |

## حدود صريحة
- المعنى يأتي من المتجهات المُدخلة. مع `hashEmbed` المعجمي يقيس هذا التشابه البنيوي/المعجمي لا الدلالي العميق.
- العنصر المنفرد المخالف له conductance≈1 فلا يظهر كعنقود؛ يُكشف عبر `lowSupport` (عتبة إرشادية `0.25×median`).
- `σ` المطلق يعني أن إجابات مختلفة لفظياً تبدو مفككة؛ هذا قراءة صادقة لا عيب.

## الربط (تم)
- **`langGraphBridge.ts`**: بعد جمع إجابات النماذج يُستدعى `embedBatch` ثم `computeSpectralConsensus`. تُملأ `spectralState` بقيم حقيقية:
  - `coherence` / `energy` ← `cohesion`
  - `spectralRadius` ← `perronRoot`
  - `entropy` ← `1 - cohesion`
  - `psi` يُشتق من كتلة العنقود المهيمن + التماسك.
- **`kernelResearch.ts`**: أُضيفت `computeVectorSpectralCertificate(vectors)` التي تُرجع شهادة طيفية كاملة (Cheeger، فجوة، أوزان Perron، outliers) بدل نسبة التقلّص العددية فقط. الدالة القديمة `estimateSpectralTraceCertificate` ما زالت متاحة لآثار الخلاف عبر الجولات.

## نظرية المعلومات والفيزياء الإحصائية (تم)

- `src/lib/omega/infoPhysics.ts`: Boltzmann weights، طاقة حرة قابلة للقياس \(F=\langle E\rangle - T S\)، NMI بين العناقيد والصحة.
- `consensusEval` يقيس الآن: boltzmann aggregator، freeEnergy، nmiClusterCorrect.
- نتيجة offline أولية: **freeEnergy** أعلى AUROC (~0.71) بين المقاييس المختبرة للتنبؤ بوجود مرشح صحيح.

## إصلاحات الحالات الحدية (2026-10-18)

- **n = 1:** `cohesion = 0`، `spectralSufficient = false` (لا يوجد زوج للمقارنة).
- **n = 2:** `cohesion = W₀₁` (تشابه مباشر)، `spectralSufficient = false`، `relaxationTime = ∞`.
  السبب: \(L_{\mathrm{sym}}\) لرسم متصل بلا حلقات ذاتية على عقدتين له دائماً \(\lambda_2=2\)، فيعطي التماسك الطيفي الكلاسيكي قيمة 1 حتى لإجابتين متعامدتين؛ وسلسلة ماركوف تتناوب ولا تختلط.
- **n ≥ 3:** السلوك الطيفي السابق دون تغيير، `spectralSufficient = true`.
- **AUROC:** متوسط رتب للتعادل (mid-ranks) في `consensusEval.auroc` حتى لا تعتمد النتيجة على ترتيب الإدخال.

## أمن تنفيذ الكود (P0 — 2026-10-18)

- `SafeCodeSandbox` لم يعد يمرّر كائنات المضيف (`Math`, `String`, `Object`, …) إلى `vm` داخل العملية.
- على الخادم: التفويض إلى `src/server/sandbox.ts` (عملية فرعية + env فارغ + حدود ذاكرة/زمن).
- المتصفح: معطّل افتراضيًا؛ `OMEGA_ALLOW_BROWSER_SANDBOX=1` للعروض المحلية الموثوقة فقط.
- إيقاف كامل: `OMEGA_DISABLE_CODE_SANDBOX=1`.
- ما زال مطلوبًا: سياسة شبكة للحاوية (منع SSRF/egress داخلي) — نموذج الصلاحيات في Node لا يمنع الشبكة الصادرة.
