# Algorithm Upgrade v2.2 — Toward stronger algorithmic honesty & signal

## New module: `src/lib/omega/evidencePsi.ts`

| Idea | Problem solved |
|------|----------------|
| **Trimmed centroid** | Outlier / correlated cluster dominance; helps minority-correct |
| **Ψ_hybrid** | Agreement-only Ψ cannot see truth → blend Q, F_proxy, numeric coverage, evidence |
| **numericCoverage** | Math questions: reward answers that reuse question numbers |
| **structuralQuality** | Replace fixed novelty with measured text structure |
| **textSanityProxy** | Replace F≡1 theatre with text-based neutral/low scores |
| **uncertain** | Explicit when k<3 or top-gap tiny |

## Wired into

- `omegaCore.scorePsi` → uses `scoreEvidencePsi`
- `kernelUpgrade.computeConsensusPsi` → trimmed centroid + EMA reset on topic shift
- `kernelUpgrade.computeReasoningQuality` / `computeFalsificationResistance` → measured proxies
- `neuralSymbolicHyperGrid` → **token** match (not substring `includes`)

## Honest ceiling

These changes raise **engineering algorithm quality** substantially (engineering design quality only — not a measured task-performance score.
A true **≥8/10 on real-task superiority** still requires provider benchmarks with external verify/CAS.
EOF
echo ok
