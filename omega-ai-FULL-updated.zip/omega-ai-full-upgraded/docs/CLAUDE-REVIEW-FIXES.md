# Fixes from algorithmic review (2026-10-11)

## Confirmed issues addressed

1. **`buildSynthesizerPrompt`** — `{c.modelId}` → `${c.modelId}` in `kernelUpgrade.ts`.
2. **Falsification resistance F** — hardcoded `counterExamples=0, falsificationTests=1` no longer yields F≈1; neutral **0.5** when unmeasured.
3. **Fusion modelCandidates** — removed fake novelty/falsification constants.
4. **Telemetry variance/sigma** — computed from candidate Ψ values, not 0.015/0.122 literals.
5. **Hybrid fallback report** — no `Math.random()` improvement theatre; marked SIMULATED, status regressed, 0 tests.
6. **`promoteIndividual`** — blocked unless `docs/reports/.evolution-gate-status.json` has `decision: PASS` (from `npm run evolution-gate`).

## Still open

- Ψ remains agreement-not-truth (by design; needs external verify/CAS).
- Hyper-Grid keyword `includes` false positives.
- Real provider benchmark for non-offline gate PASS.
- security-phase10 test path for hybrid routes (update test to `src/server/routes/`).
