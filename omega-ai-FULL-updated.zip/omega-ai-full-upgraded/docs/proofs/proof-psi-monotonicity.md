# Proof Sketch: Monotonicity of clipExpPsi in δ

## Lemma

Fix \(\sigma \ge 0\), \(\alpha > 0\), \(\beta > 0\), \(\varepsilon > 0\). Define

\[
D(\sigma) = \alpha\cdot\max(\sigma,\varepsilon) + \beta > 0,
\quad
f(\delta) = \exp(-\delta / D(\sigma)).
\]

Let \(\Psi(\delta) = \mathrm{clip}_{[m,M]}(f(\delta))\) with \(0 < m \le M\) (in code: \(m=0.01\), \(M=1\)).

Then for all \(\delta_1 \le \delta_2\):

\[
\Psi(\delta_1) \ge \Psi(\delta_2).
\]

## Proof

1. \(D(\sigma)\) is independent of \(\delta\) and strictly positive.
2. The map \(\delta \mapsto -\delta/D\) is non-increasing.
3. \(\exp(\cdot)\) is strictly increasing, so \(f(\delta)=\exp(-\delta/D)\) is **strictly decreasing** in \(\delta\).
4. The clip operator \(\mathrm{clip}_{[m,M]}(x)=\min(M,\max(m,x))\) is non-decreasing in \(x\).
5. Composition of a strictly decreasing continuous function with a non-decreasing clip yields a **non-increasing** function of \(\delta\).

Hence \(\delta_1 \le \delta_2 \Rightarrow \Psi(\delta_1) \ge \Psi(\delta_2)\).

## Corollary (rank stability)

If two candidates have \(\delta_a < \delta_b\) at the same \(\sigma\), then \(\Psi_a \ge \Psi_b\).  
Changing \(\alpha,\beta\) (hence \(D\)) does **not** reverse this pairwise order for a fixed pair \((\delta_a,\delta_b,\sigma)\).

## Note on discrete ties

When \(f(\delta)\) falls below \(m\) or above \(M\), plateaus appear (\(\Psi\) constant on intervals). Monotonicity still holds; strict inequality may not.

## Empirical check

`tests/psi-mathematical-properties.test.ts`, `tests/psi-sensitivity.test.ts`.
