# Benchmark Report — omega-benchmark-v0

- **Date:** YYYY-MM-DD
- **Git / package:** 
- **Seed:** 42 (must match `tests/benchmark/suite.json`)
- **Model pool / depth policy:** 
- **Provider keys present:** yes/no (list classes only, never secrets)

## Summary

| Metric | Value |
|--------|-------|
| Accuracy (suite) | |
| Latency p50 / p95 (ms) | |
| Mean model calls / item | |
| Mean top Ψ | |
| Mean Ψ spread | |
| verified true/false/null % | |
| sourceClass real/mixed/simulated/failed % | |
| Global memory writes | |

## Per-item

| id | pass | latency_ms | psi_top | verified | sourceClass |
|----|------|------------|---------|----------|-------------|
| math-derivative-1 | | | | | |
| … | | | | | |

## Router distribution

| modelId | times selected | notes |
|---------|----------------|-------|
| | | |

## Regressions vs previous report

- Previous report: `benchmark-YYYY-MM-DD.md`
- Accuracy Δ:
- Latency Δ:
- Any invariant/test failures:

## Evolution gate

- [ ] Suite run completed with fixed seed
- [ ] No accept of hybrid evolution without non-regression on accuracy
- [ ] Trace artifacts retained (paths):

## Notes

…
