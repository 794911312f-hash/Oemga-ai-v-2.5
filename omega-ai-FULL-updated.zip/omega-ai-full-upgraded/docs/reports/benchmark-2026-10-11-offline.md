# Benchmark Report — omega-benchmark-v1

- **Date (UTC):** 2026-10-11
- **Mode:** offline fixture
- **Evidence tier:** offline_fixture (NOT experimental provider evidence)
- **sourceClass real/mixed/sim+fail:** 0/0/50
- **Seed:** 42
- **Core bridge:** benchmark-offline
- **Items:** 50

## Summary

| Metric | Value |
|--------|-------|
| Accuracy | 100.0% (50/50) |
| Latency p50 / p95 (ms) | 0 / 0 |
| Mean top Ψ | 0.550 |
| verified true/false/null | 0/0/50 |
| sourceClass mix | simulated:50 |

## Per-item

| id | pass | latency_ms | psi_top | verified | sourceClass |
|----|------|------------|---------|----------|-------------|
| math-derivative-1 | yes | 0 | 0.55 | null | simulated |
| math-quadratic-sum | yes | 0 | 0.55 | null | simulated |
| math-integral-1 | yes | 0 | 0.55 | null | simulated |
| math-pythagoras | yes | 0 | 0.55 | null | simulated |
| math-percent | yes | 0 | 0.55 | null | simulated |
| math-log | yes | 0 | 0.55 | null | simulated |
| math-limit | yes | 0 | 0.55 | null | simulated |
| math-matrix-det | yes | 0 | 0.55 | null | simulated |
| math-gcd | yes | 0 | 0.55 | null | simulated |
| code-sum | yes | 0 | 0.55 | null | simulated |
| code-palindrome | yes | 0 | 0.55 | null | simulated |
| code-factorial | yes | 0 | 0.55 | null | simulated |
| code-binary-search | yes | 0 | 0.55 | null | simulated |
| code-sql-select | yes | 0 | 0.55 | null | simulated |
| code-stack | yes | 0 | 0.55 | null | simulated |
| code-http-get | yes | 0 | 0.55 | null | simulated |
| code-json | yes | 0 | 0.55 | null | simulated |
| logic-contradiction | yes | 0 | 0.55 | null | simulated |
| logic-modus-ponens | yes | 0 | 0.55 | null | simulated |
| logic-syllogism | yes | 0 | 0.55 | null | simulated |
| logic-xor | yes | 0 | 0.55 | null | simulated |
| logic-contrapositive | yes | 0 | 0.55 | null | simulated |
| logic-set | yes | 0 | 0.55 | null | simulated |
| logic-and | yes | 0 | 0.55 | null | simulated |
| math-ideal-gas | yes | 0 | 0.55 | null | simulated |
| science-newton2 | yes | 0 | 0.55 | null | simulated |
| science-photosynthesis | yes | 0 | 0.55 | null | simulated |
| science-dna | yes | 0 | 0.55 | null | simulated |
| science-celsius | yes | 0 | 0.55 | null | simulated |
| science-light | yes | 0 | 0.55 | null | simulated |
| science-atom | yes | 0 | 0.55 | null | simulated |
| knowledge-arabic | yes | 0 | 0.55 | null | simulated |
| knowledge-egypt | yes | 0 | 0.55 | null | simulated |
| knowledge-un | yes | 0 | 0.55 | null | simulated |
| knowledge-earth-moon | yes | 0 | 0.55 | null | simulated |
| knowledge-arabic-lang | yes | 0 | 0.55 | null | simulated |
| knowledge-pi | yes | 0 | 0.55 | null | simulated |
| knowledge-http-status | yes | 0 | 0.55 | null | simulated |
| retrieval-context-omega | yes | 0 | 0.55 | null | simulated |
| retrieval-policy | yes | 0 | 0.55 | null | simulated |
| retrieval-number | yes | 0 | 0.55 | null | simulated |
| retrieval-color | yes | 0 | 0.55 | null | simulated |
| retrieval-author | yes | 0 | 0.55 | null | simulated |
| retrieval-date | yes | 0 | 0.55 | null | simulated |
| multi-step-newton | yes | 0 | 0.55 | null | simulated |
| multistep-force-units | yes | 0 | 0.55 | null | simulated |
| multistep-area | yes | 0 | 0.55 | null | simulated |
| multistep-temp | yes | 0 | 0.55 | null | simulated |
| multistep-discount | yes | 0 | 0.55 | null | simulated |
| multistep-avg | yes | 0 | 0.55 | null | simulated |

## Calibration

| Metric | Value |
|--------|-------|
| n | 50 |
| Accuracy | 100.0% |
| Mean confidence | 0.550 |
| Brier (↓ better) | 0.2025 |
| ECE (↓ better) | 0.4500 |
| Confidence gap (mean p − acc) | -0.450 |

> Underconfident on average (gap < −0.05).

> Offline fixture: calibration numbers are harness smoke only, not model calibration claims.


## Honesty

This run used **offline fixtures**. Engineering harness only.
Do **not** cite as model or Ψ task performance.
Filename suffix `-offline` — evolution-gate must not treat as PASS evidence.

## Evolution gate

- [ ] **Not eligible** until a *-run.md report exists (provider-backed)
- [ ] Mathematical + regression tests still pass
- [ ] Promote only if accuracy did not regress beyond policy
