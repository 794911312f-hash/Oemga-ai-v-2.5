# Consensus Evaluation Report — 2026-10-18 (offline)

> **Honesty**: synthetic multi-candidate sets derived from gold expects + hashEmbed.
> Not provider-backed experimental evidence. See `docs/BENCHMARK-REAL.md`.
> Regenerated from current code (AUROC mid-ranks, n<3 cohesion fix, SE/CI/McNemar).

Items: **50** · Candidates per item: **5**

## 1. Aggregator accuracy (vs gold)

| Method | Accuracy ± SE | 95% Wilson CI | n correct / n | Mean conf. |
|--------|---------------|---------------|---------------|------------|
| `majority` | 26.0% ± 6.2% | [15.9%, 39.6%] | 13/50 | 0.324 |
| `self_consistency` | 28.0% ± 6.3% | [17.5%, 41.7%] | 14/50 | 0.324 |
| `logprob_weighted` | 38.0% ± 6.9% | [25.9%, 51.8%] | 19/50 | 0.390 |
| `best_of_n` | 38.0% ± 6.9% | [25.9%, 51.8%] | 19/50 | 1.000 |
| `spectral_weighted` | 28.0% ± 6.3% | [17.5%, 41.7%] | 14/50 | 0.359 |
| `centroid_nearest` | 24.0% ± 6.0% | [14.3%, 37.4%] | 12/50 | 0.524 |
| `boltzmann` | 38.0% ± 6.9% | [25.9%, 51.8%] | 19/50 | 0.390 |

## 2. Paired tests (McNemar, continuity-corrected)

Compares methods on the **same** items. p-value is null when discordant pairs < 5 (χ² unreliable).

| A vs B | Δacc (A−B) | n₁₀ (A✓ B✗) | n₀₁ (A✗ B✓) | χ² | p (approx) |
|--------|------------|-------------|-------------|-----|------------|
| `self_consistency` vs `majority` | 2.0% | 1 | 0 | 0.000 | n/a (<5 disc.) |
| `logprob_weighted` vs `majority` | 12.0% | 9 | 3 | 2.083 | 0.149 |
| `best_of_n` vs `majority` | 12.0% | 9 | 3 | 2.083 | 0.149 |
| `spectral_weighted` vs `majority` | 2.0% | 4 | 3 | 0.000 | 1.000 |
| `centroid_nearest` vs `majority` | -2.0% | 3 | 4 | 0.000 | 1.000 |
| `boltzmann` vs `majority` | 12.0% | 9 | 3 | 2.083 | 0.149 |
| `boltzmann` vs `logprob_weighted` | 0.0% | 0 | 0 | 0.000 | n/a (<5 disc.) |
| `spectral_weighted` vs `logprob_weighted` | -10.0% | 1 | 6 | 2.286 | 0.131 |

## 3. Predictive power of agreement metrics

Higher AUROC / Pearson = metric better separates items that contain a correct answer.
Entropy / JSD / outlierCount / freeEnergy are inverted (lower disagreement → higher score).
AUROC uses mid-ranks for ties.

| Metric | Pearson (any correct) | Pearson (spectral chosen) | AUROC (any correct) |
|--------|----------------------|---------------------------|---------------------|
| `spectral.cohesion` | 0.196 | 0.226 | 0.631 |
| `spectral.gap` | 0.196 | 0.226 | 0.631 |
| `semanticEntropy` | 0.163 | 0.301 | 0.591 |
| `jsdToCentroid` | -0.173 | -0.278 | 0.416 |
| `meanPairwiseCosine` | -0.453 | -0.295 | 0.234 |
| `outlierCount` | 0.186 | 0.280 | 0.595 |
| `nmiClusterCorrect` | 0.368 | -0.099 | 0.643 |
| `freeEnergy` | 0.347 | 0.349 | 0.713 |
| `freeEnergyDisagreement` | 0.175 | 0.153 | 0.627 |
| `disagreementEnergy` | 0.196 | 0.226 | 0.631 |

## 4. Accuracy by category

### math (n=9)

| Method | Accuracy ± SE | 95% CI |
|--------|---------------|--------|
| `majority` | 22.2% ± 13.9% | [6.3%, 54.7%] |
| `self_consistency` | 22.2% ± 13.9% | [6.3%, 54.7%] |
| `logprob_weighted` | 44.4% ± 16.6% | [18.9%, 73.3%] |
| `best_of_n` | 44.4% ± 16.6% | [18.9%, 73.3%] |
| `spectral_weighted` | 33.3% ± 15.7% | [12.1%, 64.6%] |
| `centroid_nearest` | 22.2% ± 13.9% | [6.3%, 54.7%] |
| `boltzmann` | 44.4% ± 16.6% | [18.9%, 73.3%] |

### code (n=8)

| Method | Accuracy ± SE | 95% CI |
|--------|---------------|--------|
| `majority` | 25.0% ± 15.3% | [7.1%, 59.1%] |
| `self_consistency` | 25.0% ± 15.3% | [7.1%, 59.1%] |
| `logprob_weighted` | 12.5% ± 11.7% | [2.2%, 47.1%] |
| `best_of_n` | 12.5% ± 11.7% | [2.2%, 47.1%] |
| `spectral_weighted` | 12.5% ± 11.7% | [2.2%, 47.1%] |
| `centroid_nearest` | 12.5% ± 11.7% | [2.2%, 47.1%] |
| `boltzmann` | 12.5% ± 11.7% | [2.2%, 47.1%] |

### logic (n=7)

| Method | Accuracy ± SE | 95% CI |
|--------|---------------|--------|
| `majority` | 14.3% ± 13.2% | [2.6%, 51.3%] |
| `self_consistency` | 14.3% ± 13.2% | [2.6%, 51.3%] |
| `logprob_weighted` | 57.1% ± 18.7% | [25.0%, 84.2%] |
| `best_of_n` | 57.1% ± 18.7% | [25.0%, 84.2%] |
| `spectral_weighted` | 14.3% ± 13.2% | [2.6%, 51.3%] |
| `centroid_nearest` | 14.3% ± 13.2% | [2.6%, 51.3%] |
| `boltzmann` | 57.1% ± 18.7% | [25.0%, 84.2%] |

### science (n=7)

| Method | Accuracy ± SE | 95% CI |
|--------|---------------|--------|
| `majority` | 28.6% ± 17.1% | [8.2%, 64.1%] |
| `self_consistency` | 42.9% ± 18.7% | [15.8%, 75.0%] |
| `logprob_weighted` | 42.9% ± 18.7% | [15.8%, 75.0%] |
| `best_of_n` | 42.9% ± 18.7% | [15.8%, 75.0%] |
| `spectral_weighted` | 42.9% ± 18.7% | [15.8%, 75.0%] |
| `centroid_nearest` | 28.6% ± 17.1% | [8.2%, 64.1%] |
| `boltzmann` | 42.9% ± 18.7% | [15.8%, 75.0%] |

### knowledge (n=7)

| Method | Accuracy ± SE | 95% CI |
|--------|---------------|--------|
| `majority` | 0.0% ± 0.0% | [0.0%, 35.4%] |
| `self_consistency` | 0.0% ± 0.0% | [0.0%, 35.4%] |
| `logprob_weighted` | 28.6% ± 17.1% | [8.2%, 64.1%] |
| `best_of_n` | 28.6% ± 17.1% | [8.2%, 64.1%] |
| `spectral_weighted` | 14.3% ± 13.2% | [2.6%, 51.3%] |
| `centroid_nearest` | 14.3% ± 13.2% | [2.6%, 51.3%] |
| `boltzmann` | 28.6% ± 17.1% | [8.2%, 64.1%] |

### retrieval (n=6)

| Method | Accuracy ± SE | 95% CI |
|--------|---------------|--------|
| `majority` | 33.3% ± 19.2% | [9.7%, 70.0%] |
| `self_consistency` | 33.3% ± 19.2% | [9.7%, 70.0%] |
| `logprob_weighted` | 33.3% ± 19.2% | [9.7%, 70.0%] |
| `best_of_n` | 33.3% ± 19.2% | [9.7%, 70.0%] |
| `spectral_weighted` | 33.3% ± 19.2% | [9.7%, 70.0%] |
| `centroid_nearest` | 33.3% ± 19.2% | [9.7%, 70.0%] |
| `boltzmann` | 33.3% ± 19.2% | [9.7%, 70.0%] |

### multi_step (n=6)

| Method | Accuracy ± SE | 95% CI |
|--------|---------------|--------|
| `majority` | 66.7% ± 19.2% | [30.0%, 90.3%] |
| `self_consistency` | 66.7% ± 19.2% | [30.0%, 90.3%] |
| `logprob_weighted` | 50.0% ± 20.4% | [18.8%, 81.2%] |
| `best_of_n` | 50.0% ± 20.4% | [18.8%, 81.2%] |
| `spectral_weighted` | 50.0% ± 20.4% | [18.8%, 81.2%] |
| `centroid_nearest` | 50.0% ± 20.4% | [18.8%, 81.2%] |
| `boltzmann` | 50.0% ± 20.4% | [18.8%, 81.2%] |

## 5. Spectral hyper-parameter sensitivity

| σ | minGap | Mean cohesion | Spectral-weighted accuracy |
|---|--------|---------------|----------------------------|
| 0.3 | 0.05 | 0.309 | 28.0% |
| 0.3 | 0.1 | 0.309 | 28.0% |
| 0.3 | 0.2 | 0.309 | 28.0% |
| 0.5 | 0.05 | 0.512 | 28.0% |
| 0.5 | 0.1 | 0.512 | 28.0% |
| 0.5 | 0.2 | 0.512 | 28.0% |
| 0.8 | 0.05 | 0.780 | 28.0% |
| 0.8 | 0.1 | 0.780 | 28.0% |
| 0.8 | 0.2 | 0.780 | 28.0% |
| median | 0.05 | 0.925 | 28.0% |
| median | 0.1 | 0.925 | 28.0% |
| median | 0.2 | 0.925 | 28.0% |

## 6. Takeaways (auto)

- Best aggregator under this offline protocol: **`logprob_weighted`** (38.0% ± 6.9%, 95% CI [25.9%, 51.8%]).
- Strongest predictive metric for “item has a correct candidate”: **`freeEnergy`** (AUROC 0.713).
- No method significantly beats majority at p<0.05 under this offline sample (n=50); treat ranking as provisional.
- Next step for real claims: re-run with provider-backed candidates (`sourceClass=real`) and the same SE/CI/McNemar tables.
