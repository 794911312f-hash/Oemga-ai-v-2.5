# Benchmark Report — omega-benchmark-v1

- **Date (UTC):** 2026-10-11
- **Mode:** workspace runner (provider-backed)
- **Evidence tier:** experimental_provider (provider-backed; eligible for gate review)
- **sourceClass real/mixed/sim+fail:** 27/11/12
- **Seed:** 42
- **Core bridge:** benchmark-openai-provider
- **Items:** 50

## Summary

| Metric | Value |
|--------|-------|
| Accuracy | 84.0% (42/50) |
| Latency p50 / p95 (ms) | 3007 / 8369 |
| Mean top Ψ | 0.521 |
| verified true/false/null | 36/14/0 |
| sourceClass mix | mixed:11, real:27, failed:12 |

## Per-item

| id | pass | latency_ms | psi_top | verified | sourceClass |
|----|------|------------|---------|----------|-------------|
| math-derivative-1 | yes | 1763 | 0.7815 | true | mixed |
| math-quadratic-sum | yes | 3513 | 0.7301 | true | mixed |
| math-integral-1 | yes | 1986 | 0.7815 | true | mixed |
| math-pythagoras | yes | 1956 | 0.3319 | false | real |
| math-percent | yes | 2093 | 0.3247 | false | real |
| math-log | yes | 2011 | 0.3026 | false | real |
| math-limit | yes | 2584 | 0.6599 | true | real |
| math-matrix-det | yes | 2679 | 0.7521 | true | mixed |
| math-gcd | yes | 3424 | 0.6599 | true | real |
| code-sum | no | 7415 | 0.4488 | true | failed |
| code-palindrome | no | 7208 | 0.4488 | true | failed |
| code-factorial | yes | 7154 | 0.4488 | true | failed |
| code-binary-search | no | 7442 | 0.466 | true | failed |
| code-sql-select | yes | 1663 | 0.6671 | true | real |
| code-stack | yes | 2914 | 0.6599 | true | real |
| code-http-get | yes | 4294 | 0.466 | true | failed |
| code-json | yes | 1872 | 0.3443 | false | real |
| logic-contradiction | yes | 3007 | 0.6599 | true | real |
| logic-modus-ponens | yes | 3048 | 0.3443 | false | real |
| logic-syllogism | yes | 8237 | 0.466 | true | failed |
| logic-xor | yes | 3022 | 0.3443 | false | real |
| logic-contrapositive | yes | 8101 | 0.466 | true | failed |
| logic-set | no | 4063 | 0.466 | true | failed |
| logic-and | yes | 2401 | 0.3443 | false | real |
| math-ideal-gas | no | 3522 | 0.6116 | true | mixed |
| science-newton2 | yes | 3657 | 0.5386 | true | mixed |
| science-photosynthesis | yes | 2646 | 0.3659 | false | real |
| science-dna | no | 4054 | 0.466 | true | failed |
| science-celsius | yes | 2063 | 0.6815 | true | real |
| science-light | no | 2424 | 0.6599 | true | real |
| science-atom | yes | 1994 | 0.6743 | true | real |
| knowledge-arabic | yes | 1797 | 0.3791 | false | real |
| knowledge-egypt | yes | 1102 | 0.3247 | false | real |
| knowledge-un | yes | 1880 | 0.6599 | true | real |
| knowledge-earth-moon | yes | 3475 | 0.466 | true | failed |
| knowledge-arabic-lang | no | 3329 | 0.466 | true | failed |
| knowledge-pi | yes | 2434 | 0.3247 | false | real |
| knowledge-http-status | yes | 2963 | 0.6499 | true | real |
| retrieval-context-omega | yes | 2039 | 0.6815 | true | real |
| retrieval-policy | yes | 3647 | 0.466 | true | failed |
| retrieval-number | yes | 1696 | 0.3247 | false | real |
| retrieval-color | yes | 2218 | 0.3247 | false | real |
| retrieval-author | yes | 1735 | 0.3247 | false | real |
| retrieval-date | yes | 1864 | 0.7432 | true | mixed |
| multi-step-newton | yes | 9430 | 0.5622 | true | mixed |
| multistep-force-units | yes | 7024 | 0.5537 | true | mixed |
| multistep-area | yes | 7712 | 0.6599 | true | real |
| multistep-temp | yes | 8369 | 0.5837 | true | mixed |
| multistep-discount | yes | 8477 | 0.6599 | true | real |
| multistep-avg | yes | 4195 | 0.5406 | true | mixed |

## Calibration

| Metric | Value |
|--------|-------|
| n | 50 |
| Accuracy | 84.0% |
| Mean confidence | 0.521 |
| Brier (↓ better) | 0.2525 |
| ECE (↓ better) | 0.3188 |
| Confidence gap (mean p − acc) | -0.319 |

> Underconfident on average (gap < −0.05).


## Honesty

Provider-backed run: 27 item(s) with `sourceClass=real`.
Check per-item sourceClass before citing aggregate metrics.
Eligible for evolution-gate review (still requires non-expired status fields).

## Evolution gate

- [ ] Compared against previous *-run.md report
- [ ] Mathematical + regression tests still pass
- [ ] Promote only if accuracy did not regress beyond policy
