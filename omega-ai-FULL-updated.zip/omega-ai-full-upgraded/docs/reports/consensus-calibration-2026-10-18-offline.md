# Consensus calibration — 2026-10-18 (offline)

> Synthetic candidates + hashEmbed. Not provider-backed experimental evidence.

Grid: σ ∈ {0.25, 0.35, 0.5, 0.7, 1, median} · minGap ∈ {0.05, 0.1, 0.15, 0.25} · T ∈ {0.3, 0.5, 1, 1.5, 2}
Evaluations: **120** · Items: **50**

## Top 15 configurations (by Boltzmann accuracy)

| Rank | σ | minGap | T | Boltzmann acc | Spectral acc | Logprob acc | FE AUROC | Cohesion AUROC | Mean cohesion |
|------|---|--------|---|---------------|--------------|-------------|---------|----------------|---------------|
| 1 | 1 | 0.05 | 2 | 38.0% | 28.0% | 38.0% | 0.740 | 0.669 | 0.863 |
| 2 | 1 | 0.1 | 2 | 38.0% | 28.0% | 38.0% | 0.740 | 0.669 | 0.863 |
| 3 | 1 | 0.15 | 2 | 38.0% | 28.0% | 38.0% | 0.740 | 0.669 | 0.863 |
| 4 | 1 | 0.25 | 2 | 38.0% | 28.0% | 38.0% | 0.740 | 0.669 | 0.863 |
| 5 | median | 0.05 | 2 | 38.0% | 28.0% | 38.0% | 0.740 | 0.693 | 0.925 |
| 6 | median | 0.1 | 2 | 38.0% | 28.0% | 38.0% | 0.740 | 0.693 | 0.925 |
| 7 | median | 0.15 | 2 | 38.0% | 28.0% | 38.0% | 0.740 | 0.693 | 0.925 |
| 8 | median | 0.25 | 2 | 38.0% | 28.0% | 38.0% | 0.740 | 0.693 | 0.925 |
| 9 | 0.7 | 0.05 | 2 | 38.0% | 28.0% | 38.0% | 0.731 | 0.656 | 0.713 |
| 10 | 0.7 | 0.1 | 2 | 38.0% | 28.0% | 38.0% | 0.731 | 0.656 | 0.713 |
| 11 | 0.7 | 0.15 | 2 | 38.0% | 28.0% | 38.0% | 0.731 | 0.656 | 0.713 |
| 12 | 0.7 | 0.25 | 2 | 38.0% | 28.0% | 38.0% | 0.731 | 0.656 | 0.713 |
| 13 | 1 | 0.05 | 1.5 | 38.0% | 28.0% | 38.0% | 0.731 | 0.669 | 0.863 |
| 14 | 1 | 0.1 | 1.5 | 38.0% | 28.0% | 38.0% | 0.731 | 0.669 | 0.863 |
| 15 | 1 | 0.15 | 1.5 | 38.0% | 28.0% | 38.0% | 0.731 | 0.669 | 0.863 |

## Recommended defaults (offline optimum)

```ts
// spectralConsensus / evaluateItem / computeHybridConfidence
sigma: 1,
minGap: 0.05,
boltzmannTemperature: 2,
// kernel blend (suggested starting point)
spectralBlend: 0.35,
```

Best Boltzmann accuracy **38.0%** at σ=1, minGap=0.05, T=2.
Free-energy AUROC at that point: **0.740** · spectral cohesion AUROC: **0.669**.

## Notes

- Re-run with `sourceClass=real` candidates before locking production constants.
- `spectralBlend` is not swept here; tune on real fusion traces after σ/T are fixed.
