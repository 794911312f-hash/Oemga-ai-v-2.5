# Ψ / score → P̂(correct) calibration

- dataset: `omega-psi-calibration-v1` v1.0.0
- score field: **psi_agreement** (agreement-style raw score)
- train n=16, holdout n=12
- date: 2026-10-20
- claimEligible: **false**

## Ψ → P̂(correct) holdout calibration

> **claimEligible=false** — harness / offline only. Do **not** cite as model calibration.

| Stage | n | Accuracy | Mean p | Brier ↓ | ECE ↓ | gap (p−acc) |
|-------|---|----------|--------|---------|-------|-------------|
| Raw score (e.g. Ψ) on holdout | 12 | 50.0% | 0.713 | 0.2921 | 0.2583 | 0.213 |
| After temperature T=3.400 | 12 | 50.0% | 0.578 | 0.2452 | 0.0838 | 0.078 |

- Train fit: NLL=0.6717, Brier=0.2399
- Accuracy is unchanged by temperature (labels fixed); only the probabilistic mapping p→P̂ changes.

## Interpretation

- **Raw p**: typically Ψ (درجة اتفاق). High Brier/ECE ⇒ do not show as % correctness in UI.
- **Temperature T**: softens or sharpens logits; fit only on train, metrics on holdout.
- **Accuracy** does not change with T; only the probabilistic interpretation of p does.
- To promote Ψ→P̂ in product: replace fixture pairs with live Math+CAS executive `y` + model Ψ, disjoint holdout, `--data=...` and `--claim-live`.
