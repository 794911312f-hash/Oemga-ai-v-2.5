# OVO detector validation (measured, synthetic faults) — old S/J/M vs defect detector vs merged (defect + strict jitter)

- **Date (UTC):** 2026-10-17
- **Evidence tier:** measured on synthetic ffmpeg clips; validates DETECTORS only
- **Design:** 30 clips per cell, 12 s @ 10 fps, 160×90, onset t = 6 s; probe = 16×8 gray (old) and 64×36 gray (new) @ 2 fps; validation seeds disjoint from calibration seeds
- **Content:** `smooth` = ffmpeg gradients; `textured` = gradients + static noise texture. Neither is natural video.
- **NEW thresholds:** calibrated on 120 clean clips only; the `clean` rows are the held-out false-alarm rate.

| Content | Condition | n | OLD alarm (S / J / M) | Defect-only alarm | MERGED alarm (95% CI) | channels (chg/loc/det/luma/jit) | MERGED pre-onset FA | regen OLD rule → NEW rule |
|---|---|---|---|---|---|---|---|---|
| textured | no fault (false-alarm control) | 30 | 13% (0% / 13% / 0%) | 0% | **0%** (-0%–11%) | 0%/0%/0%/0%/0% | 0% | 3% → **0%** |
| textured | local block 40×25 (7% of frame) | 30 | 80% (0% / 80% / 0%) | 67% | **67%** (49%–81%) | 63%/33%/0%/17%/33% | 0% | 7% → **67%** |
| textured | local block 20×12 (1.7% of frame) | 30 | 10% (3% / 10% / 0%) | 20% | **20%** (10%–37%) | 0%/20%/0%/0%/0% | 0% | 7% → **20%** |
| textured | global blur σ=6 | 30 | 23% (0% / 23% / 0%) | 20% | **20%** (10%–37%) | 0%/0%/20%/0%/0% | 0% | 3% → **20%** |
| textured | global temporal noise (alls=80) | 30 | 100% (0% / 100% / 87%) | 100% | **100%** (89%–100%) | 100%/37%/0%/63%/100% | 0% | 13% → **100%** |
| textured | global brightness −0.35 | 30 | 100% (70% / 100% / 100%) | 100% | **100%** (89%–100%) | 100%/70%/13%/100%/100% | 3% | 97% → **100%** |
| textured | brightness flicker ±0.3 | 30 | 100% (33% / 100% / 100%) | 100% | **100%** (89%–100%) | 100%/30%/0%/97%/100% | 0% | 43% → **100%** |
| textured | camera shake (crop jitter) | 30 | 63% (0% / 63% / 0%) | 47% | **50%** (33%–67%) | 47%/0%/0%/3%/17% | 0% | 10% → **50%** |
| textured | hard cut to unrelated content (positive control) | 30 | 100% (3% / 100% / 100%) | 100% | **100%** (89%–100%) | 100%/30%/0%/70%/100% | 0% | 7% → **100%** |

Detected = post-onset alarm rate clearly above the `clean` row of the same content (non-overlapping CIs is the conservative reading).
