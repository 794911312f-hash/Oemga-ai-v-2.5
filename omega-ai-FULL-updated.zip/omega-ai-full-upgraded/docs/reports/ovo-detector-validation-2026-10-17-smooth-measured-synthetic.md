# OVO detector validation (measured, synthetic faults) — old S/J/M vs defect detector vs merged (defect + strict jitter)

- **Date (UTC):** 2026-10-17
- **Evidence tier:** measured on synthetic ffmpeg clips; validates DETECTORS only
- **Design:** 30 clips per cell, 12 s @ 10 fps, 160×90, onset t = 6 s; probe = 16×8 gray (old) and 64×36 gray (new) @ 2 fps; validation seeds disjoint from calibration seeds
- **Content:** `smooth` = ffmpeg gradients; `textured` = gradients + static noise texture. Neither is natural video.
- **NEW thresholds:** calibrated on 120 clean clips only; the `clean` rows are the held-out false-alarm rate.

| Content | Condition | n | OLD alarm (S / J / M) | Defect-only alarm | MERGED alarm (95% CI) | channels (chg/loc/det/luma/jit) | MERGED pre-onset FA | regen OLD rule → NEW rule |
|---|---|---|---|---|---|---|---|---|
| smooth | no fault (false-alarm control) | 30 | 23% (0% / 23% / 0%) | 3% | **3%** (1%–17%) | 3%/0%/0%/0%/0% | 0% | 10% → **3%** |
| smooth | local block 40×25 (7% of frame) | 30 | 80% (0% / 80% / 0%) | 53% | **53%** (36%–70%) | 43%/30%/0%/20%/33% | 0% | 10% → **53%** |
| smooth | local block 20×12 (1.7% of frame) | 30 | 30% (0% / 30% / 0%) | 33% | **33%** (19%–51%) | 10%/27%/0%/0%/3% | 0% | 7% → **33%** |
| smooth | global blur σ=6 | 30 | 20% (0% / 20% / 0%) | 0% | **0%** (-0%–11%) | 0%/0%/0%/0%/0% | 0% | 13% → **0%** |
| smooth | global temporal noise (alls=80) | 30 | 100% (0% / 100% / 93%) | 100% | **100%** (89%–100%) | 100%/37%/0%/67%/100% | 3% | 3% → **100%** |
| smooth | global brightness −0.35 | 30 | 100% (73% / 100% / 100%) | 100% | **100%** (89%–100%) | 100%/60%/0%/97%/100% | 0% | 97% → **100%** |
| smooth | brightness flicker ±0.3 | 30 | 100% (37% / 100% / 100%) | 100% | **100%** (89%–100%) | 100%/47%/0%/100%/100% | 0% | 40% → **100%** |
| smooth | camera shake (crop jitter) | 30 | 70% (0% / 70% / 0%) | 30% | **30%** (17%–48%) | 30%/0%/0%/3%/27% | 0% | 3% → **30%** |
| smooth | hard cut to unrelated content (positive control) | 30 | 100% (7% / 100% / 97%) | 100% | **100%** (89%–100%) | 100%/43%/0%/80%/100% | 0% | 13% → **100%** |

Detected = post-onset alarm rate clearly above the `clean` row of the same content (non-overlapping CIs is the conservative reading).
