# Fusion simulation study

- **Date (UTC):** 2026-10-17
- **Evidence tier:** simulation (assumptions below; NOT real-LLM evidence)
- **Design:** 100 replicates × 200 questions × K=4 options × M=5 models, seeds 1000..1099
- **Truth:** independent of the embedding geometry (label drawn first; embedding = prototype + noise)
- `best_single` is an oracle chosen in hindsight; `majority_label` needs exact-answer matching (MCQ/short answers).
- Policy code mirrors scripts/compare-fusion-policies.ts. Candidate order is shuffled per question (ties otherwise leak model identity).

### S1 five equal models p=0.70, independent errors

| Policy | Accuracy % (mean ± 95% CI) | Δ vs label-majority (paired) |
|---|---|---|
| random | 69.71 ± 0.63 | -21.30 ± 0.66 |
| avg_single | 69.85 ± 0.29 | -21.16 ± 0.35 |
| best_single | 73.94 ± 0.39 | -17.07 ± 0.45 |
| majority_label | 91.01 ± 0.41 | — |
| orthant_majority | 74.20 ± 0.64 | -16.81 ± 0.63 |
| borda | 89.26 ± 0.46 | -1.76 ± 0.37 |
| rrf | 90.57 ± 0.41 | -0.44 ± 0.30 |
| psi | 90.57 ± 0.41 | -0.44 ± 0.30 |

Ψ and RRF choose the same top candidate in 99.99% of questions.

### S2 one strong (0.90) + four weak (0.55), independent

| Policy | Accuracy % (mean ± 95% CI) | Δ vs label-majority (paired) |
|---|---|---|
| random | 62.14 ± 0.67 | -21.79 ± 0.65 |
| avg_single | 61.88 ± 0.30 | -22.06 ± 0.39 |
| best_single | 89.80 ± 0.42 | 5.87 ± 0.57 |
| majority_label | 83.93 ± 0.52 | — |
| orthant_majority | 66.38 ± 0.75 | -17.56 ± 0.79 |
| borda | 81.70 ± 0.55 | -2.24 ± 0.43 |
| rrf | 83.64 ± 0.52 | -0.29 ± 0.43 |
| psi | 83.66 ± 0.52 | -0.28 ± 0.43 |

Ψ and RRF choose the same top candidate in 99.95% of questions.

### S3 five equal models p=0.70, correlated errors rho=0.7

| Policy | Accuracy % (mean ± 95% CI) | Δ vs label-majority (paired) |
|---|---|---|
| random | 70.38 ± 0.60 | -16.83 ± 0.66 |
| avg_single | 69.85 ± 0.28 | -17.36 ± 0.38 |
| best_single | 73.44 ± 0.38 | -13.77 ± 0.49 |
| majority_label | 87.22 ± 0.48 | — |
| orthant_majority | 73.10 ± 0.51 | -14.12 ± 0.56 |
| borda | 86.24 ± 0.50 | -0.98 ± 0.27 |
| rrf | 86.87 ± 0.48 | -0.34 ± 0.25 |
| psi | 86.88 ± 0.48 | -0.33 ± 0.25 |

Ψ and RRF choose the same top candidate in 99.97% of questions.

### S4 one strong (0.90) + four weak (0.50), correlated rho=0.7

| Policy | Accuracy % (mean ± 95% CI) | Δ vs label-majority (paired) |
|---|---|---|
| random | 57.72 ± 0.77 | -14.26 ± 0.72 |
| avg_single | 58.05 ± 0.32 | -13.93 ± 0.45 |
| best_single | 90.01 ± 0.41 | 18.03 ± 0.68 |
| majority_label | 71.98 ± 0.66 | — |
| orthant_majority | 60.96 ± 0.75 | -11.02 ± 0.73 |
| borda | 70.80 ± 0.69 | -1.18 ± 0.37 |
| rrf | 71.94 ± 0.66 | -0.04 ± 0.34 |
| psi | 71.93 ± 0.66 | -0.05 ± 0.34 |

Ψ and RRF choose the same top candidate in 99.96% of questions.

### S5 five equal models p=0.70, independent, high phrasing noise

| Policy | Accuracy % (mean ± 95% CI) | Δ vs label-majority (paired) |
|---|---|---|
| random | 69.71 ± 0.63 | -21.30 ± 0.66 |
| avg_single | 69.85 ± 0.29 | -21.16 ± 0.35 |
| best_single | 73.94 ± 0.39 | -17.07 ± 0.45 |
| majority_label | 91.01 ± 0.41 | — |
| orthant_majority | 69.40 ± 0.62 | -21.62 ± 0.64 |
| borda | 87.75 ± 0.50 | -3.26 ± 0.42 |
| rrf | 87.28 ± 0.47 | -3.73 ± 0.39 |
| psi | 87.28 ± 0.47 | -3.73 ± 0.39 |

Ψ and RRF choose the same top candidate in 99.96% of questions.

## Reading guide

Accuracy differences smaller than the CI are noise. Results hold only under the stated generative model.
