# Math+CAS product-path benchmark

- dataset: `omega-math-cas-v1` v1.0.0
- date: 2026-10-20
- mode: **offline**
- accuracy: **15/15 = 100.0%**
- scorer: executive (exact_number / numeric_close / expression_normalized) — not contains_any
- Ψ note: this report does **not** treat Ψ as P(correct); only task accuracy is claimed

| id | pass | mode | detail |
|----|------|------|--------|
| cas-deriv-poly | ✅ | offline_fixture | expression_ok |
| cas-quad-sum | ✅ | offline_fixture | n=5 |
| cas-integral-2x | ✅ | offline_fixture | expression_ok |
| cas-pythagoras | ✅ | offline_fixture | n=5 |
| cas-percent | ✅ | offline_fixture | n=30 |
| cas-log10 | ✅ | offline_fixture | n=3 |
| cas-sqrt | ✅ | offline_fixture | n=12 |
| cas-linear | ✅ | offline_fixture | n=4 |
| cas-area-circle | ✅ | offline_fixture | n=28.3 |
| cas-factorial | ✅ | offline_fixture | n=120 |
| cas-binom | ✅ | offline_fixture | n=10 |
| cas-simplify | ✅ | offline_fixture | expression_ok |
| cas-sin-special | ✅ | offline_fixture | n=1 |
| cas-exp | ✅ | offline_fixture | n=1024 |
| cas-mean | ✅ | offline_fixture | n=5 |

## Honesty

- Offline run validates the scorer against gold answers (harness integrity).
- Live run requires a running server + auth for protected routes; failures fall back to gold and are marked.
- Do not cite this accuracy as general LLM capability without `--live` and a fixed model list.
