# Benchmark Report — omega-benchmark-v1

- **Date (UTC):** 2026-10-10
- **Mode:** offline fixture
- **Evidence tier:** offline_fixture (NOT experimental provider evidence)
- **Seed:** 42
- **Core bridge:** benchmark-offline
- **Items:** 11

## Summary

| Metric | Value |
|--------|-------|
| Accuracy | 100.0% (11/11) |
| Latency p50 / p95 (ms) | — / — |
| Mean top Ψ | 0.550 |
| verified true/false/null | 0/0/11 |
| sourceClass mix | simulated:11 |

## Per-item

| id | pass | latency_ms | psi_top | verified | sourceClass |
|----|------|------------|---------|----------|-------------|
| code-sum | yes | — | 0.55 | null | simulated |
| code-palindrome | yes | — | 0.55 | null | simulated |
| knowledge-arabic | yes | — | 0.55 | null | simulated |
| logic-contradiction | yes | — | 0.55 | null | simulated |
| logic-modus-ponens | yes | — | 0.55 | null | simulated |
| math-derivative-1 | yes | — | 0.55 | null | simulated |
| math-quadratic-sum | yes | — | 0.55 | null | simulated |
| multi-step-newton | yes | — | 0.55 | null | simulated |
| multistep-force-units | yes | — | 0.55 | null | simulated |
| retrieval-context-omega | yes | — | 0.55 | null | simulated |
| math-ideal-gas | yes | — | 0.55 | null | simulated |

## Honesty

This run used **offline fixtures**. It validates the harness and scoring only. Do **not** cite as model or Ψ task performance.

## Evolution gate

- [ ] Compared against previous non-offline report
- [ ] Mathematical + regression tests still pass
- [ ] Promote only if accuracy did not regress beyond policy
