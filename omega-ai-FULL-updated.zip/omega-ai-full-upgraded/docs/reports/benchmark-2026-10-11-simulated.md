# Benchmark Report — omega-benchmark-v1

- **Date (UTC):** 2026-10-11
- **Mode:** workspace runner WITHOUT live providers (SIMULATED)
- **Evidence tier:** simulated_no_providers (NOT experimental — no sourceClass=real; do not cite)
- **sourceClass real/mixed/sim+fail:** 0/4/5
- **Seed:** 42
- **Core bridge:** benchmark-openai-provider
- **Items:** 9

## Summary

| Metric | Value |
|--------|-------|
| Accuracy | 11.1% (1/9) |
| Latency p50 / p95 (ms) | 27 / 169 |
| Mean top Ψ | 0.540 |
| verified true/false/null | 9/0/0 |
| sourceClass mix | mixed:4, failed:5 |

## Per-item

| id | pass | latency_ms | psi_top | verified | sourceClass |
|----|------|------------|---------|----------|-------------|
| math-derivative-1 | no | 169 | 0.5784 | true | mixed |
| math-quadratic-sum | yes | 51 | 0.5784 | true | mixed |
| math-integral-1 | no | 42 | 0.5784 | true | mixed |
| math-pythagoras | no | 22 | 0.5154 | true | failed |
| math-percent | no | 18 | 0.5082 | true | failed |
| math-log | no | 27 | 0.5082 | true | failed |
| math-limit | no | 22 | 0.5082 | true | failed |
| math-matrix-det | no | 44 | 0.5784 | true | mixed |
| math-gcd | no | 19 | 0.5082 | true | failed |

## Calibration

| Metric | Value |
|--------|-------|
| n | 9 |
| Accuracy | 11.1% |
| Mean confidence | 0.540 |
| Brier (↓ better) | 0.2756 |
| ECE (↓ better) | 0.4291 |
| Confidence gap (mean p − acc) | 0.429 |

> Overconfident on average (gap > 0.05).


## Honesty

**SIMULATED / no live providers.** Zero items with `sourceClass=real`.
Filename suffix `-simulated` (not `-run`).
Do **not** cite accuracy, Ψ, or calibration as model performance.
Register Core Bridge + API keys, then re-run without `--offline`.

## Evolution gate

- [ ] **Not eligible** until a *-run.md report exists (provider-backed)
- [ ] Mathematical + regression tests still pass
- [ ] Promote only if accuracy did not regress beyond policy
