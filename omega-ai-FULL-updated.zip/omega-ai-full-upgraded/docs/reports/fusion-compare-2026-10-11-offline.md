# Fusion Policy Comparison — omega-benchmark-v1

- **Date (UTC):** 2026-10-11
- **Mode:** offline synthetic geometry
- **Evidence tier:** offline_fixture (NOT provider experimental evidence)
- **Items:** 50
- **Seed base:** 42

## Summary

| Method | Accuracy | Notes |
|--------|----------|-------|
| Ψ (consensus) | 100.0% (50/50) | clipExpPsi rank |
| Majority | 100.0% (50/50) | orthant labels |
| Borda | 82.0% (41/50) | pairwise cosine |
| RRF | 100.0% (50/50) | cosine-to-centroid ranks |

## Honesty

Synthetic candidates are constructed so a clear geometric winner exists.
This measures ranking behaviour under controlled geometry — **not** LLM task superiority.
For Tier-2 claims, re-run with real multi-model candidates on the same item ids.
