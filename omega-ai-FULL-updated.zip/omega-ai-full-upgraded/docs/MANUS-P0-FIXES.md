# Manus review — fixes applied (continued)

## P0/P1 done

| Issue | Fix |
|-------|-----|
| Missing `numericCoverage` | Re-export → arithmeticCheck |
| `OmegaCoreRequest.depth` | Optional field |
| ToT `Math.random` score | Deterministic heuristic |
| Tool placeholders success:true | success:false + error |
| Neural verified from confidence | verified: null |
| Hybrid verified from neural confidence | only symbolic verified |
| ensembleMode single real | real_single_provider |
| resolveTrustedUserId narrowing | TrustedUserResult + ok === false |
| Router fake history (10 calls / 8 success) | totalCalls:0, seededPrior:true |
| Distillation by length alone | requires symbolicVerified===true |
| hashEmbed docs | labeled bag-of-characters |

## Still open

- Full typecheck/build on complete deps
- Real provider benchmark `*-run.md`
- Real semantic embeddings
- Real Python/SymPy sandbox
