# Server decomposition (Phase 12.3+)

`server.ts` is the composition root. HTTP handlers live under `src/server/routes/`:

| Module | Responsibility |
|--------|----------------|
| toolsRoutes | datetime, weather, news, OEIS |
| codeRoutes | isolated JS execute |
| mediaRoutes | image, video, voice, OVO, avatar, media/* |
| inferenceRoutes | ensemble, deduce, complete, embed, verify |
| bridgeRoutes | DSPy, OpenHands, browser-use, SymPy/Lean, Open-Sora |
| graphRoutes / modelRouterRoutes / hybridEvolutionRoutes | graph, router, evolution |
| workspaceRoutes | Cognitive Workspace |

Register via `registerModularRoutes(app, deps)` with helpers from server scope.
