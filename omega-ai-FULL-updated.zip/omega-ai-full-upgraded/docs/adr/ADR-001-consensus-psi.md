# ADR-001: Consensus confidence Ψ via clipped exponential of embedding deviation

- **Status:** Accepted
- **Date:** 2026-10-10
- **Context:** Multi-model responses need a scalar “agreement” score for ranking and fusion weights without claiming ground truth.

## Decision

Use

\[
\Psi_i=\mathrm{clip}_{[0.01,1]}\big(\exp(-\delta_i/(\alpha\sigma_{\mathrm{eff}}+\beta))\big)
\]

with \(\delta_i=1-\cos(v_i,c)\), \(\alpha=1.5\), \(\beta=0.05\).

## Why exp(·)?

- Maps unbounded positive deviation into \((0,1]\).
- Smooth, monotone in \(\delta\), cheap to compute.
- Avoids discontinuous thresholds as the sole ranking signal.

## Why α = 1.5 and β = 0.05?

- **Empirical defaults**, not MLE/optimal control results.
- \(\beta\) prevents a near-zero denominator when \(\sigma\approx0\).
- \(\alpha\) softens the role of sample std so a single outlier does not dominate decay length scale alone.
- Any retune requires sensitivity sweeps + fixed benchmark (see `docs/specs/psi-spec.md`).

## Consequences

- High Ψ ≠ truth (correlated errors).
- Must pair with verification, tools, and honest `sourceClass`.
- Spec + invariants + property tests are mandatory for changes.

## Alternatives considered

| Alternative | Why not (for now) |
|-------------|-------------------|
| Majority vote on tokens | Brittle across languages/styles |
| RRF only | Needs ranked lists per system; we have free text |
| Learned judge model only | Costly; still not ground truth |
| Raw cosine to centroid | Not normalized as confidence-like weight |
