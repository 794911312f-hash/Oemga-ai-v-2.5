# Smart Behavioral Intelligence (Cognitive Workspace)

Goal: make Omega *act* intelligently, not only score candidates.

## Loop

1. **classifyAndPolicy** — math/code/logic/multi-step/factual
2. **tool-first** — CAS/calculator before LLM for symbolic/numeric math
3. **tool-grounded merge** — attach external CAS result to the answer
4. **shouldRevise** — second pass when verify fails, psi low, or answer empty
5. **Ψ_hybrid + CAS B_ev** — confidence reflects tools and structure

## Files

- `smartLoop.ts` — policy + revision + merge
- `workspace.ts` — orchestration hooks
- `planner.ts` — tool tasks when toolFirst
- `confidence.ts` / `evidencePsi.ts` — scoring

## Limits (honest)

Intelligence still depends on available models and tools.
Without API keys, revision annotates rather than regenerates.
