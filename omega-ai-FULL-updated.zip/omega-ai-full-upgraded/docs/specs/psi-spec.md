# Specification: Consensus Confidence Ψ (Psi)

**Status:** normative for `clipExpPsi` in `src/lib/omega/math.ts`  
**Consumers:** `omegaCore.scorePsi`, `fusion.scoreCandidates`, Cognitive Workspace confidence (derived)

## 1. Intent

Ψ scores **agreement among candidate answers**, not external truth.
High Ψ means “candidates are close in embedding space,” not “the answer is correct.”

## 2. Definition

Given candidates with embedding vectors \(v_1,\ldots,v_k \in \mathbb{R}^d\):

\[
c = \frac{1}{k}\sum_{j=1}^{k} v_j
\]

\[
\delta_i = 1 - \cos(v_i, c) \in [0, 2]
\]

\[
\sigma = \sqrt{\frac{1}{k}\sum_i (\delta_i - \bar\delta)^2}
\]

\[
\Psi_i = \mathrm{clip}_{[0.01,\,1]}
\left(
\exp\left(
-\frac{\delta_i}{\alpha\cdot\max(\sigma,\varepsilon)+\beta}
\right)
\right)
\]

### Constants (current implementation)

| Symbol | Code | Default | Role |
|--------|------|---------|------|
| \(\alpha\) | `1.5` | 1.5 | Scales influence of empirical spread \(\sigma\) |
| \(\beta\) | `0.05` | 0.05 | Floor in denominator; prevents division by ~0 |
| \(\varepsilon\) | `1e-6` | 1e-6 | Lower bound on \(\sigma\) before scaling |
| clip min | `0.01` | 0.01 | Numerical floor |
| clip max | `1.0` | 1.0 | Upper bound |

**These are empirical knobs, not derived optima.** Changing them requires sensitivity runs (see §6) and must not silently change API semantics without a version note.

## 3. Required mathematical properties

| ID | Property | Requirement |
|----|----------|-------------|
| P1 | Monotonicity in \(\delta\) | For fixed \(\sigma\), \(\delta_1 \le \delta_2 \Rightarrow \Psi(\delta_1)\ge\Psi(\delta_2)\) |
| P2 | Boundedness | \(\Psi \in [0.01, 1]\) for all finite inputs |
| P3 | Consensus peak | \(\delta=0 \Rightarrow \Psi \ge 0.95\) for typical \(\sigma\) |
| P4 | Identical inputs | All \(v_i\) equal \(\Rightarrow \sigma\approx0\), all \(\Psi_i\) near 1 |
| P5 | Outlier depression | A vector far from a tight cluster has lower \(\Psi\) than cluster members |

**Tests:** `tests/psi-mathematical-properties.test.ts`

## 4. Fusion policy (related, not part of \(\Psi\) algebra)

From `fusion.ts` defaults:

| Constant | Default | Meaning |
|----------|---------|---------|
| `directThreshold` | 0.88 | Top \(\Psi\) high enough → take winner without heavy aggregate |
| `uncertainSpread` | (see code) | Small spread between top scores → return top-2 / uncertain mode |

## 5. Failure modes (Ψ-specific)

| Mode | Behaviour | Mitigation |
|------|-----------|------------|
| Correlated error | All models share same wrong claim → high \(\Psi\) | Verification, external tools, do not treat \(\Psi\) as truth |
| Embedding collapse | Hash/weak embeds make distinct texts look similar | Prefer semantic embeddings when keys exist |
| Single candidate | \(\Psi\) forced/trivial | Treat as non-consensus; mark source honestly |
| Outlier correct | One correct, many wrong → correct may get low \(\Psi\) | Uncertain mode, verification, domain tools |

## 6. Sensitivity (required before retuning)

Sweep \(\alpha \in \{1.0,1.5,2.0\}\), \(\beta \in \{0.01,0.05,0.1\}\) on a **fixed** benchmark seed.
Record: accuracy proxy, mean top-\(\Psi\), uncertain rate, pairwise rank stability.
Do not retune on the evaluation set used for public claims.

## 7. Complexity

- Centroid + deltas: \(O(kd)\)
- \(\Psi\) map: \(O(k)\)
- Dominant cost remains model inference I/O

## 8. Versioning

- Spec version tracks behaviour of `clipExpPsi` signature.
- Any change to \(\alpha,\beta,\varepsilon\), clip bounds → bump spec + changelog + re-run property tests.


## Extension: Ψ_hybrid (evidencePsi.ts)

\[
\\Psi^{\\mathrm{hybrid}}_i = \\mathrm{clip}\big(
0.55\\,\\Psi^{\\mathrm{agr}}_i + 0.20\\,Q_i + 0.10\\,F^{\\mathrm{proxy}}_i + 0.15\\,N_i + B^{\\mathrm{ev}}_i
\big)
\]

- Trimmed centroid for agreement when \(k\\ge 3\)
- \(Q\): structural quality from text
- \(F^{proxy}\): self-falsification proxy (not claimed external)
- \(N\): numeric coverage vs question
- \(B^{ev}\): verified / tool / simulated adjustments
