# Omega Algorithm Specifications & Scientific Baseline

## Layout

| Package | Path |
|---------|------|
| **Specifications** | `docs/specs/` (`psi-spec`, `router-spec`, `failure-modes`, `evolution-gate`) |
| **Invariants** | `docs/invariants/psi-invariants.md` |
| **Proof sketches** | `docs/proofs/proof-psi-monotonicity.md` |
| **ADRs** | `docs/adr/ADR-001-consensus-psi.md` |
| **Benchmark suite** | `tests/benchmark/suite.json` |
| **Benchmark reports** | `docs/reports/benchmark-TEMPLATE.md` → `benchmark-YYYY-MM-DD.md` |
| **Math validation** | `tests/psi-*.test.ts` |
| **Regression** | `tests/regression/psi-*.test.ts` |

## Commands

```bash
npx tsx --test tests/psi-mathematical-properties.test.ts tests/psi-sensitivity.test.ts
npx tsx --test tests/regression/*.test.ts
```

## Reproducibility

1. Fixed seed in suite.json  
2. Same model pool / depth  
3. Full traces  
4. Evolution only via `evolution-gate.md` policy  

## Algorithm Manifest

`docs/manifests/consensus-psi.yaml` — links version, specs, proofs, tests, constants.

## CI pipeline

`.github/workflows/omega-quality.yml`

```
Unit/Typecheck → Mathematical (Ψ) → Regression → Fusion baseline compare
```

Provider benchmark remains manual/nightly until secrets + dated reports exist.
