# Specification: Confidence Calibration

## Metrics

| Metric | Formula | Direction |
|--------|---------|-----------|
| **Brier** | \(\frac1n\sum_i (p_i - y_i)^2\) | lower better |
| **ECE** | equal-width bins on \([0,1]\), weighted \(|\bar p - \bar y|\) | lower better |
| **Confidence gap** | \(\bar p - \mathrm{accuracy}\) | near 0 |

## Implementation

- `src/lib/omega/calibration.ts`
- Emitted by `scripts/run-benchmark.ts` into each report
- Tests: `tests/calibration.test.ts`

## Honesty

Offline fixture runs may show low Brier because answers embed expect tokens **and** psi is fixed — **do not cite**.

Only non-offline reports with real Ψ/confidence may claim calibration quality.

## CAS → B_ev

When `symbolic_cas` or `calculator` succeeds (`sourceClass=real`):

1. Global toolSupport boost in confidence estimator
2. Per-candidate boost if answer text aligns with CAS output snippet
3. Mild penalty if CAS succeeded but candidate ignores it

See `cognitiveWorkspace/confidence.ts` toolBoost + evidence map.
