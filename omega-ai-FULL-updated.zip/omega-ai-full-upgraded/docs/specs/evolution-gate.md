# Evolution Gate (policy)

**Goal:** Prevent hybrid self-evolution from accepting changes that only improve self-scores while regressing the fixed benchmark.

## Rule

Before `promote` / accepting a hybrid evolution cycle that alters routing, harness, or default fusion thresholds:

1. Run `tests/benchmark/suite.json` with **seed = 42** and recorded model pool.
2. Compare to the last published report under `docs/reports/benchmark-*.md`.
3. **Accept** only if:
   - Suite accuracy does not decrease by more than a configured tolerance (default: 0 absolute for v0), **and**
   - Property/regression tests (`psi-*`, `regression/psi-*`) pass, **and**
   - No increase in `sourceClass=simulated` rate on items that previously were `real` without documented provider outage.
4. **Reject** otherwise; keep prior harness/population parent.

## Non-goals (v0)

- Full statistical significance testing
- Online bandit regret bounds

## Implementation status

- Policy documented (this file)
- Automated gate hook in `hybrid-evolution/promote` — **pending** (wire when CI has provider secrets or offline fixtures)

## Related

- `docs/specs/failure-modes.md` FM-7
- `docs/reports/benchmark-TEMPLATE.md`


## CLI

```bash
npm run evolution-gate
npx tsx scripts/evolution-gate.ts --tolerance 0.02
npx tsx scripts/evolution-gate.ts --json
```

Exit codes: `0` PASS, `1` REJECT, `2` INSUFFICIENT (no non-offline report).

## Implementation status

- Policy documented
- CLI gate: `scripts/evolution-gate.ts` ✅
- Automated hook inside `hybrid-evolution/promote` — optional next step (call CLI or shared parser before promote)
