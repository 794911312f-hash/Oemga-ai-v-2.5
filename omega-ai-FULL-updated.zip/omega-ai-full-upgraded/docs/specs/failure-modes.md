# Failure Mode Analysis — Omega Consensus Stack

Scope: Router → Providers → Fusion(Ψ) → Verify → Memory → Kernel → Evolution

## FM-1 Correlated model error

**Scenario:** GPT / Claude / Gemini / Qwen return the same false claim.  
**Symptom:** High \(\Psi\), fusion picks the error with confidence.  
**Root cause:** \(\Psi\) measures agreement, not truth.  
**Expected system behaviour:**
- `sourceClass` may still be `real`
- Verify may pass if the shared myth is internally consistent
**Required mitigations:**
- Tools/CAS/retrieval for checkable domains
- Never write to global memory on \(\Psi\) alone without `verified === true` or tool evidence
- Benchmark items designed for known correlated hallucinations

## FM-2 Lone correct minority

**Scenario:** One model correct, majority wrong and similar.  
**Symptom:** Correct candidate low \(\Psi\); wrong cluster wins.  
**Mitigations:**
- Uncertain mode when spread is small among top-2 *or* when top disagrees with tool result
- Domain routing that includes specialist models
- Optional: robust centroid (trimmed mean) — *not implemented yet*

## FM-3 Slow but accurate model

**Scenario:** Best model has high latency.  
**Symptom:** Router heuristic may de-prioritize it (latency enters operational preference indirectly via UX, ELO updates if timeouts count as failure).  
**Risk:** Accuracy regresses toward fast-mediocre.  
**Mitigations:**
- Separate quality score from latency SLA
- Allow user/depth=`deep` to expand pool
- Do not treat timeout as permanent quality failure without sample size floor

## FM-4 Provider outage → simulation

**Scenario:** API keys missing or providers down.  
**Symptom:** `simulated: true` candidates; possible uniform simulated text.  
**Required behaviour:**
- `sourceClass`: `simulated` or `mixed` or `failed` — never `real`
- No global memory write for simulated (enforced post-12.2)
- UI must surface badge honestly

## FM-5 Memory poisoning

**Scenario:** User or correlated errors repeatedly stored.  
**Symptom:** Later retrieval reinforces falsehoods; router may learn bad success labels if success:=“returned 200”.  
**Mitigations in place:** guest isolation; skip simulated/failed global writes.  
**Still open:**
- TTL / decay on semantic nodes
- Per-user vector stores only for long-term
- Reject write unless verified or tool-backed

## FM-6 Verification null / soft pass

**Scenario:** `verify` returns `null` or algorithmic pass.  
**Symptom:** Pipeline continues; confidence still moderate-high.  
**Required:** treat `null` as unknown in UI and memory gates (not as success).

## FM-7 Evolution drift

**Scenario:** Hybrid evolution accepts cycles on noisy self-scores.  
**Symptom:** Harness/policy drifts without external benchmark gate.  
**Required:** fixed eval suite + accept/reject threshold before promote.

## FM-8 Identity / prompt injection in fusion path

**Scenario:** Identity or jailbreak-like questions short-circuit policies.  
**Code note:** `isIdentityQuestion` special-cases some paths in fusion.  
**Required:** explicit tests so identity handling cannot elevate simulated content to `real`.

## Traceability

Every failure mode investigation should attach:
- `workspaceId` / core trace
- `sourceClass`, \(\Psi\), `verified`
- model ids and `simulated` flags
- whether memory write occurred
