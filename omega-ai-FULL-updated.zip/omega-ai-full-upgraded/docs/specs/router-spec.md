# Specification: Intelligent Model Router

**Implementation:** `src/lib/omega/intelligentRouter.ts`  
**Name in marketing vs code:** Prefer **“heuristic UCB-inspired score”** — not classical UCB1 or Thompson Sampling unless implemented.

## Composite score (current)

\[
s(m) = 0.35\cdot \mathrm{successRate}
+ 0.35\cdot \overline{\Psi}
+ 0.20\cdot \mathrm{eloNorm}
+ 0.10\cdot \sqrt{\frac{2\ln N}{n_m}}
\]

| Term | Meaning |
|------|---------|
| successRate | successfulCalls / totalCalls |
| \(\overline{\Psi}\) | running average consensus score when outcomes recorded |
| eloNorm | \((ELO - 1200)/800\) clipped by data range |
| exploration | UCB1-*style* bonus, weight 0.10 only |

## Explicit non-claims

- Not full UCB1 (reward is not a pure empirical mean with matching exploration term).
- Not Thompson Sampling (no Beta/posterior sampling in this path).
- ELO is updated vs a fixed baseline (~1500), not a full pairwise tournament matrix.

## Failure interactions

- Timeouts counted as failures bias against slow accurate models (see failure-modes FM-3).
- High \(\Psi\) on wrong consensus inflates \(\overline{\Psi}\) (FM-1).

## Change control

Altering weights (0.35/0.35/0.20/0.10) requires sensitivity on a fixed benchmark and a changelog entry.
