# Product path: Math + CAS (measurable)

## Scope

Single product claim:

> Omega can answer a **closed set of school/college math items** and be scored by **executive checks** (numeric equality or normalized expression match), not by substring `contains_any` alone.

Out of scope for this path: general chat quality, video “physics”, self-evolution, OVO quality uplift.

## Artifacts

| Artifact | Path |
|----------|------|
| Dataset | `datasets/omega-math-cas-v1/items.json` |
| Runner | `scripts/run-math-cas-benchmark.ts` |
| Reports | `docs/reports/math-cas-benchmark-*.md` |

## Ψ policy on this path

Ψ is an **agreement / proximity score** among candidates (or temporal signal score in video), **not** calibrated P(correct).  
UI and docs must say **درجة اتفاق** / **agreement score**. Accuracy is reported only from the executive scorer above.

## Physics / media policy

There is **no** rigid-body / ODE physics solver in the media pipeline. Catalog fields formerly called `physicsRating` are **editorial visual-coherence claims**, not measured simulation scores. Scene text is **storyboard / visual prompt**, not physics simulation output.


## Calibration (Ψ → P̂(correct))

| Artifact | Path |
|----------|------|
| Metrics + temperature scaling | `src/lib/omega/calibration.ts` |
| Train/holdout pairs (fixture) | `datasets/omega-math-cas-v1/psi-calibration-pairs.json` |
| Runner | `scripts/run-psi-calibration.ts` |
| Reports | `docs/reports/psi-calibration-*.md` |

```bash
npm run calibrate:psi:offline
```

Holdout Brier/ECE on the **default fixture** only prove the pipeline.  
For a product claim: dump live pairs `{id, split, y, p}` where `y` is executive Math+CAS correctness and `p` is model Ψ, then:

```bash
npx tsx scripts/run-psi-calibration.ts --data=path/to/live-pairs.json --claim-live
```

Until `claimEligible=true` and ECE is acceptably low, UI keeps Ψ as **درجة اتفاق**.
