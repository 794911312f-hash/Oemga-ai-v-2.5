# Workspace Security Fixes (post Phase 12 review)

## Fixed
1. **Memory isolation** — `persistWorkspaceOutcome` no longer writes guests or `simulated`/`failed` outcomes into `globalOmegaMemory`. Shared semantic store requires authenticated user + `sourceClass` real|mixed + psi ≥ 0.55. Working memory remains per-user manager.
2. **Guest trace isolation** — Traces scoped by `guest:<sessionId>` via `X-Omega-Guest-Session` header (or cookie `omega_guest_session`). Without a session, guests get ephemeral scope and cannot `GET` traces of others. Workspace IDs use `crypto.randomUUID()`.
3. **Rate limit** — `POST /api/omega/workspace` under `aiComputeLimiter` (45/min), not only the global 120/min bucket.
4. **Core verify** — bridge `verify` uses `selfVerify` algorithmic path when possible; returns `null` only on failure (never fake success).
5. **EADDRINUSE** — process exits with code 1 so monitors detect the failure.

## Remaining debt
- Split `server.ts` into routers
- HTTP integration tests for workspace routes
- Stronger Firebase rules audit for public apiKey

## Phase 12.3 — Modular routes + tests

### server.ts decomposition
Extracted modules under `src/server/routes/`:
- `hybridEvolutionRoutes.ts`
- `graphRoutes.ts`
- `modelRouterRoutes.ts`
- `index.ts` → `registerModularRoutes(app)`

`server.ts` still hosts provider/tool/chat routes; further extraction can continue incrementally.

### Tests
- `tests/workspace-http-security.test.ts` — full HTTP (requires `npm install`)
- `tests/workspace-security-logic.test.ts` — security logic without network
