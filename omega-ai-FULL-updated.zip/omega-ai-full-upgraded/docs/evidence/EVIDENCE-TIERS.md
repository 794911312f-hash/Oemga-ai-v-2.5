# Evidence Tiers — What Omega May Claim

Clear separation between engineering checks and scientific claims.

## Tier 1 — Engineering Validation ✅ (in repo)

**Proves:** implementation matches specs; invariants hold; regressions caught.

| Artifact | Path |
|----------|------|
| Specs / invariants / proofs / ADR | `docs/specs`, `docs/invariants`, `docs/proofs`, `docs/adr` |
| Math + regression tests | `tests/psi-*.test.ts`, `tests/regression/` |
| Offline baseline geometry | `tests/fusion-compare/` |
| CI | `.github/workflows/omega-quality.yml` |
| Manifest | `docs/manifests/consensus-psi.yaml` |

**Allowed claim:** “The Ψ implementation obeys documented mathematical properties and CI guards.”

**Not allowed:** “Ψ is better than RRF/Self-Consistency on real LLM tasks.”

## Tier 2 — Experimental Validation ⏳

**Requires:** fixed dataset + real model pool + dated report.

| Artifact | Path |
|----------|------|
| Dataset | `datasets/omega-benchmark-v1/` |
| Suite pointer | `tests/benchmark/suite.json` |
| Report template | `docs/reports/benchmark-TEMPLATE.md` |
| Filled reports | `docs/reports/benchmark-YYYY-MM-DD.md` |
| Evolution gate | `docs/specs/evolution-gate.md` + `scripts/evolution-gate.ts` (`npm run evolution-gate`) |
| Benchmark runner | `scripts/run-benchmark.ts` (`npm run benchmark` / `benchmark:offline`) |

**Protocol:**
1. Seed 42, fixed model list, fixed depth policy  
2. Same questions for Ψ vs Majority / Borda / RRF / Self-Consistency fusion policies  
3. Log accuracy, latency, verify rate, mean Ψ, sourceClass mix, memory writes  
4. Append row to leaderboard (below)

**Allowed claim (only after reports exist):** “On omega-benchmark-v1 with models {…}, policy A scored X±… vs B.”

## Tier 3 — Scientific Validation ❌ (not claimed)

**Requires:** multiple datasets, confidence intervals / significance tests, preregistered splits, independent replication.

**Allowed claim:** none until Tier 2 reports are public and stats are documented.

---

## Leaderboard (experimental)

Fill only from dated reports — do not invent numbers.

| Version | Date | Accuracy | Latency p50 | Verify rate | Ψ avg | Notes |
|---------|------|----------|-------------|-------------|-------|-------|
| — | — | — | — | — | — | No provider run recorded yet |

---

## Rule of honesty

`sourceClass`, `verified: null`, and evidence tier labels must appear in any public performance discussion.
