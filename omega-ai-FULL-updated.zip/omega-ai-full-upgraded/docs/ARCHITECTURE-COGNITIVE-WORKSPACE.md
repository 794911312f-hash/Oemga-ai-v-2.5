# Cognitive Workspace Architecture (Phase 11–12)

## الهدف
تنسيق دورة استدلال واحدة فوق محركات أوميغا الموجودة، مع إفصاح صادق عن المصدر والتحقق.

## الدورة
```
Question
  → Intent + Planner
  → Memory Bridge + Knowledge Graph
  → Tool Orchestrator
  → OmegaCore (via Core Bridge)
  → Synthesizer
  → Agent Coordinator (optional)
  → Reflector / selfVerify
  → Confidence Estimator
  → Answer + CognitiveTrace
```

## العقود الأساسية

### WorkspaceRequest / WorkspaceResult
انظر `src/lib/omega/cognitiveWorkspace/types.ts`.

### Core Bridge (Phase 12.0)
- `registerCoreRunner(fn, label)` يُستدعى من `server.ts` عند الإقلاع.
- `runBoundCore(request)` يستدعيه `CognitiveWorkspace`.
- إن لم يُسجَّل runner → `sourceClass: simulated` + placeholder صريح (لا ادعاء نجاح وهمي).

### sourceClass
| القيمة | المعنى |
|--------|--------|
| real | مزودون/أدوات حقيقية فقط |
| mixed | خليط حقيقي + محاكاة |
| simulated | محاكاة / fallback |
| failed | فشل صريح |

### verified
`true | false | null` — `null` يعني تعذّر التحقق، وليس نجاحًا.

## الملفات
| مسار | دور |
|------|-----|
| `cognitiveWorkspace/workspace.ts` | المنسّق |
| `coreBridge.ts` | ربط OmegaCore |
| `planner.ts` | الخطة |
| `memoryBridge.ts` / `graphBridge.ts` | سياق |
| `toolOrchestrator.ts` | أدوات |
| `synthesizer.ts` / `confidence.ts` | دمج + ثقة |
| `reflector.ts` | تحقق + تأمل |
| `agentCoordinator.ts` | وكلاء |
| `server/workspaceRoutes.ts` | HTTP |
| `CognitiveWorkspaceLab.tsx` | UI |

## API
- `POST /api/omega/workspace`
- `POST /api/omega/workspace/plan`
- `GET /api/omega/workspace/trace/:id`
- `GET /api/omega/workspace/health` → يتضمن `coreBridge.wired`

## اختبارات
`tests/cognitive-workspace-*.test.ts`

## مبادئ
1. لا يستبدل OmegaCore — يبني فوقه.
2. فشل أداة/وكيل لا يسقط الدورة.
3. كل أثر يُسجَّل في CognitiveTrace.
4. الضيوف: fast/balanced فقط؛ deep يتطلب مصادقة.
