# Invariants: Consensus Ψ and Fusion Weights

**Normative.** Any change that violates these must fail CI property/regression tests.

## I-Ψ-1 Bounds

\[
0.01 \le \Psi_i \le 1 \quad \forall i
\]

(Implementation floor is 0.01, not 0.)

## I-Ψ-2 Monotonicity in δ

For fixed \(\sigma,\alpha,\beta\):

\[
\delta_1 \le \delta_2 \implies \Psi(\delta_1) \ge \Psi(\delta_2)
\]

## I-Ψ-3 Consensus at zero deviation

\[
\delta = 0 \implies \Psi(\delta,\sigma) \ge 0.95
\]
for \(\sigma\) in the practical operating range used by tests.

## I-W-1 Non-negative weights

When weights are derived as \(w_i = \Psi_i / \sum_j \Psi_j\):

\[
w_i \ge 0
\]

## I-W-2 Partition of unity

\[
\sum_i w_i = 1
\]
(when \(\sum\Psi > 0\); else uniform \(1/k\)).

## I-R-1 Router score range (soft)

Composite router score is designed to lie approximately in \([0,1]\) under normal ledger values; exploration term may push slightly outside — clamp or document if enforced in code later.

## Test mapping

| Invariant | Test |
|-----------|------|
| I-Ψ-1,2,3 | `tests/psi-mathematical-properties.test.ts` |
| I-Ψ-2 across α,β | `tests/psi-sensitivity.test.ts` |
| I-W-1,2 | `tests/regression/psi-weight-invariants.test.ts` |
| Ordering regression | `tests/regression/psi-ordering-regression.test.ts` |
