# Real (provider-backed) benchmark

## Filename contract

| Suffix | Meaning | Evolution gate |
|--------|---------|----------------|
| `*-offline.md` | Fixture harness | Never PASS |
| `*-simulated.md` | Workspace ran but **zero** `sourceClass=real` | Never PASS |
| `*-run.md` | At least one `sourceClass=real` | Eligible for review |

## Commands

```bash
# Engineering only
npm run benchmark:offline

# Will write *-simulated.md if no API / no real answers
npm run benchmark

# Fail hard (exit 2) unless provider-backed
npm run benchmark:require-real

npm run evolution-gate
```

## Requirements for *-run.md

1. Core Bridge registered with real model calls  
2. API keys in env (GOOGLE_API_KEY / GEMINI_API_KEY / OPENAI_API_KEY / ANTHROPIC_API_KEY / …)  
3. At least one item with `sourceClass=real`  

Accuracy on `*-simulated.md` must **not** be cited as model performance.
