/**
 * scripts/validate-ovo-real-injection.ts
 * =============================================================================
 * Fault injection into a REAL video (handheld, natural texture and motion). Paired design:
 * each faulted variant is compared frame-by-frame with the same video re-encoded with no fault,
 * so alarms the real footage raises on its own (fast pans, exposure changes) are NOT counted as
 * detections. A fault is "detected" when some frame at/after onset alarms in the variant but not in
 * the reference. Clean variants (re-encode at random CRF) estimate the attributable false-alarm rate.
 *
 * Caveats: ONE source video → variants share content (random fault parameters/onsets only), so the
 * CIs describe parameter variation, not content variation. Not independent of the source's motion.
 *
 * Env: OVO_REAL_VIDEO (proxy mp4), OVO_REAL_N (default 30), OVO_REAL_CONDS (comma list), OVO_REAL_TAG.
 */
import { execFile } from "node:child_process";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { promisify } from "node:util";
import { analyzeVideoBuffer } from "../src/lib/omega/videoProbe.ts";
import { globalOmegaVideoOptimizer } from "../src/lib/omega/ovoEngine.ts";
import { mulberry32, pool, wilson } from "./lib/ovo-clips.ts";

const run = promisify(execFile);
const SRC = process.env.OVO_REAL_VIDEO ?? "/tmp/real/proxy.mp4";
const N = Number(process.env.OVO_REAL_N ?? 30);
const TAG = process.env.OVO_REAL_TAG ?? "all";
const W = 480, H = 854;
const gray = (g: number) => `0x${g.toString(16).padStart(2, "0").repeat(3)}`;

interface V { id: string; label: string; args: (r: () => number, onset: number) => { pre: string[]; fc: string; crf: number }; onsetRange: [number, number] }
const f1 = (fault: string) => (_r: () => number, _o: number) => ({ pre: [], fc: `[0:v]${fault}[v]`, crf: 28 });
const CONDS: V[] = [
  { id: "clean", label: "no fault (re-encode, random CRF 24–34)", onsetRange: [5, 7], args: (r) => ({ pre: [], fc: "[0:v]null[v]", crf: 24 + Math.floor(r() * 11) }) },
  { id: "local_large", label: "local block 25%×28% of frame", onsetRange: [5, 7], args: (r, o) => ({ pre: [], fc: `[0:v]drawbox=x=${Math.floor(r() * (W - 120))}:y=${Math.floor(r() * (H - 239))}:w=120:h=239:color=${gray(30 + Math.floor(r() * 200))}@1:t=fill:enable='gte(t,${o})'[v]`, crf: 28 }) },
  { id: "local_small", label: "local block 12.5%×13% of frame", onsetRange: [5, 7], args: (r, o) => ({ pre: [], fc: `[0:v]drawbox=x=${Math.floor(r() * (W - 60))}:y=${Math.floor(r() * (H - 111))}:w=60:h=111:color=${gray(30 + Math.floor(r() * 200))}@1:t=fill:enable='gte(t,${o})'[v]`, crf: 28 }) },
  { id: "blur_light", label: "global blur σ=4", onsetRange: [5, 7], args: (_r, o) => f1(`gblur=sigma=4:enable='gte(t,${o})'`)(_r, o) },
  { id: "blur_medium", label: "global blur σ=8", onsetRange: [5, 7], args: (_r, o) => f1(`gblur=sigma=8:enable='gte(t,${o})'`)(_r, o) },
  { id: "blur_heavy", label: "global blur σ=16", onsetRange: [5, 7], args: (_r, o) => f1(`gblur=sigma=16:enable='gte(t,${o})'`)(_r, o) },
  { id: "noise", label: "global temporal noise (alls=60)", onsetRange: [5, 7], args: (_r, o) => ({ ...f1(`noise=alls=60:allf=t:enable='gte(t,${o})'`)(_r, o), crf: 40 }) },
  { id: "darken", label: "global brightness −0.2", onsetRange: [5, 7], args: (_r, o) => f1(`eq=brightness=-0.2:enable='gte(t,${o})'`)(_r, o) },
  { id: "flicker", label: "brightness flicker ±0.2", onsetRange: [5, 7], args: (_r, o) => f1(`eq=brightness='if(gte(t,${o}),0.2*sin(2*PI*8*t),0)':eval=frame`)(_r, o) },
  { id: "shake", label: "extra camera shake (crop jitter ±5%)", onsetRange: [5, 7], args: (_r, o) => f1(`crop=432:768:'24+22*if(gte(t,${o}),sin(37*t),0)':'43+38*if(gte(t,${o}),sin(29*t),0)',scale=${W}:${H}`)(_r, o) },
  { id: "jump_cut", label: "temporal jump (content +3 s) at onset", onsetRange: [4.5, 6], args: (_r, o) => ({ pre: ["-ss", "3", "-i", SRC], fc: `[0:v][1:v]overlay=enable='gte(t,${o})'[v]`, crf: 28 }) },
];

async function encode(dir: string, c: V, seed: number) {
  const r = mulberry32(seed);
  const onset = Number((c.onsetRange[0] + r() * (c.onsetRange[1] - c.onsetRange[0])).toFixed(2));
  const a = c.args(r, onset);
  const out = join(dir, `${c.id}-${seed}.mp4`);
  await run("ffmpeg", ["-v", "error", "-y", "-i", SRC, ...a.pre, "-filter_complex", a.fc, "-map", "[v]", "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", String(a.crf), "-pix_fmt", "yuv420p", out], { maxBuffer: 1 << 20 });
  return { buf: await readFile(out), onset };
}

interface Frames { S: boolean[]; J: boolean[]; M: boolean[]; D: boolean[]; ch: string[][] }
async function frames(buf: Buffer): Promise<Frames> {
  const probe = await analyzeVideoBuffer(buf, 24);
  const rep = globalOmegaVideoOptimizer.runInferenceOptimizationLoop({ prompt: "real", frameObservations: probe.frameObservations });
  const t = rep.stepsTrace;
  return { S: t.map((s) => !s.frame.stationaryRegime), J: t.map((s) => s.motion.jitterDetected), M: t.map((s) => s.character.morphWarning), D: t.map((s) => !!s.defect?.alarm), ch: t.map((s) => s.defect?.channels ?? []) };
}
const wilsonTxt = (k: number, n: number) => { const [a, b] = wilson(k, n); return `${(100 * k / n).toFixed(0)}% (${(100 * a).toFixed(0)}–${(100 * b).toFixed(0)})`; };

async function main() {
  const dir = await mkdtemp(join(tmpdir(), "ovo-real-"));
  const want = (process.env.OVO_REAL_CONDS ?? CONDS.map((c) => c.id).join(",")).split(",");
  const ref = await frames((await encode(dir, CONDS[0], 1)).buf); // CRF drawn from seed 1 → fixed reference
  const res: Record<string, any> = {};
  const jobs = CONDS.filter((c) => want.includes(c.id)).flatMap((c) => Array.from({ length: N }, (_, i) => ({ c, seed: 7000 + i * 13 })));
  await pool(jobs, 4, async ({ c, seed }) => {
    try {
      const { buf, onset } = await encode(dir, c, seed);
      const f = await frames(buf);
      const k = Math.ceil(onset / 0.5) + 1; // first probe step index at/after onset (1-based)
      const post = (arr: boolean[]) => arr.some((v, i) => i + 1 >= k && v);
      const attrib = (a: boolean[], b: boolean[]) => a.some((v, i) => i + 1 >= k && v && !b[i]);
      const R = (res[c.id] ??= { n: 0, D: 0, S: 0, J: 0, M: 0, ch: { change: 0, local: 0, detailDrop: 0, luma: 0 } });
      R.n++;
      if (attrib(f.D, ref.D)) R.D++;
      if (attrib(f.S, ref.S)) R.S++;
      if (attrib(f.J, ref.J)) R.J++;
      if (attrib(f.M, ref.M)) R.M++;
      for (const name of Object.keys(R.ch)) if (f.ch.some((cs, i) => i + 1 >= k && cs.includes(name) && !ref.ch[i].includes(name))) R.ch[name]++;
    } catch (e: any) { console.error(`FAILED ${c.id}: ${e?.message ?? e}`); }
  });
  await rm(dir, { recursive: true, force: true });
  await writeFile(`/tmp/real/res_${TAG}.json`, JSON.stringify({ res, refAlarmFrames: ref.D.map((v, i) => (v ? i : -1)).filter((i) => i >= 0) }));
  for (const c of CONDS) if (res[c.id]) { const R = res[c.id]; console.log(`${c.id.padEnd(12)} n=${R.n} NEW ${wilsonTxt(R.D, R.n)} [chg ${R.ch.change} loc ${R.ch.local} det ${R.ch.detailDrop} luma ${R.ch.luma}] | OLD S ${R.S} J ${R.J} M ${R.M}`); }
}
main().catch((e) => { console.error(e); process.exit(1); });
