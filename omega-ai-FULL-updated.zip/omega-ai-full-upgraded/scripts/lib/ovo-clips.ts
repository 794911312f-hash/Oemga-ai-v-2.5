/**
 * Shared ffmpeg clip synthesis for OVO validation/calibration.
 * Content families:
 *   smooth   — ffmpeg `gradients` source (random seed/speed/colour count)
 *   textured — the same gradients blended with a STATIC noise texture (gives blur something to remove)
 * Faults start at t = ONSET. All clips: 160×90, 10 fps, 12 s, probed at 2 fps by production code.
 */
import { execFile } from "node:child_process";
import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { promisify } from "node:util";

const run = promisify(execFile);
export const W = 160, H = 90, FPS = 10, DUR = 12, ONSET = 6;
export const SIZE = `${W}x${H}`;

export function mulberry32(a: number) {
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export type Content = "smooth" | "textured";
const gray = (g: number) => `0x${g.toString(16).padStart(2, "0").repeat(3)}`;

export interface Cond { id: string; label: string; fault: (r: () => number) => string; cut?: boolean }

export const CONDS: Cond[] = [
  { id: "clean", label: "no fault (false-alarm control)", fault: () => "null" },
  {
    id: "local_artifact_large", label: "local block 40×25 (7% of frame)",
    fault: (r) => `drawbox=x=${Math.floor(r() * (W - 40))}:y=${Math.floor(r() * (H - 25))}:w=40:h=25:color=${gray(30 + Math.floor(r() * 200))}@1:t=fill:enable='gte(t,${ONSET})'`,
  },
  {
    id: "local_artifact_small", label: "local block 20×12 (1.7% of frame)",
    fault: (r) => `drawbox=x=${Math.floor(r() * (W - 20))}:y=${Math.floor(r() * (H - 12))}:w=20:h=12:color=${gray(30 + Math.floor(r() * 200))}@1:t=fill:enable='gte(t,${ONSET})'`,
  },
  { id: "global_blur", label: "global blur σ=6", fault: () => `gblur=sigma=6:enable='gte(t,${ONSET})'` },
  { id: "global_noise", label: "global temporal noise (alls=80)", fault: () => `noise=alls=80:allf=t:enable='gte(t,${ONSET})'` },
  { id: "global_darken", label: "global brightness −0.35", fault: () => `eq=brightness=-0.35:enable='gte(t,${ONSET})'` },
  { id: "flicker", label: "brightness flicker ±0.3", fault: () => `eq=brightness='if(gte(t,${ONSET}),0.3*sin(2*PI*8*t),0)':eval=frame` },
  {
    id: "camera_shake", label: "camera shake (crop jitter)",
    fault: () => `crop=144:81:'8+7*if(gte(t,${ONSET}),sin(37*t),0)':'4.5+4*if(gte(t,${ONSET}),sin(29*t),0)',scale=160:90`,
  },
  { id: "hard_cut", label: "hard cut to unrelated content (positive control)", fault: () => "null", cut: true },
];

const grad = (seed: number, sp: string, n: number, d: number) =>
  `gradients=s=${SIZE}:d=${d}:r=${FPS}:seed=${seed}:speed=${sp}:n=${n}`;

export async function makeClip(dir: string, content: Content, cond: Cond, seed: number): Promise<Buffer> {
  const r = mulberry32(seed ^ 0x9e3779b9);
  const sp = (0.005 + r() * 0.02).toFixed(4);
  const n = 2 + Math.floor(r() * 3);
  const tex = (label: string) =>
    content === "textured"
      ? `color=c=gray:s=${SIZE}:r=${FPS}:d=${DUR},noise=alls=60:allf=u:all_seed=${seed % 10000}[tx];[${label}][tx]blend=all_mode=overlay:all_opacity=0.6`
      : "null";
  const fault = cond.fault(r);
  const out = join(dir, `${content}-${cond.id}-${seed}.mp4`);
  let args: string[];
  if (cond.cut) {
    // two unrelated sources joined at ONSET, then (optionally) textured
    const fc = `${grad(seed, sp, 3, ONSET)}[a];${grad(seed + 7919, sp, 4, DUR - ONSET)}[b];[a][b]concat=n=2:v=1:a=0[c];` +
      (content === "textured" ? tex("c") + "[v]" : "[c]null[v]");
    args = ["-filter_complex", fc, "-map", "[v]"];
  } else {
    const fc = `${grad(seed, sp, n, DUR)}[g];` + (content === "textured" ? tex("g") + "[t];[t]" : "[g]") + `${fault}[v]`;
    args = ["-filter_complex", fc, "-map", "[v]"];
  }
  await run("ffmpeg", ["-v", "error", "-y", ...args, "-t", String(DUR), "-c:v", "libx264", "-preset", "ultrafast", "-crf", "30", "-pix_fmt", "yuv420p", out], { maxBuffer: 1 << 20 });
  return readFile(out);
}

export async function pool<T>(items: T[], limit: number, fn: (x: T) => Promise<void>) {
  let i = 0;
  await Promise.all(Array.from({ length: limit }, async () => { while (i < items.length) await fn(items[i++]); }));
}
export function wilson(k: number, n: number, z = 1.96): [number, number] {
  if (n === 0) return [0, 0];
  const p = k / n, d = 1 + z * z / n, c = p + z * z / (2 * n);
  const m = z * Math.sqrt((p * (1 - p) + z * z / (4 * n)) / n);
  return [(c - m) / d, (c + m) / d];
}
