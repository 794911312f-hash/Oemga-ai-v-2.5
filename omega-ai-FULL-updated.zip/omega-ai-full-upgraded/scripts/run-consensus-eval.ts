/**
 * scripts/run-consensus-eval.ts
 * =============================================================================
 * Offline measurement package:
 *   - Reference aggregators vs spectral weighting
 *   - Semantic entropy & JSD as competing agreement metrics
 *   - Predictive power (Pearson / AUROC) of each metric vs gold correctness
 *   - Binomial SE, Wilson 95% CI, McNemar paired tests
 *   - Spectral hyper-parameter sensitivity (σ, minGap)
 *
 * Usage:
 *   npx tsx scripts/run-consensus-eval.ts
 *   npx tsx scripts/run-consensus-eval.ts --n-candidates 6
 *
 * Honesty: this run is offline / synthetic candidates derived from gold expects.
 * It is engineering evidence for relative ranking of methods, NOT provider-backed
 * experimental claims. See docs/BENCHMARK-REAL.md.
 */

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  evaluateItem,
  summarize,
  spectralSensitivity,
  synthesizeCandidates,
  type EvalItem,
  type GoldExpect,
} from "../src/lib/omega/consensusEval.ts";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const DATASET = path.join(ROOT, "datasets/omega-benchmark-v1");
const REPORTS = path.join(ROOT, "docs/reports");

interface BenchItem {
  id: string;
  category: string;
  question: string;
  expect: GoldExpect;
}

function loadItems(): BenchItem[] {
  const index = JSON.parse(fs.readFileSync(path.join(DATASET, "index.json"), "utf-8"));
  const items: BenchItem[] = [];
  for (const meta of Object.values(index.categories as Record<string, { file: string }>)) {
    const data = JSON.parse(fs.readFileSync(path.join(DATASET, meta.file), "utf-8"));
    for (const it of data.items as BenchItem[]) items.push(it);
  }
  return items;
}

function pct(x: number): string {
  return (x * 100).toFixed(1) + "%";
}

function fmt(x: number, d = 3): string {
  return x.toFixed(d);
}

function main() {
  const args = process.argv.slice(2);
  let nCandidates = 5;
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "--n-candidates" && args[i + 1]) nCandidates = parseInt(args[i + 1], 10);
  }

  const raw = loadItems();
  console.log(`[consensus-eval] loaded ${raw.length} benchmark items`);

  const items: EvalItem[] = raw.map((it, idx) =>
    synthesizeCandidates(it, nCandidates, 42 + idx)
  );

  const results = items.map((it) => evaluateItem(it));
  const report = summarize(results);

  console.log("[consensus-eval] running spectral sensitivity…");
  report.spectralParamSensitivity = spectralSensitivity(
    items,
    [0.3, 0.5, 0.8, "median"],
    [0.05, 0.1, 0.2]
  );

  const date = new Date().toISOString().slice(0, 10);
  const lines: string[] = [];
  lines.push(`# Consensus Evaluation Report — ${date} (offline)`);
  lines.push("");
  lines.push("> **Honesty**: synthetic multi-candidate sets derived from gold expects + hashEmbed.");
  lines.push("> Not provider-backed experimental evidence. See `docs/BENCHMARK-REAL.md`.");
  lines.push("> Regenerated from current code (AUROC mid-ranks, n<3 cohesion fix, SE/CI/McNemar).");
  lines.push("");
  lines.push(`Items: **${report.nItems}** · Candidates per item: **${nCandidates}**`);
  lines.push("");

  lines.push("## 1. Aggregator accuracy (vs gold)");
  lines.push("");
  lines.push("| Method | Accuracy ± SE | 95% Wilson CI | n correct / n | Mean conf. |");
  lines.push("|--------|---------------|---------------|---------------|------------|");
  for (const m of report.methods) {
    lines.push(
      `| \`${m.name}\` | ${pct(m.accuracy)} ± ${pct(m.se)} | [${pct(m.ci95.low)}, ${pct(m.ci95.high)}] | ${m.nCorrect}/${m.n} | ${fmt(m.meanConfidence)} |`
    );
  }
  lines.push("");

  lines.push("## 2. Paired tests (McNemar, continuity-corrected)");
  lines.push("");
  lines.push("Compares methods on the **same** items. p-value is null when discordant pairs < 5 (χ² unreliable).");
  lines.push("");
  lines.push("| A vs B | Δacc (A−B) | n₁₀ (A✓ B✗) | n₀₁ (A✗ B✓) | χ² | p (approx) |");
  lines.push("|--------|------------|-------------|-------------|-----|------------|");
  for (const t of report.pairedTests) {
    const p =
      t.pValue === null ? "n/a (<5 disc.)" : t.pValue < 0.001 ? "<0.001" : t.pValue.toFixed(3);
    lines.push(
      `| \`${t.methodA}\` vs \`${t.methodB}\` | ${pct(t.accuracyDelta)} | ${t.n10} | ${t.n01} | ${fmt(t.chi2)} | ${p} |`
    );
  }
  lines.push("");

  lines.push("## 3. Predictive power of agreement metrics");
  lines.push("");
  lines.push("Higher AUROC / Pearson = metric better separates items that contain a correct answer.");
  lines.push("Entropy / JSD / outlierCount / freeEnergy are inverted (lower disagreement → higher score).");
  lines.push("AUROC uses mid-ranks for ties.");
  lines.push("");
  lines.push("| Metric | Pearson (any correct) | Pearson (spectral chosen) | AUROC (any correct) |");
  lines.push("|--------|----------------------|---------------------------|---------------------|");
  for (const p of report.predictive) {
    lines.push(
      `| \`${p.metric}\` | ${fmt(p.pearsonAnyCorrect)} | ${fmt(p.pearsonChosenCorrect)} | ${fmt(p.aurocAnyCorrect)} |`
    );
  }
  lines.push("");

  lines.push("## 4. Accuracy by category");
  lines.push("");
  for (const [cat, block] of Object.entries(report.byCategory)) {
    lines.push(`### ${cat} (n=${block.n})`);
    lines.push("");
    lines.push("| Method | Accuracy ± SE | 95% CI |");
    lines.push("|--------|---------------|--------|");
    for (const m of block.methods) {
      lines.push(
        `| \`${m.name}\` | ${pct(m.accuracy)} ± ${pct(m.se)} | [${pct(m.ci95.low)}, ${pct(m.ci95.high)}] |`
      );
    }
    lines.push("");
  }

  if (report.spectralParamSensitivity) {
    lines.push("## 5. Spectral hyper-parameter sensitivity");
    lines.push("");
    lines.push("| σ | minGap | Mean cohesion | Spectral-weighted accuracy |");
    lines.push("|---|--------|---------------|----------------------------|");
    for (const row of report.spectralParamSensitivity) {
      lines.push(
        `| ${row.sigma} | ${row.minGap} | ${fmt(row.meanCohesion)} | ${pct(row.spectralAccuracy)} |`
      );
    }
    lines.push("");
  }

  lines.push("## 6. Takeaways (auto)");
  lines.push("");
  const bestMethod = [...report.methods].sort((a, b) => b.accuracy - a.accuracy)[0];
  const bestMetric = [...report.predictive].sort((a, b) => b.aurocAnyCorrect - a.aurocAnyCorrect)[0];
  lines.push(
    `- Best aggregator under this offline protocol: **\`${bestMethod.name}\`** (${pct(bestMethod.accuracy)} ± ${pct(bestMethod.se)}, 95% CI [${pct(bestMethod.ci95.low)}, ${pct(bestMethod.ci95.high)}]).`
  );
  lines.push(
    `- Strongest predictive metric for “item has a correct candidate”: **\`${bestMetric.metric}\`** (AUROC ${fmt(bestMetric.aurocAnyCorrect)}).`
  );
  const vsMaj = report.pairedTests.filter((t) => t.methodB === "majority" && t.pValue !== null);
  const significant = vsMaj.filter((t) => (t.pValue ?? 1) < 0.05);
  if (significant.length) {
    lines.push(
      `- Methods significantly different from majority (p<0.05, McNemar): ${significant.map((t) => `\`${t.methodA}\``).join(", ") || "none"}.`
    );
  } else {
    lines.push("- No method significantly beats majority at p<0.05 under this offline sample (n=50); treat ranking as provisional.");
  }
  lines.push("- Next step for real claims: re-run with provider-backed candidates (`sourceClass=real`) and the same SE/CI/McNemar tables.");
  lines.push("");

  fs.mkdirSync(REPORTS, { recursive: true });
  const outPath = path.join(REPORTS, `consensus-eval-${date}-offline.md`);
  fs.writeFileSync(outPath, lines.join("\n"), "utf-8");
  console.log(`[consensus-eval] wrote ${outPath}`);

  console.log("\n=== Aggregator accuracy (±SE) ===");
  for (const m of report.methods) {
    console.log(`  ${m.name.padEnd(20)} ${pct(m.accuracy)} ± ${pct(m.se)}  CI[${pct(m.ci95.low)}, ${pct(m.ci95.high)}]`);
  }
  console.log("\n=== Predictive AUROC (any correct) ===");
  for (const p of report.predictive) {
    console.log(`  ${p.metric.padEnd(22)} ${fmt(p.aurocAnyCorrect)}`);
  }
  console.log("\n=== McNemar vs majority ===");
  for (const t of report.pairedTests.filter((x) => x.methodB === "majority")) {
    const p = t.pValue === null ? "n/a" : t.pValue.toFixed(3);
    console.log(`  ${t.methodA.padEnd(20)} Δ=${pct(t.accuracyDelta)}  χ²=${fmt(t.chi2)}  p=${p}`);
  }
}

main();
