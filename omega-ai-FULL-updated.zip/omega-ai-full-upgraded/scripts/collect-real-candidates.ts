/**
 * scripts/collect-real-candidates.ts
 * =============================================================================
 * Collect multi-provider candidate answers for consensusEval (real path).
 *
 * Reads datasets/omega-benchmark-v1, calls available providers with a fixed
 * system prompt, writes JSONL + summary under datasets/real-candidates/.
 *
 * Usage:
 *   npx tsx scripts/collect-real-candidates.ts
 *   npx tsx scripts/collect-real-candidates.ts --limit 10
 *   npx tsx scripts/collect-real-candidates.ts --category math
 *
 * Env (any subset):
 *   OPENAI_API_KEY   → openai / gpt-4o-mini (default model)
 *   GOOGLE_API_KEY or GEMINI_API_KEY → gemini-2.0-flash
 *   ANTHROPIC_API_KEY → claude-3-5-haiku (if SDK path available via fetch)
 *
 * Honesty: only rows with at least one sourceClass=real are usable for *-run
 * consensus evaluation. Missing keys → that provider is skipped, not simulated.
 */

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import OpenAI from "openai";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const DATASET = path.join(ROOT, "datasets/omega-benchmark-v1");
const OUT_DIR = path.join(ROOT, "datasets/real-candidates");

interface GoldExpect {
  type: string;
  values: string[];
}

interface BenchItem {
  id: string;
  category: string;
  question: string;
  expect: GoldExpect;
}

interface CandidateRow {
  modelId: string;
  text: string;
  logprob?: number;
  sourceClass: "real" | "failed";
  latencyMs: number;
  error?: string;
}

interface ItemCandidates {
  id: string;
  category: string;
  question: string;
  expect: GoldExpect;
  collectedAt: string;
  candidates: CandidateRow[];
}

const SYSTEM = `You are a careful assistant. Answer the user question briefly and precisely.
If the answer is a number or short fact, put it clearly in the first sentence.
Do not refuse ordinary factual or math questions.`;

function loadItems(category?: string): BenchItem[] {
  const index = JSON.parse(fs.readFileSync(path.join(DATASET, "index.json"), "utf-8"));
  const items: BenchItem[] = [];
  for (const meta of Object.values(index.categories as Record<string, { file: string }>)) {
    const data = JSON.parse(fs.readFileSync(path.join(DATASET, meta.file), "utf-8"));
    for (const it of data.items as BenchItem[]) {
      if (category && it.category !== category) continue;
      items.push(it);
    }
  }
  return items;
}

function hasOpenAI(): boolean {
  return Boolean(process.env.OPENAI_API_KEY);
}
function hasGemini(): boolean {
  return Boolean(process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY);
}
function hasAnthropic(): boolean {
  return Boolean(process.env.ANTHROPIC_API_KEY);
}

async function callOpenAI(question: string): Promise<CandidateRow> {
  const t0 = Date.now();
  const model = process.env.OMEGA_OPENAI_MODEL || "gpt-4o-mini";
  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const res = await client.chat.completions.create({
      model,
      temperature: 0.2,
      max_tokens: 400,
      messages: [
        { role: "system", content: SYSTEM },
        { role: "user", content: question },
      ],
    });
    const text = res.choices[0]?.message?.content?.trim() || "";
    const lp = res.choices[0]?.logprobs?.content
      ? res.choices[0]!.logprobs!.content!.reduce((s, t) => s + (t.logprob ?? 0), 0)
      : undefined;
    return {
      modelId: `openai:${model}`,
      text,
      logprob: lp,
      sourceClass: text ? "real" : "failed",
      latencyMs: Date.now() - t0,
      error: text ? undefined : "empty response",
    };
  } catch (e: any) {
    return {
      modelId: `openai:${model}`,
      text: "",
      sourceClass: "failed",
      latencyMs: Date.now() - t0,
      error: String(e?.message ?? e),
    };
  }
}

async function callGemini(question: string): Promise<CandidateRow> {
  const t0 = Date.now();
  const key = process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY || "";
  const model = process.env.OMEGA_GEMINI_MODEL || "gemini-2.0-flash";
  try {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`;
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: `${SYSTEM}\n\n${question}` }] }],
        generationConfig: { temperature: 0.2, maxOutputTokens: 400 },
      }),
    });
    if (!res.ok) {
      const body = await res.text();
      return {
        modelId: `gemini:${model}`,
        text: "",
        sourceClass: "failed",
        latencyMs: Date.now() - t0,
        error: `HTTP ${res.status}: ${body.slice(0, 200)}`,
      };
    }
    const data = (await res.json()) as any;
    const text =
      data?.candidates?.[0]?.content?.parts?.map((p: any) => p.text).join("")?.trim() || "";
    return {
      modelId: `gemini:${model}`,
      text,
      sourceClass: text ? "real" : "failed",
      latencyMs: Date.now() - t0,
      error: text ? undefined : "empty response",
    };
  } catch (e: any) {
    return {
      modelId: `gemini:${model}`,
      text: "",
      sourceClass: "failed",
      latencyMs: Date.now() - t0,
      error: String(e?.message ?? e),
    };
  }
}

async function callAnthropic(question: string): Promise<CandidateRow> {
  const t0 = Date.now();
  const model = process.env.OMEGA_ANTHROPIC_MODEL || "claude-3-5-haiku-20241022";
  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY || "",
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model,
        max_tokens: 400,
        temperature: 0.2,
        system: SYSTEM,
        messages: [{ role: "user", content: question }],
      }),
    });
    if (!res.ok) {
      const body = await res.text();
      return {
        modelId: `anthropic:${model}`,
        text: "",
        sourceClass: "failed",
        latencyMs: Date.now() - t0,
        error: `HTTP ${res.status}: ${body.slice(0, 200)}`,
      };
    }
    const data = (await res.json()) as any;
    const text =
      (data?.content || [])
        .filter((b: any) => b.type === "text")
        .map((b: any) => b.text)
        .join("")
        .trim() || "";
    return {
      modelId: `anthropic:${model}`,
      text,
      sourceClass: text ? "real" : "failed",
      latencyMs: Date.now() - t0,
      error: text ? undefined : "empty response",
    };
  } catch (e: any) {
    return {
      modelId: `anthropic:${model}`,
      text: "",
      sourceClass: "failed",
      latencyMs: Date.now() - t0,
      error: String(e?.message ?? e),
    };
  }
}

async function collectForQuestion(q: string): Promise<CandidateRow[]> {
  const jobs: Promise<CandidateRow>[] = [];
  if (hasOpenAI()) jobs.push(callOpenAI(q));
  if (hasGemini()) jobs.push(callGemini(q));
  if (hasAnthropic()) jobs.push(callAnthropic(q));
  return Promise.all(jobs);
}

function parseArgs(argv: string[]) {
  let limit = Infinity;
  let category: string | undefined;
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === "--limit" && argv[i + 1]) limit = parseInt(argv[++i], 10);
    if (argv[i] === "--category" && argv[i + 1]) category = argv[++i];
  }
  return { limit, category };
}

async function main() {
  const { limit, category } = parseArgs(process.argv.slice(2));
  const providers = [
    hasOpenAI() && "openai",
    hasGemini() && "gemini",
    hasAnthropic() && "anthropic",
  ].filter(Boolean) as string[];

  if (providers.length === 0) {
    console.error(
      "[collect-real] No provider keys. Set OPENAI_API_KEY and/or GOOGLE_API_KEY|GEMINI_API_KEY and/or ANTHROPIC_API_KEY."
    );
    process.exit(2);
  }

  const items = loadItems(category).slice(0, limit === Infinity ? undefined : limit);
  console.log(`[collect-real] providers=${providers.join(",")} items=${items.length}`);

  fs.mkdirSync(OUT_DIR, { recursive: true });
  const date = new Date().toISOString().slice(0, 10);
  const outPath = path.join(OUT_DIR, `candidates-${date}.jsonl`);
  const fh = fs.createWriteStream(outPath, { flags: "w" });

  let itemsWithReal = 0;
  let totalReal = 0;
  let totalFailed = 0;

  for (let i = 0; i < items.length; i++) {
    const it = items[i];
    process.stdout.write(`[collect-real] ${i + 1}/${items.length} ${it.id}… `);
    const candidates = await collectForQuestion(it.question);
    const real = candidates.filter((c) => c.sourceClass === "real").length;
    const failed = candidates.length - real;
    totalReal += real;
    totalFailed += failed;
    if (real > 0) itemsWithReal += 1;
    console.log(`real=${real} failed=${failed}`);

    const row: ItemCandidates = {
      id: it.id,
      category: it.category,
      question: it.question,
      expect: it.expect,
      collectedAt: new Date().toISOString(),
      candidates,
    };
    fh.write(JSON.stringify(row) + "\n");
  }
  fh.end();

  const summary = {
    date,
    providers,
    nItems: items.length,
    itemsWithReal,
    totalRealCandidates: totalReal,
    totalFailedCandidates: totalFailed,
    outPath: path.relative(ROOT, outPath),
    note: "Feed into scripts/run-consensus-eval-real.ts (or extend evaluateItem) — only sourceClass=real rows count as experimental.",
  };
  const sumPath = path.join(OUT_DIR, `summary-${date}.json`);
  fs.writeFileSync(sumPath, JSON.stringify(summary, null, 2));
  console.log(`[collect-real] wrote ${outPath}`);
  console.log(`[collect-real] summary ${sumPath}`);
  console.log(JSON.stringify(summary, null, 2));
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
