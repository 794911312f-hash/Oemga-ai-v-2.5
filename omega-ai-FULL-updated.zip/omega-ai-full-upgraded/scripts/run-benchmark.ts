/**
 * scripts/run-benchmark.ts
 * =============================================================================
 * Omega Benchmark Runner — Experimental Validation (Tier 2 harness)
 * =============================================================================
 *
 * Loads datasets/omega-benchmark-v1, runs each item through Cognitive Workspace
 * (or a deterministic offline fixture if --offline), scores expect.contains_any,
 * and writes docs/reports/benchmark-YYYY-MM-DD.md
 *
 * Usage:
 *   npx tsx scripts/run-benchmark.ts
 *   npx tsx scripts/run-benchmark.ts --offline
 *   npx tsx scripts/run-benchmark.ts --category math
 *   npx tsx scripts/run-benchmark.ts --require-real
 *
 * Honesty:
 *   --offline → evidence_tier=offline_fixture; filename *-offline.md
 *   No API / all simulated|failed → evidence_tier=simulated_no_providers;
 *     filename *-simulated.md (NEVER *-run.md)
 *   At least one sourceClass=real → evidence_tier=experimental_provider;
 *     filename *-run.md (eligible for evolution-gate consideration)
 */

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  clearCoreRunner,
  registerCoreRunner,
  runCognitiveWorkspace,
  getCoreBridgeStatus,
} from "../src/lib/omega/cognitiveWorkspace/index.ts";
import {
  evaluateCalibration,
  formatCalibrationMarkdown,
  type CalibrationPair,
} from "../src/lib/omega/calibration.ts";
import OpenAI from "openai";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const DATASET = path.join(ROOT, "datasets/omega-benchmark-v1");
const REPORTS = path.join(ROOT, "docs/reports");

interface BenchItem {
  id: string;
  category: string;
  question: string;
  context?: string;
  expect: { type: string; values: string[] };
  depth?: "fast" | "balanced" | "deep";
}

interface ItemResult {
  id: string;
  category: string;
  pass: boolean;
  latency_ms: number;
  psi_top: number | null;
  verified: boolean | null | string;
  sourceClass: string;
  answer_preview: string;
}

function parseArgs(argv: string[]) {
  const offline = argv.includes("--offline");
  const requireReal = argv.includes("--require-real");
  const catIdx = argv.indexOf("--category");
  const category = catIdx >= 0 ? argv[catIdx + 1] : null;
  return { offline, category, requireReal };
}

/** Heuristic: any common provider env key present (does not validate the key). */
function detectProviderEnv(): { present: string[]; missingHint: string } {
  const keys = [
    "GOOGLE_API_KEY",
    "GEMINI_API_KEY",
    "OPENAI_API_KEY",
    "ANTHROPIC_API_KEY",
    "OMEGA_PROVIDER_KEYS",
  ];
  const present = keys.filter((k) => {
    const v = process.env[k];
    return typeof v === "string" && v.trim().length > 8;
  });
  return {
    present,
    missingHint:
      "Set at least one of GOOGLE_API_KEY / GEMINI_API_KEY / OPENAI_API_KEY / ANTHROPIC_API_KEY",
  };
}

function loadItems(categoryFilter: string | null): BenchItem[] {
  const index = JSON.parse(
    fs.readFileSync(path.join(DATASET, "index.json"), "utf-8")
  );
  const items: BenchItem[] = [];
  for (const [cat, meta] of Object.entries(index.categories as Record<string, { file: string }>)) {
    if (categoryFilter && cat !== categoryFilter && meta.file.replace(".json", "") !== categoryFilter) {
      // also allow multistep vs multi_step
      if (!(categoryFilter === "multistep" && cat === "multi_step")) continue;
    }
    const file = path.join(DATASET, meta.file);
    const data = JSON.parse(fs.readFileSync(file, "utf-8"));
    for (const it of data.items as BenchItem[]) {
      items.push({ ...it, category: it.category || cat });
    }
  }
  return items;
}

function scoreContainsAny(answer: string, values: string[]): boolean {
  const lower = answer.toLowerCase();
  return values.some((v) => lower.includes(String(v).toLowerCase()));
}

/** Deterministic offline answers that satisfy expect where possible — fixture only */
function offlineAnswer(item: BenchItem): string {
  if (item.context) {
    return `حسب السياق المعطى: ${item.context}`;
  }
  const hints = item.expect?.values || [];
  return `إجابة تثبيتية (offline fixture). عناصر متوقعة للمطابقة: ${hints.join(" | ")}. ${hints[0] || ""}`;
}

function todayStamp(): string {
  const d = new Date();
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, "0");
  const day = String(d.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function writeReport(opts: {
  offline: boolean;
  results: ItemResult[];
  bridgeLabel: string;
}): string {
  const { offline, results, bridgeLabel } = opts;
  const passed = results.filter((r) => r.pass).length;
  const n = results.length || 1;
  const accuracy = passed / n;
  const latencies = results.map((r) => r.latency_ms).sort((a, b) => a - b);
  const p50 = latencies[Math.floor(latencies.length * 0.5)] ?? 0;
  const p95 = latencies[Math.floor(latencies.length * 0.95)] ?? p50;
  const psiVals = results.map((r) => r.psi_top).filter((x): x is number => x != null);
  const psiAvg =
    psiVals.length > 0
      ? psiVals.reduce((a, b) => a + b, 0) / psiVals.length
      : null;

  const verifyCounts = { true: 0, false: 0, null: 0 };
  for (const r of results) {
    if (r.verified === true) verifyCounts.true++;
    else if (r.verified === false) verifyCounts.false++;
    else verifyCounts.null++;
  }

  const sourceMix: Record<string, number> = {};
  for (const r of results) {
    sourceMix[r.sourceClass] = (sourceMix[r.sourceClass] || 0) + 1;
  }

  const realCount = results.filter((r) => r.sourceClass === "real").length;
  const simCount = results.filter(
    (r) => r.sourceClass === "simulated" || r.sourceClass === "failed"
  ).length;
  const mixedCount = results.filter((r) => r.sourceClass === "mixed").length;

  // Provider-backed only if not offline AND at least one real answer
  const providerBacked = !offline && realCount > 0;

  let tier: string;
  let suffix: string;
  let modeLabel: string;
  if (offline) {
    tier = "offline_fixture (NOT experimental provider evidence)";
    suffix = "offline";
    modeLabel = "offline fixture";
  } else if (!providerBacked) {
    tier =
      "simulated_no_providers (NOT experimental — no sourceClass=real; do not cite)";
    suffix = "simulated";
    modeLabel = "workspace runner WITHOUT live providers (SIMULATED)";
  } else {
    tier = "experimental_provider (provider-backed; eligible for gate review)";
    suffix = "run";
    modeLabel = "workspace runner (provider-backed)";
  }

  const stamp = todayStamp();
  const outName = `benchmark-${stamp}-${suffix}.md`;
  const outPath = path.join(REPORTS, outName);

  const lines: string[] = [
    `# Benchmark Report — omega-benchmark-v1`,
    ``,
    `- **Date (UTC):** ${stamp}`,
    `- **Mode:** ${modeLabel}`,
    `- **Evidence tier:** ${tier}`,
    `- **sourceClass real/mixed/sim+fail:** ${realCount}/${mixedCount}/${simCount}`,
    `- **Seed:** 42`,
    `- **Core bridge:** ${bridgeLabel}`,
    `- **Items:** ${results.length}`,
    ``,
    `## Summary`,
    ``,
    `| Metric | Value |`,
    `|--------|-------|`,
    `| Accuracy | ${(accuracy * 100).toFixed(1)}% (${passed}/${results.length}) |`,
    `| Latency p50 / p95 (ms) | ${p50} / ${p95} |`,
    `| Mean top Ψ | ${psiAvg != null ? psiAvg.toFixed(3) : "—"} |`,
    `| verified true/false/null | ${verifyCounts.true}/${verifyCounts.false}/${verifyCounts.null} |`,
    `| sourceClass mix | ${Object.entries(sourceMix)
      .map(([k, v]) => `${k}:${v}`)
      .join(", ")} |`,
    ``,
    `## Per-item`,
    ``,
    `| id | pass | latency_ms | psi_top | verified | sourceClass |`,
    `|----|------|------------|---------|----------|-------------|`,
  ];

  for (const r of results) {
    lines.push(
      `| ${r.id} | ${r.pass ? "yes" : "no"} | ${r.latency_ms} | ${
        r.psi_top ?? "—"
      } | ${String(r.verified)} | ${r.sourceClass} |`
    );
  }


  // Calibration (Brier / ECE) — only meaningful for non-offline when p is real confidence
  const pairs: CalibrationPair[] = results.map((r) => ({
    y: r.pass ? 1 : 0,
    p: typeof r.psi_top === "number" ? r.psi_top : 0.5,
    id: r.id,
  }));
  const cal = evaluateCalibration(pairs, 10);
  lines.push(``, formatCalibrationMarkdown(cal));
  if (offline) {
    lines.push(
      `> Offline fixture: calibration numbers are harness smoke only, not model calibration claims.`,
      ``
    );
  }

  lines.push(
    ``,
    `## Honesty`,
    ``,
  );
  if (offline) {
    lines.push(
      `This run used **offline fixtures**. Engineering harness only.`,
      `Do **not** cite as model or Ψ task performance.`,
      `Filename suffix \`-offline\` — evolution-gate must not treat as PASS evidence.`
    );
  } else if (!providerBacked) {
    lines.push(
      `**SIMULATED / no live providers.** Zero items with \`sourceClass=real\`.`,
      `Filename suffix \`-simulated\` (not \`-run\`).`,
      `Do **not** cite accuracy, Ψ, or calibration as model performance.`,
      `Register Core Bridge + API keys, then re-run without \`--offline\`.`
    );
  } else {
    lines.push(
      `Provider-backed run: ${realCount} item(s) with \`sourceClass=real\`.`,
      `Check per-item sourceClass before citing aggregate metrics.`,
      `Eligible for evolution-gate review (still requires non-expired status fields).`
    );
  }
  lines.push(
    ``,
    `## Evolution gate`,
    ``,
    providerBacked
      ? `- [ ] Compared against previous *-run.md report`
      : `- [ ] **Not eligible** until a *-run.md report exists (provider-backed)`,
    `- [ ] Mathematical + regression tests still pass`,
    `- [ ] Promote only if accuracy did not regress beyond policy`,
    ``
  );

  fs.mkdirSync(REPORTS, { recursive: true });
  fs.writeFileSync(outPath, lines.join("\n"), "utf-8");
  return outPath;
}

async function main() {
  const { offline, category, requireReal } = parseArgs(process.argv.slice(2));
  const items = loadItems(category);
  if (items.length === 0) {
    console.error("No benchmark items loaded");
    process.exit(1);
  }

  if (offline && requireReal) {
    console.error("Cannot combine --offline with --require-real");
    process.exit(1);
  }

  const envKeys = detectProviderEnv();
  if (!offline) {
    console.log(
      envKeys.present.length
        ? `[benchmark] Provider env detected: ${envKeys.present.join(", ")}`
        : `[benchmark] No provider API keys in env — results will be SIMULATED unless Core Bridge injects real answers.\n[benchmark] ${envKeys.missingHint}`
    );
  }

  clearCoreRunner();
  if (offline) {
    registerCoreRunner(async (req) => {
      // Match offline answers loosely via question id search is not available —
      // return text that includes common expect tokens from the question path
      return {
        answer: `offline:${req.question.slice(0, 120)}`,
        candidates: [],
        sourceClass: "simulated",
      psi: 0.55,
      verified: null,
      };
    }, "benchmark-offline");
  } else if (process.env.OPENAI_API_KEY) {
    // Explicit provider-backed runner for reproducible CLI validation. A real
    // response is labelled real; failures remain failed and never become
    // simulated evidence.
    const client = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
      baseURL: process.env.OPENAI_API_BASE || process.env.OPENAI_BASE_URL || undefined,
    });
    registerCoreRunner(async (req) => {
      try {
        const response = await client.chat.completions.create({
          model: process.env.OMEGA_BENCHMARK_MODEL || "gpt-5-nano",
          temperature: 0,
          max_tokens: 700,
          messages: [
            {
              role: "system",
              content:
                "Answer the user's benchmark question accurately and concisely. " +
                "Return the answer directly; do not claim tool verification you did not perform.",
            },
            { role: "user", content: req.question },
          ],
        });
        const text = response.choices[0]?.message?.content?.trim() || "";
        return {
          answer: text,
          candidates: text ? [{ text, modelId: process.env.OMEGA_BENCHMARK_MODEL || "gpt-5-nano" }] : [],
          sourceClass: text ? "real" : "failed",
          psi: null,
          verified: null,
        };
      } catch (error: any) {
        return {
          answer: `Provider error: ${String(error?.message ?? error)}`,
          candidates: [],
          sourceClass: "failed",
          psi: null,
          verified: null,
        };
      }
    }, "benchmark-openai-provider");
  }

  const results: ItemResult[] = [];

  for (const item of items) {
    const t0 = Date.now();
    let answer = "";
    let psi: number | null = null;
    let verified: boolean | null = null;
    let sourceClass = "failed";

    try {
      if (offline) {
        answer = offlineAnswer(item);
        sourceClass = "simulated";
        psi = 0.55;
        verified = null;
      } else {
        const q = item.context
          ? `${item.question}\n\n[سياق]\n${item.context}`
          : item.question;
        const out = await runCognitiveWorkspace({
          userId: "benchmark-runner",
          question: q,
          depth: item.depth === "deep" ? "balanced" : item.depth || "fast",
        });
        answer = out.answer || "";
        psi = out.confidence?.psi ?? out.psi ?? null;
        verified = out.confidence?.verified ?? null;
        sourceClass = out.sourceClass || out.confidence?.sourceClass || "mixed";
      }
    } catch (err: any) {
      answer = `ERROR: ${err?.message ?? err}`;
      sourceClass = "failed";
    }

    const latency_ms = Date.now() - t0;
    const pass =
      item.expect?.type === "contains_any"
        ? scoreContainsAny(answer, item.expect.values || [])
        : false;

    results.push({
      id: item.id,
      category: item.category,
      pass,
      latency_ms,
      psi_top: psi,
      verified,
      sourceClass,
      answer_preview: answer.slice(0, 160),
    });

    console.log(
      `${pass ? "PASS" : "FAIL"}  ${item.id}  ${latency_ms}ms  src=${sourceClass}`
    );
  }

  const status = getCoreBridgeStatus();
  const realCount = results.filter((r) => r.sourceClass === "real").length;
  if (!offline && realCount === 0) {
    console.warn(
      "\n[benchmark] WARNING: no sourceClass=real — writing *-simulated.md, not *-run.md"
    );
    console.warn(
      "[benchmark] Register Core Bridge + API keys for experimental provider evidence."
    );
  }
  const reportPath = writeReport({
    offline,
    results,
    bridgeLabel: status.wired ? status.label : "unregistered",
  });

  const passed = results.filter((r) => r.pass).length;
  console.log(`\nAccuracy: ${passed}/${results.length}`);
  console.log(`Report: ${reportPath}`);
  if (!offline && realCount === 0) {
    console.log("Evidence: SIMULATED (not provider-backed)");
  } else if (!offline) {
    console.log(`Evidence: provider-backed (real=${realCount})`);
  } else {
    console.log("Evidence: offline_fixture");
  }
  clearCoreRunner();

  // Hard honesty: never claim provider-backed without real items
  if (!offline && realCount === 0) {
    if (requireReal) {
      console.error(
        "\n[benchmark] --require-real: aborting (exit 2). No sourceClass=real items."
      );
      process.exit(2);
    }
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
