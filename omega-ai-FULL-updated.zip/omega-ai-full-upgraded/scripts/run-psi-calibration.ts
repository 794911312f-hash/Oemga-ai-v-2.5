/**
 * Link raw Ψ (agreement score) → P̂(correct) via temperature scaling.
 *
 *   npx tsx scripts/run-psi-calibration.ts
 *   npx tsx scripts/run-psi-calibration.ts --offline
 *   npx tsx scripts/run-psi-calibration.ts --claim-live   # only with real holdout file
 *
 * Default data: datasets/omega-math-cas-v1/psi-calibration-pairs.json
 * (train / holdout splits). Offline = harness only (claimEligible=false).
 *
 * Live path (future): write pairs from Math+CAS executive y + model Ψ into
 * the same JSON shape, then re-run with --claim-live.
 */

import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import {
  calibrateScoreOnHoldout,
  formatHoldoutCalibrationMarkdown,
  type CalibrationPair,
} from "../src/lib/omega/calibration.ts";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const DEFAULT_DATA = path.join(
  ROOT,
  "datasets/omega-math-cas-v1/psi-calibration-pairs.json"
);
const REPORT_DIR = path.join(ROOT, "docs/reports");

type FilePair = CalibrationPair & { split: "train" | "holdout"; id?: string };

type DatasetFile = {
  name: string;
  version: string;
  score_name?: string;
  pairs: FilePair[];
};

function loadPairs(filePath: string): {
  train: CalibrationPair[];
  holdout: CalibrationPair[];
  meta: DatasetFile;
} {
  const meta = JSON.parse(fs.readFileSync(filePath, "utf8")) as DatasetFile;
  const train: CalibrationPair[] = [];
  const holdout: CalibrationPair[] = [];
  for (const row of meta.pairs) {
    const y = row.y === 1 ? 1 : 0;
    const p = Number(row.p);
    const item: CalibrationPair = { y, p, id: row.id };
    if (row.split === "holdout") holdout.push(item);
    else train.push(item);
  }
  return { train, holdout, meta };
}

function main() {
  const claimLive = process.argv.includes("--claim-live");
  const dataPath =
    process.argv.find((a) => a.startsWith("--data="))?.slice(7) || DEFAULT_DATA;

  const { train, holdout, meta } = loadPairs(dataPath);
  if (holdout.length === 0) {
    console.error("No holdout pairs in", dataPath);
    process.exitCode = 1;
    return;
  }

  // Fixtures shipped in-repo are never claim-eligible unless explicitly overridden
  // *and* the user passes --claim-live (they must supply real predictions).
  const isDefaultFixture = path.resolve(dataPath) === path.resolve(DEFAULT_DATA);
  const claimEligible = claimLive && !isDefaultFixture;

  const result = calibrateScoreOnHoldout(train, holdout, {
    nBins: 10,
    claimEligible,
  });

  const day = new Date().toISOString().slice(0, 10);
  const tag = claimEligible ? "live" : "offline";
  fs.mkdirSync(REPORT_DIR, { recursive: true });
  const reportPath = path.join(REPORT_DIR, `psi-calibration-${day}-${tag}.md`);

  const md = [
    `# Ψ / score → P̂(correct) calibration`,
    ``,
    `- dataset: \`${meta.name}\` v${meta.version}`,
    `- score field: **${meta.score_name ?? "p"}** (agreement-style raw score)`,
    `- train n=${train.length}, holdout n=${holdout.length}`,
    `- date: ${day}`,
    `- claimEligible: **${claimEligible}**`,
    ``,
    formatHoldoutCalibrationMarkdown(result),
    `## Interpretation`,
    ``,
    `- **Raw p**: typically Ψ (درجة اتفاق). High Brier/ECE ⇒ do not show as % correctness in UI.`,
    `- **Temperature T**: softens or sharpens logits; fit only on train, metrics on holdout.`,
    `- **Accuracy** does not change with T; only the probabilistic interpretation of p does.`,
    `- To promote Ψ→P̂ in product: replace fixture pairs with live Math+CAS executive \`y\` + model Ψ, disjoint holdout, \`--data=...\` and \`--claim-live\`.`,
    ``,
  ].join("\n");

  fs.writeFileSync(reportPath, md, "utf8");
  console.log(md);
  console.log(`\nWrote ${reportPath}`);
}

main();
