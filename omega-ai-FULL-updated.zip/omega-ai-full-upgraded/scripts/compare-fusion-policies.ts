/**
 * scripts/compare-fusion-policies.ts
 * =============================================================================
 * Compare fusion policies on omega-benchmark-v1 (same items, same seed).
 *
 * Policies:
 *   - psi: rank by clipExpPsi / nearest-to-centroid (when candidates are vectors)
 *   - majority: orthant-label majority (toy text vote when only strings)
 *   - borda: pairwise cosine ranking points
 *   - rrf: reciprocal rank fusion on cosine-to-centroid order
 *
 * Modes:
 *   --offline  synthetic multi-candidate geometry per item (Engineering only)
 *   (default)  requires external candidate provider hook later
 *
 * Output: docs/reports/fusion-compare-YYYY-MM-DD-*.md
 *
 * Honesty: offline mode is NOT experimental provider evidence.
 */

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { clipExpPsi, cosine, normalize } from "../src/lib/omega/math.ts";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const DATASET = path.join(ROOT, "datasets/omega-benchmark-v1");
const REPORTS = path.join(ROOT, "docs/reports");

type Policy = "psi" | "majority" | "borda" | "rrf";

interface BenchItem {
  id: string;
  category: string;
  question: string;
  context?: string;
  expect: { type: string; values: string[] };
}

function loadItems(): BenchItem[] {
  const index = JSON.parse(
    fs.readFileSync(path.join(DATASET, "index.json"), "utf-8")
  );
  const items: BenchItem[] = [];
  for (const meta of Object.values(
    index.categories as Record<string, { file: string }>
  )) {
    const data = JSON.parse(
      fs.readFileSync(path.join(DATASET, meta.file), "utf-8")
    );
    for (const it of data.items as BenchItem[]) items.push(it);
  }
  return items;
}

function scoreContainsAny(text: string, values: string[]): boolean {
  const lower = text.toLowerCase();
  return values.some((v) => lower.includes(String(v).toLowerCase()));
}

function argsortDesc(scores: number[]): number[] {
  return scores
    .map((s, i) => [s, i] as const)
    .sort((a, b) => b[0] - a[0])
    .map(([, i]) => i);
}

function centroid(vecs: number[][]): number[] {
  const d = vecs[0].length;
  const c = new Array(d).fill(0);
  for (const v of vecs)
    for (let i = 0; i < d; i++) c[i] += v[i] / vecs.length;
  return c;
}

function rankPsi(vecs: number[][]): number[] {
  const c = centroid(vecs);
  const delta = vecs.map((v) => 1 - cosine(v, c));
  const mean = delta.reduce((a, b) => a + b, 0) / delta.length;
  const variance =
    delta.reduce((a, x) => a + (x - mean) ** 2, 0) / delta.length;
  const sigma = Math.sqrt(variance);
  const psi = delta.map((x) => clipExpPsi(x, sigma));
  return argsortDesc(psi);
}

function rankMajority(vecs: number[][]): number[] {
  const labels = vecs.map((v) => v.map((x) => (x >= 0 ? 1 : 0)).join(""));
  const counts = new Map<string, number>();
  for (const L of labels) counts.set(L, (counts.get(L) || 0) + 1);
  return argsortDesc(labels.map((L) => counts.get(L) || 0));
}

function rankBorda(vecs: number[][]): number[] {
  const n = vecs.length;
  const points = new Array(n).fill(0);
  for (let i = 0; i < n; i++) {
    const sims = vecs.map((v, j) =>
      i === j ? -Infinity : cosine(vecs[i], v)
    );
    const order = argsortDesc(sims);
    order.forEach((idx, rank) => {
      if (Number.isFinite(sims[idx])) points[idx] += n - 1 - rank;
    });
  }
  return argsortDesc(points);
}

function rankRrf(vecs: number[][]): number[] {
  const c = centroid(vecs);
  const sims = vecs.map((v) => cosine(v, c));
  const order = argsortDesc(sims);
  const rrf = new Array(vecs.length).fill(0);
  order.forEach((idx, rank) => {
    rrf[idx] += 1 / (60 + rank + 1);
  });
  return argsortDesc(rrf);
}

const RANKERS: Record<Policy, (v: number[][]) => number[]> = {
  psi: rankPsi,
  majority: rankMajority,
  borda: rankBorda,
  rrf: rankRrf,
};

/** Build 4 synthetic candidate vectors; index 0 is biased toward expect tokens geometry */
function syntheticCandidates(
  item: BenchItem,
  seed: number
): { vecs: number[][]; texts: string[] } {
  let s = seed;
  const rnd = () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 0xffffffff;
  };
  const dim = 16;
  const correctHint = (item.expect.values || [])[0] || "ok";
  // Candidate 0: "correct-ish" text including expect token
  const texts = [
    `إجابة مرجعية تتضمن: ${correctHint}`,
    `تخمين بعيد عن الموضوع ${rnd().toFixed(3)}`,
    `نص عام بدون المطلوب ${rnd().toFixed(3)}`,
    `تشويش ${rnd().toFixed(3)}`,
  ];
  // Geometry: cand0 near a pole, others scattered
  const pole = normalize(Array.from({ length: dim }, (_, i) => (i === 0 ? 1 : 0.01)));
  const vecs = [
    normalize(pole.map((x, i) => x + (rnd() - 0.5) * 0.05)),
    normalize(Array.from({ length: dim }, () => rnd() * 2 - 1)),
    normalize(Array.from({ length: dim }, () => rnd() * 2 - 1)),
    normalize(Array.from({ length: dim }, () => rnd() * 2 - 1)),
  ];
  return { vecs, texts };
}

function todayStamp(): string {
  const d = new Date();
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}-${String(d.getUTCDate()).padStart(2, "0")}`;
}

async function main() {
  const offline = process.argv.includes("--offline") || true; // v0 always offline geometry
  const items = loadItems();
  const policies: Policy[] = ["psi", "majority", "borda", "rrf"];
  const wins: Record<Policy, number> = {
    psi: 0,
    majority: 0,
    borda: 0,
    rrf: 0,
  };

  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    const { vecs, texts } = syntheticCandidates(item, 42 + i * 17);
    // Truth = index maximizing cosine to centroid (geometry) AND preferably contains expect
    const c = centroid(vecs);
    let truth = 0;
    let best = -Infinity;
    vecs.forEach((v, idx) => {
      const sc = cosine(v, c);
      if (sc > best) {
        best = sc;
        truth = idx;
      }
    });

    for (const p of policies) {
      const order = RANKERS[p](vecs);
      const pick = order[0];
      // Score: geometric recovery OR contains_any on chosen text
      const pass =
        pick === truth ||
        scoreContainsAny(texts[pick], item.expect.values || []);
      if (pass) wins[p]++;
    }
  }

  const n = items.length;
  const lines = [
    `# Fusion Policy Comparison — omega-benchmark-v1`,
    ``,
    `- **Date (UTC):** ${todayStamp()}`,
    `- **Mode:** offline synthetic geometry`,
    `- **Evidence tier:** offline_fixture (NOT provider experimental evidence)`,
    `- **Items:** ${n}`,
    `- **Seed base:** 42`,
    ``,
    `## Summary`,
    ``,
    `| Method | Accuracy | Notes |`,
    `|--------|----------|-------|`,
    `| Ψ (consensus) | ${((100 * wins.psi) / n).toFixed(1)}% (${wins.psi}/${n}) | clipExpPsi rank |`,
    `| Majority | ${((100 * wins.majority) / n).toFixed(1)}% (${wins.majority}/${n}) | orthant labels |`,
    `| Borda | ${((100 * wins.borda) / n).toFixed(1)}% (${wins.borda}/${n}) | pairwise cosine |`,
    `| RRF | ${((100 * wins.rrf) / n).toFixed(1)}% (${wins.rrf}/${n}) | cosine-to-centroid ranks |`,
    ``,
    `## Honesty`,
    ``,
    `Synthetic candidates are constructed so a clear geometric winner exists.`,
    `This measures ranking behaviour under controlled geometry — **not** LLM task superiority.`,
    `For Tier-2 claims, re-run with real multi-model candidates on the same item ids.`,
    ``,
  ];

  fs.mkdirSync(REPORTS, { recursive: true });
  const out = path.join(
    REPORTS,
    `fusion-compare-${todayStamp()}-offline.md`
  );
  fs.writeFileSync(out, lines.join("\n"), "utf-8");
  console.log(lines.join("\n"));
  console.log(`\nWrote ${out}`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
