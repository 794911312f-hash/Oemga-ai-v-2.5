/**
 * scripts/calibrate-consensus.ts
 * =============================================================================
 * Grid calibration of spectral σ, minGap, Boltzmann T, and spectral blend λ
 * against offline synthetic multi-candidate sets from omega-benchmark-v1.
 *
 * Objective: maximise boltzmann / spectral-weighted accuracy and freeEnergy AUROC.
 *
 * Honesty: offline / hashEmbed only — not provider-backed evidence.
 *
 * Usage:
 *   npx tsx scripts/calibrate-consensus.ts
 */

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  evaluateItem,
  synthesizeCandidates,
  summarize,
  type EvalItem,
  type GoldExpect,
} from "../src/lib/omega/consensusEval.ts";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const DATASET = path.join(ROOT, "datasets/omega-benchmark-v1");
const REPORTS = path.join(ROOT, "docs/reports");

interface BenchItem {
  id: string;
  category: string;
  question: string;
  expect: GoldExpect;
}

function loadItems(): BenchItem[] {
  const index = JSON.parse(fs.readFileSync(path.join(DATASET, "index.json"), "utf-8"));
  const items: BenchItem[] = [];
  for (const meta of Object.values(index.categories as Record<string, { file: string }>)) {
    const data = JSON.parse(fs.readFileSync(path.join(DATASET, meta.file), "utf-8"));
    for (const it of data.items as BenchItem[]) items.push(it);
  }
  return items;
}

function pct(x: number): string {
  return (x * 100).toFixed(1) + "%";
}

function main() {
  const raw = loadItems();
  const items: EvalItem[] = raw.map((it, idx) => synthesizeCandidates(it, 5, 42 + idx));
  console.log(`[calibrate] ${items.length} items, 5 candidates each`);

  const sigmas: Array<number | "median"> = [0.25, 0.35, 0.5, 0.7, 1.0, "median"];
  const minGaps = [0.05, 0.1, 0.15, 0.25];
  const temperatures = [0.3, 0.5, 1.0, 1.5, 2.0];

  type Row = {
    sigma: number | "median";
    minGap: number;
    temperature: number;
    boltzmannAcc: number;
    spectralAcc: number;
    logprobAcc: number;
    freeEnergyAuroc: number;
    cohesionAuroc: number;
    meanCohesion: number;
  };

  const rows: Row[] = [];
  let done = 0;
  const total = sigmas.length * minGaps.length * temperatures.length;

  for (const sigma of sigmas) {
    for (const minGap of minGaps) {
      for (const temperature of temperatures) {
        const results = items.map((it) =>
          evaluateItem(it, { sigma, minGap }, temperature)
        );
        const report = summarize(results);
        const boltzmannAcc =
          report.methods.find((m) => m.name === "boltzmann")?.accuracy ?? 0;
        const spectralAcc =
          report.methods.find((m) => m.name === "spectral_weighted")?.accuracy ?? 0;
        const logprobAcc =
          report.methods.find((m) => m.name === "logprob_weighted")?.accuracy ?? 0;
        const freeEnergyAuroc =
          report.predictive.find((p) => p.metric === "freeEnergy")?.aurocAnyCorrect ?? 0.5;
        const cohesionAuroc =
          report.predictive.find((p) => p.metric === "spectral.cohesion")?.aurocAnyCorrect ??
          0.5;
        const meanCohesion =
          results.reduce((s, r) => s + r.agreement.spectral.cohesion, 0) /
          (results.length || 1);

        rows.push({
          sigma,
          minGap,
          temperature,
          boltzmannAcc,
          spectralAcc,
          logprobAcc,
          freeEnergyAuroc,
          cohesionAuroc,
          meanCohesion,
        });
        done += 1;
        if (done % 20 === 0) console.log(`[calibrate] ${done}/${total}`);
      }
    }
  }

  // Rank by boltzmann accuracy, then freeEnergy AUROC
  rows.sort((a, b) => {
    const d = b.boltzmannAcc - a.boltzmannAcc;
    if (Math.abs(d) > 1e-9) return d;
    return b.freeEnergyAuroc - a.freeEnergyAuroc;
  });

  const date = new Date().toISOString().slice(0, 10);
  const lines: string[] = [];
  lines.push(`# Consensus calibration — ${date} (offline)`);
  lines.push("");
  lines.push("> Synthetic candidates + hashEmbed. Not provider-backed experimental evidence.");
  lines.push("");
  lines.push(`Grid: σ ∈ {${sigmas.join(", ")}} · minGap ∈ {${minGaps.join(", ")}} · T ∈ {${temperatures.join(", ")}}`);
  lines.push(`Evaluations: **${total}** · Items: **${items.length}**`);
  lines.push("");

  lines.push("## Top 15 configurations (by Boltzmann accuracy)");
  lines.push("");
  lines.push("| Rank | σ | minGap | T | Boltzmann acc | Spectral acc | Logprob acc | FE AUROC | Cohesion AUROC | Mean cohesion |");
  lines.push("|------|---|--------|---|---------------|--------------|-------------|---------|----------------|---------------|");
  rows.slice(0, 15).forEach((r, i) => {
    lines.push(
      `| ${i + 1} | ${r.sigma} | ${r.minGap} | ${r.temperature} | ${pct(r.boltzmannAcc)} | ${pct(r.spectralAcc)} | ${pct(r.logprobAcc)} | ${r.freeEnergyAuroc.toFixed(3)} | ${r.cohesionAuroc.toFixed(3)} | ${r.meanCohesion.toFixed(3)} |`
    );
  });
  lines.push("");

  const best = rows[0];
  lines.push("## Recommended defaults (offline optimum)");
  lines.push("");
  lines.push("```ts");
  lines.push(`// spectralConsensus / evaluateItem / computeHybridConfidence`);
  lines.push(`sigma: ${JSON.stringify(best.sigma)},`);
  lines.push(`minGap: ${best.minGap},`);
  lines.push(`boltzmannTemperature: ${best.temperature},`);
  lines.push(`// kernel blend (suggested starting point)`);
  lines.push(`spectralBlend: 0.35,`);
  lines.push("```");
  lines.push("");
  lines.push(
    `Best Boltzmann accuracy **${pct(best.boltzmannAcc)}** at σ=${best.sigma}, minGap=${best.minGap}, T=${best.temperature}.`
  );
  lines.push(
    `Free-energy AUROC at that point: **${best.freeEnergyAuroc.toFixed(3)}** · spectral cohesion AUROC: **${best.cohesionAuroc.toFixed(3)}**.`
  );
  lines.push("");
  lines.push("## Notes");
  lines.push("");
  lines.push("- Re-run with `sourceClass=real` candidates before locking production constants.");
  lines.push("- `spectralBlend` is not swept here; tune on real fusion traces after σ/T are fixed.");
  lines.push("");

  fs.mkdirSync(REPORTS, { recursive: true });
  const outPath = path.join(REPORTS, `consensus-calibration-${date}-offline.md`);
  fs.writeFileSync(outPath, lines.join("\n"), "utf-8");
  console.log(`[calibrate] wrote ${outPath}`);
  console.log(
    `[calibrate] BEST σ=${best.sigma} minGap=${best.minGap} T=${best.temperature} boltzmann=${pct(best.boltzmannAcc)} FE-AUROC=${best.freeEnergyAuroc.toFixed(3)}`
  );
}

main();
