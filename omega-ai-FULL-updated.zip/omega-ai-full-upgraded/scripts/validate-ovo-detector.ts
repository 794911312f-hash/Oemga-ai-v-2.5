/**
 * scripts/validate-ovo-detector.ts
 * =============================================================================
 * MEASURED validation of OVO's detectors on ffmpeg-synthesized clips with faults injected at
 * t = 6 s of a 12 s clip, through the production path (ffmpeg → analyzeVideoBuffer → OVO).
 * Validation seeds (5000+) are disjoint from calibration seeds (90000+).
 *
 * Compared per clip, in the post-onset window (probe frames 13..24):
 *   OLD  S (stationaryRegime=false), J (jitterDetected), M (morphWarning)
 *   NEW  defect detector (ovoDefects.ts) — any channel, and per channel
 * and the false-alarm rate on the same clips' pre-onset window (frames 7..12).
 *
 * Measures detection of known synthetic faults only. It does NOT measure whether a generator
 * improves when controls are applied, nor perceptual quality.
 *
 * Env: OVO_VALIDATION_N (default 30), OVO_CONTENT = smooth | textured | both (default both).
 */
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { analyzeVideoBuffer } from "../src/lib/omega/videoProbe.ts";
import { globalOmegaVideoOptimizer } from "../src/lib/omega/ovoEngine.ts";
import { aggregateControls } from "../src/lib/omega/ovoActuation.ts";
import { CONDS, makeClip, pool, wilson, type Content } from "./lib/ovo-clips.ts";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const N = Number(process.env.OVO_VALIDATION_N ?? 30);
const CONTENTS: Content[] = process.env.OVO_CONTENT === "smooth" ? ["smooth"] : process.env.OVO_CONTENT === "textured" ? ["textured"] : ["smooth", "textured"];
const POST_FROM = 13, PRE_FROM = 7;
const pct = (x: number) => (100 * x).toFixed(0) + "%";

interface Acc { n: number; oldAny: number; S: number; J: number; M: number; newAny: number; defOnly: number; defOnlyPre: number; ch: Record<string, number>; newPre: number; oldPre: number; regenOld: number; regenNew: number }
const blank = (): Acc => ({ n: 0, oldAny: 0, S: 0, J: 0, M: 0, newAny: 0, defOnly: 0, defOnlyPre: 0, ch: { change: 0, local: 0, detailDrop: 0, luma: 0, jitter: 0 }, newPre: 0, oldPre: 0, regenOld: 0, regenNew: 0 });

async function main() {
  const dir = await mkdtemp(join(tmpdir(), "ovo-val-"));
  const acc: Record<string, Acc> = {};
  for (const ct of CONTENTS) for (const c of CONDS) acc[`${ct}/${c.id}`] = blank();

  const jobs = CONTENTS.flatMap((ct) => CONDS.flatMap((c) => Array.from({ length: N }, (_, i) => ({ ct, c, i }))));
  await pool(jobs, 4, async ({ ct, c, i }) => {
    try {
      const probe = await analyzeVideoBuffer(await makeClip(dir, ct, c, 5000 + i * 31), 24);
      const rep = globalOmegaVideoOptimizer.runInferenceOptimizationLoop({ prompt: "validation", frameObservations: probe.frameObservations });
      const A = acc[`${ct}/${c.id}`];
      const post = rep.stepsTrace.filter((s) => s.stepIndex >= POST_FROM);
      const pre = rep.stepsTrace.filter((s) => s.stepIndex >= PRE_FROM && s.stepIndex < POST_FROM);
      const oldCh = (xs: typeof post) => ({ S: xs.some((s) => !s.frame.stationaryRegime), J: xs.some((s) => s.motion.jitterDetected), M: xs.some((s) => s.character.morphWarning) });
      const op = oldCh(post), oq = oldCh(pre);
      A.n++;
      if (op.S || op.J || op.M) A.oldAny++;
      if (op.S) A.S++; if (op.J) A.J++; if (op.M) A.M++;
      if (oq.S || oq.J || oq.M) A.oldPre++;
      if (post.some((s) => s.defect?.alarm)) A.newAny++;
      if (post.some((s) => s.defect?.channels.some((x) => x !== "jitter"))) A.defOnly++;
      if (pre.some((s) => s.defect?.channels.some((x) => x !== "jitter"))) A.defOnlyPre++;
      if (pre.some((s) => s.defect?.alarm)) A.newPre++;
      for (const k of Object.keys(A.ch)) if (post.some((s) => s.defect?.channels.includes(k as any))) A.ch[k]++;
      const base = { cfgScale: 7, numSamplingSteps: 30, motionScore: 4.5 };
      const differs = (a: ReturnType<typeof aggregateControls>) => a.cfgScale !== 7 || a.numSamplingSteps !== 30 || a.motionScore !== 4.5 || a.promptTokens.length > 0;
      // legacy rule: S/J-driven (defect data stripped)
      const legacyRep = { ...rep, stepsTrace: rep.stepsTrace.map((s) => ({ ...s, defect: undefined })) };
      if (rep.summaryMetrics.interventionsTriggered > 0 && differs(aggregateControls(legacyRep as any, base))) A.regenOld++;
      // new rule: defect-detector-driven
      if (rep.summaryMetrics.defectAlarmSteps > 0 && differs(aggregateControls(rep, base))) A.regenNew++;
    } catch (e: any) { console.error(`FAILED ${ct}/${c.id}#${i}: ${e?.message ?? e}`); }
  });
  await rm(dir, { recursive: true, force: true });

  const lines = ["| Content | Condition | n | OLD alarm (S / J / M) | Defect-only alarm | MERGED alarm (95% CI) | channels (chg/loc/det/luma/jit) | MERGED pre-onset FA | regen OLD rule → NEW rule |", "|---|---|---|---|---|---|---|---|---|"];
  const json: any = {};
  for (const ct of CONTENTS) for (const c of CONDS) {
    const A = acc[`${ct}/${c.id}`]; const [lo, hi] = wilson(A.newAny, A.n);
    lines.push(`| ${ct} | ${c.label} | ${A.n} | ${pct(A.oldAny / A.n)} (${pct(A.S / A.n)} / ${pct(A.J / A.n)} / ${pct(A.M / A.n)}) | ${pct(A.defOnly / A.n)} | **${pct(A.newAny / A.n)}** (${pct(lo)}–${pct(hi)}) | ${pct(A.ch.change / A.n)}/${pct(A.ch.local / A.n)}/${pct(A.ch.detailDrop / A.n)}/${pct(A.ch.luma / A.n)}/${pct(A.ch.jitter / A.n)} | ${pct(A.newPre / A.n)} | ${pct(A.regenOld / A.n)} → **${pct(A.regenNew / A.n)}** |`);
    json[`${ct}/${c.id}`] = { n: A.n, oldAny: A.oldAny / A.n, newAny: A.newAny / A.n, defOnly: A.defOnly / A.n, newCi: [lo, hi], newPre: A.newPre / A.n, regenOld: A.regenOld / A.n, regenNew: A.regenNew / A.n, channels: A.ch };
  }
  const d = new Date().toISOString().slice(0, 10);
  const md = [
    "# OVO detector validation (measured, synthetic faults) — old S/J/M vs defect detector vs merged (defect + strict jitter)",
    "",
    `- **Date (UTC):** ${d}`,
    "- **Evidence tier:** measured on synthetic ffmpeg clips; validates DETECTORS only",
    `- **Design:** ${N} clips per cell, 12 s @ 10 fps, 160×90, onset t = 6 s; probe = 16×8 gray (old) and 64×36 gray (new) @ 2 fps; validation seeds disjoint from calibration seeds`,
    "- **Content:** `smooth` = ffmpeg gradients; `textured` = gradients + static noise texture. Neither is natural video.",
    "- **NEW thresholds:** calibrated on 120 clean clips only; the `clean` rows are the held-out false-alarm rate.",
    "",
    ...lines,
    "",
    "Detected = post-onset alarm rate clearly above the `clean` row of the same content (non-overlapping CIs is the conservative reading).",
    "",
  ].join("\n");
  fs.mkdirSync(path.join(ROOT, "docs/reports"), { recursive: true });
  const tag = CONTENTS.length === 2 ? "" : `-${CONTENTS[0]}`;
  const out = path.join(ROOT, "docs/reports", `ovo-detector-validation-${d}${tag}-measured-synthetic.md`);
  fs.writeFileSync(out, md, "utf-8");
  console.log(md); console.log(JSON.stringify(json)); console.log(`\nWrote ${out}`);
}
main().catch((e) => { console.error(e); process.exit(1); });
