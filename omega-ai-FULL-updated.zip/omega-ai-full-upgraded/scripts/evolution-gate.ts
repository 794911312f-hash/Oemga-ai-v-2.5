/**
 * scripts/evolution-gate.ts
 * =============================================================================
 * Evolution Gate — accept/reject promote based on dated benchmark reports
 * =============================================================================
 *
 * Policy (docs/specs/evolution-gate.md + consensus-psi manifest):
 *   - Reject if only offline_fixture reports exist
 *   - Compare latest non-offline report vs previous non-offline
 *   - Fail if accuracy regresses beyond tolerance
 *   - Require minimum item count when configured
 *
 * Usage:
 *   npx tsx scripts/evolution-gate.ts
 *   npx tsx scripts/evolution-gate.ts --tolerance 0.02
 *   npx tsx scripts/evolution-gate.ts --json
 *
 * Exit codes:
 *   0 = PASS (promote allowed under policy)
 *   1 = REJECT
 *   2 = insufficient evidence (no non-offline report)
 */

import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const REPORTS = path.join(ROOT, "docs/reports");
const DATASET_INDEX = path.join(
  ROOT,
  "datasets/omega-benchmark-v1/index.json"
);

interface ParsedReport {
  file: string;
  date: string;
  offline: boolean;
  realCount?: number | null;
  providerBacked?: boolean;
  accuracy: number | null;
  items: number | null;
  evidenceTier: string;
}

function parseArgs(argv: string[]) {
  const json = argv.includes("--json");
  const tIdx = argv.indexOf("--tolerance");
  const tolerance =
    tIdx >= 0 && argv[tIdx + 1] ? Number(argv[tIdx + 1]) : 0.0;
  return { json, tolerance: Number.isFinite(tolerance) ? tolerance : 0 };
}

function listReportFiles(): string[] {
  if (!fs.existsSync(REPORTS)) return [];
  return fs
    .readdirSync(REPORTS)
    .filter(
      (f) =>
        f.startsWith("benchmark-") &&
        f.endsWith(".md") &&
        !f.includes("TEMPLATE")
    )
    .sort();
}

function parseReport(file: string): ParsedReport {
  const text = fs.readFileSync(path.join(REPORTS, file), "utf-8");
  const offline =
    /offline/i.test(file) ||
    /-simulated\.md$/i.test(file) ||
    /offline fixture/i.test(text) ||
    /simulated_no_providers/i.test(text) ||
    (/SIMULATED/i.test(text) && /no live providers/i.test(text)) ||
    /Evidence tier:\*\*.*offline/i.test(text) ||
    /Evidence tier:\*\*.*simulated/i.test(text) ||
    /evidence_tier.*offline/i.test(text);

  let accuracy: number | null = null;
  const accMatch = text.match(
    /\|\s*Accuracy\s*\|\s*([\d.]+)\s*%\s*\((\d+)\s*\/\s*(\d+)\)/i
  );
  if (accMatch) {
    accuracy = Number(accMatch[1]) / 100;
  } else {
    const frac = text.match(/Accuracy[^\d]*(\d+)\s*\/\s*(\d+)/i);
    if (frac) accuracy = Number(frac[1]) / Number(frac[2]);
  }

  let items: number | null = null;
  const itemsMatch = text.match(/\*\*Items:\*\*\s*(\d+)/i);
  if (itemsMatch) items = Number(itemsMatch[1]);
  else if (accMatch) items = Number(accMatch[3]);

  const dateMatch = file.match(/benchmark-(\d{4}-\d{2}-\d{2})/);
  const date = dateMatch ? dateMatch[1] : "unknown";

  const tierMatch = text.match(/\*\*Evidence tier:\*\*\s*(.+)/i);
  const evidenceTier = tierMatch ? tierMatch[1].trim() : offline ? "offline_fixture" : "unknown";
  const realMatch = text.match(/sourceClass real\/mixed\/sim\+fail:\*\*?\s*(\d+)/i)
    || text.match(/real\/mixed\/sim\+fail[:\s]*(\d+)/i)
    || text.match(/\breal[=:]\s*(\d+)/i);
  const realCount = realMatch ? Number(realMatch[1]) : null;
  // simulated / offline already offline=true; also treat zero-real non-offline as insufficient
  const providerBacked = !offline && realCount != null && realCount > 0;

  return { file, date, offline, accuracy, items, evidenceTier, realCount, providerBacked };
}

function expectedMinItems(): number {
  try {
    const idx = JSON.parse(fs.readFileSync(DATASET_INDEX, "utf-8"));
    return Number(idx.total_items) || 50;
  } catch {
    return 50;
  }
}

function main() {
  const { json, tolerance } = parseArgs(process.argv.slice(2));
  const files = listReportFiles();
  const parsed = files.map(parseReport);
  const nonOffline = parsed.filter((r) => !r.offline);
  const offline = parsed.filter((r) => r.offline);
  const minItems = expectedMinItems();

  const result: {
    decision: "PASS" | "REJECT" | "INSUFFICIENT";
    reason: string;
    latest?: ParsedReport;
    previous?: ParsedReport;
    offlineCount: number;
    nonOfflineCount: number;
    minItems: number;
    tolerance: number;
  } = {
    decision: "INSUFFICIENT",
    reason: "",
    offlineCount: offline.length,
    nonOfflineCount: nonOffline.length,
    minItems,
    tolerance,
  };

  if (nonOffline.length === 0) {
    result.decision = "INSUFFICIENT";
    result.reason =
      "No non-offline benchmark report found. Offline fixtures cannot authorize promote (manifest: reject_if_offline_only).";
  } else {
    // sort by date then filename
    nonOffline.sort((a, b) => a.file.localeCompare(b.file));
    const latest = nonOffline[nonOffline.length - 1];
    result.latest = latest;

    if (latest.providerBacked === false || (latest.realCount != null && latest.realCount < 1)) {
      result.decision = "INSUFFICIENT";
      result.reason = `Report ${latest.file} has no sourceClass=real items — not provider-backed.`;
    } else if (latest.accuracy == null) {
      result.decision = "REJECT";
      result.reason = `Latest report ${latest.file} has no parseable Accuracy field.`;
    } else if (latest.items != null && latest.items < minItems) {
      result.decision = "REJECT";
      result.reason = `Latest report items=${latest.items} < required minimum_items=${minItems}.`;
    } else if (nonOffline.length >= 2) {
      const previous = nonOffline[nonOffline.length - 2];
      result.previous = previous;
      if (previous.accuracy != null) {
        const delta = latest.accuracy - previous.accuracy;
        if (delta < -tolerance) {
          result.decision = "REJECT";
          result.reason = `Accuracy regression: ${(previous.accuracy * 100).toFixed(1)}% → ${(latest.accuracy * 100).toFixed(1)}% (Δ=${(delta * 100).toFixed(1)}pp, tolerance=${(tolerance * 100).toFixed(1)}pp).`;
        } else {
          result.decision = "PASS";
          result.reason = `Non-regression vs ${previous.file}: ${(previous.accuracy * 100).toFixed(1)}% → ${(latest.accuracy * 100).toFixed(1)}%.`;
        }
      } else {
        result.decision = "PASS";
        result.reason = `Latest non-offline report ${latest.file} accepted (previous lacked accuracy).`;
      }
    } else {
      result.decision = "PASS";
      result.reason = `First non-offline report ${latest.file} accuracy=${(
        (latest.accuracy ?? 0) * 100
      ).toFixed(1)}% — baseline established.`;
    }
  }

  // Persist for hybridSelfEvolution.promoteIndividual()
  try {
    const statusPath = path.join(REPORTS, ".evolution-gate-status.json");
    let sha256: string | null = null;
    if (result.latest?.file) {
      try {
        const body = fs.readFileSync(path.join(REPORTS, result.latest.file), "utf-8");
        sha256 = crypto.createHash("sha256").update(body).digest("hex");
      } catch { /* ignore */ }
    }
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
    fs.writeFileSync(
      statusPath,
      JSON.stringify(
        {
          decision: result.decision,
          reason: result.reason,
          at: new Date().toISOString(),
          latest: result.latest?.file ?? null,
          sha256,
          expiresAt,
        },
        null,
        2
      ),
      "utf-8"
    );
  } catch (e) {
    console.warn("Could not write .evolution-gate-status.json", e);
  }

  if (json) {
    console.log(JSON.stringify(result, null, 2));
  } else {
    console.log(`Evolution Gate: ${result.decision}`);
    console.log(`Reason: ${result.reason}`);
    console.log(
      `Reports: offline=${result.offlineCount}, non-offline=${result.nonOfflineCount}`
    );
    if (result.latest) {
      console.log(
        `Latest: ${result.latest.file} acc=${result.latest.accuracy} items=${result.latest.items}`
      );
    }
  }

  if (result.decision === "PASS") process.exit(0);
  if (result.decision === "INSUFFICIENT") process.exit(2);
  process.exit(1);
}

main();
