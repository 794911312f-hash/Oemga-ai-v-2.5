/**
 * Calibrates DEFECT_THRESHOLDS on CLEAN clips only (seeds 90000+, disjoint from validation seeds 5000+).
 * Rule: per channel, tau = max(3, 1.15 × the 97th percentile of per-clip maximum z over warm frames).
 * Prints the values to paste into src/lib/omega/ovoDefects.ts.
 */
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { analyzeVideoBuffer } from "../src/lib/omega/videoProbe.ts";
import { OmegaDefectDetector } from "../src/lib/omega/ovoDefects.ts";
import { globalOmegaVideoOptimizer } from "../src/lib/omega/ovoEngine.ts";
import { CONDS, makeClip, pool, type Content } from "./lib/ovo-clips.ts";

const N = Number(process.env.OVO_CAL_N ?? 60);
const clean = CONDS.find((c) => c.id === "clean")!;
const q = (xs: number[], p: number) => { const s = [...xs].sort((a, b) => a - b); return s[Math.min(s.length - 1, Math.floor(p * s.length))]; };

async function main() {
  const dir = await mkdtemp(join(tmpdir(), "ovo-cal-"));
  const maxz: Record<string, number[]> = { change: [], local: [], detailDrop: [], luma: [] };
const minPsi: number[] = [], maxD: number[] = [];
  const jobs = (["smooth", "textured"] as Content[]).flatMap((c) => Array.from({ length: N }, (_, i) => ({ c, seed: 90000 + i * 17 })));
  await pool(jobs, 4, async ({ c, seed }) => {
    const probe = await analyzeVideoBuffer(await makeClip(dir, c, clean, seed), 24);
    const det = new OmegaDefectDetector({ change: 1e9, local: 1e9, detailDrop: 1e9, luma: 1e9 });
    const m = probe.frameObservations.map((o) => det.evaluate(o.defect!)).filter((x) => x.warm);
    maxz.change.push(Math.max(...m.map((x) => x.zChange)));
    maxz.local.push(Math.max(...m.map((x) => x.zLocal)));
    maxz.detailDrop.push(Math.max(...m.map((x) => x.zDetailDrop)));
    maxz.luma.push(Math.max(...m.map((x) => x.zLuma)));
    const rep = globalOmegaVideoOptimizer.runInferenceOptimizationLoop({ prompt: "cal", frameObservations: probe.frameObservations });
    const warmSteps = rep.stepsTrace.filter((st) => st.stepIndex >= 7);
    minPsi.push(Math.min(...warmSteps.map((st) => st.motion.localConfidencePsi)));
    maxD.push(Math.max(...warmSteps.map((st) => Math.abs(st.motion.pidDerivativeTermD))));
  });
  await rm(dir, { recursive: true, force: true });
  const out: Record<string, number> = {};
  for (const k of Object.keys(maxz)) {
    const p97 = q(maxz[k], 0.97);
    out[k] = Number(Math.max(3, 1.15 * p97).toFixed(2));
    console.log(`${k.padEnd(11)} clips=${maxz[k].length} median=${q(maxz[k], 0.5).toFixed(2)} p97=${p97.toFixed(2)} max=${Math.max(...maxz[k]).toFixed(2)} → tau=${out[k]}`);
  }
  // jitter: strictly below the legacy 0.55 / above 0.35, and clear of the clean-clip tails
  const psiTau = Number(Math.min(0.55, 0.85 * q(minPsi, 0.03)).toFixed(3));
  const dTau = Number(Math.max(0.35, 1.15 * q(maxD, 0.97)).toFixed(3));
  console.log(`jitter psi: min-per-clip median=${q(minPsi, 0.5).toFixed(3)} p3=${q(minPsi, 0.03).toFixed(3)} → psi<${psiTau}`);
  console.log(`jitter |D|: max-per-clip median=${q(maxD, 0.5).toFixed(3)} p97=${q(maxD, 0.97).toFixed(3)} → |D|>${dTau}`);
  console.log(JSON.stringify({ ...out, jitterPsi: psiTau, jitterD: dTau }));
}
main().catch((e) => { console.error(e); process.exit(1); });
