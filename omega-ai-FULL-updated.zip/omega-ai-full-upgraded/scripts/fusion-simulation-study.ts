/**
 * scripts/fusion-simulation-study.ts
 * =============================================================================
 * Controlled SIMULATION of fusion policies with ground truth that is independent
 * of the geometry (unlike compare-fusion-policies.ts, where "truth" is defined as
 * the candidate nearest the centroid — the very thing Ψ/RRF select).
 *
 * Model of the world (all assumptions, none measured from real LLMs):
 *   - K answer options per question; ground truth label is random.
 *   - M models; model i answers correctly with probability p_i.
 *   - Wrong answers: uniform over the wrong options ("independent" errors) or, with
 *     probability rho, a shared distractor common to all models ("correlated" errors).
 *   - A response is embedded as prototype[label] + Gaussian noise (phrasing noise).
 *
 * Output: docs/reports/fusion-simulation-study-<date>-simulated.md  (+ JSON on stdout)
 * Evidence tier: SIMULATION. Says how the policies behave under stated assumptions;
 * says nothing about real LLM performance.
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { clipExpPsi, cosine, normalize } from "../src/lib/omega/math.ts";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

function mulberry32(a: number) {
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function gauss(r: () => number) {
  const u = Math.max(1e-12, r()), v = r();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

const argsortDesc = (xs: number[]) => xs.map((s, i) => [s, i] as const).sort((a, b) => b[0] - a[0]).map(([, i]) => i);
const centroid = (vs: number[][]) => vs[0].map((_, d) => vs.reduce((a, v) => a + v[d], 0) / vs.length);

// --- policies: same logic as scripts/compare-fusion-policies.ts -------------------
function rankPsi(vs: number[][]) {
  const c = centroid(vs);
  const delta = vs.map((v) => 1 - cosine(v, c));
  const mean = delta.reduce((a, b) => a + b, 0) / delta.length;
  const sigma = Math.sqrt(delta.reduce((a, x) => a + (x - mean) ** 2, 0) / delta.length);
  return argsortDesc(delta.map((x) => clipExpPsi(x, sigma)));
}
function rankRrf(vs: number[][]) {
  const c = centroid(vs);
  const order = argsortDesc(vs.map((v) => cosine(v, c)));
  const rrf = new Array(vs.length).fill(0);
  order.forEach((idx, rank) => (rrf[idx] += 1 / (60 + rank + 1)));
  return argsortDesc(rrf);
}
function rankBorda(vs: number[][]) {
  const n = vs.length, pts = new Array(n).fill(0);
  for (let i = 0; i < n; i++) {
    const sims = vs.map((v, j) => (i === j ? -Infinity : cosine(vs[i], v)));
    argsortDesc(sims).forEach((idx, rank) => { if (Number.isFinite(sims[idx])) pts[idx] += n - 1 - rank; });
  }
  return argsortDesc(pts);
}
function rankOrthantMajority(vs: number[][]) {
  const labels = vs.map((v) => v.map((x) => (x >= 0 ? 1 : 0)).join(""));
  const cnt = new Map<string, number>();
  labels.forEach((l) => cnt.set(l, (cnt.get(l) || 0) + 1));
  return argsortDesc(labels.map((l) => cnt.get(l) || 0));
}

interface Scenario { name: string; p: number[]; rho: number; sigma: number }
const SCENARIOS: Scenario[] = [
  { name: "S1 five equal models p=0.70, independent errors", p: [0.7, 0.7, 0.7, 0.7, 0.7], rho: 0, sigma: 0.35 },
  { name: "S2 one strong (0.90) + four weak (0.55), independent", p: [0.9, 0.55, 0.55, 0.55, 0.55], rho: 0, sigma: 0.35 },
  { name: "S3 five equal models p=0.70, correlated errors rho=0.7", p: [0.7, 0.7, 0.7, 0.7, 0.7], rho: 0.7, sigma: 0.35 },
  { name: "S4 one strong (0.90) + four weak (0.50), correlated rho=0.7", p: [0.9, 0.5, 0.5, 0.5, 0.5], rho: 0.7, sigma: 0.35 },
  { name: "S5 five equal models p=0.70, independent, high phrasing noise", p: [0.7, 0.7, 0.7, 0.7, 0.7], rho: 0, sigma: 1.2 },
];

const POLICIES = ["random", "avg_single", "best_single", "majority_label", "orthant_majority", "borda", "rrf", "psi"] as const;
type PolicyName = (typeof POLICIES)[number];

function runReplicate(sc: Scenario, seed: number, Q = 200, K = 4, dim = 16) {
  const r = mulberry32(seed);
  const protos = Array.from({ length: K }, () => normalize(Array.from({ length: dim }, () => gauss(r))));
  const M = sc.p.length;
  const hits: Record<PolicyName, number> = Object.fromEntries(POLICIES.map((p) => [p, 0])) as any;
  const single = new Array(M).fill(0);
  let psiRrfAgree = 0;

  for (let q = 0; q < Q; q++) {
    const truth = Math.floor(r() * K);
    const shared = (truth + 1 + Math.floor(r() * (K - 1))) % K; // common misconception
    const labels: number[] = [];
    for (let m = 0; m < M; m++) {
      if (r() < sc.p[m]) labels.push(truth);
      else if (r() < sc.rho) labels.push(shared);
      else labels.push((truth + 1 + Math.floor(r() * (K - 1))) % K);
    }
    labels.forEach((l, m) => { if (l === truth) single[m]++; });
    // Shuffle candidate order per question: policies break ties by index, and index 0 is the
    // strong model in S2/S4 — without this a tie-break would leak model identity into the result.
    for (let i = M - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [labels[i], labels[j]] = [labels[j], labels[i]]; }
    const vecs = labels.map((l) => protos[l].map((x) => x + sc.sigma * gauss(r) / Math.sqrt(dim)));

    const pick = (order: number[]) => labels[order[0]] === truth;
    hits.random += labels[Math.floor(r() * M)] === truth ? 1 : 0;
    const counts = new Array(K).fill(0); labels.forEach((l) => counts[l]++);
    const maxC = Math.max(...counts);
    const tied = counts.map((c, i) => (c === maxC ? i : -1)).filter((i) => i >= 0);
    hits.majority_label += tied[Math.floor(r() * tied.length)] === truth ? 1 : 0; // random tie-break
    hits.orthant_majority += pick(rankOrthantMajority(vecs)) ? 1 : 0;
    hits.borda += pick(rankBorda(vecs)) ? 1 : 0;
    const rrf = rankRrf(vecs), psi = rankPsi(vecs);
    hits.rrf += pick(rrf) ? 1 : 0;
    hits.psi += pick(psi) ? 1 : 0;
    if (rrf[0] === psi[0]) psiRrfAgree++;
  }
  hits.avg_single = single.reduce((a, b) => a + b, 0) / M;
  hits.best_single = Math.max(...single); // oracle: best model chosen in hindsight (upper bound for "pick one model")
  const acc = Object.fromEntries(POLICIES.map((p) => [p, hits[p] / Q])) as Record<PolicyName, number>;
  return { acc, psiRrfAgree: psiRrfAgree / Q };
}

const mean = (xs: number[]) => xs.reduce((a, b) => a + b, 0) / xs.length;
const sd = (xs: number[]) => { const m = mean(xs); return Math.sqrt(xs.reduce((a, x) => a + (x - m) ** 2, 0) / (xs.length - 1)); };
const ci95 = (xs: number[]) => 1.96 * sd(xs) / Math.sqrt(xs.length);

const REPS = 100;
const rows: string[] = [];
const json: any = {};
for (const sc of SCENARIOS) {
  const reps = Array.from({ length: REPS }, (_, i) => runReplicate(sc, 1000 + i));
  const col = (p: PolicyName) => reps.map((x) => x.acc[p]);
  json[sc.name] = {};
  rows.push(`### ${sc.name}`, "", "| Policy | Accuracy % (mean ± 95% CI) | Δ vs label-majority (paired) |", "|---|---|---|");
  const base = col("majority_label");
  for (const p of POLICIES) {
    const c = col(p);
    const diff = c.map((x, i) => x - base[i]);
    const dtxt = p === "majority_label" ? "—" : `${(100 * mean(diff)).toFixed(2)} ± ${(100 * ci95(diff)).toFixed(2)}`;
    rows.push(`| ${p} | ${(100 * mean(c)).toFixed(2)} ± ${(100 * ci95(c)).toFixed(2)} | ${dtxt} |`);
    json[sc.name][p] = { mean: mean(c), ci95: ci95(c), diffVsMajority: mean(diff), diffCi95: ci95(diff) };
  }
  const agree = mean(reps.map((x) => x.psiRrfAgree));
  rows.push("", `Ψ and RRF choose the same top candidate in ${(100 * agree).toFixed(2)}% of questions.`, "");
  json[sc.name].psiRrfAgreement = agree;
}

const d = new Date().toISOString().slice(0, 10);
const md = [
  "# Fusion simulation study",
  "",
  `- **Date (UTC):** ${d}`,
  `- **Evidence tier:** simulation (assumptions below; NOT real-LLM evidence)`,
  `- **Design:** ${REPS} replicates × 200 questions × K=4 options × M=5 models, seeds 1000..${1000 + REPS - 1}`,
  "- **Truth:** independent of the embedding geometry (label drawn first; embedding = prototype + noise)",
  "- `best_single` is an oracle chosen in hindsight; `majority_label` needs exact-answer matching (MCQ/short answers).",
  "- Policy code mirrors scripts/compare-fusion-policies.ts. Candidate order is shuffled per question (ties otherwise leak model identity).",
  "",
  ...rows,
  "## Reading guide",
  "",
  "Accuracy differences smaller than the CI are noise. Results hold only under the stated generative model.",
  "",
].join("\n");
fs.mkdirSync(path.join(ROOT, "docs/reports"), { recursive: true });
const out = path.join(ROOT, "docs/reports", `fusion-simulation-study-${d}-simulated.md`);
fs.writeFileSync(out, md, "utf-8");
console.log(md);
console.log(`\nWrote ${out}`);
