/**
 * Closed Math+CAS product-path benchmark.
 *
 * Executive scoring only (numbers / normalized expressions) — not contains_any.
 *
 *   npx tsx scripts/run-math-cas-benchmark.ts
 *   npx tsx scripts/run-math-cas-benchmark.ts --offline
 *
 * Offline mode scores gold_answer strings (harness self-check).
 * Live mode POSTs to /api/omega/complete when OMEGA_BENCH_BASE_URL is set;
 * otherwise falls back to offline gold (and records mode=offline_fixture).
 */

import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const DATA = path.join(ROOT, "datasets/omega-math-cas-v1/items.json");
const REPORT_DIR = path.join(ROOT, "docs/reports");

type Expect =
  | { type: "exact_number"; value: number; tol?: number }
  | { type: "numeric_close"; value: number; abs_tol?: number; rel_tol?: number }
  | { type: "expression_normalized"; must_include?: string[]; any_of?: string[]; must_not?: string[] }
  | { type: "exact_string"; value: string };

type Item = {
  id: string;
  question: string;
  expect: Expect;
  gold_answer: string;
};

type Dataset = {
  name: string;
  version: string;
  items: Item[];
};

const ARABIC_DIGITS = "٠١٢٣٤٥٦٧٨٩";
const PERSIAN_DIGITS = "۰۱۲۳۴۵۶۷۸۹";

function normalizeDigits(s: string): string {
  let out = "";
  for (const ch of s) {
    const a = ARABIC_DIGITS.indexOf(ch);
    if (a >= 0) {
      out += String(a);
      continue;
    }
    const p = PERSIAN_DIGITS.indexOf(ch);
    if (p >= 0) {
      out += String(p);
      continue;
    }
    out += ch;
  }
  return out;
}

function normalizeExpr(s: string): string {
  return normalizeDigits(s)
    .toLowerCase()
    .replace(/²/g, "^2")
    .replace(/³/g, "^3")
    .replace(/\*\*/g, "^")
    .replace(/\s+/g, "")
    .replace(/×/g, "*")
    .replace(/÷/g, "/");
}

/** Extract first plausible number from free text */
function extractNumber(text: string): number | null {
  const t = normalizeDigits(text).replace(/,/g, "");
  const m = t.match(/[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?/);
  if (!m) return null;
  const n = Number(m[0]);
  return Number.isFinite(n) ? n : null;
}

function scoreAnswer(answer: string, expect: Expect): { pass: boolean; detail: string } {
  const text = (answer || "").trim();
  if (!text) return { pass: false, detail: "empty answer" };

  if (expect.type === "exact_string") {
    const ok =
      normalizeDigits(text).trim().toLowerCase() ===
      normalizeDigits(expect.value).trim().toLowerCase();
    return { pass: ok, detail: ok ? "exact_string" : `got=${text.slice(0, 80)}` };
  }

  if (expect.type === "exact_number") {
    const n = extractNumber(text);
    if (n === null) return { pass: false, detail: "no number parsed" };
    const tol = expect.tol ?? 1e-6;
    const ok = Math.abs(n - expect.value) <= tol;
    return { pass: ok, detail: ok ? `n=${n}` : `n=${n} want=${expect.value}` };
  }

  if (expect.type === "numeric_close") {
    const n = extractNumber(text);
    if (n === null) return { pass: false, detail: "no number parsed" };
    const absTol = expect.abs_tol ?? 0;
    const relTol = expect.rel_tol ?? 0;
    const ok =
      Math.abs(n - expect.value) <= absTol ||
      Math.abs(n - expect.value) <= relTol * Math.max(1, Math.abs(expect.value));
    return { pass: ok, detail: ok ? `n=${n}` : `n=${n} want≈${expect.value}` };
  }

  if (expect.type === "expression_normalized") {
    const norm = normalizeExpr(text);
    if (expect.must_not) {
      for (const bad of expect.must_not) {
        if (norm.includes(normalizeExpr(bad))) {
          return { pass: false, detail: `must_not:${bad}` };
        }
      }
    }
    if (expect.must_include) {
      for (const req of expect.must_include) {
        if (!norm.includes(normalizeExpr(req))) {
          return { pass: false, detail: `missing:${req}` };
        }
      }
    }
    if (expect.any_of && expect.any_of.length > 0) {
      const hit = expect.any_of.some((c) => norm.includes(normalizeExpr(c)));
      if (!hit) return { pass: false, detail: `none of any_of matched; norm=${norm.slice(0, 60)}` };
    }
    return { pass: true, detail: "expression_ok" };
  }

  return { pass: false, detail: "unknown expect type" };
}

async function fetchLiveAnswer(question: string, baseUrl: string): Promise<string | null> {
  try {
    const res = await fetch(`${baseUrl.replace(/\/$/, "")}/api/omega/complete`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question, userId: "math-cas-bench" }),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as any;
    return (
      data?.result?.answer ||
      data?.result?.finalText ||
      data?.answer ||
      data?.text ||
      null
    );
  } catch {
    return null;
  }
}

async function main() {
  const offline = process.argv.includes("--offline");
  const baseUrl = process.env.OMEGA_BENCH_BASE_URL || "";
  const raw = JSON.parse(fs.readFileSync(DATA, "utf8")) as Dataset;

  const rows: {
    id: string;
    pass: boolean;
    detail: string;
    mode: string;
    answerPreview: string;
  }[] = [];

  for (const item of raw.items) {
    let answer: string;
    let mode: string;
    if (!offline && baseUrl) {
      const live = await fetchLiveAnswer(item.question, baseUrl);
      if (live) {
        answer = live;
        mode = "live_api";
      } else {
        answer = item.gold_answer;
        mode = "offline_fixture_fallback";
      }
    } else {
      answer = item.gold_answer;
      mode = "offline_fixture";
    }
    const { pass, detail } = scoreAnswer(answer, item.expect);
    rows.push({
      id: item.id,
      pass,
      detail,
      mode,
      answerPreview: answer.slice(0, 120).replace(/\n/g, " "),
    });
  }

  const passed = rows.filter((r) => r.pass).length;
  const total = rows.length;
  const accuracy = total ? passed / total : 0;
  const day = new Date().toISOString().slice(0, 10);
  const suffix = offline || !baseUrl ? "offline" : "live";
  fs.mkdirSync(REPORT_DIR, { recursive: true });
  const reportPath = path.join(REPORT_DIR, `math-cas-benchmark-${day}-${suffix}.md`);

  const md = [
    `# Math+CAS product-path benchmark`,
    ``,
    `- dataset: \`${raw.name}\` v${raw.version}`,
    `- date: ${day}`,
    `- mode: **${suffix}**`,
    `- accuracy: **${passed}/${total} = ${(accuracy * 100).toFixed(1)}%**`,
    `- scorer: executive (exact_number / numeric_close / expression_normalized) — not contains_any`,
    `- Ψ note: this report does **not** treat Ψ as P(correct); only task accuracy is claimed`,
    ``,
    `| id | pass | mode | detail |`,
    `|----|------|------|--------|`,
    ...rows.map(
      (r) =>
        `| ${r.id} | ${r.pass ? "✅" : "❌"} | ${r.mode} | ${r.detail.replace(/\|/g, "/")} |`,
    ),
    ``,
    `## Honesty`,
    ``,
    `- Offline run validates the scorer against gold answers (harness integrity).`,
    `- Live run requires a running server + auth for protected routes; failures fall back to gold and are marked.`,
    `- Do not cite this accuracy as general LLM capability without \`--live\` and a fixed model list.`,
    ``,
  ].join("\n");

  fs.writeFileSync(reportPath, md, "utf8");
  console.log(md);
  console.log(`\nWrote ${reportPath}`);
  // Exit non-zero if offline gold fails (scorer/data bug)
  if ((offline || !baseUrl) && passed < total) {
    process.exitCode = 1;
  }
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
