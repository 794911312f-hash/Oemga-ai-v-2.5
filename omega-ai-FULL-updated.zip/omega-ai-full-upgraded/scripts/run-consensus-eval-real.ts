/**
 * scripts/run-consensus-eval-real.ts
 * =============================================================================
 * Run consensusEval on candidates collected by collect-real-candidates.ts.
 * Produces docs/reports/consensus-eval-YYYY-MM-DD-run.md only if ≥1 real candidate
 * exists per evaluated item threshold.
 *
 * Usage:
 *   npx tsx scripts/run-consensus-eval-real.ts
 *   npx tsx scripts/run-consensus-eval-real.ts --input datasets/real-candidates/candidates-2026-10-18.jsonl
 */

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  evaluateItem,
  summarize,
  type EvalItem,
  type CandidateAnswer,
  type GoldExpect,
} from "../src/lib/omega/consensusEval.ts";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const DEFAULT_DIR = path.join(ROOT, "datasets/real-candidates");
const REPORTS = path.join(ROOT, "docs/reports");

interface CollectedRow {
  id: string;
  category: string;
  question: string;
  expect: GoldExpect;
  candidates: Array<{
    modelId: string;
    text: string;
    logprob?: number;
    sourceClass: string;
  }>;
}

function latestJsonl(): string | null {
  if (!fs.existsSync(DEFAULT_DIR)) return null;
  const files = fs
    .readdirSync(DEFAULT_DIR)
    .filter((f) => f.startsWith("candidates-") && f.endsWith(".jsonl"))
    .sort();
  return files.length ? path.join(DEFAULT_DIR, files[files.length - 1]) : null;
}

function pct(x: number) {
  return (x * 100).toFixed(1) + "%";
}
function fmt(x: number, d = 3) {
  return x.toFixed(d);
}

function main() {
  const args = process.argv.slice(2);
  let input = latestJsonl();
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "--input" && args[i + 1]) input = path.resolve(args[++i]);
  }
  if (!input || !fs.existsSync(input)) {
    console.error("[consensus-eval-real] No input JSONL. Run collect-real-candidates.ts first.");
    process.exit(2);
  }

  const lines = fs.readFileSync(input, "utf-8").trim().split("\n").filter(Boolean);
  const rows: CollectedRow[] = lines.map((l) => JSON.parse(l));

  const items: EvalItem[] = [];
  let skippedNoReal = 0;
  for (const row of rows) {
    const realCands = row.candidates.filter((c) => c.sourceClass === "real" && c.text.trim());
    if (realCands.length < 2) {
      skippedNoReal += 1;
      continue;
    }
    const candidates: CandidateAnswer[] = realCands.map((c, i) => ({
      id: `${row.id}-${c.modelId}-${i}`,
      text: c.text,
      modelId: c.modelId,
      logprob: c.logprob,
    }));
    items.push({
      id: row.id,
      category: row.category,
      question: row.question,
      expect: row.expect,
      candidates,
    });
  }

  console.log(
    `[consensus-eval-real] input=${input} items_usable=${items.length} skipped_no_real=${skippedNoReal}`
  );
  if (items.length === 0) {
    console.error("[consensus-eval-real] No items with ≥2 real candidates. Aborting (no *-run report).");
    process.exit(3);
  }

  const results = items.map((it) => evaluateItem(it));
  const report = summarize(results);
  const date = new Date().toISOString().slice(0, 10);

  const linesOut: string[] = [];
  linesOut.push(`# Consensus Evaluation Report — ${date} (run)`);
  linesOut.push("");
  linesOut.push("> **Evidence tier: experimental_provider** — candidates from real API providers.");
  linesOut.push(`> Source: \`${path.relative(ROOT, input)}\``);
  linesOut.push(`> Items with ≥2 real candidates: **${items.length}** (skipped ${skippedNoReal}).`);
  linesOut.push("");
  linesOut.push("## Aggregator accuracy ± SE (Wilson 95% CI)");
  linesOut.push("");
  linesOut.push("| Method | Accuracy ± SE | 95% CI | n |");
  linesOut.push("|--------|---------------|--------|---|");
  for (const m of report.methods) {
    linesOut.push(
      `| \`${m.name}\` | ${pct(m.accuracy)} ± ${pct(m.se)} | [${pct(m.ci95.low)}, ${pct(m.ci95.high)}] | ${m.nCorrect}/${m.n} |`
    );
  }
  linesOut.push("");
  linesOut.push("## McNemar vs majority");
  linesOut.push("");
  linesOut.push("| A vs B | Δacc | n10 | n01 | χ² | p |");
  linesOut.push("|--------|------|-----|-----|-----|---|");
  for (const t of report.pairedTests.filter((x) => x.methodB === "majority")) {
    const p =
      t.pValue === null ? "n/a" : t.pValue < 0.001 ? "<0.001" : t.pValue.toFixed(3);
    linesOut.push(
      `| \`${t.methodA}\` vs majority | ${pct(t.accuracyDelta)} | ${t.n10} | ${t.n01} | ${fmt(t.chi2)} | ${p} |`
    );
  }
  linesOut.push("");
  linesOut.push("## Predictive AUROC");
  linesOut.push("");
  linesOut.push("| Metric | AUROC |");
  linesOut.push("|--------|-------|");
  for (const p of report.predictive) {
    linesOut.push(`| \`${p.metric}\` | ${fmt(p.aurocAnyCorrect)} |`);
  }
  linesOut.push("");

  fs.mkdirSync(REPORTS, { recursive: true });
  const outPath = path.join(REPORTS, `consensus-eval-${date}-run.md`);
  fs.writeFileSync(outPath, linesOut.join("\n"));
  console.log(`[consensus-eval-real] wrote ${outPath}`);
}

main();
